#include "StdAfx.h"
#include "Transform.h"
#include "hc3dutil.h"


pa::CTransform::CTransform(void)
{
	double ftemp[pa::AXIS_NUM] = {0.0, 0.0, 0.0, 0.0, 0.0};
	SetOffset( ftemp );
}

pa::CTransform::~CTransform(void)
{
}

// ���ο� Offset ���� �����ϰ�, ���� ����� ���� �Ѵ� 
void pa::CTransform::SetOffset( double fOffset[pa::AXIS_NUM] )
{
	for( int i = 0; i<pa::AXIS_NUM; i++ ) 
	{
		fOffset_[i]		= fOffset[i];
		fPosition_[i]	= 0.0;
	}
	
	bG28_ = FALSE;
	bG54_ = FALSE;
}

// nc-file�� ���� ������ �޾�, ��ȯ�� ��ǥ�� �� ���� ���� �Ѵ� 
void pa::CTransform::TRANSFORM( char *gcode, int buf_size )
{
	char	szToken[16][32];			// token�� 32byte, 16�� ���� ��� ���� = 512 byte
	char	sztemp[64];	
	int		len = strlen(gcode) - 2;	// -2 is '\r\n'
	int		index = 0;
	int		g_val;
	int		token_index = 0;
	char	*ptrAxis[pa::AXIS_NUM] = { NULL, NULL, NULL, NULL, NULL };

	BOOL	bCalc = FALSE;

	bG28_ = FALSE;

	//////////////////////////////////////////////////////////////////////////
	// 1. g-code �Ľ�
	//////////////////////////////////////////////////////////////////////////

	memset( (void*)szToken, 0, sizeof(char)*16*32 );
	index = 0;
	memset( (void*)sztemp, 0, sizeof(char)*64 );
	
	for( int i = 0; i<len; i++ )
	{
		sztemp[index++] = gcode[i];

		if( gcode[i]==' ' || i>=len-1 )
		{
			memcpy((void*)szToken[token_index], sztemp, strlen(sztemp) );

			sztemp[index] = NULL;
			switch( sztemp[0] )
			{
			case 'x':
			case 'X':
				fPosition_[pa::AXIS_X] = (double)atof(sztemp+1);
				ptrAxis[pa::AXIS_X] = szToken[token_index];
				bCalc = TRUE;
				break;
			case 'y':
			case 'Y':
				fPosition_[pa::AXIS_Y] = (double)atof(sztemp+1);
				ptrAxis[pa::AXIS_Y] = szToken[token_index];
				bCalc = TRUE;
				break;
			case 'z':
			case 'Z':
				fPosition_[pa::AXIS_Z] = (double)atof(sztemp+1);
				ptrAxis[pa::AXIS_Z] = szToken[token_index];
				bCalc = TRUE;
				break;
			case 'a':
			case 'A':
				fPosition_[pa::AXIS_A] = (double)atof(sztemp+1);
				// ptrAxis[pa::AXIS_A] = szToken[token_index];
				bCalc = TRUE;
				break;
			case 'b':
			case 'B':
				fPosition_[pa::AXIS_B] = (double)atof(sztemp+1);
				// ptrAxis[pa::AXIS_B] = szToken[token_index];
				bCalc = TRUE;
				break;

			case 'g':
			case 'G':
				g_val = (int)atoi(sztemp+1);
				if( g_val == 28 )
				{
					bG28_ = TRUE;
				}
				else if( g_val == 53 ) 
				{
					bG54_ = FALSE;
				}
				else if( g_val >= 54 && g_val <= 59 )
				{
					bG54_ = TRUE;
				}
			}

			token_index++;
			index = 0;
			memset( (void*)sztemp, 0, sizeof(char)*64 );
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// 2. ��ǥ ��ȯ 
	//////////////////////////////////////////////////////////////////////////
	
	if( bCalc==TRUE && bG54_==TRUE && bG28_==FALSE )
	{
		// ��ǥ�� �ٽ� ��� �Ѵ� 
		char AXIS_NAME[] = { 'X', 'Y', 'Z', 'A', 'B' };
		double fNewPosition[pa::AXIS_NUM] = { 0.0, 0.0, 0.0, 0.0, 0.0 };

		calc( fNewPosition );		
		
		for( int i = 0; i<pa::AXIS_NUM; i++ )
		{
			if( ptrAxis[i] ) 
			{
				sprintf_s( ptrAxis[i], 31, "%c%.3f ", AXIS_NAME[i], fNewPosition[i] );
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// 3. reform g-code
	//////////////////////////////////////////////////////////////////////////
	memset((void*)gcode, 0, sizeof(char)*buf_size);

	index = 0;

	for( int i = 0; i<token_index; i++ )
	{
		len = strlen(szToken[i]);
		memcpy((void *)(gcode + index), (const void *)(szToken[i]), len );
		index += len;
	}
}

void pa::CTransform::calc( double fRetPosition[pa::AXIS_NUM] )
{
	hc3dutil::CMatrix	matrixReverse[2];
	hc3dutil::CMatrix	matrixTranslate;
	hc3dutil::CMatrix	matrixForword[2];

	hc3dutil::CMatrix::MATRIX_ROTATE_Y( &matrixReverse[0], fPosition_[AXIS_A] );		// A���� Y���� ȸ�� ���� (������ �ٲ�� ����)
	hc3dutil::CMatrix::MATRIX_ROTATE_X( &matrixReverse[1], fPosition_[AXIS_B]*-1.0 );	// B���� X���� ȸ�� ���� 

	hc3dutil::CMatrix::MATRIX_TRANSLATE( &matrixTranslate, fOffset_[AXIS_X], fOffset_[AXIS_Y], fOffset_[AXIS_Z] );

	hc3dutil::CMatrix::MATRIX_ROTATE_Y( &matrixForword[0], fPosition_[AXIS_A]*-1.0 );
	hc3dutil::CMatrix::MATRIX_ROTATE_X( &matrixForword[1], fPosition_[AXIS_B] );

	//
	hc3dutil::CMatrix	mat = matrixReverse[1] * matrixReverse[0] * 
							  matrixTranslate *
							  matrixForword[0] * matrixForword[1];
	
	//
	hc3dutil::CVector	vtr_old( fPosition_[pa::AXIS_X], fPosition_[pa::AXIS_Y], fPosition_[pa::AXIS_Z] );
	hc3dutil::CVector	vtr_new;

	hc3dutil::CMatrix::TRANSFORM( &vtr_new, &vtr_old, &mat );

	//
	fRetPosition[pa::AXIS_X] = vtr_new.f_[pa::AXIS_X] + 0.0005;
	fRetPosition[pa::AXIS_Y] = vtr_new.f_[pa::AXIS_Y] + 0.0005;
	fRetPosition[pa::AXIS_Z] = vtr_new.f_[pa::AXIS_Z] + 0.0005;
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

pa::CTransformVPst::CTransformVPst(void)
{
	b_transform_ = FALSE;
	n_multi_org_index_ = -1;
	n_sub_coord_index_ = -1;
	memset((void*)fPosition_, 0, sizeof(double)*pa::AXIS_NUM);
}

pa::CTransformVPst::~CTransformVPst(void)
{

}

// ���ڿ� ���� "/r/n" 
int  pa::CTransformVPst::parsing( char *gcode, char *pTokens[32] )
{
	int tokenIndex = 0;
	int i = 0;
	
	memset((void*)pTokens, 0, sizeof(char*)*32 );

	while( gcode[i]!='\r' && gcode[i]!='\n' && gcode[i]!=NULL )
	{
		if( (gcode[i]>='0' && gcode[i]<='9') || gcode[i]=='.' || gcode[i]==' ' || gcode[i]=='-'  || gcode[i]=='+' )
		{
			//  ����
		}
		else 
		{
			// ���� 
			pTokens[tokenIndex++] = gcode+i;
		}

		++i;
	}

	pTokens[tokenIndex] = gcode+i;

	return tokenIndex;
}

void pa::CTransformVPst::calc( double fRetPosition[pa::AXIS_NUM] )
{
	double	fAPos = fabs( fPosition_[pa::AXIS_A] );
	double	fBPos = fabs( fPosition_[pa::AXIS_B] );
	BOOL	bIsA180 = ( fAPos > 179.9 && fAPos < 180.1 );
	BOOL	bIsB180 = ( fBPos > 179.9 && fBPos < 180.1 );
	pa::SMultiOriginData *pMOD = pa::PPAStatus->GetMultiOriginData();

	//////////////////////////////////////////////////////////////////////////
	// ��ġ Offset�� ���Ѵ� 
	//////////////////////////////////////////////////////////////////////////
	fRetPosition[0] = fPosition_[0] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][0];
	fRetPosition[1] = fPosition_[1] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][1];
	fRetPosition[2] = fPosition_[2] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][2];

	//////////////////////////////////////////////////////////////////////////
	// �۾� Offset�� ���Ѵ� 
	//////////////////////////////////////////////////////////////////////////
	if( bIsA180 == FALSE && bIsB180 == FALSE )
	{
		// A0 B0
		fRetPosition[0] = fRetPosition[0] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][3];
		fRetPosition[1] = fRetPosition[1] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][4];
		fRetPosition[2] = fRetPosition[2] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][5];
	}
	else if( bIsA180 == TRUE && bIsB180 == FALSE )
	{
		// A180 B0
		fRetPosition[0] = fRetPosition[0] - pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][3];
		fRetPosition[1] = fRetPosition[1] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][4];
		fRetPosition[2] = fRetPosition[2] - pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][5];
	}
	else if( bIsA180 == FALSE && bIsB180 == TRUE )
	{
		// A0 B180
		fRetPosition[0] = fRetPosition[0] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][3];
		fRetPosition[1] = fRetPosition[1] - pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][4];
		fRetPosition[2] = fRetPosition[2] - pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][5];
	}
	else 
	{
		// A180 B180
		fRetPosition[0] = fRetPosition[0] - pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][3];
		fRetPosition[1] = fRetPosition[1] - pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][4];
		fRetPosition[2] = fRetPosition[2] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][5];
	}
}

void pa::CTransformVPst::calc_offset( double fRetPosition[pa::AXIS_NUM] )
{
//	pa::SMultiOriginData	*pMOD = pa::PState->GetMultiOriginData();
	pa::SMultiOriginData	*pMOD = pa::PPAStatus->GetMultiOriginData();

	//////////////////////////////////////////////////////////////////////////
	// ��ġ Offset�� ���Ѵ� 
	//////////////////////////////////////////////////////////////////////////
	fRetPosition[pa::AXIS_X] = fPosition_[pa::AXIS_X] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][pa::AXIS_X];
	fRetPosition[pa::AXIS_Y] = fPosition_[pa::AXIS_Y] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][pa::AXIS_Y];
	fRetPosition[pa::AXIS_Z] = fPosition_[pa::AXIS_Z] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][pa::AXIS_Z];
}

void pa::CTransformVPst::calc_transfer( double fRetPosition[pa::AXIS_NUM] )
{
// 	pa::SMultiOriginData	*pMOD = pa::PState->GetMultiOriginData();
	pa::SMultiOriginData	*pMOD = pa::PPAStatus->GetMultiOriginData();
	hc3dutil::CMatrix	matrixReverse[2];
	hc3dutil::CMatrix	matrixTranslate;
	hc3dutil::CMatrix	matrixForword[2];

 	hc3dutil::CMatrix::MATRIX_ROTATE_Y( &matrixReverse[0], fPosition_[AXIS_A] );		// A���� Y���� ȸ�� ���� (������ �ٲ�� ����)
	hc3dutil::CMatrix::MATRIX_ROTATE_X( &matrixReverse[1], fPosition_[AXIS_B]*-1.0 );	// B���� X���� ȸ�� ���� 

	double fReverseXY = pMOD->hMultiOrigin[n_multi_org_index_].bReverseXY[n_sub_coord_index_] == TRUE ? -1.0 : 1.0;
	double x_offset = pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][3] * fReverseXY;
	double y_offset = pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][4] * fReverseXY;
	double z_offset = pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][5];


	hc3dutil::CMatrix::MATRIX_TRANSLATE( 
		&matrixTranslate,
		x_offset,	//pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][3], 
		y_offset,	//pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][4],
		z_offset );	//pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][5] );

	hc3dutil::CMatrix::MATRIX_ROTATE_Y( &matrixForword[0], fPosition_[AXIS_A]*-1.0 );
	hc3dutil::CMatrix::MATRIX_ROTATE_X( &matrixForword[1], fPosition_[AXIS_B] );

	//
	hc3dutil::CMatrix	mat =	matrixReverse[1] * 
								matrixReverse[0] * 
								matrixTranslate *
								matrixForword[0] * matrixForword[1];

	//
//	hc3dutil::CVector	vtr_old( fPosition_[pa::AXIS_X], fPosition_[pa::AXIS_Y], fPosition_[pa::AXIS_Z] );
	hc3dutil::CVector	vtr_old( fRetPosition[pa::AXIS_X], fRetPosition[pa::AXIS_Y],fRetPosition[pa::AXIS_Z] );
	hc3dutil::CVector	vtr_new;

	hc3dutil::CMatrix::TRANSFORM( &vtr_new, &vtr_old, &mat );

	//
	fRetPosition[pa::AXIS_X] = vtr_new.f_[pa::AXIS_X] + 0.0005;
	fRetPosition[pa::AXIS_Y] = vtr_new.f_[pa::AXIS_Y] + 0.0005;
	fRetPosition[pa::AXIS_Z] = vtr_new.f_[pa::AXIS_Z] + 0.0005;
}

// 2016.10.12 Single Abutment ���� �߰� 
/*
void pa::CTransformVPst::calc_single_abutment( double fRetPosition[pa::AXIS_NUM] )
{
	pa::SMultiOriginData	*pMOD = pa::PPAStatus->GetMultiOriginData();
	
	double fDeltaX = pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][3];
	double fDeltaY = pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][4];
	double fDeltaZ = pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][5];
	
	double fA0 = atan( fDeltaZ / fDeltaX );
	double fR  = sqrt( fDeltaZ* fDeltaZ + fDeltaX*fDeltaX );

	double fX1 = fPosition_[pa::AXIS_X] + fR * cos(fA0 + fPosition_[pa::AXIS_A]);
	double fY1 = fPosition_[pa::AXIS_Y] + fDeltaY;
	double fZ1 = fPosition_[pa::AXIS_Z] + fR * sin(fA0 + fPosition_[pa::AXIS_A]);

	fRetPosition[pa::AXIS_X] = fX1;
	fRetPosition[pa::AXIS_Y] = fY1;
	fRetPosition[pa::AXIS_Z] = fZ1;
}
*/
void pa::CTransformVPst::calc_single_abutment( double fRetPosition[pa::AXIS_NUM] )
{
	pa::SMultiOriginData	*pMOD = pa::PPAStatus->GetMultiOriginData();

	double fDeltaX = pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][3];
	double fDeltaY = pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][4];
	double fDeltaZ = pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][5];

	//////////////////////////////////////////////////////////////////////////
	// 2017.04.18  
	// ���� ������ �����ϰ�, ȯ���� ��ġ �ɼ¸� ���ѵ��� ���� 
// 	fRetPosition[pa::AXIS_X] = fPosition_[pa::AXIS_X] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][pa::AXIS_X];
// 	fRetPosition[pa::AXIS_Y] = fPosition_[pa::AXIS_Y] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][pa::AXIS_Y];
// 	fRetPosition[pa::AXIS_Z] = fPosition_[pa::AXIS_Z] + pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][pa::AXIS_Z];
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	// fDeltaX�� 0�� ���, ���� �����ͷ� ġȯ
	if( fabs(fDeltaX) < 0.00001 )
	{
		fDeltaX = 0.00001;
	}

	//////////////////////////////////////////////////////////////////////////
	/*
	double fRadian = atan( fdX / fdY );
	fAngle  = hc3dutil::MAKE_ANGLE( fRadian );	*/

//	double fA0 = atan( fDeltaZ / fDeltaX );				// DeltaX�� 0�� ��� ���� ���� 
	double fA0 = 0.0;

	if( fDeltaX > 0.0 && fDeltaZ < 0.0 )
	{
		if( fabs(fDeltaX) < 0.0001 )	// fDeltaX == 0 �� ��� 
		{
			fA0 = 90.0;
		}
		else
		{
		//	fA0 = atan( fabs( fDeltaZ / fDeltaX ) );
			double fRadian = atan( fabs( fDeltaZ / fDeltaX ) );
			fA0 = hc3dutil::MAKE_ANGLE( fRadian );
		}
	}
	else if( fDeltaX < 0.0 && fDeltaZ < 0.0 )
	{
		if( fabs(fDeltaZ) < 0.0001 )
		{
			fA0 = 180.0;
		}
		else 
		{
		//	fA0 = 90.0 + atan( fabs( fDeltaZ / fDeltaX ) );
		//	fA0 = 180.0 - atan( fabs( fDeltaZ / fDeltaX ) );
			double fRadian = atan( fabs( fDeltaZ / fDeltaX ) );
			fA0 = 180.0 - hc3dutil::MAKE_ANGLE( fRadian );
		}
	}
	else if( fDeltaX < 0.0 && fDeltaZ > 0.0 )
	{
		if( fabs(fDeltaX) < 0.0001 )
		{
			fA0 = 270.0;
		}
		else 
		{
		//	fA0 = 180.0 + atan( fabs( fDeltaZ / fDeltaX ) );
			double fRadian = atan( fabs( fDeltaZ / fDeltaX ) );
			fA0 = 180.0 + hc3dutil::MAKE_ANGLE( fRadian );
		}
	}
	else //if( fDeltaX > 0.0 && fDeltaZ > 0.0 )
	{
		if( fabs( fDeltaZ ) < 0.0001 )
		{
			fA0 = 0.0;
		}
		else 
		{
		//	fA0 = 270.0 + atan( fabs( fDeltaZ / fDeltaX ) );
		//	fA0 = 360.0 - atan( fabs( fDeltaZ / fDeltaX ) );
			double fRadian = atan( fabs( fDeltaZ / fDeltaX ) );
			fA0 = 360.0 - hc3dutil::MAKE_ANGLE( fRadian );
		}
	}

	double fR  = sqrt( fDeltaZ*fDeltaZ + fDeltaX*fDeltaX );

	double fX1 = fPosition_[pa::AXIS_X] + fR * cos(fA0 + fPosition_[pa::AXIS_A]);
	double fY1 = fPosition_[pa::AXIS_Y] + fDeltaY;
	double fZ1 = fPosition_[pa::AXIS_Z] + fR * sin(fA0 + fPosition_[pa::AXIS_A]);

	fX1 += pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][pa::AXIS_X];
	fY1 += pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][pa::AXIS_Y];
	fZ1 += pMOD->hMultiOrigin[n_multi_org_index_].fOffset[n_sub_coord_index_][pa::AXIS_Z];

	fRetPosition[pa::AXIS_X] = fX1;
	fRetPosition[pa::AXIS_Y] = fY1;
	fRetPosition[pa::AXIS_Z] = fZ1;
}

// 2015.10.07 
// gcode�� ���� �����Ͱ� ������ �������� ���, �����߻� �� ���� ��� �߰� 
BOOL pa::CTransformVPst::TRANSFORM2( char *gcode, int buf_size )
{
	int		numToken = 0;
	char	*pTokens[32];		// parsing �Լ����� ���� ���ڸ� ����ؼ� �и��� ������ pToken�� ���� 
	char	szTokens[32][32];	// pTokens�� �� �׸��� ���� 
	char	*ptrAxis[pa::AXIS_NUM] = { NULL, NULL, NULL, NULL, NULL };

	BOOL	bCalc = FALSE;

	memset((void*)szTokens, 0, sizeof(char)*32*32);

	numToken = parsing( gcode, pTokens );
	if( numToken >= 32 )
	{
		// ���� 
		return FALSE;
	}

	for( int i = 0; i<numToken; i++ )
	{
		int nLen = pTokens[i+1] - pTokens[i];

		memcpy((void*)(szTokens[i]), pTokens[i], nLen );

		switch( pTokens[i][0] )
		{
		case 'x':
		case 'X':
			fPosition_[pa::AXIS_X] = atof(pTokens[i]+1); ptrAxis[pa::AXIS_X] = szTokens[i]; bCalc = TRUE;
			break;
		case 'y':
		case 'Y':
			fPosition_[pa::AXIS_Y] = atof(pTokens[i]+1); ptrAxis[pa::AXIS_Y] = szTokens[i]; bCalc = TRUE;
			break;
		case 'z':
		case 'Z':
			fPosition_[pa::AXIS_Z] = atof(pTokens[i]+1); ptrAxis[pa::AXIS_Z] = szTokens[i]; bCalc = TRUE;
			break;
		case 'a':
		case 'A':
			fPosition_[pa::AXIS_A] = atof(pTokens[i]+1); ptrAxis[pa::AXIS_A] = szTokens[i]; bCalc = TRUE;
			break;
		case 'b':
		case 'B':
			fPosition_[pa::AXIS_B] = atof(pTokens[i]+1); ptrAxis[pa::AXIS_B] = szTokens[i]; bCalc = TRUE;
			break;
		case 'g':
		case 'G':
			{
			//	gcode = (pTokens[i][1]-'0')*10 + (pTokens[i][2]-'0');
				int gcode = (szTokens[i][1]-'0')*10 + (szTokens[i][2]-'0');
				if( nLen<=4 ) 
				{
					if( (gcode>=53 && gcode<=59) || gcode==28 ) 
					{
						n_multi_org_index_ = -1;
						n_sub_coord_index_ = -1;	
					}
				}
				else 
				{
					//////////////////////////////////////////////////////////////////////////
					// G57.1 ó�� �ڿ� sub-coordinate ������ �ִ��� Ȯ�� 
					if( (gcode>=53 && gcode<=59) && pTokens[i][3]=='.' )
					{
						for( int k = 0; k<pa::PPAStatus->GetMultiOriginData()->nNumGCode; k++ ) 
						{
							if( gcode == pa::PPAStatus->GetMultiOriginData()->hMultiOrigin[k].nGcode ) 
							{
								n_multi_org_index_ = k;							// G57.1�� ��� 0, G56.1�� ��� 0
								n_sub_coord_index_ = atoi(pTokens[i]+4) - 1;	// G56.1�� ��� 1, G56.2�� ��� 1 

								memset((void*)szTokens[i], 0, sizeof(char)*32);
								memcpy((void*)szTokens[i], "G54 ", 4);
								break;
							}
						}
					}
					else 
					{
						// error: �߸��� G-Code => �� �̴� 
					}
					//////////////////////////////////////////////////////////////////////////
				}
			}
			break;
		}
	}

	//////////////////////////////////////////////////////////////////////////

	static char *P_AXIX_NAME = "XYZABC";
	double fNewPosition[pa::AXIS_NUM] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
	if( bCalc==TRUE && n_multi_org_index_!=-1 && n_sub_coord_index_!=-1 )
	{
// 		calc_offset( fNewPosition );
// 		calc_transfer( fNewPosition );

		//////////////////////////////////////////////////////////////////////////
		// 2016.10.12 
		// �� ��� �Լ��� ������ ��, ���ǽ��� �߰� �Ѵ� 
		// n_multi_org_index == 0, 1 �� 57, 55�� ���, �״�� 
		// n_multi_org_index == 2 �� 55�� ���, calc_single_abutment() �Լ��� ����ϵ��� ���� �Ѵ� 
		//////////////////////////////////////////////////////////////////////////
		// 2016.12.21.
		//	- single abutment ��� �߰� 
		if( n_multi_org_index_ == 0 || n_multi_org_index_ == 1 )
		{
			// G57, G56
			calc_offset( fNewPosition );
			calc_transfer( fNewPosition );
		}
		else if( n_multi_org_index_ == 2 ) 
		{
			// G55 
			calc_single_abutment( fNewPosition );
			// for aingle test rm
			//	calc_offset( fNewPosition );
			//	calc_transfer( fNewPosition );
		}
		else 
		{
			calc_offset( fNewPosition );
			calc_transfer( fNewPosition );
		}

		//////////////////////////////////////////////////////////////////////////
		// 2015.09.14 
		fNewPosition[pa::AXIS_A] = fPosition_[pa::AXIS_A];
		fNewPosition[pa::AXIS_B] = fPosition_[pa::AXIS_B];
		//////////////////////////////////////////////////////////////////////////

		for( int i = 0; i<pa::AXIS_NUM; i++ ) {
			if( ptrAxis[i] ) {
//				sprintf_s( ptrAxis[i], 31, "%c%.3f ", P_AXIX_NAME[i], fNewPosition[i] );
				ptrAxis[i][0] = P_AXIX_NAME[i];
				sprintf_s( &(ptrAxis[i][1]), 30, "%.3f ", fNewPosition[i] );
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////

	memset((void*)gcode, 0, sizeof(char)*buf_size);

	int index = 0;
	for( int i = 0; i<numToken; i++ )
	{
		int len = strlen( szTokens[i] );
		memcpy((void*)(gcode + index), (const char*)(szTokens[i]), len);
		index += len;
	}

	return TRUE;
}

// �ӵ� ���� (���۸� �и�)
// void pa::CTransformVPst::TRANSFORM( char *gcode, int buf_size )
// {
// 	char	szToken[16][32];			// token�� 32byte, 16�� ���� ��� ���� = 512 byte
// 	char	sztemp[64];	
// 	int		len = strlen(gcode) - 2;	// -2 is '\r\n'
// 	int		index = 0;
// 	int		g_val;
// 	int		token_index = 0;
// 	char	*ptrAxis[pa::AXIS_NUM] = { NULL, NULL, NULL, NULL, NULL };
// 
// 	BOOL	bCalc = FALSE;
// 
// 	b_transform_ = FALSE;
// 
// 	//////////////////////////////////////////////////////////////////////////
// 	// 1. g-code �Ľ�
// 	//////////////////////////////////////////////////////////////////////////
// 
// 	memset( (void*)szToken, 0, sizeof(char)*16*32 );
// 	index = 0;
// 	memset( (void*)sztemp, 0, sizeof(char)*64 );
// 
// 	for( int i = 0; i<len; i++ )
// 	{
// 		sztemp[index++] = gcode[i];
// 
// 		if( gcode[i]==' ' || i>=len-1 )
// 		{
// 			memcpy((void*)szToken[token_index], sztemp, strlen(sztemp) );
// 
// 			sztemp[index] = NULL;
// 			switch( sztemp[0] )
// 			{
// 			case 'x':
// 			case 'X':
// 				fPosition_[pa::AXIS_X] = (double)atof(sztemp+1);
// 				ptrAxis[pa::AXIS_X] = szToken[token_index];
// 				bCalc = TRUE;
// 				break;
// 			case 'y':
// 			case 'Y':
// 				fPosition_[pa::AXIS_Y] = (double)atof(sztemp+1);
// 				ptrAxis[pa::AXIS_Y] = szToken[token_index];
// 				bCalc = TRUE;
// 				break;
// 			case 'z':
// 			case 'Z':
// 				fPosition_[pa::AXIS_Z] = (double)atof(sztemp+1);
// 				ptrAxis[pa::AXIS_Z] = szToken[token_index];
// 				bCalc = TRUE;
// 				break;
// 			case 'a':
// 			case 'A':
// 				fPosition_[pa::AXIS_A] = (double)atof(sztemp+1);
// 				// ptrAxis[pa::AXIS_A] = szToken[token_index];
// 				bCalc = TRUE;
// 				break;
// 			case 'b':
// 			case 'B':
// 				fPosition_[pa::AXIS_B] = (double)atof(sztemp+1);
// 				// ptrAxis[pa::AXIS_B] = szToken[token_index];
// 				bCalc = TRUE;
// 				break;
// 
// 			case 'g':
// 			case 'G':
// 				//if( strlen(sztemp) <= 4 ) 
// 				if( index <= 4 )
// 				{
// 					char sz[3] = { sztemp[1], sztemp[2], 0 };
// 				//	int gcode = (int)atoi(sz);
// 					int gcode = (sztemp[1]-'0')*10 + (sztemp[2]-'0');
// 					if( gcode==28 || (gcode>=53 && gcode<=59) ) {
// 						// ��ǥ�� ��ȯ ����...
// 						b_transform_ = FALSE;
// 						n_multi_org_index_ = -1;
// 						n_sub_coord_index_ = -1;
// 					}
// 				}
// 				else 
// 				{
// 					// G57.1 G57.10 => . ���� 
// 					char sz[3] = { sztemp[1], sztemp[2], 0 };
// 				//	int gcode = (int)atoi(sz);	// 28, 53, 54, 55, ... 59 ��� 
// 					int gcode = (sztemp[1]-'0')*10 + (sztemp[2]-'0');
// 					if( ( gcode>=53 && gcode<=59 ) && sztemp[3] == '.' )
// 					{
// 						for( int i = 0; i<pa::PState->GetMultiOriginData()->nNumGCode; i++ ) 
// 						{
// 							if( gcode == pa::PState->GetMultiOriginData()->hMultiOrigin[i].nGcode ) 
// 							{
// 								// ��ǥ�� ��� ����...
// 								b_transform_ = TRUE;
// 								n_multi_org_index_ = i;
// 								n_sub_coord_index_ = atoi( sztemp+4 ) - 1;
// 								//
// 								memset((void*)szToken[token_index], 0, sizeof(char)*32);
// 								sprintf_s(szToken[token_index], 31, "G54");	// token�� "G54"�� ���� 
// 								break;
// 							}
// 							else 
// 							{
// 								// error: Multi-Origin�� ��ϵ��� ���� ��ǥ��
// 							}
// 						}
// 					}
// 					else 
// 					{
// 						// error: �߸��� G-Code
// 					}
// 				}
// 			}
// 
// 			token_index++;
// 			index = 0;
// 			memset( (void*)sztemp, 0, sizeof(char)*64 );
// 		}
// 	}
// 
// 	//////////////////////////////////////////////////////////////////////////
// 	// 2. ��ǥ ��ȯ 
// 	//////////////////////////////////////////////////////////////////////////
// // 	if( bCalc==TRUE && b_transform_==TRUE && n_multi_org_index_!=-1 && n_sub_coord_index_!=-1 )
// 	if( bCalc==TRUE && n_multi_org_index_!=-1 && n_sub_coord_index_!=-1 )
// 	{
// 		// ��ǥ�� �ٽ� ��� �Ѵ� 
// 		char AXIS_NAME[] = { 'X', 'Y', 'Z', 'A', 'B' };
// 		double fNewPosition[pa::AXIS_NUM] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
// 
// 		calc( fNewPosition );		
// 
// 		for( int i = 0; i<pa::AXIS_NUM; i++ )
// 		{
// 			if( ptrAxis[i] ) 
// 			{
// 				sprintf_s( ptrAxis[i], 31, "%c%.3f ", AXIS_NAME[i], fNewPosition[i] );
// 			}
// 		}
// 	}
// 
// 	//////////////////////////////////////////////////////////////////////////
// 	// 3. reform g-code
// 	//////////////////////////////////////////////////////////////////////////
// 	memset((void*)gcode, 0, sizeof(char)*buf_size);
// 
// 	index = 0;
// 
// 	for( int i = 0; i<token_index; i++ )
// 	{
// 		len = strlen(szToken[i]);
// 		memcpy((void *)(gcode + index), (const void *)(szToken[i]), len );
// 		index += len;
// 	}
// }


