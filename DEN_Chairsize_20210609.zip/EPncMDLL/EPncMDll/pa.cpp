#include "stdafx.h"
#include "pa.h"
// #include "EPncM.h"
#include "EPncMDLL.h"
#include "ErrorDlg.h"

//////////////////////////////////////////////////////////////////////////
// ���� ���� 
//////////////////////////////////////////////////////////////////////////
namespace pa 
{
CString STR_ERROR_TYPE_FILEPATH	= CString( INI_PA_ERROR_TYPE_PATH );
CString STR_ERROR_CODE_FILEPATH	= CString( INI_PA_ERROR_CODE_PATH );
CString STR_ERROR_MESSAGE_FILEPATH	= CString( INI_PA_ERROR_MESSAGE_PATH );

CPAAsyncComm*		PPAAsyncComm[2]	= { NULL, NULL };
CPAStatus*			PPAStatus		= NULL;

CPAMotion*			PAMotion		= NULL;
CPThread*			PThread			= NULL;
CPNCFile*			PNCFile			= NULL;
CPNCFileMgr*		PNCFileMgr		= NULL;
CPIpcServer*		PIpcServer		= NULL;
CPConfig*			PConfig			= NULL;
ACAutoLoader*		PAutoLoader		= NULL;
CPContinueRunInfo*	PContinueRunInfo= NULL;
CPTool*				PTool			= NULL;

BOOL				IS_SUCCESS_FIRST_CONNECT = FALSE;

DWORD				todaySpindleRunTime = 0;
SYSTEMTIME			currentReadWriteTime;
int					nMaxxLinkRemoteServer_PortNo = 0;
int					nRemotePNC_PortNo = 0;
}

//////////////////////////////////////////////////////////////////////////
// ���� �Լ�  
//////////////////////////////////////////////////////////////////////////

/** 
 * Socket �ʱ�ȭ �� ���� 
 */
BOOL pa::STARTUP_SOCKET_COMM( CString& strErrMsg )
{
	WSADATA	wsaData;
	int		n = WSAStartup(MAKEWORD(2,0), &wsaData);

	strErrMsg.Format( _T("") );

	switch( n ) 
	{
	case WSASYSNOTREADY :		strErrMsg.Format( _T("WSASYSNOTREADY") ); break;
	case WSAVERNOTSUPPORTED :	strErrMsg.Format( _T("WSAVERNOTSUPPORTED") ); break;
	case WSAEPROCLIM :			strErrMsg.Format( _T("WSAEPROCLIM") ); break;
	case WSAEFAULT :			strErrMsg.Format( _T("WSAEFAULT") ); break;
	}

	return (BOOL)( n==0 );
}

void pa::CLEANUP_SOCKER_COMM()
{
	WSACleanup();
}

/** 
 * Socket ���� �ڵ带 �޽����� ��ȯ 
 */
void pa::GET_SOCKET_ERROR_MESSAGE( DWORD dwErrorCode, CString& strErrorCode )
{
	TCHAR szMsg[1024] = {0,};

	memset( (void*)szMsg, 0, sizeof(char)*1024 );

	FormatMessage( FORMAT_MESSAGE_FROM_SYSTEM, NULL, dwErrorCode, 0, szMsg, 1024, NULL );

	strErrorCode.Format( _T("[%d] %s"), dwErrorCode, szMsg );
}

/** 
 * PA ����� ���� �޽����� ���� �Ѵ� 
 */
void pa::GET_PA_ERROR_MESSAGE( int nErrorType, int nErrorCode, CString& strErrorType, int& nErrorTypeIsAlarm, CString& strErrorCode, CString& strErrorMessage )
{
	CCEIniFile hIniFile;
	CString strKeyName, strValueName, strValueName2;

	strErrorType.Format( _T("") );
	strErrorCode.Format( _T("") );
	strErrorMessage.Format( _T("") );

	switch( nErrorType )
	{
	case pa::ERR_RND_CMD:
	case pa::ERR_PA_STREAM:
		strKeyName.Format( _T("RND_CMD") );
		break;
	case pa::ERR_PNC:
		strKeyName.Format( _T("PNC") );
		break;
	default:
		strErrorType.Format( _T("*") );
		strErrorCode.Format( _T("*") );
		strErrorMessage.Format( _T("*") ); 
		return ;
	}

	strValueName.Format( _T("E%d"), nErrorCode );
	strValueName2.Format( _T("A%d"), nErrorCode );

	//////////////////////////////////////////////////////////////////////////

	hIniFile.Open( STR_ERROR_TYPE_FILEPATH );	// PAErrorType.ini

	hIniFile.GetValue( strKeyName, strValueName, (CString*)&strErrorType );
	hIniFile.GetValue( strKeyName, strValueName2, (int*)&nErrorTypeIsAlarm ); 

	hIniFile.Close();

	hIniFile.Open( STR_ERROR_CODE_FILEPATH );	// PAErrorCode.ini

	hIniFile.GetValue( strKeyName, strValueName, (CString*)&strErrorCode );

	hIniFile.Close();

	hIniFile.Open( STR_ERROR_MESSAGE_FILEPATH );	// PAErrorMessage.ini

	hIniFile.GetValue( strKeyName, strValueName, (CString*)&strErrorMessage );

	hIniFile.Close();
}

/** 
 * port1 = 10100, port2 = 10000
 */
BOOL pa::PA_INITIALIZE( char* pIpAddr, int nPortNo1, int nPortNo2, int nPortNoForStream, CString& strErrMsg )
{
	CString	strConfigFilePath;
	CString strAutoLoaderConfigFilePath;
	CString strReplaceNCCodeConfigFilePath;
	CString strCheckNcCodeConfigFilePath;
	BOOL	bRet;
	char	sztemp[128];

#ifdef _DEBUG
	Sleep( 1*1000 );	// ����� ���ñ��� 1�ʰ� ��� 
#else 
// 	Sleep( 30*1000 );	// ����� ���ñ��� 30�ʰ� ��� 
	Sleep( 1*1000 );	// ����� ���ñ��� 30�ʰ� ��� 
#endif 

	strConfigFilePath = CString( INI_PA_CONFIG_PATH );
	strAutoLoaderConfigFilePath = CString( INI_AL_TEACHING_POINT_PATH ); //AutoLoaderConfig.ini") );
	strReplaceNCCodeConfigFilePath = CString( INI_REPLACE_NC_CODE_CONFIG_PATH );
	strCheckNcCodeConfigFilePath = CString( INI_NC_FILE_CHECKER_CONFIG_PATH );

	// 0. �ʿ��� ���丮�� ���� ���, �̸� ����� 
	CREATE_NECESSARY_DIRECTORIES();

	// 1. PAComm �ʱ�ȭ �� ���� 
	PPAAsyncComm[0] = new CPAAsyncComm(2048);
	if( PPAAsyncComm[0] == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pa::PAAsyncComm[0] object") );
	}
	PPAAsyncComm[1] = new CPAAsyncComm( 2048 );
	if( PPAAsyncComm[1] == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pa::PAAsyncComm[1] object") );
	}

	DWORD	dwErrCode = 0;
	int		retry_count = 0;
#ifdef _USE_PA_

	DWORD dwTime = GetTickCount();
	CString strDbg;

	PPAAsyncComm[0]->Connect( pIpAddr, nPortNo1 );
	Sleep( 1000 );
	while( TRUE )
	{
		hcsock::ISocket::EN_CONNECT_STATE conn_status = PPAAsyncComm[0]->GetConnectState();

		//////////////////////////////////////////////////////////////////////////
		// Timeout Checking : 60�� �ȿ� ������� ������, ���� ó�� �Ѵ� 
		// 300�� ���� �ø��� 
		if( (GetTickCount() - dwTime) > 120*1000 )
		{
		//	AfxMessageBox( _T("not 1") );
		//	ShowConnectFailDialog( 1 );
			return FALSE;
		}
		//////////////////////////////////////////////////////////////////////////

		// ���� �ɶ����� ���
		if( conn_status == hcsock::ISocket::CONNECTED ) 
		{
			break;
		}
		else if( conn_status == hcsock::ISocket::PENDING_CONNECT ) 
		{
			;	
		}
		else if( conn_status == hcsock::ISocket::NOT_CONNECT ) 
		{
			// �ٽ� ���� �õ� 
			PPAAsyncComm[0]->Connect( pIpAddr, nPortNo1 );
			// 10�� ��� 
			Sleep( 10000 );	
		}
	}

	dwTime = GetTickCount();
	PPAAsyncComm[1]->Connect( pIpAddr, nPortNo2 );
	Sleep( 5000 );
	while( TRUE ) 
	{
		hcsock::ISocket::EN_CONNECT_STATE conn_status = PPAAsyncComm[1]->GetConnectState();

		//////////////////////////////////////////////////////////////////////////
		// Timeout Checking : 60�� �ȿ� ������� ������, ���� ó�� �Ѵ� 
		// 300�� ���� �ø��� 
		if( (GetTickCount() - dwTime) > 120*1000 )
		{
		//	AfxMessageBox( _T("not 2") );
		//	ShowConnectFailDialog( 2 );
			return FALSE;
		}
		//////////////////////////////////////////////////////////////////////////

		// ���� �ɶ����� ���
		if( conn_status == hcsock::ISocket::CONNECTED ) 
		{
			break;
		}
		else if( conn_status == hcsock::ISocket::PENDING_CONNECT ) 
		{
			;	
		}
		else if( conn_status == hcsock::ISocket::NOT_CONNECT ) 
		{
			// �ٽ� ���� �õ� 
			PPAAsyncComm[1]->Connect( pIpAddr, nPortNo2 );
		}

		// 10�� ��� 
		Sleep( 10000 );	
	}
#endif

	//////////////////////////////////////////////////////////////////////////

	// 2. PMotion �ʱ�ȭ 
	PAMotion = new CPAMotion();
	if( PAMotion == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::PMotion object") );
		return FALSE;
	}

	// 3. PConfig �ʱ�ȭ 
	int using_autoloader = 0;
	PConfig = new CPConfig();
	if( PConfig == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::PConfig object") );
		return FALSE;
	}
	bRet = PConfig->Initialize( strConfigFilePath, strErrMsg );
	if( bRet == FALSE ) {
		return FALSE;
	}
	bRet = PConfig->Load(using_autoloader, strErrMsg );	// uploadMotorScale // �Լ����� bUsingAirLimitSensor, nAirLimitInterval �����͸� �о� �´� 
	if( bRet == FALSE ) {
		return FALSE;
	}

	// 4. log ��ü �ʱ�ȭ 
	P_LOG = new CLog( 
		PConfig->pConfig_->nEnableOperationLog, PConfig->pConfig_->nEnableIpcCommLog,
		PConfig->pConfig_->nEnableThreadModeLog, PConfig->pConfig_->nEnableOpPenalLog, 
		PConfig->pConfig_->nEnableExtLog, PConfig->pConfig_->nEnableErrLog );
	if( P_LOG ) {
		P_LOG->Initialize( 30 );
		P_LOG->WriteLog( CLog::TYPE_OPER, 0, _T("<<< Start. EPncM.Dll >>>") );
		P_LOG->WriteLog( CLog::TYPE_OPER, 1, theApp.P_VERSION );
	}

	P_LOG->EnableOperationLog( PConfig->pConfig_->nEnableOperationLog );
	P_LOG->EnableIpcCommLog( PConfig->pConfig_->nEnableIpcCommLog );
	P_LOG->EnableThreadModeLog( PConfig->pConfig_->nEnableThreadModeLog );
	P_LOG->EnableOpPanelLog( PConfig->pConfig_->nEnableOpPenalLog );
	P_LOG->EnableExtLog( PConfig->pConfig_->nEnableExtLog );
	P_LOG->EnableErrLog( PConfig->pConfig_->nEnableErrLog );

	//////////////////////////////////////////////////////////////////////////
	// 2016.12.14
	//	> ���� ���ɵ� ���ð� ������ ���� �Ѵ� 
	DELETE_TODAY_SPINDLE_RUN_TIME(100);
	//////////////////////////////////////////////////////////////////////////

	// 5. ReplaceNCCode �ʱ�ȭ 
	bRet = CGCodeHelper::LoadReplaceCommand( strReplaceNCCodeConfigFilePath, strErrMsg );
	if( bRet == FALSE ) {
		return FALSE;
	}

	// 6. NcFileChecker �ʱ�ȭ 
	bRet = CGCodeHelper::LoadCheckCommand( strCheckNcCodeConfigFilePath, strErrMsg );
	if( bRet = FALSE ) {
		return FALSE;
	}

	// 7. PTool �ʱ�ȭ 
	PTool = new CPTool();
	if( PTool == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::PTool object") );
		return FALSE;
	}
	bRet = PTool->Initialize( strErrMsg );
	if( bRet == FALSE ) {
		return FALSE;
	}

	// 8. PPAState 
	PPAStatus = new CPAStatus();
	if( PPAStatus == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::PAState object") );
		return FALSE;
	} 
	bRet = PPAStatus->Initialize( strErrMsg );
	if( bRet == FALSE ) {
		return FALSE;
	}

#ifdef _USE_PA_
	PPAAsyncComm[0]->SetRefPAStatus( PPAStatus->GetPAStatus() );
	PPAAsyncComm[0]->SetRefThreadState( PPAStatus->GetThreadState() );
	PPAAsyncComm[1]->SetRefPAStatus( PPAStatus->GetPAStatus() );
	PPAAsyncComm[1]->SetRefThreadState( PPAStatus->GetThreadState() );
#endif 

	//////////////////////////////////////////////////////////////////////////
	// �����͸� ����⿡ ������ ���, ����⿡�� �о� �´� 
	try {
#ifdef _USE_PA_
		//////////////////////////////////////////////////////////////////////////
		// SMCT ���� ���� (2017.05.01)
		//	- 2017.05.19 �������� �������� �ʴ´� 
		DWORD	dwErr = 0;
		DWORD	dwSysErr = 0;
	//	int		nRespErrCode[2] = {0, 0};	// ���ɿ� �����ڵ尡 �������� ���� ��, ���� �ڵ� 
		int		nRespErrCode = 0;
		int		nRespSysErrCode = 0;

		pa::PPAStatus->GetThreadState()->nIsConnectedIOBoard = 1;		// IO Board Connection flag 1�� �ʱ�ȭ

		pa::INIT_CLEAN_SPINDLE_RUN_TIME();					// clean timeout �� ���ð��� �о� ���δ�. poweron test ����� ��� �Ѵ�  
		try {
			PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_SMCT );
			PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_SMCT, 10000 );
			dwErr = CPAAsyncComm::DW_RESPONSE_SMCT_CMD;
			nRespErrCode = CPAAsyncComm::N_ERRORCODE_SMCT_CMD;
		}
		catch ( pa::CPException& e ) {
			dwErr = 0;
		}
		try {
			PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RISM);
			PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RISM, 10000 );
			dwSysErr = CPAAsyncComm::DW_RESPONSE_RISMCT_CMD;
			nRespSysErrCode = CPAAsyncComm::N_ERRORCODE_RISMCT_CMD;	
		}
		catch ( pa::CPException& e ) {
			dwSysErr = 0;
		}
		BOOL	coord_offset = TRUE;
		BOOL	teaching_point = TRUE;
		BOOL	multi_origin = TRUE;
		BOOL	cleaning_timeout = FALSE;

		//////////////////////////////////////////////////////////////////////////
		// coordinate offset �����͸� �а�...
		for( int i = 0; i<pa::COORD_NUM; i++ ) 
		{
			pa::PAMotion->RCFG( (pa::EN_COORDINATE)i );
			Sleep(10);
		}
		Sleep(100);
		//////////////////////////////////////////////////////////////////////////
		// z-origin offset �����͸� �а�...
		pa::PAMotion->RTOO(1);	// 	OPTION_Z1AXIS_ORIGIN_OFFSET = 0,	// double
		Sleep(10);
		pa::PAMotion->RTOO(2);	//	OPTION_Z2AXIS_ORIGIN_OFFSET // double
		Sleep(10);
		pa::PAMotion->RTDATA("spindleoffset");
		Sleep(10);
		pa::PAMotion->RTHS();	// 	OPTION_TOOL_SENSING_HIGHSPEED,	// double
		Sleep(10);
		pa::PAMotion->RTLS();	// 	OPTION_TOOL_SENSING_LOWSPEED,	// double
		Sleep(10);
		pa::PAMotion->RTMG();	//	OPTION_TOOL_SENSING_MARGIN		// double
		Sleep(10);
		pa::PAMotion->RTPPO();	//	OPTION_TOOL_POCKET_PUT_OFFSET	// double 
		Sleep(10);
		//////////////////////////////////////////////////////////////////////////
		// teaching point �����͸� �а�...
		for( int i = 0; i<pa::TEACHING_POINT_NUM; i++ ) 
		{
			pa::PAMotion->RTCP( (pa::EN_TEACHING_POINT)i );
			Sleep(10);
		}
		Sleep(100);
		//////////////////////////////////////////////////////////////////////////
		// multiorigin offset �����͸� �о...
		// PAStatus::Initialize() �Լ����� �о��� 
		// - coordinate offset data range�� �о��� 
		// - multiorigin �Ķ��Ÿ�� �о��� 
		// - tool pocket range �Ķ��Ÿ�� �о��� (poweron_test_config.ini)
		//////////////////////////////////////////////////////////////////////////
		// coordinate offset ������ ���� ���� Ȯ�� 
		coord_offset = CHECK_COORD_OFFSET_RANGE();
		// teaching point ������ ���� ���� Ȯ�� 
		teaching_point = CHECK_TEACH_POINT_RANGE();
		// multiorigin offset ������ ���� ���� Ȯ�� (base ��ġ�� Ȯ������ �ʰ�, offset ������ Ȯ���Ѵ�)
		multi_origin = CHECK_MULTIORIGIN_RANGE();
		// cleaning timeout �����͸� Ȯ���Ѵ� 
		DWORD dwCleanTimeout = pa::PConfig->pConfig_->nCleaningTimeout_Hour ;					// �� ����
		dwCleanTimeout = dwCleanTimeout * 60 * 60;												// -> �� -> �� 
		DWORD dwCurrCleanTime = pa::PPAStatus->GetThreadState()->dwCLEAN_SPINDLE_RUN_TIME;		// �� ���� 
		cleaning_timeout = (dwCleanTimeout < dwCurrCleanTime) ? TRUE : FALSE;
		//////////////////////////////////////////////////////////////////////////
		// ���信 ������ �ִ��� Ȯ�� 
		// ������ �ִٸ�, ���� ������ ǥ���� �ְ� ��� ���� ���θ� Ȯ�� �Ѵ� 
		if( ShowPowerOnTestFailDialog( dwErr, dwSysErr, nRespErrCode, nRespSysErrCode, coord_offset, teaching_point, multi_origin, cleaning_timeout ) == IDCANCEL )
		{
			// Turn off power �޽��� ��� 
			// ShowPowerOffDialog();
			return FALSE;
		}

		//////////////////////////////////////////////////////////////////////////
		// 
		if( cleaning_timeout == TRUE )
		{
			// cleaning time�� �ʱ�ȭ �Ѵ� 
			pa::RESET_CLEAN_SPINDLE_RUN_TIME();
		}
#endif 
	}
	catch ( pa::CPException& e ) {

	}
	//////////////////////////////////////////////////////////////////////////

	// 9. AutoLoader �ʱ�ȭ 
	PAutoLoader = NULL;

	switch( pa::MODEL_INFO.GetAutoLoaderType() )
	{
	case pa::SModelInfo2::AL_TYPE_NONE:
	case pa::SModelInfo2::AL_TYPE_BLOCK:
		PAutoLoader = new CBlockAutoLoader();
		break;
	case pa::SModelInfo2::AL_TYPE_DISK:
		PAutoLoader = new CDiskAutoLoader();
		break;
	}
	
	if( PAutoLoader == NULL ) {
		strErrMsg.Format( _T("memocy alloc error for pmac::PAutoLoader object") );
		return FALSE;
	} 
	bRet = PAutoLoader->Initialize( strAutoLoaderConfigFilePath, strErrMsg );
	if( bRet == FALSE ) {
		return FALSE;
	}
	if( PAutoLoader ) {
		PAutoLoader->GetAutoLoaderConfig()->bUsingAutoLoader = (using_autoloader == 0) ? FALSE : TRUE;
	}

	//PState->GetThreadState()->bConnectedPmac = TRUE;

	// 11. Graphic LCD �ʱ�ȭ 
// 	pGLCDComm = new CGLCDComm();
// 	if( pGLCDComm == NULL ) {
// 		strErrMsg.Format( _T("memory alloc error for pmac::PGLCDComm object") );
// 	}
// 	pGLCDComm->Initialize( 50, strErrMsg );
#ifdef _GLCD_SOCKET_
	// use CGLCDCommEx 
	CGLCDCommEx* pLCD = new CGLCDCommEx(1024);
	//pLCD->Initialize(_T("192.168.0.223"), 4001);
	pLCD->Initialize(INI_GLCD_PATH, strErrMsg);
	pGLCD = pLCD;
#else 
	// use CGLDCComm
	CGLCDComm* pLCD = CGLCDComm();
	pLCD->Initialize(50, strErrMsg);
	pGLCD = pLCD;
#endif 
	
	// 7. PThread �ʱ�ȭ 
	PThread = new CPThread();
	if( PThread == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::PThread object") );
		return FALSE;
	}
	bRet = PThread->Initialize( 100, strErrMsg );		 // 10 -> 100 ���� 
	if( bRet == FALSE ) {
		return FALSE;
	}

	try
	{
#ifdef _USE_PA_
		PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_STOP );
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_STOP );
		PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_INIT );
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_INIT );
		PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_RST );
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_RST, 60000 );
		PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_VER );
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_VER );
		//////////////////////////////////////////////////////////////////////////
		// 2017.01.13
		// ������� IP�ּҸ� �д´� 
		PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RADR );
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RADR );
		PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RRIOADR );
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RRIOADR );
		//////////////////////////////////////////////////////////////////////////
		// 2017.03.24 
		// Select M28/M29 ������ �д´� 
		PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_GWVF );
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_GWVF );
		//////////////////////////////////////////////////////////////////////////
		// TOOL ���� ���� 
		int		tool_no = 0;
		double	tool_length = 0;
		int		tool_lenght_update_flag = 0;
		pa::CPThread::READ_TOOL_INF0( 0, &tool_no, &tool_length, &tool_lenght_update_flag );
		PAMotion->RND_STIN( tool_no, tool_length, tool_lenght_update_flag );
		pa::CPThread::READ_TOOL_INF0( 1, &tool_no, &tool_length, &tool_lenght_update_flag );
		PAMotion->RND_STIN( tool_no, tool_length, tool_lenght_update_flag );

		//////////////////////////////////////////////////////////////////////////
		// 2018.02.27 UsingAirLimitSensor, nAirLimitInterval ���� �����͸� ������ �����Ѵ� 
		int nUsingAirLimitSensor = PConfig->pConfig_->bUsingAirLimitSensor == FALSE ? 0 : 1;
		int nAirLimitInterval = PConfig->pConfig_->nAirLimitInterval;
		int nSensorType = (int)pa::MODEL_INFO.GetAirPressureSensorType();
		PAMotion->RND_SALF( TRUE, nUsingAirLimitSensor, nAirLimitInterval, nSensorType );

		//////////////////////////////////////////////////////////////////////////
		// 2018.05.16 ���� �÷ο� ���� �ĸ���Ÿ�� ������ ���� �Ѵ� 
		int nUsingWaterFlowSensor = PConfig->pConfig_->bUsingFlowSensor == FALSE ? 0 : 1;
		int startTimeout = PConfig->pConfig_->nFlowSensorStartTimeout;
		int sensingTimeout = PConfig->pConfig_->nFlowSensorTimeout;
		PAMotion->RND_SFSF( TRUE, nUsingWaterFlowSensor, startTimeout, sensingTimeout);
		//////////////////////////////////////////////////////////////////////////
		// 2020.03.19 Purge air hold time �Ķ��Ÿ�� ������ �����Ѵ� 
		BOOL bUsingSpindleAirPurge = PConfig->pConfig_->bUsingSpindleAirPurge;
		int nPurgeAirHoldTime = (bUsingSpindleAirPurge == TRUE) ? PConfig->pConfig_->nPurgeAirHoldTime : 0;
		PAMotion->RND_WPAR( TRUE, nPurgeAirHoldTime );

		//////////////////////////////////////////////////////////////////////////
		// 2020.05.01 JoSpeed ���� 
		PAMotion->WJSS(100);

#endif
		//////////////////////////////////////////////////////////////////////////
	}
	catch( CPException& e )
	{
	}

	//////////////////////////////////////////////////////////////////////
	// 2020.03.19. ����� �ð� �ҷ��ͼ� PC�ð����� ����
	DWORD	dwErr = 0;
	int		nRespErrCode = 0;
	try {
#ifdef _USE_PA_
		PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RDT );		// Command ����
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RDT, 10000 );
		dwErr = CPAAsyncComm::DW_RESPONSE_RDT_CMD;
		nRespErrCode = CPAAsyncComm::N_ERRORCODE_RDT_CMD;
#endif 
	}
	catch ( pa::CPException& e ) {
		dwErr = 0;
	}
	///////////////////////////////////////////////////////////////////////


	// 3. PNcFile �ʱ�ȭ 
	PNCFile = new CPNCFile();
	if( PNCFile == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::PNcFile object") );
		return FALSE;
	}

	// 8. PNCFileMgr
	PNCFileMgr = new CPNCFileMgr();
	if( PNCFileMgr == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::PNCFileMgr object") );
		return FALSE;
	}
	bRet = PNCFileMgr->Initialize( strErrMsg );
	if( bRet == FALSE ) {
		return FALSE;
	}

	// 9. PIpcServer �ʱ�ȭ 
	PIpcServer = new CPIpcServer;
	if( PIpcServer == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::PIpcServer objct") );
		return FALSE;
	}
	bRet = PIpcServer->Initialize( 50, strErrMsg );
	if( bRet == FALSE ) {
		return FALSE;
	}

	// 10. ServerSocket �ʱ�ȭ 
//	int nRemoteSocket_PortNo = 10089;
// 	PREMOTE_SERVER = new CPncRemoteServer();

	//////////////////////////////////////////////////////////////////////////
	//
	// 	int nMaxxLinkRemoteServer_PortNo = 21000;
	// ȭ�� ���� ������ 21000���� �ϰ�, 
	// ���� ������ 21010���� �����Ѵ� 
// 	P_MLSERVER = new maxxlink::CMLServer();

	//////////////////////////////////////////////////////////////////////////
	// 2017.12.08 �߰� new-maxxlink
// 	P_REMOTE_SERVER = new CRemoteServer();

	//////////////////////////////////////////////////////////////////////////
	// 
	PContinueRunInfo = new CPContinueRunInfo();
	if( PContinueRunInfo == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::PContinueRunInfo object") );
		return FALSE;
	}
	if( PContinueRunInfo->Initialize( strErrMsg ) == FALSE ) {
		return FALSE;
	}

	//////////////////////////////////////////////////////////////////////////

	// 10. Start IPC Server/Main/Graphic LCD Thread 
// 	pGLCDComm->Start();
// 	pGLCDComm->SendCommand(_T("t0.txt=\"\""));
	pGLCD->StartComm();
	Sleep(100);
	pGLCD->SendCommand(_T("page0.t0.txt=\"\""));
	pGLCD->SendCommand(_T("page1.t0.txt=\"\""));
	pGLCD->SendCommand(_T("page0.g0.txt=\"\""));
	pGLCD->SendCommand(_T("page1.g0.txt=\"\""));

	// 11. Start IPC Server
	PIpcServer->Start();

	// 12. Start main thread 
	PThread->Start();


	// 11. ���� �۾� ������ �ִ��� Ȯ���ϰ�, ������ ������ �ε��Ѵ�  
	//     pmac::PState�� ������ ����� �� ���� (���� ���� X)
// 	int currWorkNCFileIndex = pa::PNCFileMgr->GetCurrentWorkNCFileIndex();
// 	if( currWorkNCFileIndex != -1 )
// 	{
// 		pa::SNCFileInfo* p = pa::PNCFileMgr->GetNCFileInfo( currWorkNCFileIndex );
// 
// 		if( p->state == NCFILE_STATE_RUNNING ) {
// 			p->state = NCFILE_STATE_STOP;
// 			pa::PNCFileMgr->UpdateNCFileInfo( currWorkNCFileIndex, p );
// 		}
// 
// 		if( p->finish == 0 ) 
// 		{
// 			//////////////////////////////////////////////////////////////////////////
// 			// �� �� �۾��� �߰��� ����
// 			// ������ Open �Ѵ� 
// 			if( !pa::PThread->OpenNCFile( currWorkNCFileIndex, strErrMsg ) )
// 			{
// 				throw CPException( ERR_PNC, PNC_ERR_FILE_OPEN, strErrMsg );
// 			}
// 			CString str = PPAStatus->GetThreadState()->hNCFileInfo.file_name;
// 		}
// 	}
// 	else 
// 	{
// 		pa::PThread->CloseNCFile();
// 	}

	// �Ʒ� ����� ���� -> ������ ��� deselect �ϰ�, �ֱ� ����� ���ϵ� ���� �ʴ´� 
	pa::PThread->CloseNCFile();
	pa::PNCFileMgr->DeselectAllNCFiles( FALSE );

	//////////////////////////////////////////////////////////////////////////
	// 2017.09.02. �����ʱ�ȭ�� �߿� 
	PPAStatus->GetThreadState()->bCompleteResetOrigin_  = TRUE;		// �ʱ� ���� true, �������� ��� false
	//////////////////////////////////////////////////////////////////////////

	return TRUE;
}

void pa::PA_DESTROY()
{
	if( PThread ) {
		PThread->Stop();
	}
	if( PIpcServer ) {
		PIpcServer->Stop();
	}
	if( PContinueRunInfo ) {
		delete PContinueRunInfo;
		PContinueRunInfo = NULL;
	}

	Sleep(500);

	if( PIpcServer ) {
		delete PIpcServer;
		PIpcServer = NULL;
	}
	
	if( PThread ) {
		delete PThread;
		PThread = NULL;
	}

	if( PNCFileMgr  ) {
		delete PNCFileMgr;
		PNCFileMgr = NULL;
	}

	if( PNCFile ) {
		delete PNCFile;
		PNCFile = NULL;
	}

	if( PAMotion ) {
		delete PAMotion;
		PAMotion = NULL;
	}

	if( PAutoLoader ) {
		delete PAutoLoader;
		PAutoLoader = NULL;
	}

	if( PPAStatus ) {
		delete PPAStatus;
		PPAStatus = NULL;
	}

	if( PPAAsyncComm[0] ) {
		delete PPAAsyncComm[0];
		PPAAsyncComm[0] = NULL;
	}
	if( PPAAsyncComm[1] ) {
		delete PPAAsyncComm[1];
		PPAAsyncComm[1] = NULL;
	}

	if( PConfig ) {
		delete PConfig;
		PConfig = NULL;
	}

	if( P_LOG )
	{
		delete P_LOG;
		P_LOG = NULL;
	}

	if( PTool )
	{
		delete PTool;
		PTool = NULL;
	}

// 	if (pGLCDComm)
// 	{
// 		pGLCDComm->Stop();
// 	}
// 
// 	if ( pGLCDComm )
// 	{
// 		delete pGLCDComm;
// 		pGLCDComm = NULL;
// 	}
#ifdef _GLCD_SOCKET_ 
// 	((CGLCDCommEx*)pGLCD)->Destroy();
// 	delete ((CGLCDCommEx*)pGLCD);
#else 
	((CGLCDComm*)pGLCD)->Destroy();
	delete ((CGLCDComm*)pGLCD);
#endif 

}

void pa::INIT_TOTAL_LEFT_SPINDLE_RUN_TIME()
{
	TCHAR	*PATH = _T("..\\..\\Data\\EPnc\\rnd");
	FILE *pf = _tfopen( PATH, _T("rb") );

	if( pf == NULL ) {
		pf = _tfopen( _T("..\\..\\Data\\EPnc\\rnd"), _T("wb") );
		PPAStatus->GetThreadState()->dwTOTAL_LEFT_SPINDLE_RUN_TIME = 0;
		SAVE_TOTAL_LEFT_SPINDLE_RUN_TIME();
	}

	fread( (void*)&(PPAStatus->GetThreadState()->dwTOTAL_LEFT_SPINDLE_RUN_TIME), 1, sizeof(DWORD), pf );

	fclose( pf ); pf = NULL;
}

void pa::INIT_TOTAL_RIGHT_SPINDLE_RUN_TIME()
{
	TCHAR	*PATH = _T("..\\..\\Data\\EPnc\\rnd2");
	FILE *pf = _tfopen( PATH, _T("rb") );

	if( pf == NULL ) {
		pf = _tfopen( _T("..\\..\\Data\\EPnc\\rnd2"), _T("wb") );
		PPAStatus->GetThreadState()->dwTOTAL_RIGHT_SPINDLE_RUN_TIME = 0;
		SAVE_TOTAL_RIGHT_SPINDLE_RUN_TIME();
	}

	fread( (void*)&(PPAStatus->GetThreadState()->dwTOTAL_RIGHT_SPINDLE_RUN_TIME), 1, sizeof(DWORD), pf );

	fclose( pf ); pf = NULL;
}

void pa::SAVE_TOTAL_LEFT_SPINDLE_RUN_TIME()
{
	TCHAR	*PATH = _T("..\\..\\Data\\EPnc\\rnd");
	FILE *pf = _tfopen( PATH, _T("wb") );

	if( pf == NULL )
		return ;

	fwrite( (void*)&(PPAStatus->GetThreadState()->dwTOTAL_LEFT_SPINDLE_RUN_TIME), 1, sizeof(DWORD), pf );

	fclose( pf ); pf = NULL;
}

void pa::SAVE_TOTAL_RIGHT_SPINDLE_RUN_TIME()
{
	TCHAR	*PATH = _T("..\\..\\Data\\EPnc\\rnd2");
	FILE *pf = _tfopen( PATH, _T("wb") );

	if( pf == NULL )
		return ;

	fwrite( (void*)&(PPAStatus->GetThreadState()->dwTOTAL_RIGHT_SPINDLE_RUN_TIME), 1, sizeof(DWORD), pf );

	fclose( pf ); pf = NULL;
}

void pa::INIT_CLEAN_SPINDLE_RUN_TIME()
{
// 	TCHAR	*PATH = _T("/Flash Disk/clean");	//_T("/SD Card/EPNC/rnd")
	TCHAR	*PATH = _T("..\\..\\Data\\EPnc\\clean");
	FILE *pf = _tfopen( PATH, _T("rb") );

	if( pf == NULL ) {
// 		pf = _tfopen( _T("/SD Card/EPNC/clean"), _T("wb") );
		pf = _tfopen( _T("..\\..\\Data\\EPnc\\clean"), _T("wb") );
		PPAStatus->GetThreadState()->dwCLEAN_SPINDLE_RUN_TIME = 0;
		SAVE_CLEAN_SPINDLE_RUN_TIME();
	}

	fread( (void*)&(PPAStatus->GetThreadState()->dwCLEAN_SPINDLE_RUN_TIME), 1, sizeof(DWORD), pf );

	fclose( pf ); pf = NULL;

#ifdef _DEBUG
	CString strDbg;
	strDbg.Format( _T("CLEAN_SPINDLE_RUN_TIME : %d sec\n"), PPAStatus->GetThreadState()->dwCLEAN_SPINDLE_RUN_TIME );
	TRACE(strDbg);
// 	PPAStatus->GetThreadState()->dwCLEAN_SPINDLE_RUN_TIME = 500*60*60 + 12;
// 	SAVE_CLEAN_SPINDLE_RUN_TIME();
#endif
}

void pa::SAVE_CLEAN_SPINDLE_RUN_TIME()
{
//	TCHAR	*PATH = _T("/Flash Disk/clean");	//_T("/SD Card/EPNC/rnd")
	TCHAR	*PATH = _T("..\\..\\Data\\EPnc/clean");
	FILE *pf = _tfopen( PATH, _T("wb") );

	if( pf == NULL )
		return ;

	fwrite( (void*)&(PPAStatus->GetThreadState()->dwCLEAN_SPINDLE_RUN_TIME), 1, sizeof(DWORD), pf );

	fclose( pf ); pf = NULL;
}

void pa::RESET_CLEAN_SPINDLE_RUN_TIME()
{
	PPAStatus->GetThreadState()->dwCLEAN_SPINDLE_RUN_TIME = 0;

	SAVE_CLEAN_SPINDLE_RUN_TIME();
}

void pa::INIT_TOTAL_FILTER_TIME()
{
	TCHAR	*PATH = _T("..\\..\\Data\\EPnc\\Filter");
	FILE *pf = _tfopen( PATH, _T("rb") );

	if( pf == NULL ) {
		pf = _tfopen( _T("..\\..\\Data\\EPnc\\Filter"), _T("wb") );
		PPAStatus->GetThreadState()->dwTOTAL_FILTER_TIME = 0;
		SAVE_TOTAL_FILTER_TIME();
	}

	fread( (void*)&(PPAStatus->GetThreadState()->dwTOTAL_FILTER_TIME), 1, sizeof(DWORD), pf );

	fclose( pf ); pf = NULL;

#ifdef _DEBUG
	CString strDbg;
	strDbg.Format( _T("TOTAL_FILTER_RUN_TIME : %d sec\n"), PPAStatus->GetThreadState()->dwTOTAL_FILTER_TIME );
	TRACE(strDbg);
#endif
}

void pa::SAVE_TOTAL_FILTER_TIME()
{	
	TCHAR	*PATH = _T("..\\..\\Data\\EPnc\\Filter");
	FILE *pf = _tfopen( PATH, _T("wb") );

	if( pf == NULL )
		return ;

	fwrite( (void*)&(PPAStatus->GetThreadState()->dwTOTAL_FILTER_TIME), 1, sizeof(DWORD), pf );

	fclose( pf ); pf = NULL;
}

void pa::READ_TODAY_SPINDLE_RUN_TIME()
{
	SYSTEMTIME	stm;
	CString		filepath;

	GetLocalTime( &stm );
	filepath.Format( _T("%s\\%04d_%02d_%02d_spindle_runtime.log"), 
	//	SPINDLE_LOG_PATH, 
		LOG_SPINDLE_PATH,
		stm.wYear, stm.wMonth, stm.wDay );

	FILE* pf = _tfopen( filepath, _T("rt") );

	if( pf == NULL ) 
	{
		pf = _tfopen( filepath, _T("wt") );
		todaySpindleRunTime = 0;
		pa::WRITE_TODAY_SPINDLE_RUN_TIME( stm );
	}
	else 
	{
	//	fscanf( pf, "%u", &todaySpindleRunTime );
		_ftscanf( pf, _T("%u"), &todaySpindleRunTime );

		currentReadWriteTime = stm;

		fclose( pf );
		pf = NULL;
	}
}

void pa::WRITE_TODAY_SPINDLE_RUN_TIME(SYSTEMTIME stm)
{
	CString		filePath;
	
// 	filePath.Format( _T("%s\\%04d_%02d_%02d_spindle_runtime.log"), SPINDLE_LOG_PATH, stm.wYear, stm.wMonth, stm.wDay );
	filePath.Format( _T("%s\\%04d_%02d_%02d_spindle_runtime.log"), LOG_SPINDLE_PATH, stm.wYear, stm.wMonth, stm.wDay );
	FILE *pf = _tfopen( filePath, _T("wt") );

	if( pf == NULL ) {
		return ;
	}

	_ftprintf( pf, _T("%u"), todaySpindleRunTime );

	fclose( pf ); 
	
	pf = NULL;
}

// keeping day ���� ������ ���� �Ѵ� 
void pa::DELETE_TODAY_SPINDLE_RUN_TIME(int nKeepingDays)
{
//	pa::DELETE_OLD_FILE( nKeepingDays, _T("log"), SPINDLE_LOG_PATH );
	pa::DELETE_OLD_FILE( nKeepingDays, _T("log"), LOG_SPINDLE_PATH );
}

void pa::CREATE_NECESSARY_DIRECTORIES()
{
	CreateDirectory( NCFILE_PATH, NULL );
	CreateDirectory( LOG_PATH, NULL );
//	CreateDirectory( SPINDLE_LOG_PATH, NULL );
	CreateDirectory( LOG_SPINDLE_PATH, NULL );
}

//////////////////////////////////////////////////////////////////////////
//

void pa::ShowConnectFailDialog( int nCount )
{
	CString strTitle;
	CString strErrMsg;
	CString strTemp;
	strTitle.Format( _T(" Connection Fail ") );

	strErrMsg.Format( _T("") );
	strTemp.Format( _T(" Not conencted to the motion-controller. (connection=%d) \r\n"), nCount ); strErrMsg += strTemp;
	strTemp.Format( _T(" turn off power and checking the items. \r\n")); strErrMsg += strTemp;
	strTemp.Format( _T("\r\n") ); strErrMsg += strTemp;
	strTemp.Format( _T("  > checking.. lan cable connection with motion controller \r\n") ); strErrMsg += strTemp;
	strTemp.Format( _T("  > checking.. pc and motion controller's ip-address \r\n") ); strErrMsg += strTemp;
	strTemp.Format( _T("  > checking.. motion-controller power-on \r\n") ); strErrMsg += strTemp;

	CErrorDlg dlg;
	dlg.SetTitle( strTitle );
	dlg.SetMessage( strErrMsg );
	dlg.SetButtonStatus( FALSE );
	dlg.DoModal();
}

int pa::ShowPowerOnTestFailDialog( DWORD dwErrCode, DWORD dwSysErrCode, int nRespErrCode, int nRespSysErrCode, BOOL coord_offset, BOOL teach_point, BOOL multi_origin, BOOL cleaning_timeout )
{
	/*
	enum EN_SMCT_ERR
	{
	SMCT_ERR_TOOL_TOUCH_SENSOR_ERROR	= 0x00000001,
	SMCT_ERR_001						= 0x00000002,
	SMCT_ERR_X_AXIS_LIMIT_SENSOR		= 0x00000004,
	SMCT_ERR_Y_AXIS_LIMIT_SENSOR		= 0x00000008,

	SMCT_ERR_Z_AXIS_LIMIT_SENSOR		= 0x00000010,
	SMCT_ERR_IO_BOARD_COMM				= 0x00000020,
	SMCT_ERR_002						= 0x00000040,
	SMCT_ERR_COLLING_PAN				= 0x00000080,

	SMCT_ERR_003						= 0x00000100,
	SMCT_ERR_SPINDLE_DRIVER_COMM		= 0x00000200,
	SMCT_ERR_CONTROLLER_ERR_STATE		= 0x00000400,
	SMCT_ERR_MAIN_AIR					= 0x00000800,

	SMCT_ERR_TEACHINGPOINT_AND_SYSTEM_PARAM_OUT_OF_RANGE	= 0x00001000,
	SMCT_ERR_LICENSE_CHECK_FAILED		= 0x00002000
	};

	enum EN_RISMCT_ERR
	{
	RISMCT_ERR_001						= 0x00000001,	// 1
	RISMCT_ERR_ACCDEC					= 0x00000002,	// 2
	RISMCT_ERR_MAX_SPD					= 0x00000004,	// 3
	RISMCT_ERR_AXIS_DIR					= 0x00000008,	// 4
	RISMCT_ERR_ORG_SPD					= 0x00000010,	// 5
	RISMCT_ERR_002						= 0x00000020,	// 6
	RISMCT_ERR_ORG_DIR					= 0x00000040,	// 7

	RISMCT_ERR_004						= 0x00000080,	// 8
	RISMCT_ERR_005						= 0x00000100,	// 9
	RISMCT_ERR_006						= 0x00000200,	// 10 
	RISMCT_ERR_007						= 0x00000300,	// 11
	RISMCT_ERR_008						= 0x00000400,	// 12
	RISMCT_ERR_SOL_TIMEOUT				= 0x00001000	// 13
	};
	*/
	static CString ERR_MSG[] = {
		_T(" > Touch sensor1 error \r\n"),
		_T(" > Touch sensor2 error \r\n" ),
		_T(" > X Axis limit sensor error \r\n"),
		_T(" > Y Axis limit sensor error \r\n"),

		_T(" > Z Axis limit sensor error \r\n"),
		_T(" > I/O board communication error \r\n"),
		_T(" > ERR 002 \r\n"),
		_T(" > Colling pan error \r\n"),
		
		_T(" > Spindle driver Communication2 error \r\n"),
		_T(" > Spindle driver communication error \r\n"),
		_T(" > Controller error status \r\n"),
		_T(" > Main air limit error \r\n"),

		_T(" > Teaching point and system parameter out of range \r\n"),
		_T(" > License checking fail \r\n")
	};
	static CString ERR_MSG2[] = {
		_T(" > ERR 001\r\n"),
		_T(" > Acc/Dec data error\r\n"),
		_T(" > max speed error\r\n"),
		_T(" > axis direction error\r\n"),
		_T(" > origin speed error\r\n"),
		_T(" > ERR 002\r\n"),
		_T(" > origin direction error\r\n"),

		_T(" > ERR 004\r\n"),
		_T(" > ERR 005\r\n"),
		_T(" > ERR 006\r\n"),
		_T(" > ERR 007\r\n"),
		_T(" > ERR 008\r\n"),
		_T(" > sol timeout\r\n")
	};

	CString strTitle;
	CString strErrMsg;
	CString strTemp;
	DWORD	dwMask = 0x00000001;
	int		nShowDlg = 0;

	strTitle.Format( _T(" PowerOn Test Message ") );
	strErrMsg.Format( _T("") );

	P_LOG->WriteLog( CLog::TYPE_OPER, 0, _T("PowerOnTest Log") );

	if( dwErrCode != 0 )
	{
		if( dwErrCode == 99999 ) 
		{
			// ���� ���信 ���� E-nnn. nRespErrCode�� ���� �ڵ�
			strTitle.Format( _T("SMCT ERROR [%d]\n"), nRespErrCode );
			strErrMsg += strTitle;
			nShowDlg = 1;
		}
		else 
		{
			dwMask = 0x00000001;
			for( int i = 0; i < 14; i++ )
			{
				if( (dwErrCode & dwMask) == dwMask )
				{
					strErrMsg += ERR_MSG[i];
					if (i == 5)	// I/O Board Connection fail
					{
						pa::PPAStatus->GetThreadState()->nIsConnectedIOBoard = 0;
					}
					P_LOG->WriteLog( CLog::TYPE_OPER, 0, ERR_MSG[i] );
					nShowDlg = 1;
				}

				dwMask <<= 1;
			}
		}
	}

	if( dwSysErrCode != 0 )
	{
		if( dwSysErrCode == 99999 )
		{
			// ���� ������ E-nnn. nRespErrCode�� ���� �ڵ�
			strTemp.Format( _T("RISM ERROR [%d]\n"), nRespSysErrCode );
			P_LOG->WriteLog( CLog::TYPE_OPER, 0, strTemp );
			strErrMsg += strTemp;
			nShowDlg = 1;
		}
		else 
		{
			strTemp.Format( _T("\r\n") ); strErrMsg += strTemp;
			strTemp.Format( _T("System param error : %d\n\r"), dwSysErrCode ); strErrMsg += strTemp;
			P_LOG->WriteLog( CLog::TYPE_OPER, 0, strTemp );
			strErrMsg += ERR_MSG2[dwSysErrCode-1];
			P_LOG->WriteLog( CLog::TYPE_OPER, 0, ERR_MSG2[dwSysErrCode-1] );
			nShowDlg = 1;
		}
	}

	if( coord_offset == FALSE || teach_point == FALSE || multi_origin == FALSE )
	{
		strTemp.Format( _T("system parameter error :\r\n") ); strErrMsg += strTemp;
		if( coord_offset == FALSE )
		{
			strTemp.Format( _T(" > coordinate offset range error \r\n") );
			P_LOG->WriteLog( CLog::TYPE_OPER, 0, strTemp );
			strErrMsg += strTemp;
			nShowDlg = 1;
		}

		if( teach_point == FALSE )
		{
			strTemp.Format( _T(" > teaching point range error \r\n") );
			P_LOG->WriteLog( CLog::TYPE_OPER, 0, strTemp );
			strErrMsg += strTemp;
			nShowDlg = 1;
		}

		if( multi_origin == FALSE )
		{
			strTemp.Format( _T(" > multiorigin offset range error \r\n" ) );
			P_LOG->WriteLog( CLog::TYPE_OPER, 0, strTemp );
			strErrMsg += strTemp;
			nShowDlg = 1;
		}
	}

	if( cleaning_timeout == TRUE )
	{
		strTemp.Format( _T("Need Cleaning ... \r\n") ); strErrMsg += strTemp;
		P_LOG->WriteLog( CLog::TYPE_OPER, 0, strTemp );
		strTemp.Format( _T(" > cooling water tank \r\n") ); strErrMsg += strTemp;
		P_LOG->WriteLog( CLog::TYPE_OPER, 0, strTemp );
		nShowDlg = 1;
	}

	int nRet = IDOK;
	if( nShowDlg != 0 )
	{
		CErrorDlg dlg;
		dlg.SetTitle( strTitle );
		dlg.SetMessage( strErrMsg );
		dlg.SetButtonStatus( TRUE );
		nRet = dlg.DoModal();
	}

	return nRet;
}

void pa::ShowPowerOffDialog()
{
	CString strTitle;
	CString strErrMsg;

	strTitle.Format( _T(" Turn off power ") );
	strErrMsg.Format( _T(" > turn off power ") );

	CErrorDlg dlg;
	dlg.SetTitle( strTitle );
	dlg.SetMessage( strErrMsg );
	dlg.SetButtonStatus( FALSE );
	dlg.DoModal();
}

// Coordinate Offset ���� ������ �� �Ѵ�
BOOL pa::CHECK_COORD_OFFSET_RANGE()
{
	double	fx_min = pa::PPAStatus->GetCoordinateOffsetDataRange()->fMin[pa::AXIS_X];
	double	fx_max = pa::PPAStatus->GetCoordinateOffsetDataRange()->fMax[pa::AXIS_X];
	double	fy_min = pa::PPAStatus->GetCoordinateOffsetDataRange()->fMin[pa::AXIS_Y];
	double	fy_max = pa::PPAStatus->GetCoordinateOffsetDataRange()->fMax[pa::AXIS_Y];
	double	fz_min = pa::PPAStatus->GetCoordinateOffsetDataRange()->fMin[pa::AXIS_Z];
	double	fz_max = pa::PPAStatus->GetCoordinateOffsetDataRange()->fMax[pa::AXIS_Z];
	double	z_org_offset = 0.0; 

	// X, Y�� ��. 
	// �񱳴� G54���� 
	for( int i = (int)COORD_G54; i<(int)COORD_NUM; i++ )
	{
		double fx = pa::PConfig->pConfig_->fCoordOffset[i][pa::AXIS_X];
		double fy = pa::PConfig->pConfig_->fCoordOffset[i][pa::AXIS_Y];

		if( fx < fx_min || fx > fx_max ) {
			return FALSE;
		}
		if( fy < fy_min || fy > fy_max ) {
			return FALSE;
		}
	}

	// Z�� �� 
// 	z_org_offset = PConfig->pConfig_->fOptionData[OPTION_ZAXIS_ORIGIN_OFFSET];
// 	if( z_org_offset < fz_min && z_org_offset > fz_max )
// 	{
// 		return FALSE;
// 	}

	return TRUE;
}

BOOL pa:: CHECK_TEACH_POINT_RANGE()
{
	int		nCheckPoint[] = 
	{
		TEACHING_POINT_LEFT_TOOL1, TEACHING_POINT_LEFT_TOOL2, TEACHING_POINT_LEFT_TOOL3, 
		TEACHING_POINT_RIGHT_TOOL4, TEACHING_POINT_RIGHT_TOOL5, TEACHING_POINT_RIGHT_TOOL6, TEACHING_POINT_READYPOS,
		TEACHING_POINT_SENSING_UP1, TEACHING_POINT_SENSING_DN1, TEACHING_POINT_SENSING_UP2, TEACHING_POINT_SENSING_DN2
	};
	double	fx_min	= pa::PPAStatus->GetPowerOnTestConfig()->toolpocket_x_min;
	double	fx_max	= pa::PPAStatus->GetPowerOnTestConfig()->toolpocket_x_max;
	double	fy_min	= pa::PPAStatus->GetPowerOnTestConfig()->toolpocket_y_min;
	double	fy_max	= pa::PPAStatus->GetPowerOnTestConfig()->toolpocket_y_max;

	if( pa::PPAStatus->GetPowerOnTestConfig()->IsLoaded == 0 )
	{
		return FALSE;
	}

	// Tool Pocket ��ġ�� ���� �ȿ� ����ִ��� Ȯ���Ѵ� 
	for( int i = 0; i<TEACHING_POINT_NUM; i++ )
	{
		double fx = pa::PConfig->pConfig_->fTeachingPoint[nCheckPoint[i]][pa::AXIS_X];
		double fy = pa::PConfig->pConfig_->fTeachingPoint[nCheckPoint[i]][pa::AXIS_Y];

		if( fx < fx_min || fx > fx_max ) {
			return FALSE;
		}
		if( fy < fy_min || fy > fy_max ) {
			return FALSE;
		}
	}

	return TRUE;
}

BOOL pa::CHECK_MULTIORIGIN_RANGE()
{
	int		nNumGCode = pa::PPAStatus->GetMultiOriginData()->nNumGCode;

	double	fmin = pa::PPAStatus->GetMultiOriginData()->fOffset_Min_;
	double	fmax = pa::PPAStatus->GetMultiOriginData()->fOffset_Max_;

	for( int i = 0; i<nNumGCode; i++ )
	{
		for( int j = 0; j<pa::PPAStatus->GetMultiOriginData()->hMultiOrigin[i].nNumSubCoord; j++ )
		{
			for( int k = 3; k<6; k++ )
			{
				double fVal = pa::PPAStatus->GetMultiOriginData()->hMultiOrigin[i].fOffset[j][k];
				if( fVal < fmin || fVal > fmax ) 
				{
					return FALSE;
				}
			}
		}
	}

	return TRUE;
}

//////////////////////////////////////////////////////////////////////////

