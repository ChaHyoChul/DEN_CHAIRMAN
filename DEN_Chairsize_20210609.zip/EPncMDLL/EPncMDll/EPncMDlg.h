#pragma once


class CLCDAliveSender : public CGeneralThread
{
private:
	virtual void Execute();
};

// CEPncMDlg ��ȭ �����Դϴ�.

class CEPncMDlg : public CDialog
{
	DECLARE_DYNAMIC(CEPncMDlg)

private:
	HANDLE hEvent_;
	int isInitSuccess_;

	CLCDAliveSender hLCDAliveSender_;


public:
	CEPncMDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CEPncMDlg();

	int GetInitSuccess()
	{
		return isInitSuccess_;
	}

// ��ȭ ���� �������Դϴ�.
	enum { IDD = 106 }; //IDD_DIALOG_EPNCM };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT_PTR nIDEvent);

	static void WRITE_DIFF_TIME_LOG(DWORD dwDiffTick);
};


