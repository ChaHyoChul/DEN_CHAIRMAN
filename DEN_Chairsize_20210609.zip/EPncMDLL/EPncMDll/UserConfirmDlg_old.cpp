// UserConfirmDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncMDll.h"
#include "UserConfirmDlg.h"


// CUserConfirmDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CUserConfirmDlg, CDialog)

CUserConfirmDlg::CUserConfirmDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUserConfirmDlg::IDD, pParent)
{

}

CUserConfirmDlg::~CUserConfirmDlg()
{
}

void CUserConfirmDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CUserConfirmDlg, CDialog)
END_MESSAGE_MAP()


// CUserConfirmDlg �޽��� ó�����Դϴ�.
