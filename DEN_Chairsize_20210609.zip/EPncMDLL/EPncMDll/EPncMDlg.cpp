// EPncMDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncMDLL.h"
#include "EPncMDlg.h"
#include "AutoCalDlg.h"

// CEPncMDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CEPncMDlg, CDialog)

CEPncMDlg::CEPncMDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEPncMDlg::IDD, pParent)
{
	hEvent_ = NULL;
	isInitSuccess_ = 1;	// �ʱ� ������ 1�� ����. ������ �� 0���� �ٲ۴�.
}

CEPncMDlg::~CEPncMDlg()
{
	
}

void CEPncMDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CEPncMDlg, CDialog)
	ON_WM_DESTROY()
	ON_WM_TIMER()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CEPncMDlg �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CEPncMDlg::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
	{
		return TRUE;
	}

	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CEPncMDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	//
	CString strErrMsg(_T(""));

	CString		strConfigFilePath;
	CCEIniFile	hIniFile;

	strConfigFilePath = CString( INI_PA_CONFIG_PATH );

	hIniFile.Open( strConfigFilePath );
	hIniFile.GetValue( _T("PA"), _T("IpAddr"), (CString*)&theApp.strIpAddr );
	hIniFile.GetValue( _T("PA"), _T("PortNo1"), (int*)&theApp.nPortNo1 );
	hIniFile.GetValue( _T("PA"), _T("PortNo2"), (int*)&theApp.nPortNo2 );
	hIniFile.GetValue( _T("PA"), _T("PortNoForStream"), (int*)&theApp.nPortNoForStream );

	memset((void*)theApp.szIpAddr, 0, sizeof(char)*64);

	hcutil::CSTRING_TO_ASCII( theApp.strIpAddr, theApp.szIpAddr, 63 );

	// port1 = 10100
	// port2 = 10000
	if( pa::PA_INITIALIZE( theApp.szIpAddr, theApp.nPortNo1, theApp.nPortNo2, theApp.nPortNoForStream, strErrMsg ) == FALSE ) { 
		//AfxMessageBox( strErrMsg, MB_OK|MB_ICONERROR );
		isInitSuccess_ = 0;
		CDialog::OnCancel();
		return FALSE;
	}

	//////////////////////////////////////////////////////////////////////////
	// ������ ����Ѵ� 
	memset((void*)pa::PPAStatus->GetThreadState()->szMotionProgVersion, 0, sizeof(TCHAR)*128 );
	_stprintf_s( pa::PPAStatus->GetThreadState()->szMotionProgVersion, 
		127,
		_T("%s"),
		theApp.P_VERSION );
#ifdef _SAVE_RUNTIME_
	_tcscat( pa::PPAStatus->GetThreadState()->szMotionProgVersion, _T("-SRT") );
#endif
	_stprintf_s( pa::PPAStatus->GetThreadState()->szPAControllerVersion, 
		127,
		_T("%s"),
		pa::CPAAsyncComm::SZ_PA_CTRL_VER );

	_stprintf_s( pa::PPAStatus->GetThreadState()->szPA_IP_ARRD, 
		32, 
		_T("%s"),
		pa::CPAAsyncComm::SZ_PA_IP_ADDR );

	_stprintf_s( pa::PPAStatus->GetThreadState()->szCANTOPS_IP_ADDR, 
		32, 
		_T("%s"),
		pa::CPAAsyncComm::SZ_CANTOPS_IP_ADDR );
	//////////////////////////////////////////////////////////////////////////
	//
	CUserConfirmDlg::INITIALIZE_DLG();
	CHomeDlg::INITIALIZE_DLG();
	CAutoCalDlg::INITIALIZE_DLG();

	//////////////////////////////////////////////////////////////////////////
	//
	pa::INIT_TOTAL_LEFT_SPINDLE_RUN_TIME();
	pa::INIT_TOTAL_RIGHT_SPINDLE_RUN_TIME();
	pa::INIT_TOTAL_FILTER_TIME();
	pa::READ_TODAY_SPINDLE_RUN_TIME();
	// 	pa::INIT_CLEAN_SPINDLE_RUN_TIME();

// 	CString strTemp[2];
// 	//int count = hcsock::GET_IP_ADDRESS( strTemp, 2 );
// 	memset((void*)(pa::PPAStatus->GetThreadState()->szIpAddress), 0, sizeof(TCHAR)*64);
// 	_stprintf_s( pa::PPAStatus->GetThreadState()->szIpAddress, 63, _T("%s / %s\n\n"), strTemp[0], strTemp[1] );
// 	TRACE( pa::PPAStatus->GetThreadState()->szIpAddress );

	CString strTemp[3];
	int count = hcsock::GET_IP_ADDRESS( strTemp, 3 );
	memset((void*)(pa::PPAStatus->GetThreadState()->szIpAddress), 0, sizeof(TCHAR)*64);
	_stprintf_s( pa::PPAStatus->GetThreadState()->szIpAddress, 63, _T("%s / %s\n\n"), strTemp[0], _T("") );
	TRACE( pa::PPAStatus->GetThreadState()->szIpAddress );

	//////////////////////////////////////////////////////////////////////////
	//
	SetTimer( 1, 1000, NULL );
	SetTimer( 2, 10*1000, NULL );	// 10 �ʿ� �ѹ��� ���� �۾� ���� ��ȣ�� (SD �޸𸮿�)�����Ѵ�
	SetTimer( 3, 1000, NULL );
	SetTimer( 4, 1000, NULL );		// 0.2�ʿ� �ѹ���, PA������ ������¸� �����Ѵ� 
	SetTimer( 5, 3000, NULL );		// 1.4�ʿ� �ѹ��� GLCD�� Alive ��ȣ�� ������ 

	//////////////////////////////////////////////////////////////////////////
	// UI ���α׷��� �����ϱ� ����, event�� signal ���·� ����� 
	hEvent_ = OpenEvent( EVENT_ALL_ACCESS, FALSE, _T("EVT_EPNCM") );
	if( hEvent_ != NULL ) {
		SetEvent( hEvent_ );
	}
	//////////////////////////////////////////////////////////////////////////

	hLCDAliveSender_.Create(1500, IThread::ThreadType_Continue, NULL, 0);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CEPncMDlg::OnDestroy()
{
	CDialog::OnDestroy();

	CUserConfirmDlg::DELETE_DLG();
	CHomeDlg::DELETE_DLG();
	CAutoCalDlg::DELETE_DLG();

	if (pa::PTool)
	{
		pa::PTool->Destroy();
	}

	CloseHandle( hEvent_ );

	KillTimer( 1 );
	KillTimer( 2 );
	KillTimer( 3 );

	pa::PA_DESTROY();
}

void CEPncMDlg::OnTimer(UINT_PTR nIDEvent)
{
	//////////////////////////////////////////////////////////////////////////
	// 
	BOOL	bSaveSelectedLogFiles_;			// �⺻ FALSE, TRUE�̸� UI ���α׷����� �α� ������ ������ �� FALSE�� ����� 
	char	szSelectedLogFiles_[1024*6];	// ���õ� �α� ������ ������ ���´� 
	int		nNumSelectLogFiles_;			// ���õ� �α� ������ ���� 
	int		nLenSelectLogFiles_;			// �α� ���� ���� ���� 
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetRunMode();

	if( nIDEvent == 1 ) 
	{
		// 1000 msec
		//////////////////////////////////////////////////////////////////////////
		// ���� ������� Tool ���ð� ī��Ʈ 
		static int LEFT_SPINDLE_RUN = 0;
		static int RIGHT_SPINDLE_RUN = 0;
		static DWORD RUN_SPINDLE_TIME = GetTickCount();
		static DWORD RUN_SPINDLE_TIME2 = GetTickCount();
		static DWORD RUN_SPINDLE_TIME3 = GetTickCount();
		static DWORD ERR_SPINDLE_TIME = 0;
		static DWORD ERR_SPINDLE_TIME2 = 0;
		static DWORD ERR_SPINDLE_TIME3 = 0;
		SYSTEMTIME currentReadWriteTime = pa::currentReadWriteTime;
		SYSTEMTIME newTime;
		int toolNo		= pa::PPAStatus->GetPAStatus()->nCurrentToolNo;
		int toolNo2		= pa::PPAStatus->GetPAStatus()->nCurrentTool2No;
		int spindleRun	= pa::PPAStatus->GetPAStatus()->nSpindleRun;
		int spindle2Run = pa::PPAStatus->GetPAStatus()->nSpindle2Run;

		GetLocalTime( &newTime );

		if( spindleRun != 0 && spindle2Run == 0)
		{
			DWORD dwPrevSpindleTime = RUN_SPINDLE_TIME;
			DWORD dwDbg;
			dwDbg = RUN_SPINDLE_TIME = GetTickCount();
			ERR_SPINDLE_TIME += RUN_SPINDLE_TIME - dwPrevSpindleTime;
			DWORD spindle_run_time = ERR_SPINDLE_TIME / 1000;
			ERR_SPINDLE_TIME %= 1000;

#ifdef _DEBUG 
			CString str;
			str.Format( _T("Left tool inc. time : [%d] %d - %d\n"), dwDbg, spindle_run_time, ERR_SPINDLE_TIME );
			TRACE(str);
#endif 

			// ���� ������� ���ð� ���� 
			pa::PTool->IncToolUsingTime( toolNo, spindle_run_time );	

			// �� ���ð� ���� 
			pa::PPAStatus->GetThreadState()->dwTOTAL_LEFT_SPINDLE_RUN_TIME += spindle_run_time;

			// cleaning �� ���, run ����϶��� ���ð��� ���� �Ѵ� => �ϴ� ����. �ǹ� ���� �� 
			// �ð� ������ ���� ������ �ǹ̸� �ٸ��� ����ϱ� ������, run ��带 Ȯ���ص� ������ 
			pa::PPAStatus->GetThreadState()->dwCLEAN_SPINDLE_RUN_TIME += spindle_run_time;	

			pa::PPAStatus->GetThreadState()->dwTOTAL_FILTER_TIME += spindle_run_time;

			// pa::todaySpindleRunTime++;
			pa::todaySpindleRunTime += spindle_run_time;

			if( currentReadWriteTime.wDay != newTime.wDay ) {
				pa::WRITE_TODAY_SPINDLE_RUN_TIME( currentReadWriteTime );
				pa::currentReadWriteTime = newTime;
				pa::todaySpindleRunTime = 0;
			}
		}

		else
		{
			RUN_SPINDLE_TIME = GetTickCount();
			ERR_SPINDLE_TIME = 0;
		}

		if ( spindleRun == 0 && spindle2Run != 0 )
		{
			DWORD dwPrevSpindleTime = RUN_SPINDLE_TIME2;
			DWORD dwDbg;
			dwDbg = RUN_SPINDLE_TIME2 = GetTickCount();
			ERR_SPINDLE_TIME2 += RUN_SPINDLE_TIME2 - dwPrevSpindleTime;
			DWORD spindle_run_time = ERR_SPINDLE_TIME2 / 1000;
			ERR_SPINDLE_TIME2 %= 1000;

#ifdef _DEBUG 
			CString str;
			str.Format( _T("Right tool inc. time : [%d] %d - %d\n"), dwDbg, spindle_run_time, ERR_SPINDLE_TIME2 );
			TRACE(str);
#endif 

			// ���� ������� ���ð� ���� 
			pa::PTool->IncToolUsingTime( toolNo2, spindle_run_time );	

			// �� ���ð� ���� 
			pa::PPAStatus->GetThreadState()->dwTOTAL_RIGHT_SPINDLE_RUN_TIME += spindle_run_time;

			// cleaning �� ���, run ����϶��� ���ð��� ���� �Ѵ� => �ϴ� ����. �ǹ� ���� �� 
			// �ð� ������ ���� ������ �ǹ̸� �ٸ��� ����ϱ� ������, run ��带 Ȯ���ص� ������ 
			pa::PPAStatus->GetThreadState()->dwCLEAN_SPINDLE_RUN_TIME += spindle_run_time;	

			pa::PPAStatus->GetThreadState()->dwTOTAL_FILTER_TIME += spindle_run_time;

			// pa::todaySpindleRunTime++;
			pa::todaySpindleRunTime += spindle_run_time;

			if( currentReadWriteTime.wDay != newTime.wDay ) {
				pa::WRITE_TODAY_SPINDLE_RUN_TIME( currentReadWriteTime );
				pa::currentReadWriteTime = newTime;
				pa::todaySpindleRunTime = 0;
			}
		}
		else
		{
			RUN_SPINDLE_TIME2 = GetTickCount();
			ERR_SPINDLE_TIME2 = 0;
		}

		if ( spindleRun != 0 && spindle2Run != 0 )
		{
			DWORD dwPrevSpindleTime = RUN_SPINDLE_TIME3;
			DWORD dwDbg;
			dwDbg = RUN_SPINDLE_TIME3 = GetTickCount();
			ERR_SPINDLE_TIME3 += RUN_SPINDLE_TIME3 - dwPrevSpindleTime;
			DWORD spindle_run_time = ERR_SPINDLE_TIME3 / 1000;
			ERR_SPINDLE_TIME3 %= 1000;

#ifdef _DEBUG 
			CString str;
			str.Format( _T("Left, Right tool inc. time : [%d] %d - %d\n"), dwDbg, spindle_run_time, ERR_SPINDLE_TIME3 );
			TRACE(str);
#endif 
			// ���� ������� ���ð� ����
			pa::PTool->IncToolUsingTime( toolNo, spindle_run_time );
			pa::PTool->IncToolUsingTime( toolNo2, spindle_run_time );

			// �� ���ð� ����
			pa::PPAStatus->GetThreadState()->dwTOTAL_LEFT_SPINDLE_RUN_TIME += spindle_run_time;
			pa::PPAStatus->GetThreadState()->dwTOTAL_RIGHT_SPINDLE_RUN_TIME += spindle_run_time;

			pa::PPAStatus->GetThreadState()->dwCLEAN_SPINDLE_RUN_TIME += spindle_run_time;

			pa::PPAStatus->GetThreadState()->dwTOTAL_FILTER_TIME += spindle_run_time;

			// pa::todaySpindleRunTime++;
			pa::todaySpindleRunTime += spindle_run_time;

			if( currentReadWriteTime.wDay != newTime.wDay ) {
				pa::WRITE_TODAY_SPINDLE_RUN_TIME( currentReadWriteTime );
				pa::currentReadWriteTime = newTime;
				pa::todaySpindleRunTime = 0;
			}
		}
		else
		{
			RUN_SPINDLE_TIME3 = GetTickCount();
			ERR_SPINDLE_TIME3 = 0;
		}

		//////////////////////////////////////////////////////////////////////////
		// ���ɵ��� ���ٰ� ���߾��� ��, ���� �ð��� ���� �Ѵ� 
		if( LEFT_SPINDLE_RUN != 0 && spindleRun==0 ) {
			// ���ð� ���� 
			// ���� ������� ���ð� ���� 
			pa::PTool->SaveToolUsingTimeAll();
			// �� ���ð� ���� 
			pa::SAVE_TOTAL_LEFT_SPINDLE_RUN_TIME();
			// û�� �˸� ���ð� ���� 
			pa::SAVE_CLEAN_SPINDLE_RUN_TIME();
			// ���� �˸� ���ð� ����
			pa::SAVE_TOTAL_FILTER_TIME();
			// 
			pa::WRITE_TODAY_SPINDLE_RUN_TIME( currentReadWriteTime );
		}

		if( LEFT_SPINDLE_RUN != spindleRun ) {
			LEFT_SPINDLE_RUN = spindleRun;
		}

		if (RIGHT_SPINDLE_RUN != 0 && spindle2Run==0) {
			pa::PTool->SaveToolUsingTimeAll();
			pa::SAVE_TOTAL_RIGHT_SPINDLE_RUN_TIME();
			pa::SAVE_CLEAN_SPINDLE_RUN_TIME();
			pa::SAVE_TOTAL_FILTER_TIME();
			pa::WRITE_TODAY_SPINDLE_RUN_TIME( currentReadWriteTime );
		}

		if( RIGHT_SPINDLE_RUN != spindle2Run ) {
			RIGHT_SPINDLE_RUN = spindle2Run;
		}

		//////////////////////////////////////////////////////////////////////////
		// Running ���̸�, �۾��ð� ī��Ʈ 

		//////////////////////////////////////////////////////////////////////////
		// run ����� ��쿡�� �ð��� ���� ��Ų��
		//	- Maxxlink �����ϸ鼭 �����ð��� �����Ǵ� ���� ������ IncRunningTime() �Լ� ���� 
		pa::PPAStatus->IncRunningTime( (hRunMode == pa::RUNMODE_RUN) ? TRUE : FALSE );
		//////////////////////////////////////////////////////////////////////////

		if( hRunMode == pa::RUNMODE_RUN ) {
			//////////////////////////////////////////////////////////////////////////
			// 2017.01.05
			int currLineNo = pa::PPAStatus->GetThreadState()->nCurrentNCCodeStepNo; //pmac::PState->GetPmacState()->nCurrentNCCodeStepNo;
			int firstToolChangeLineNo =	pa::PPAStatus->GetThreadState()->nNCFileInfo_FirstToolChageLine;	// pmac::PState->GetThreadState()->nNCFileInfo_FirstToolChageLine;
			int secondToolChangeLineNo = pa::PPAStatus->GetThreadState()->nNCFileInfo_SecondToolChageLine;	// pmac::PState->GetThreadState()->nNCFileInfo_SecondToolChageLine;
			//////////////////////////////////////////////////////////////////////////

			//	pa::PPAStatus->IncRunningTime();

			//////////////////////////////////////////////////////////////////////////
			// 2017.01.05
			// If before Tool Change 2? increment first half. Increment second half otherwise.
			if (currLineNo < secondToolChangeLineNo) {
				if (currLineNo != firstToolChangeLineNo) {
					//	pmac::PState->IncFirstHalfRunningTime();
					pa::PPAStatus->IncFirstHalfRunningTime();
				}
			} else {
				if (currLineNo != secondToolChangeLineNo) {
					//	pmac::PState->IncSecondHalfRunningTime();
					pa::PPAStatus->IncSecondHalfRunningTime();
				}
			}
			//////////////////////////////////////////////////////////////////////////
		}
	}
	else if( nIDEvent == 2 ) 
	{
		// 10x1000 msec
		//////////////////////////////////////////////////////////////////////////
		// 10�ʿ� �ѹ��� Machining Line ��ȣ�� �����Ѵ� 
		if( ( hRunMode == pa::RUNMODE_RUN || hRunMode == pa::RUNMODE_PAUSE ) &&
			( pa::PThread->GetStep( pa::RUNMODE_RUN ) < 20000 ) )
		{
			//	pa::PPAStatus->SetNCFileMachiningLine( pa::PPAStatus->GetThreadState()->nCurrentNCCodeStepNo, TRUE );
		}
	}
	else if( nIDEvent == 3 )
	{
		// 1000 msec
		//////////////////////////////////////////////////////////////////////////
		KillTimer( 3 );

		// User Confirm Dialog 
		pa::PPAStatus->GetThreadState()->bIsShowUserConfirmDlg	= CUserConfirmDlg::IS_SHOW_DLG();
		// Origin Dialog
		pa::PPAStatus->GetThreadState()->bIsShowOriginDlg		= CHomeDlg::IS_SHOW();
		// 
		pa::PPAStatus->GetThreadState()->bIsShowCableConnectDlg = CAutoCalDlg::IS_SHOW_DLG();

		SetTimer( 3, 250, NULL );
	}
	else if( nIDEvent == 4 )
	{
		// 200 mase 
		KillTimer( 4 );

		if( pa::PPAAsyncComm[0] == NULL || pa::PPAAsyncComm[1] == NULL ) 
		{
			pa::PPAStatus->GetThreadState()->nIsConnectedPAController = 0; 
		}
		else 
		{
			pa::PPAStatus->GetThreadState()->nIsConnectedPAController = 
				(pa::PPAAsyncComm[0]->GetConnectState() == hcsock::ISocket::CONNECTED &&
				pa::PPAAsyncComm[1]->GetConnectState() == hcsock::ISocket::CONNECTED) ? 1 : 0;
		}

		SetTimer( 4, 200, NULL );
	}
	else if (nIDEvent == 5)
	{
		KillTimer(5);
		hLCDAliveSender_.Start();
	}

	CDialog::OnTimer(nIDEvent);
}

void CEPncMDlg::WRITE_DIFF_TIME_LOG(DWORD dwDiffTick)
{
	SYSTEMTIME stm;
	
	GetLocalTime(&stm);
	FILE* pf = fopen("LCD_RESET_LOG.txt", "at");

	if (pf != NULL)
	{
		fprintf(pf, "[%d-%d-%d %d:%d:%d] %d\n", 
			stm.wYear, stm.wMonth, stm.wDay, stm.wHour, stm.wMinute, stm.wSecond,
			dwDiffTick);

		fclose(pf);
		pf = NULL;
	}
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

void CLCDAliveSender::Execute()
{
	if (pGLCD &&
		pa::PPAStatus->GetThreadState()->bShowSetupDialog_ == FALSE)
	{
		pGLCD->SendCommand(_T("page2.va0.val=0"));
// 		DWORD dwTick = GetTickCount();
// 		CString strT;
// 		strT.Format(_T("LCD.%d\n"), dwTick);
// 		TRACE(strT);
	}
}