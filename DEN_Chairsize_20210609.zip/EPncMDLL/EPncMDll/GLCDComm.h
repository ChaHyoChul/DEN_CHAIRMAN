#pragma once
#include "Comm232.h"

class CGLCDComm : public CGeneralThread, public IGLCD
{
public:
	CGLCDComm(void);
	~CGLCDComm(void);

public:
	hcipc::CIpcQueue	*pIpcQueue_;
	CComm232*	pComm;
	BOOL bInitFail;
	int leng;
	CString strRecvdata;

private:
	void Recv();
	CString RecvString();
	int RecvLeng();

public:
	BOOL Initialize( DWORD dwCycleTime, CString& strErrMsg );
	void Destroy();

	virtual void StartComm();
	virtual void SendCommand(CString cmd);

public:
	virtual void Execute();
};

// extern CGLCDComm *pGLCDComm;
