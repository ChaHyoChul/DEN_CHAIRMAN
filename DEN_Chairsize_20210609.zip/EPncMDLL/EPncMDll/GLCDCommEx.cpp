#include "StdAfx.h"
#include "GLCDCommEx.h"

//////////////////////////////////////////////////////////////////////////

CGLCDCommEx::CGLCDCommEx() 
: hcsock::CClientSocket(1024)
{
	InitializeCriticalSection(&hCS_);
	nRecvBufferIndex_ = 0;
}

CGLCDCommEx::CGLCDCommEx(int buffer_size) 
: hcsock::CClientSocket(buffer_size)
{
	InitializeCriticalSection(&hCS_);
	nRecvBufferIndex_ = 0;
}

CGLCDCommEx::~CGLCDCommEx(void)
{
	DeleteCriticalSection(&hCS_);
}

//

BOOL CGLCDCommEx::Initialize(CString strFilepath, CString& strErrMsg)
{
	CCEIniFile	iniFile;
	CString		strIpAddress;
	int			nPortNo;

	if (hcutil::IsExistFile(strFilepath) == FALSE) {
		strErrMsg.Format(_T("Not found file"));
		return FALSE;
	}

	iniFile.Open(strFilepath);
	iniFile.GetValue(_T("LCD"), _T("IPAddress"), (CString*)&strIpAddress);
	iniFile.GetValue(_T("LCD"), _T("PortNo"), (int*)&nPortNo);
	iniFile.Close();

	return Initialize(strIpAddress, nPortNo);
}

BOOL CGLCDCommEx::Initialize(CString strIpAddress, int portNo)
{
	nRecvBufferIndex_ = 0;

	memset((void*)szIPAddress_, 0, 64);
	nPortNo_ = portNo;
	hcutil::CSTRING_TO_ASCII(strIpAddress, szIPAddress_, 64);

	memset((void*)szRecvBuffer_, 0, 256);
	memset((void*)szCommandBuffer_, 0, 256);

	Connect((const char*)szIPAddress_, nPortNo_);

	// Thread�� OneShot ���� ���� 
	// �޽ñⰡ ���� ��, Start() �Ѵ� 
	Create(100, IThread::ThreadType_OneShot, NULL, 0);

	return TRUE;
}


void CGLCDCommEx::Destroy()
{
	Close();
	CGeneralThread::Destroy();
}

void CGLCDCommEx::StartComm()
{
	Close();
	Sleep(100);
	Connect((const char*)szIPAddress_, nPortNo_);
}

void CGLCDCommEx::SendCommand(CString cmd)
{
	//////////////////////////////////////////////////////////////////////////
	//
	if (socket_ == INVALID_SOCKET)
	{
		return;
	}
	//////////////////////////////////////////////////////////////////////////

	EnterCriticalSection(&hCS_);

	const int BUFFER_SIZE = 256;

	memset((void*)szCommandBuffer_, 0, BUFFER_SIZE);
	hcutil::CSTRING_TO_ASCII(cmd, szCommandBuffer_, BUFFER_SIZE);
	
	int len = strlen(szCommandBuffer_);
	char etx[3] = {0xff, 0xff, 0xff};

	Send((const char*)szCommandBuffer_, len);
	Send((const char*)etx, 3);

	LeaveCriticalSection(&hCS_);
}

void CGLCDCommEx::SendCommand(char* cmd)
{
	//////////////////////////////////////////////////////////////////////////
	//
	if (socket_ == INVALID_SOCKET)
	{
		return;
	}
	//////////////////////////////////////////////////////////////////////////

	EnterCriticalSection(&hCS_);

	char etx[3] = {0xff, 0xff, 0xff};
	int len = strlen(cmd);
	Send((const char*)cmd, len);
	Send((const char*)etx, 3);

	LeaveCriticalSection(&hCS_);
}

//
// LCD ��ü ������ ������ ������, 
// data+ff/ff/ff�� ������ 
// ��. 0xff|0xff|0xff�� �������� Ȯ���ؾ� �Ѵ� 
// 
void CGLCDCommEx::OnRecv(const char* p, int len)
{
	const int BUFFER_SIZE = 256;
	char szTempBuffer[256];

	if (p == NULL || len<=0)
	{
		return ;
	}

	// �д� �����͸� ���ۿ� ���� �Ѵ�
	memcpy((void*)(szRecvBuffer_+nRecvBufferIndex_),
		   (const void*)p, 
		   len);
	nRecvBufferIndex_ += len;

	while (true)
	{
		//////////////////////////////////////////////////////////////////////////
		// FF FF FF�� �ִ��� Ȯ��.
		// ������ ���� ��, �ϴ� ������
		int nFFIndex = -1;
		if (nRecvBufferIndex_ >= 3)
		{
			for (int i = 0; i<nRecvBufferIndex_-2; i++)
			{
				if ((byte)(szRecvBuffer_[i+0]) == 0xff &&
					(byte)(szRecvBuffer_[i+1]) == 0xff &&
					(byte)(szRecvBuffer_[i+2]) == 0xff)
				{
					nFFIndex = i+2;
					break;
				}
			}

			if (nFFIndex != -1)
			{
				// receive buffer���� ff ������ �����Ѵ� 
				memset((void*)szTempBuffer, 0, BUFFER_SIZE);
				memcpy((void*)szTempBuffer, 
						(const void*)(szRecvBuffer_+nFFIndex+1),
						nRecvBufferIndex_-4);
				nRecvBufferIndex_ -= (nFFIndex + 1);
				if (nRecvBufferIndex_ > 0)
				{
					memcpy((void*)szRecvBuffer_, 
							(const void*)szTempBuffer, 
							nRecvBufferIndex_);
					memset((void*)(szRecvBuffer_ + nRecvBufferIndex_), 0, BUFFER_SIZE - nRecvBufferIndex_);
				}
				else 
				{
					nRecvBufferIndex_ = 0;
					memset((void*)szRecvBuffer_, 0, BUFFER_SIZE);
				}

				continue;
			}
		}

		//////////////////////////////////////////////////////////////////////////

		// 
		char* pTemp = strstr(szRecvBuffer_, ".");
		if (pTemp == NULL)
		{
			break;
		}

		int len = pTemp - szRecvBuffer_;
		memset((void*)szThreadCommand_, 0, 64);
		memcpy((void*)szThreadCommand_, 
			   (const void*)szRecvBuffer_, 
			   len);

		pTemp += 1;	// ETX�� �ǳ� �ڴ� 
		nRecvBufferIndex_ -= (len + 1);

		if (nRecvBufferIndex_ > 0)
		{
			// Receive buffer ����
			memset((void*)szTempBuffer, 0, BUFFER_SIZE);
			memcpy((void*)szTempBuffer, (const void*)(pTemp), nRecvBufferIndex_);
			memcpy((void*)szRecvBuffer_, (const void*)szTempBuffer, nRecvBufferIndex_);
			memset((void*)(szRecvBuffer_ + nRecvBufferIndex_), 0, BUFFER_SIZE - nRecvBufferIndex_);
		}
		else 
		{
			nRecvBufferIndex_ = 0;
			memset((void*)szRecvBuffer_, 0, BUFFER_SIZE);
		}

		//////////////////////////////////////////////////////////////////////////
		// COMMAND ó�� 
		//////////////////////////////////////////////////////////////////////////
		
		CGeneralThread::Start();	// => Thread�� ���� ��Ų�� 
	}
}

void CGLCDCommEx::Execute()
{
	if (strcmp((const char*)szThreadCommand_, (const char*)"GLCD_READYPOS") == 0)
	{
		pa::PAMotion->MoveReadyPos();
		TRACE(_T("RECV => GLCD_READYPOS\n"));
	}
	else if (strcmp((const char*)szThreadCommand_, (const char*)"GLCD_EMO") == 0)
	{
		pa::PPAStatus->GetPAStatus()->bLCDEMOclicked = TRUE;
		TRACE(_T("RECV => GLCD_EMO\n"));
	}
	else if (strcmp((const char*)szThreadCommand_, (const char*)"GLCD_START") == 0)
	{
		if ( pa::PPAStatus->GetThreadState()->bIsOpenNCFile )
		{
			pa::PThread->DoRun( 0, TRUE );
		}
		TRACE(_T("RECV => GLCD_START\n"));
	}
	else if (strcmp((const char*)szThreadCommand_, (const char*)"GLCD_STOP") == 0)
	{
		pa::PThread->DoStop( TRUE );
		TRACE(_T("RECV => GLCD_STOP\n"));
	}
	else if (strcmp((const char*)szThreadCommand_, (const char*)"GLCD_LOPEN") == 0)
	{
		if( pa::PPAStatus->GetPAStatus()->nSpindle1ColletOpenFlag == FALSE )
		{
			pa::PAMotion->ToolClamp(0, pa::CPAMotion::UNCLAMP);
		}
			else
		{
			pa::PAMotion->ToolClamp(0, pa::CPAMotion::CLAMP);
		}
		TRACE(_T("RECV => GLCD_LOPEN\n"));
	}
	else if (strcmp((const char*)szThreadCommand_, (const char*)"GLCD_ROPEN") == 0)
	{
		if( pa::PPAStatus->GetPAStatus()->nSpindle2ColletOpenFlag == FALSE )
		{
			pa::PAMotion->ToolClamp(1, pa::CPAMotion::UNCLAMP);
		}
			else
		{
			pa::PAMotion->ToolClamp(1, pa::CPAMotion::CLAMP);
		}
		TRACE(_T("RECV => GLCD_ROPEN\n"));
	}
	else 
	{
		TRACE(_T("=> %s\n"), szThreadCommand_);
	}

}

