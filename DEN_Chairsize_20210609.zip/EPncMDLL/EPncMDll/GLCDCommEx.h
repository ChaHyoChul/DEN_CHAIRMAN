#pragma once


class CGLCDCommException
{

};


class CGLCDCommEx : public hcsock::CClientSocket, public IGLCD, public CGeneralThread
{
private:
	CRITICAL_SECTION hCS_;
	
	char szIPAddress_[64];
	int nPortNo_;

	char szCommandBuffer_[256];
	char szRecvBuffer_[256];
	int  nRecvBufferIndex_;

	char szThreadCommand_[64];

public:
	virtual void OnRecv(const char* p, int len);

public:
	BOOL Initialize(CString strFilepath, CString& strErrMsg);
	BOOL Initialize(CString strIpAddress, int portNo);
	void Destroy();

	virtual void StartComm();
	virtual void SendCommand(CString cmd);
	virtual void SendCommand(char* cmd);

	virtual void Execute();

public:
	CGLCDCommEx();
	CGLCDCommEx(int buffer_size);
	~CGLCDCommEx(void);
};
