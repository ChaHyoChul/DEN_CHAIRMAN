#pragma once

#include "resource.h"
#include "afxwin.h"

// CHomeDlg ��ȭ �����Դϴ�.

class CHomeDlg : public CDialog
{
	DECLARE_DYNAMIC(CHomeDlg)

	CBrush	brhBkgnd_;
	CBrush	brhHome_[2];
	CBrush	brhStop_;
	CFont	fntButton_;

	void updateButtonState();

public:
	CHomeDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CHomeDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = 102 }; //IDD_DIALOG_HOME };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();

public:
	static CHomeDlg*	P_HOME_DLG;

	static void INITIALIZE_DLG();
	static void DELETE_DLG();
	static void SHOW_DLG();
	static void HIDE_DLG();
	static BOOL IS_SHOW();


	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnBnClickedButtonHome();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	CButton btnHome_;
};
