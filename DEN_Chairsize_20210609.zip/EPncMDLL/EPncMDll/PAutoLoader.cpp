#include "StdAfx.h"
#include "PAutoLoader.h"

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

int pa::ACAutoLoader::AUTOLOADER_AXIS_NO = 5;

//////////////////////////////////////////////////////////////////////////

pa::ACAutoLoader::ACAutoLoader(void)
{
	strFilePath_.Format( _T("") );
	pShMemALConfig_		= NULL;
	pAutoLoaderConfig_	= NULL;
	pShMemBlockState_	= NULL;
	pBlockState_		= NULL;
}

pa::ACAutoLoader::~ACAutoLoader(void)
{
	Destroy();
}

//////////////////////////////////////////////////////////////////////////

BOOL pa::ACAutoLoader::Initialize( CString& strConfigFilePath, CString& strErrMsg )
{
	strFilePath_ = strConfigFilePath;

	pShMemALConfig_ = new hcipc::CSharedMem();
	if( pShMemALConfig_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::CAutoLoader::pShMemALConfig_ object" ) );
		return FALSE;
	} 
	pAutoLoaderConfig_ = (SAutoLoaderConfig *)pShMemALConfig_->Create( NULL, ALCONFIG_ONJECT_NAME, sizeof(SAutoLoaderConfig), FALSE, 0 );
	if( pAutoLoaderConfig_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pmac::CAutoLoader::pAutoLoaderConfig_ object") );
		return FALSE;
	}

	// ������ �ִ��� Ȯ��
	CString strTemp = CString(IPC_FILEPATH) + CString(_T("\\SHM_")) + CString(AUTOLOADER_OBJECT_NAME);
	BOOL bReset = hcutil::IsExistFile( strTemp ) == TRUE ? FALSE : TRUE;

	pShMemBlockState_ = new hcipc::CSharedMem();
	if( pShMemBlockState_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::CAutoLoader::pShMemBlockState_ object") );
		return FALSE;
	}
// 	pBlockState_ = (SAutoLoaderBlockState*)pShMemBlockState_->Create( IPC_FILEPATH, AUTOLOADER_OBJECT_NAME, sizeof(SAutoLoaderBlockState), FALSE, 0 );
	pBlockState_ = (SAutoLoaderBlockState*)pShMemBlockState_->Create( IPC_FILEPATH, AUTOLOADER_OBJECT_NAME, sizeof(SAutoLoaderBlockState), bReset, 0 );
	if( pBlockState_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pmac::CAutoLoader::pBlockState_ object") );
		return FALSE;
	}

	if( bReset ) {
		pShMemBlockState_->Flush();
	}


	// ������ �ִ��� Ȯ��
	strTemp = CString(IPC_FILEPATH) + CString(_T("\\SHM_")) + CString(ITEM_LOCATION_STATE_OBJECT_NAME);
	bReset = !hcutil::IsExistFile( strTemp );

	pShMemItemLocationState_ = new hcipc::CSharedMem();
	if( pShMemItemLocationState_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::CAutoLoader::pShMemItemLocationState_ object") );
		return FALSE;
	}
	pItemLocationState_ = (ItemLocationState*)pShMemItemLocationState_->Create( IPC_FILEPATH, ITEM_LOCATION_STATE_OBJECT_NAME, sizeof(ItemLocationState), bReset, 0 );
	if( pItemLocationState_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pmac::CAutoLoader::pItemLocationState_ object") );
		return FALSE;
	}

	if( bReset ) {
		pShMemItemLocationState_->Flush();
	}



	LoadAutoLoaderConfig();

	return TRUE;
}

void pa::ACAutoLoader::Destroy()
{
	if( pShMemALConfig_ != NULL ) {
		pShMemALConfig_->Destroy();
		delete pShMemALConfig_;
		pShMemALConfig_ = NULL;
		pAutoLoaderConfig_ = NULL;
	}

	if( pShMemBlockState_ != NULL ) {
		pShMemBlockState_->Destroy();
		delete pShMemBlockState_;
		pShMemBlockState_ = NULL;
		pBlockState_ =NULL;
	}

	if( pShMemItemLocationState_ != NULL ) {
		pShMemItemLocationState_->Destroy();
		delete pShMemItemLocationState_;
		pShMemItemLocationState_ = NULL;
		pItemLocationState_ =NULL;
	}
}

void pa::ACAutoLoader::SaveAutoLoaderConfig()
{
	// ini ���Ͽ� ������ ����Ѵ�  
	CCEIniFile	hIniFile;
	CString		strKeyName, strValueName;
	int			nTemp;
	double		fTemp;

	hIniFile.Open( strFilePath_ );

	strKeyName.Format( _T("AutoLoader") );
	hIniFile.SetValue( strKeyName, _T("Using"), (int)( pAutoLoaderConfig_->bUsingAutoLoader == TRUE ? 1 : 0 ) );

	hIniFile.SetValue( strKeyName, _T("NumBlock"), (int)( pAutoLoaderConfig_->nNumBlock_ ) );

	strKeyName.Format( _T("Motor") );
	hIniFile.SetValue( strKeyName, _T("Scale"), (double)( pAutoLoaderConfig_->fScale_ ) );

	strKeyName.Format( _T("TeachingPoint") );
	for( int i = 0; i<AUTOLOADER_TP_NUM; i++ ) {
		strValueName = STR_AUTOLOADER_TEACHING_POINT_NAME[i];
		hIniFile.SetValue( strKeyName, strValueName, (double)( pAutoLoaderConfig_->fTeachingPoint_[i] ) );
	}

	hIniFile.Close();
}

void pa::ACAutoLoader::LoadAutoLoaderConfig()
{
	// ini ���Ͽ� ������ ����Ѵ�  
	CCEIniFile	hIniFile;
	CString		strKeyName, strValueName;
	int			nTemp;
	double		fTemp;

	BOOL b = hIniFile.Open( strFilePath_ );

	// 	strKeyName.Format( _T("AutoLoader") );
	// 	hIniFile.GetValue( strKeyName, _T("Using"), (int*)&nTemp );
	// 	pAutoLoaderConfig_->bUsingAutoLoader = nTemp == 0 ? FALSE : TRUE;
	// 
	// 	hIniFile.GetValue( strKeyName, _T("NumBlock"), (int*)&nTemp );
	// 	pAutoLoaderConfig_->nNumBlock_ = nTemp;
	// 
	// 	strKeyName.Format( _T("Motor") );
	// 	hIniFile.GetValue( strKeyName, _T("Scale"), (double*)&fTemp );
	// 	pAutoLoaderConfig_->fScale_ = fTemp;

	// 	strKeyName.Format( _T("TeachingPoint") );
	strKeyName.Format( _T("AutoLoader") );
	for( int i = 0; i<AUTOLOADER_TP_NUM; i++ ) {
		strValueName = STR_AUTOLOADER_TEACHING_POINT_NAME[i];
		hIniFile.GetValue( strKeyName, strValueName, (double*)&fTemp );
		pAutoLoaderConfig_->fTeachingPoint_[i] = fTemp;
	}

	hIniFile.Close();

	// ���� ������ Teaching Point�� �ִ� ������ ���� �Ѵ� 
	int nNumBlock = (int)( pa::PAutoLoader->GetTeachingPoint( pa::AUTOLOADER_TP_NUM_BLOCK ) );
	pa::PAutoLoader->GetAutoLoaderConfig()->nNumBlock_ = nNumBlock;
}

//////////////////////////////////////////////////////////////////////////

void pa::ACAutoLoader::RefreshBlockStateStruct()
{
	if( pAutoLoaderConfig_ && pBlockState_ ) {
		for( int i = 0; i<pAutoLoaderConfig_->nNumBlock_; i++ )
		{
			pBlockState_->hBlockState[i] = pa::BLOCK_STATE_EMPTY;
			pBlockState_->slotHolderNumber[i] = -1;
		}
		pBlockState_->nWorkIndex = -1;
		
		pShMemBlockState_->Flush( (void*)(pBlockState_), sizeof(SAutoLoaderBlockState) );
	}
}

void pa::ACAutoLoader::ResetBlockStateAndNumber( int slotIndex )
{
	if( pAutoLoaderConfig_ && pBlockState_ ) {
		if ( slotIndex >= 0 && slotIndex < pAutoLoaderConfig_->nNumBlock_ ) {
			pBlockState_->hBlockState[slotIndex] = pa::BLOCK_STATE_EMPTY;
			pBlockState_->slotHolderNumber[slotIndex] = -1;
		}
		pShMemBlockState_->Flush( (void*)(&(pBlockState_)), sizeof(pBlockState_) );
	}
}

void pa::ACAutoLoader::ResetBlockStates()
{
	if( pAutoLoaderConfig_ && pBlockState_ ) {
		for( int i = 0; i<pAutoLoaderConfig_->nNumBlock_; i++ )
		{
			pBlockState_->hBlockState[i] = pa::BLOCK_STATE_EMPTY;
		}
		pShMemBlockState_->Flush( (void*)(&(pBlockState_->hBlockState)), sizeof(pBlockState_->hBlockState) );
	}
}

void pa::ACAutoLoader::ResetBlockNumbers()
{
	if( pAutoLoaderConfig_ && pBlockState_ ) {
		for( int i = 0; i<pAutoLoaderConfig_->nNumBlock_; i++ )
		{
			pBlockState_->slotHolderNumber[i] = -1;
		}
		pShMemBlockState_->Flush( (void*)(&(pBlockState_->slotHolderNumber)), sizeof(pBlockState_->slotHolderNumber) );
	}
}

void pa::ACAutoLoader::ResetAutoLoaderItemNumberState()
{
	SetWorkSpaceItemNumber( -1 );
	Sleep(200);
	SetItemPasserItemNumber( -1 );
	Sleep(200);
	SetAutoLoaderHandItemNumber( -1 );
}


//////////////////////////////////////////////////////////////////////////

pa::EN_AUTOLOADER_BLOCK_STATE pa::ACAutoLoader::GetBlockState( int nIndex )
{
	pa::EN_AUTOLOADER_BLOCK_STATE hBlockState;

	if( pBlockState_ ) {
		hBlockState = pBlockState_->hBlockState[nIndex];
	} else {
		hBlockState = pa::BLOCK_STATE_BEFORE;
	}

	return hBlockState;
}

void pa::ACAutoLoader::SetBlockState( int nIndex, pa::EN_AUTOLOADER_BLOCK_STATE hBlockState )
{
	if( pBlockState_ ) {
		pBlockState_->hBlockState[nIndex] = hBlockState;
		// ���Ͽ� ���� (Flush) 
		pShMemBlockState_->Flush( (void*)(&(pBlockState_->hBlockState[nIndex])), sizeof(pBlockState_->hBlockState[nIndex]) );
	}
}

void pa::ACAutoLoader::SetSlotHolderNum( int index, int barcodeNum )
{
	if( pBlockState_ ) {
		pBlockState_->slotHolderNumber[index] = barcodeNum ;
		// ���Ͽ� ���� (Flush) 
		pShMemBlockState_->Flush( (void*)(&(pBlockState_->slotHolderNumber[index] )), sizeof(pBlockState_->slotHolderNumber[index] ) );
	}
}

void pa::ACAutoLoader::SetWorkIndex( int nIndex )
{
	if( pBlockState_ ) {
		pBlockState_->nWorkIndex = nIndex;
		// ���Ͽ� ���� (Flush)
		pShMemBlockState_->Flush( (void*)(&(pBlockState_->nWorkIndex)), sizeof(int) );
	}
}


int pa::ACAutoLoader::GetAutoLoaderHandItemNumber()
{
	return pItemLocationState_->autoLoaderHandItemNumber;
}

int pa::ACAutoLoader::GetItemPasserItemNumber()
{
	return pItemLocationState_->itemPasserItemNumber;
}

int pa::ACAutoLoader::GetWorkSpaceItemNumber()
{
	return pItemLocationState_->workSpaceItemNumber;
}

void pa::ACAutoLoader::SetAutoLoaderHandItemNumber( int itemNumber )
{
	if( pItemLocationState_ ) {
		pItemLocationState_->autoLoaderHandItemNumber = itemNumber;
		// ���Ͽ� ���� (Flush) 
		pShMemItemLocationState_->Flush( (void*)(&(pItemLocationState_->autoLoaderHandItemNumber)), sizeof(pItemLocationState_->autoLoaderHandItemNumber) );
	}
}

void pa::ACAutoLoader::SetItemPasserItemNumber( int itemNumber )
{
	if( pItemLocationState_ ) {
		pItemLocationState_->itemPasserItemNumber = itemNumber;
		// ���Ͽ� ���� (Flush) 
		pShMemItemLocationState_->Flush( (void*)(&(pItemLocationState_->itemPasserItemNumber)), sizeof(pItemLocationState_->itemPasserItemNumber) );
	}
}

void pa::ACAutoLoader::SetWorkSpaceItemNumber( int itemNumber )
{
	if( pItemLocationState_ ) {
		pItemLocationState_->workSpaceItemNumber = itemNumber;
		// ���Ͽ� ���� (Flush) 
		pShMemItemLocationState_->Flush( (void*)(&(pItemLocationState_->workSpaceItemNumber)), sizeof(pItemLocationState_->workSpaceItemNumber) );
	}
}

void pa::ACAutoLoader::SetBlockState_All_Before( int nWorkIndex )
{
	if( pAutoLoaderConfig_ && pBlockState_ ) 
	{
		for( int i = 0; i<pAutoLoaderConfig_->nNumBlock_; i++ ) 
		{
			pBlockState_->hBlockState[i] = pa::BLOCK_STATE_BEFORE;
		}
		pBlockState_->nWorkIndex = nWorkIndex;
		pShMemBlockState_->Flush( (void*)(pBlockState_), sizeof(SAutoLoaderBlockState) );
	}
}

BOOL pa::ACAutoLoader::RecordSlotExistance(int scanIndex) {
	if( PAMotion->AL_IsBlockSensing() ) {
		// ������ �ִٰ� ǥ�� 
		SetBlockState( scanIndex, BLOCK_STATE_BEFORE );

		return TRUE;
	} else {
		// ������ ���ٰ� ǥ�� 
		SetBlockState( scanIndex, BLOCK_STATE_EMPTY );

		return FALSE;
	}
}

BOOL pa::ACAutoLoader::IsItemSensing() {
	return PAMotion->AL_IsBlockSensing();
}

int pa::ACAutoLoader::GetEmptySlotIndex() {
	for (int slotIndex=0; slotIndex<GetNumBlock(); slotIndex++) {
		if (GetBlockState(slotIndex) == BLOCK_STATE_EMPTY) {
			return slotIndex;
		}
	}

	return -1;
}

int pa::ACAutoLoader::GetWorkSpaceItemPasserJointItemNumber() {
	// Often times, an item can be marked `unknown` (value set to -1). We will take the better one of two possible data field.
	int itemNumber1 = GetWorkSpaceItemNumber();
	int itemNumber2 = GetItemPasserItemNumber();
	return itemNumber1 > itemNumber2 ? itemNumber1 : itemNumber2;
}

int pa::ACAutoLoader::GetItemPasserAutoLoaderHandJointItemNumber() {
	// Often times, an item can be marked `unknown` (value set to -1). We will take the better one of two possible data field.
	int itemNumber1 = GetAutoLoaderHandItemNumber();
	int itemNumber2 = GetItemPasserItemNumber();
	return itemNumber1 > itemNumber2 ? itemNumber1 : itemNumber2;
}


//////////////////////////////////////////////////////////////////////////

pa::CBlockAutoLoader::CBlockAutoLoader(void) {
}

pa::CBlockAutoLoader::~CBlockAutoLoader(void)
{
	Destroy();
}

BOOL pa::CBlockAutoLoader::VerifyWorkingPiece(int slotIndex) {
	return TRUE;
}

void pa::CBlockAutoLoader::WorkDoneHandler(int slotIndex) {
	if( GetBlockState( slotIndex ) != BLOCK_STATE_ERROR ) 
	{
		SetBlockState( slotIndex, BLOCK_STATE_COMPLETE );
	}
}

BOOL pa::CBlockAutoLoader::IsThereSlotData() {
	return FALSE;
}

void pa::CBlockAutoLoader::RecordSlotData(int slotIndex) {
	return;
}

int pa::CBlockAutoLoader::GetValidItemSlotIndex() {
	return GetToDoItemNumber();
}

int pa::CBlockAutoLoader::GetToDoItemNumber() {
	for (int i=0; i<GetNumBlock(); i++) {
		if (GetBlockState(i) == BLOCK_STATE_BEFORE) {
			return i;
		}
	}

	return -1;
}

int pa::CBlockAutoLoader::GetNextValidItemSlotIndex() {
	int slotIndex = GetWorkIndex();

	for (int slotIndex=0; slotIndex<GetNumBlock(); slotIndex++) {
		if (GetBlockState(slotIndex) == BLOCK_STATE_BEFORE) {
			return slotIndex;
		}
	}

	return -1;
}

BOOL pa::CBlockAutoLoader::IsThisNCFileValid(TCHAR* file_name) {
	return TRUE;
}

int pa::CBlockAutoLoader::GetItemNumberFromSlotIndex(int slotIndex) {
	return -1;
}

int pa::CBlockAutoLoader::GetSlotIndexFromItemNumber(int itemNumber) {
	// For Block AutoLoader, item number == slot index.
	return itemNumber;
}

void pa::CBlockAutoLoader::RemoveDuplicateBlockStates( int originalIndex ) {
	return;
}

BOOL pa::CBlockAutoLoader::IsThereDuplicateItemNumber()
{
	return FALSE;
}



//////////////////////////////////////////////////////////////////////////



pa::CDiskAutoLoader::CDiskAutoLoader(void) {
}

pa::CDiskAutoLoader::~CDiskAutoLoader(void)
{
	Destroy();
}

BOOL pa::CDiskAutoLoader::VerifyWorkingPiece(int slotIndex) 
{
	int holderNum = PAMotion->ReadBarcode();

	return pBlockState_-> slotHolderNumber[slotIndex] == holderNum;
}

void pa::CDiskAutoLoader::WorkDoneHandler(int slotIndex) 
{
	if( GetBlockState( slotIndex ) != BLOCK_STATE_ERROR ) 
	{
		SetBlockState( slotIndex, BLOCK_STATE_BEFORE );
	}

	return;
}

BOOL pa::CDiskAutoLoader::IsThereSlotData() 
{
	return TRUE;
}

void pa::CDiskAutoLoader::RecordSlotData(int slotIndex) 
{
	int holderNum = PAMotion->ReadBarcode();

	if (holderNum < 0) 
	{
		// TODO: raise error! Update design file.
	}

	SetSlotHolderNum( slotIndex, holderNum );
}

int pa::CDiskAutoLoader::GetValidItemSlotIndex() {
	return GetSlotIndexFromItemNumber( GetToDoItemNumber() );
}

int pa::CDiskAutoLoader::GetToDoItemNumber() {
	TCHAR* file_name = pa::PPAStatus->GetThreadState()->hNCFileInfo.file_name;

	pa::DiskAutoLoaderFileFormat format = PNCFileMgr->ParseDiskFormatNCFileName(file_name);

	if (!format.valid) {
		return -1;
	}

	return format.holderNum;
}

int pa::CDiskAutoLoader::GetNextValidItemSlotIndex() {
	int nextValidFileIndex = PNCFileMgr->GetNextDiskFormatValidNCFileIndex();

	if (nextValidFileIndex < 0) {
		return -1;
	}

	SNCFileInfo* nextValidFileInfo = PNCFileMgr->GetNCFileInfo(nextValidFileIndex);

	pa::DiskAutoLoaderFileFormat format = PNCFileMgr->ParseDiskFormatNCFileName(nextValidFileInfo->file_name);

	return GetSlotIndexFromItemNumber( format.holderNum );
}

BOOL pa::CDiskAutoLoader::IsThisNCFileValid(TCHAR* file_name) {

	pa::DiskAutoLoaderFileFormat format = PNCFileMgr->ParseDiskFormatNCFileName(file_name);

	return format.valid;
}

int pa::CDiskAutoLoader::GetItemNumberFromSlotIndex(int slotIndex) {
	return pBlockState_->slotHolderNumber[slotIndex];
}

int pa::CDiskAutoLoader::GetSlotIndexFromItemNumber(int itemNumber) {
	if ( itemNumber == -1 ) {
		return -1;
	}

	for (int i=0; i<GetNumBlock(); i++) {
		if (pBlockState_->slotHolderNumber[i] == itemNumber) {
			return i;
		}
	}

	return -1;
}

void pa::CDiskAutoLoader::RemoveDuplicateBlockStates( int originalIndex )
{
	int itemNumber = pBlockState_->slotHolderNumber[originalIndex];

	if ( itemNumber == -1 ) {
		return;
	}

	for( int i = 0; i<pAutoLoaderConfig_->nNumBlock_; i++ )
	{
		if ( i == originalIndex ) {
			continue;
		}

		if ( pBlockState_->slotHolderNumber[i] == itemNumber ) {
			ResetBlockStateAndNumber( i );
		}
	}
}

BOOL pa::CDiskAutoLoader::IsThereDuplicateItemNumber()
{
	// O(n^2) algorithm. Inefficient but clean code...
	for( int i = 0; i<pAutoLoaderConfig_->nNumBlock_-1; i++ )
	{
		for( int j=i+1; j<pAutoLoaderConfig_->nNumBlock_; j++ ) {

			if ( pBlockState_->slotHolderNumber[i] != -1 &&
				pBlockState_->slotHolderNumber[i] == pBlockState_->slotHolderNumber[j] ) {
				return TRUE;
			}
		}
	}

	return FALSE;
}

/* This is the test code for the NC File Format parsing function.

#include <vector>
void CEPncMApp::RunNCFileFormatTest()  {
	std::vector<CString> vect;

	vect.push_back(CString("12_MAT_10_19920611_1230_RAPHAEL_valid.nc"));
	vect.push_back(CString("Zero_MAT_10_19920611_1230_RAPHAEL_invalid.nc"));
	vect.push_back(CString("_MAT_10_19920611_1230_RAPHAEL_invalid.nc"));
	vect.push_back(CString("12__10_19920611_1230_RAPHAEL_invalid.nc"));
	vect.push_back(CString("12_10_19920611_1230_RAPHAEL_invalid.nc"));
	vect.push_back(CString("12_MAT_1a_19920611_1230_RAPHAEL_invalid.nc"));
	vect.push_back(CString("12_MAT_Twenty_19920611_1230_RAPHAEL_invalid.nc"));
	vect.push_back(CString("12_MAT_10__1230_RAPHAEL_invalid.nc"));
	vect.push_back(CString("12_MAT_10_19920611__RAPHAEL_invalid.nc"));
	vect.push_back(CString("12_MAT_10_19920611_RAPHAEL_invalid.nc"));
	vect.push_back(CString("12_MAT_10_19920611_1230_RAPHAEL_invalid"));

	for(std::vector<CString>::iterator it = vect.begin(); it != vect.end(); ++it) {
		TRACE( _T("TEST: ") );

		TRACE( *it );

		if ( NCFileFormatTest(*it) ) {
			TRACE( CString("..........Valid") );
		} else {
			TRACE( CString("..........Invalid") );
		}

		TRACE( _T("\n") );
	}
}

*/
