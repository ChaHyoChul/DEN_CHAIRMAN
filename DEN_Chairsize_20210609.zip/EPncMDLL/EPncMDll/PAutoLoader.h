#pragma once

namespace pa 
{

//////////////////////////////////////////////////////////////////////////
// Autoloader�� Abstract Ŭ���� 
//	
class ACAutoLoader
{
protected:
	CString strFilePath_;
// 	BOOL	bUsingAutoLoader_;						// AutoLoader ��� ���� 
// 	int		nNumBlock_;								// ������ ���� 
// 	double	fAxisScale_;							// ������ Scale 
	// 	double	fTeachingPoint_[AUTOLOADER_TP_NUM];		// AutoLoader�� ƼĪ ��ġ
	
	hcipc::CSharedMem		*pShMemALConfig_;
	SAutoLoaderConfig		*pAutoLoaderConfig_;
	
	hcipc::CSharedMem		*pShMemBlockState_;		// ������ ���¸� �����ϴ� ���� �޸� �ּ� 
	SAutoLoaderBlockState	*pBlockState_;			// 

	hcipc::CSharedMem		*pShMemItemLocationState_;
	ItemLocationState		*pItemLocationState_;
public:
	ACAutoLoader();
	virtual ~ACAutoLoader() = 0;

	static int AUTOLOADER_AXIS_NO;

	BOOL Initialize(CString& strConfigFilePath, CString& strErrCode );

	BOOL IsUsingAutoLoader() { return pAutoLoaderConfig_->bUsingAutoLoader; }		//{ return bUsingAutoLoader_; }
	void SetUsingAutoLoader( BOOL b ) {
		pAutoLoaderConfig_->bUsingAutoLoader = b;
	}

	int  GetNumBlock() { return pAutoLoaderConfig_->nNumBlock_; }					//{ return nNumBlock_; }
	double GetAxisScale() { return pAutoLoaderConfig_->fScale_; }					// { return fAxisScale_; }
	double GetTeachingPoint( EN_AUTOLOADER_TEACHING_POINT teachingPoint ) {			// return fTeachingPoint_[teachingPoint]; }
		return pAutoLoaderConfig_->fTeachingPoint_[teachingPoint];
	}
	void SetTeachingPoint( EN_AUTOLOADER_TEACHING_POINT teachingPoint, double fVal ) {
		pAutoLoaderConfig_->fTeachingPoint_[teachingPoint] = fVal;
	} 
	void RefreshBlockStateStruct();
	void ResetBlockStateAndNumber( int slotIndex );
	void ResetBlockStates();
	void ResetBlockNumbers();

	void ResetAutoLoaderItemNumberState();

	EN_AUTOLOADER_BLOCK_STATE GetBlockState( int nIndex );
	void SetBlockState( int nIndex, EN_AUTOLOADER_BLOCK_STATE hBlockState );
	void SetBlockState_All_Before( int nWorkIndex );
	int GetAutoLoaderHandItemNumber();
	int GetItemPasserItemNumber();
	int GetWorkSpaceItemNumber();
	void SetAutoLoaderHandItemNumber( int itemNumber );
	void SetItemPasserItemNumber( int itemNumber );
	void SetWorkSpaceItemNumber( int itemNumber );

	void SetWorkIndex( int nIndex ); 
	int GetWorkIndex() {
		return pBlockState_->nWorkIndex;
	}

	SAutoLoaderConfig* GetAutoLoaderConfig() {
		return pAutoLoaderConfig_;
	}

	void SaveAutoLoaderConfig();					// AutoLoader �����͸� ini ���Ͽ� �����Ѵ� 
	
	BOOL RecordSlotExistance(int scanIndex);
	BOOL IsItemSensing();
	void SetSlotHolderNum( int index, int barcodeNum );
	int GetEmptySlotIndex();
	int GetWorkSpaceItemPasserJointItemNumber();
	int GetItemPasserAutoLoaderHandJointItemNumber();

protected:
	void Destroy();

private:
	void LoadAutoLoaderConfig();

	// ------- ���� �߰� ----------
public:
	virtual BOOL VerifyWorkingPiece(int slotIndex) = 0;
	virtual EN_AUTOLOADER_FAILURE_OPTION GetRetryOption() = 0;
	virtual void WorkDoneHandler(int slotIndex) = 0;
	virtual BOOL IsThereSlotData() = 0;
	virtual void RecordSlotData(int slotIndex) = 0;
	virtual int GetValidItemSlotIndex() = 0;
	virtual int GetToDoItemNumber() = 0;
	virtual int GetNextValidItemSlotIndex() = 0;
	virtual BOOL IsThisNCFileValid(TCHAR* file_name) = 0;
	virtual int GetItemNumberFromSlotIndex(int slotIndex) = 0;
	virtual int GetSlotIndexFromItemNumber(int itemNumber) = 0;
	virtual void RemoveDuplicateBlockStates( int originalIndex ) = 0;
	virtual BOOL IsThereDuplicateItemNumber() = 0;
};

class CBlockAutoLoader : public ACAutoLoader
{
public:
	CBlockAutoLoader(void);
	~CBlockAutoLoader(void);
	virtual BOOL VerifyWorkingPiece(int slotIndex);
	virtual EN_AUTOLOADER_FAILURE_OPTION GetRetryOption() {
		return AUTOLOADER_UP_ONE;
	};
	virtual void WorkDoneHandler(int slotIndex);
	virtual BOOL IsThereSlotData();
	virtual void RecordSlotData(int slotIndex);
	virtual int GetValidItemSlotIndex();
	virtual int GetToDoItemNumber();
	virtual int GetNextValidItemSlotIndex();
	virtual BOOL IsThisNCFileValid(TCHAR* file_name);
	virtual int GetItemNumberFromSlotIndex(int slotIndex);
	virtual int GetSlotIndexFromItemNumber(int itemNumber);
	virtual void RemoveDuplicateBlockStates( int originalIndex );
	virtual BOOL IsThereDuplicateItemNumber();
};

class CDiskAutoLoader : public ACAutoLoader
{
public:
	CDiskAutoLoader(void);
	~CDiskAutoLoader(void);
	virtual BOOL VerifyWorkingPiece(int slotIndex);
	virtual EN_AUTOLOADER_FAILURE_OPTION GetRetryOption() {
		return AUTOLOADER_RESCAN;
	};
	virtual void WorkDoneHandler(int slotIndex);
	virtual BOOL IsThereSlotData();
	virtual void RecordSlotData(int slotIndex);
	virtual int GetValidItemSlotIndex();
	virtual int GetToDoItemNumber();
	virtual int GetNextValidItemSlotIndex();
	virtual BOOL IsThisNCFileValid(TCHAR* file_name);
	virtual int GetItemNumberFromSlotIndex(int slotIndex);
	virtual int GetSlotIndexFromItemNumber(int itemNumber);
	virtual void RemoveDuplicateBlockStates( int originalIndex );
	virtual BOOL IsThereDuplicateItemNumber();
};

//////////////////////////////////////////////////////////////////////////
}
