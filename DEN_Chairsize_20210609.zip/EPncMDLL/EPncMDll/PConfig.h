#pragma once

namespace pa 
{
//////////////////////////////////////////////////////////////////////////

/** 
 * Config �����͸� INI ���ϰ� ���� �޸𸮸� ���� ����ϴ� ����
 *	- INI ���Ͽ��� ���� �����͸� ���� �޸𸮿� �����ϰ�,
 *	- ���� �޸𸮿� ����� �����͸� INI ���Ͽ� �����Ѵ� 
 */ 

class CPConfig
{
private:
	CString strFilePath;

public:

private:
	hcipc::CSharedMem	*pShMem_;

	BOOL load_from_file_coordinate_offset( CString& strErrMsg );
	BOOL load_from_file_teaching_point( CString& strErrMsg );
	BOOL load_from_file_tp_option( CString& strErrMsg );
	BOOL load_from_file_sw_config_data( int& using_Autoloader, CString& strErrMsg );


public:
	SConfigData			*pConfig_;

public:
	BOOL Initialize( CString& strConfigFilePath, CString& strErrMsg );
	void Destroy();

	BOOL Load( int& using_autoloader, CString& strErrMsg );
	BOOL Save( CString& strErrMsg );

	BOOL SaveCoordOffset( CString& strErrMsg );
	BOOL SaveTeachingPoint( CString& strErrMsg );
	BOOL SaveOption( CString& strErrMsg );

	BOOL SaveUsingDetectBlock( BOOL b, CString& strErrMsg );
	BOOL SaveUsingAirLimitSensor( BOOL b, CString& strErrMsg );
	BOOL SaveDelayGripBlock( int i, CString& strErrMsg );
	BOOL SaveAirLimitInterval( int i, CString& strErrMsg );
	BOOL SaveToolErrorOccureHandlingCode( int i, CString& strErrMsg );
	BOOL SaveUsingOpPanel( BOOL b, CString& strErrMsg );
	BOOL SaveUsingFlowSensor( CString& strErrMsg );
	BOOL SaveNcFileChecker( CString& strErrMsg );
	BOOL SaveSpindleAirPurge( CString& strErrMsg );
	BOOL SaveUsingLog( CString& strErrMsg );

public:
	CPConfig(void);
	~CPConfig(void);
};

//////////////////////////////////////////////////////////////////////////
}

