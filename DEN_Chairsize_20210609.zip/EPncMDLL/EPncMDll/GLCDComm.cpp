#include "StdAfx.h"
#include "GLCDComm.h"
#include <string>

CGLCDComm	*pGLCDComm = NULL;

CGLCDComm::CGLCDComm(void)
{
}

CGLCDComm::~CGLCDComm(void)
{
}

//
BOOL CGLCDComm::Initialize( DWORD dwCycleTime, CString& strErrMsg )
{
	if( !Create( dwCycleTime, IThread::ThreadType_Continue, NULL, 0 ) ) {
		//strErrMsg.Format( _T("create thread error for CGLCDComm") );
		return FALSE;
	}

	BOOL rtn = true;
	bInitFail = false;

	pComm = new CComm232;
	pComm->SetComPort( pa::PConfig->pConfig_->nGraphicLCD_Port, 9600, 8, 0, 0 );
	if(!pComm->CreateCommInfo())
	{
		rtn = false;
		bInitFail = true;
	}
	if(!pComm->OpenComPort())
	{
		rtn = false;
		bInitFail = true;
	}   
	pComm->Purge();
	if( !rtn ) {
		if (pComm != NULL)
		{
			pComm->DestroyComm();
			pComm->Purge();
			delete pComm;
			pComm = NULL;
		}
	}

	return rtn;
}

//
void CGLCDComm::Destroy()
{
	if (pComm != NULL)
	{
		pComm->DestroyComm();
		pComm->Purge();
		delete pComm;
		pComm = NULL;
	}
}

//
void CGLCDComm::StartComm()
{
	Start();
}

// 
void CGLCDComm::SendCommand(CString cmd)
{
	if (pComm == NULL)
	{
		return;
	}
	char sztemp[512];
	hcutil::CSTRING_TO_ASCII(cmd, sztemp, 512);

	char etx[3] = {0xff, 0xff, 0xff};
	pComm->WriteCommBlock(sztemp, strlen(sztemp));
	pComm->WriteCommBlock(etx, 3);
}

void CGLCDComm::Recv()
{
	if (pComm == NULL)
	{
		return;
	}

	char szRecv[128];
	memset((void*)szRecv, 0, 128);
	leng = pComm->ReadCommBlock(szRecv, 127);

	strRecvdata = hcutil::ASCII_TO_CSTRING(szRecv);
}

int CGLCDComm::RecvLeng()
{
	if (pComm == NULL)
	{
		return 0;
	}
	return leng;
}

CString CGLCDComm::RecvString()
{
	if (pComm == NULL)
	{
		return _T("");
	}
	return strRecvdata;	// member 
}

void CGLCDComm::Execute()
{
	if (pComm == NULL)
	{
		return;
	}

	// �޴� �κ�
	int leng = 0;
	CString strRecv, strParsing;
	static CString strBuffer = _T("");

	Recv();
	leng = RecvLeng();

	if (leng == 0)
	{
		return;
	}

	
	strRecv = RecvString();

	strBuffer += strRecv;
	int nEnd = strBuffer.Find('.');
	if (nEnd == -1)
	{
		return;
	}

	else
	{
		strParsing = strBuffer.Left(nEnd);
		strBuffer.Delete(0, nEnd + 1);
	}

	if (strParsing != _T(""))
	{
		if (strParsing.Compare(_T("GLCD_READYPOS")) == 0)
		{
			pa::PAMotion->MoveReadyPos();
		}

		else if (strParsing.Compare(_T("GLCD_EMO")) == 0)
		{
			pa::PPAStatus->GetPAStatus()->bLCDEMOclicked = TRUE;
		}

		else if (strParsing.Compare(_T("GLCD_START")) == 0)
		{
			if ( pa::PPAStatus->GetThreadState()->bIsOpenNCFile )
			{
				pa::PThread->DoRun( 0, TRUE );
			}
		}

		else if (strParsing.Compare(_T("GLCD_STOP")) == 0)
		{
			pa::PThread->DoStop( TRUE );
		}

		else if (strParsing.Compare(_T("GLCD_LOPEN")) == 0)
		{
			if( pa::PPAStatus->GetPAStatus()->nSpindle1ColletOpenFlag == FALSE )
			{
				pa::PAMotion->ToolClamp(0, pa::CPAMotion::UNCLAMP);
			}
			
			else
			{
				pa::PAMotion->ToolClamp(0, pa::CPAMotion::CLAMP);
			}
		}

		else if (strParsing.Compare(_T("GLCD_ROPEN")) == 0)
		{
			if( pa::PPAStatus->GetPAStatus()->nSpindle2ColletOpenFlag == FALSE )
			{
				pa::PAMotion->ToolClamp(1, pa::CPAMotion::UNCLAMP);
			}

			else
			{
				pa::PAMotion->ToolClamp(1, pa::CPAMotion::CLAMP);
			}
		}
	}

}
