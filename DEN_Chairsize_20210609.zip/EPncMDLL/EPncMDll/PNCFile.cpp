#include "StdAfx.h"
#include "PNcFile.h"

pa::CPNCFile::CPNCFile(void)
{
	pShMem_			= NULL;
	pFile_			= NULL;
	nNumTotalLines_ = 0;
	nWorkLine_		= 0;
}

pa::CPNCFile::~CPNCFile(void)
{
	Close();
}

BOOL pa::CPNCFile::Open( CString& strNcFilePath, CString& strErrMsg )
{
	DWORD dwTime = GetTickCount();

	DWORD	dwFileSize = 0;

	nNumTotalLines_ = 0;

	//////////////////////////////////////////////////////////////////////////
	// �ϴ� �ݴ´� 
	Close();
	//////////////////////////////////////////////////////////////////////////

	// ���� ũ�⸦ �˾Ƴ���,
	if( hcutil::GetFileSize( strNcFilePath, &dwFileSize, strErrMsg ) == FALSE ) {
		return FALSE;
	}

	// ������ ���� �޸𸮿� ���� �Ѵ� 
	pShMem_ = new hcipc::CSharedMem();
	if( pShMem_ == NULL ) {
		return FALSE;
	}
	pFile_ = (char*)pShMem_->CreateEx( (TCHAR*)(LPCTSTR)strNcFilePath, _T("NC_FILE_OBJ"), (int)(dwFileSize+1), FALSE, 0 );
	if( pFile_ == NULL ) {
		return FALSE;
	}

	// �� ���ξ� ī��Ʈ �ϸ鼭, �����͸� �����Ѵ� 
	char* pTemp = pFile_;

	pLines_[nNumTotalLines_++] = pFile_;
	while( TRUE ) 
	{
		pLines_[nNumTotalLines_] = strstr( pTemp, ETX_STR );
		if( pLines_[nNumTotalLines_] != NULL ) {
			pLines_[nNumTotalLines_] += ETX_STR_LEN;	// "\n" ���� ���ڸ� ����Ű���� ������ �̵� 
			pTemp = pLines_[nNumTotalLines_];
			nNumTotalLines_++;
			if( nNumTotalLines_ >= MAX_NCFILE_LINES ) {
				// ���� �޽���
				strErrMsg.Format( _T("NC-File is too large") );
				// ���ҽ� ����
				Close();
				return FALSE;
			}
		} else {
			break;
			nNumTotalLines_--;
		}
	}

	nWorkLine_ = 0;

	dwTime = GetTickCount() - dwTime;
	CString strDebug;
	strDebug.Format( _T("Open() : %d\n"), dwTime );
	TRACE( strDebug );

	return TRUE;
}

BOOL pa::CPNCFile::Open2( CString& strNcFilePath, CString& strErrMsg )
{
	DWORD dwTime = GetTickCount();

	DWORD	dwFileSize = 0;
	DWORD	dwOpening = 0;
	char	szTemp[256];
	char*	szCharForCommand[] = { ";" };
	BOOL	bFindFirstToolChangeCode = FALSE;
//	int		nM14X_LineNo = 0;	
	int		nM14X_FirstLineNo = 0;
	int		nM14X_SecondLineNo= 0;

	CTransformVPst hTransform;
	hTransform.RESET();

	pa::PPAStatus->GetThreadState()->nNcFileLoadingRate = 0;
	nNumTotalLines_ = 0;

	Close();

	// ������ ũ�⸦ �˾� ���� 
	if( hcutil::GetFileSize( strNcFilePath, &dwFileSize, strErrMsg ) == FALSE ) {
		strErrMsg.Format( _T("get file size error. [open2()]") );
		return FALSE;
	}

	// ������ ���� ���� �޸𸮸� ���� �Ѵ� 
	pShMem_ = new hcipc::CSharedMem();
	if( pShMem_ == NULL ) {
		strErrMsg.Format( _T("memory allocate error") );
		return FALSE;
	}

//	pFile_ = (char*)pShMem_->CreateEx( NULL, _T("NC_FILE_OBJ"), (int)(dwFileSize*2), FALSE, 0 );
// 	pFile_ = (char*)pShMem_->CreateEx( NULL, _T("NC_FILE_OBJ"), (int)(dwFileSize*2), TRUE, 0 );
	pFile_ = (char*)pShMem_->CreateEx( NULL, _T("NC_FILE_OBJ"), (int)(dwFileSize + 512), TRUE, 0 );	// 512 byte ��ŭ�� ������ �д� 
	if( pFile_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error") );
		return FALSE;
	}

	// ���Ͽ��� �� ���ξ� �о� ���̺���, ��ȯ �� Shared Mem�� �����Ѵ� 
	FILE*	pf = _tfopen( (TCHAR*)(LPCTSTR)strNcFilePath, _T("rt") );

	if( pf == NULL ) {
		Close();
		strErrMsg.Format( _T("file open error") );
		return FALSE;
	}

	pLines_[nNumTotalLines_] = pFile_;
	nNumTotalLines_++;

	while( !feof( pf ) ) 
	{
		memset( (void *)szTemp, 0, sizeof(char)*256 );

		//////////////////////////////////////////////////////////////////////////
		// ���Ͽ��� ������ �о� ���δ� 
		fgets( szTemp, 255, pf );

		int ln = strlen( szTemp );
		dwOpening += ln;

	//	if( bFindFirstToolChangeCode == FALSE || nM14X_LineNo == 0 ) {
		if( bFindFirstToolChangeCode == FALSE || nM14X_SecondLineNo == 0 ) {
			if( strstr(szTemp, "M14") != NULL ) {
				if( bFindFirstToolChangeCode == FALSE ) {
					bFindFirstToolChangeCode = TRUE;
					nM14X_FirstLineNo = nNumTotalLines_;
				}
				else {
				//	nM14X_LineNo = nNumTotalLines_;
					nM14X_SecondLineNo = nNumTotalLines_;
#ifdef _DEBUG
					CString strDbg;
				//	strDbg.Format( _T("\nM14x line is %d\n\n"), nM14X_LineNo );
					strDbg.Format( _T("\nM14x line is %d\n\n"), nM14X_SecondLineNo );
					TRACE( strDbg );
#endif
				}
			}
		}

		pa::PPAStatus->GetThreadState()->nNcFileLoadingRate = (int)( ( (double)dwOpening / (double)dwFileSize ) * 100.0 + 0.5 );

		//////////////////////////////////////////////////////////////////////////
		// 0. preprocessing 
		pa::CGCodeHelper::RemoveCommantFromGCode2( szTemp, szCharForCommand, 1 );	// �ּ��� ����. %�� ���� ���´� 

		pa::CGCodeHelper::CheckReplaceCommand( szTemp );		// 

		//////////////////////////////////////////////////////////////////////////
		// 1. NC-FILE checking 
		if( pa::PConfig->pConfig_->bCheckInvalidNcCode == TRUE ) 
		{
			if( pa::CGCodeHelper::CheckNcFile( szTemp ) == FALSE ) 
			{
				strErrMsg.Format( _T("nc code error : line number is %d"), nNumTotalLines_ );
				Close();
				fclose( pf );
				return FALSE;
			}
		}

		// 2018.01.31. ������ ������� �ʱ� ������ �ּ�ó�� �Ѵ� 
// 		// 2. NC-FILE transform 
// 		if( pa::PConfig->pConfig_->bTransformNcFile == TRUE )
// 		{
// 			if( hTransform.TRANSFORM2( szTemp, 255 ) == FALSE ) 
// 			{
// 				strErrMsg.Format( _T("nc code tranform error : line number is %d"), nNumTotalLines_ );
// 				Close();
// 				fclose( pf );
// 				return FALSE;
// 			}
// 		}

		// 3. NC-FILE Tag ===> �Ʒ��� ���� 
// 		if( pmac::PConfig->pConfig_->bCheckNcFileTag == TRUE )
// 		{
// 		}

		//////////////////////////////////////////////////////////////////////////

		ln = strlen( szTemp );

		memcpy( (void *)pLines_[nNumTotalLines_-1], (const void *)szTemp, ln );

		pLines_[nNumTotalLines_] = pLines_[nNumTotalLines_-1] + ln;

		nNumTotalLines_++;
		
		if( nNumTotalLines_ >= MAX_NCFILE_LINES  ) {
			strErrMsg.Format( _T("nc-file is too large") );
			Close();
			fclose( pf );
			return FALSE;
		}
	}

	memcpy( (void*)pLines_[nNumTotalLines_-1], (const void*)szTemp, 0 );
	pLines_[nNumTotalLines_] = pLines_[nNumTotalLines_-1] + 0;
	nNumTotalLines_++;

	nNumTotalLines_--;

	//////////////////////////////////////////////////////////////////////////
	// 3. NC-FILE Tag �˻� 
	// - ù��° ���ΰ� ������ ���ο� %�� �ִ��� Ȯ�� 
	BOOL bError = FALSE;
	if( pa::PConfig->pConfig_->bCheckNcFileTag == TRUE ) 
	{
		int find_line = 0;

		// ù��° ���ο��� "%"�� ã�´� 
		memset((void*)szTemp, 0, sizeof(char)*256);
		GetLine( 0, FALSE, szTemp );
		if( szTemp[0] != '%' ) 
		{
			// Error
			TRACE(_T("nc file tag error 1\n"));
			bError = TRUE;
			strErrMsg.Format( _T("not found start tag(%%) in nc file") );
		}

		if( !bError ) {
			// ������ ���κ��� "%"�� ã�´� 
			find_line = nNumTotalLines_ - 1;
			while( TRUE )
			{
				memset((void*)szTemp, 0, sizeof(char)*256);
				GetLine( find_line, FALSE, szTemp );
				if( strlen( szTemp ) == 0 ) {
					find_line--;
				} else {
					if( szTemp[0] == '%' ) {
						break;
					} else {
						// Error 
						TRACE(_T("nc file tag error 2\n"));
						bError = TRUE;
						strErrMsg.Format( _T("not found stop tag(%%) in nc file") );
						break;
					}
				}
			}
		}
	}
	if( bError )
	{
		Close();
		fclose( pf );
		return FALSE;
	}
	//////////////////////////////////////////////////////////////////////////

	nWorkLine_ = 0;

	fclose( pf ); 

#ifdef _DEBUG
	dwTime = GetTickCount() - dwTime;
	CString strDebug;
	strDebug.Format( _T("Open2() : %d\n"), dwTime );
	TRACE( strDebug );
#endif 

	//////////////////////////////////////////////////////////////////////////
	// tool change ���ι�ȣ�� ���� 
//	pa::PPAStatus->GetThreadState()->nNCFileInfo_SecondToolChageLine = nM14X_LineNo;
	pa::PPAStatus->GetThreadState()->nNCFileInfo_FirstToolChageLine = nM14X_FirstLineNo;
	pa::PPAStatus->GetThreadState()->nNCFileInfo_SecondToolChageLine= nM14X_SecondLineNo;
	//////////////////////////////////////////////////////////////////////////

	return TRUE;
}

void pa::CPNCFile::Close()
{
	nNumTotalLines_ = 0;
	nWorkLine_ = 0;
	if( pShMem_ ) {
		delete pShMem_;
		pShMem_ = NULL;
		pFile_	= NULL;
		memset((void*)pLines_, 0, sizeof(char*)*MAX_NCFILE_LINES);
	}
}

BOOL pa::CPNCFile::IsOpen()
{
	BOOL b = ( nNumTotalLines_ != 0 ) && ( pFile_ != NULL );

	return b;
}

// �� �Լ��� ���� ����. ���׸� �����ϰ� ����ؼ��� �� 
BOOL pa::CPNCFile::GetLine( int index, BOOL bSetWorkLine, char* pNCCode )
{
	if( index >= nNumTotalLines_ ) {
		return FALSE;
	}

//	char* p = strstr( pLines_[index], ETX_STR );
//	memcpy( (void*)pNCCode, (const void*)pLines_[index], sizeof(char)*(p - pLines_[nWorkLine_]) );

	memcpy( (void*)pNCCode, (const void*)pLines_[index], sizeof(char)*(pLines_[index+1] - pLines_[index]) );

	if( bSetWorkLine ) {
		nWorkLine_ = index;
	}

	return TRUE;
}

// ���� ������ ������ �� nWorkLine ���� ���� �ϱ� ������, 
// ���� ���۸��� ���� ��ȣ�� nWorkLine - 1 �̴� 
BOOL pa::CPNCFile::GetNextLine( char* pNCCode )
{
	if( nWorkLine_+1 >= nNumTotalLines_ ) {
		return FALSE;
	}
 
// 	nWorkLine_++;

// 	char* p = strstr( pLines_[nWorkLine_+1], ETX_STR );
// 
// 	memcpy((void*)pNCCode, (const void*)pLines_[nWorkLine_+1], sizeof(char)*(p - pLines_[nWorkLine_+1]));

	memcpy( (void*)pNCCode, (const void*)pLines_[nWorkLine_], sizeof(char)*(pLines_[nWorkLine_+1] - pLines_[nWorkLine_]) );

	nWorkLine_++;

	return TRUE;
}

