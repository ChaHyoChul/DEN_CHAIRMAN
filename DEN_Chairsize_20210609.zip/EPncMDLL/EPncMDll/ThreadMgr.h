
#pragma once 

// #include <mmsystem.h>					//Using.. MultiMedia Timer 
// #pragma comment ( lib, "Winmm.lib" )

/*
#include <map>
using namespace std;
#pragma warning( disable:4786 )
*/

//////////////////////////////////////////////////////////////////////////
// CXXXThread Ŭ������ ��ӹ��� Base class
//////////////////////////////////////////////////////////////////////////
class IThread
{
public:
	enum DefThreadType
	{
		ThreadType_Continue,
		ThreadType_OneShot
	};
		
private:
	virtual void Execute( void ) = 0;

public:
	virtual bool Create( DWORD dwCycleTime, DefThreadType hThreadType, HWND hParentWnd=NULL, UINT nMsgNo=0 ) = 0;
	virtual void Destroy( void ) = 0;

	virtual bool InitializeExternal( void ) = 0;
	virtual bool DestroyExternal( void ) = 0;

	virtual void SetThreadType( DefThreadType hThreadType ) = 0;
	virtual void SetParentWnd( HWND hParentWnd ) = 0;
	virtual void SetMessageNo( UINT nMsgNo ) = 0;
	virtual void SetCycleTime( DWORD dwCycleTime ) = 0;

	virtual bool SetThreadPriority( int nPriority ) = 0;
	virtual bool SetThreadResume( void ) = 0; 
	virtual bool SetThreadSuspend( void ) = 0; 

	virtual bool Start( void ) = 0;
	virtual bool Stop( void ) = 0;

	virtual bool IsRunning( void ) = 0;

public:
	IThread( void ) {}
	virtual ~IThread( void ) {}
};


//////////////////////////////////////////////////////////////////////////
// �Ϲ����� Thread ��ü�� Base Ŭ����. 
// CGeneralThread.���� ��ӹ޾� �����Լ� Execute()�� ������ �ؼ� ����ؾ� ��.
//////////////////////////////////////////////////////////////////////////
class CGeneralThread : public IThread
{
	// Attribute
private:
	DWORD			dwCycleTime_;
	HANDLE			hThread_;
	HANDLE			evtRunning_;
	HANDLE			evtOneStep_;
	DefThreadType	hThreadType_;
	
//	HANDLE			evtStop_;

protected:
	HWND			hParentWnd_;
	UINT			nMsgNo_;
	bool			bIsRunning_;		// Thread�� ������ �̸� true, �׷��� ������ false 
										// ��� �޴� class�� Execute() �Լ����� ���� Loop�� �����Ѵٸ�,
										// �� ������ ���� false �϶�, ���� �������� ������ ���� ���;� �Ѵ�.

public:
		// Implement 
private:
	unsigned int running( void );
	virtual void Execute( void ) = 0;
	
public:
	virtual bool Create( DWORD dwCycleTime, DefThreadType hThreadType, HWND hParentWnd=NULL, UINT nMsgNo=0 );
	virtual void Destroy( void );

	virtual bool InitializeExternal( void ) { return true; }
	virtual bool DestroyExternal( void ) { return true; }

	virtual void SetThreadType( DefThreadType hThreadType ); 
	virtual void SetParentWnd( HWND hParentWnd ) { hParentWnd_ = hParentWnd; }
	virtual void SetMessageNo( UINT nMsgNo ) { nMsgNo_ = nMsgNo; }
	virtual void SetCycleTime( DWORD dwCycleTime ); 

	virtual bool SetThreadPriority( int nPriority ) { if( hThread_ == NULL ) return false; ::SetThreadPriority( hThread_, nPriority ); return true; }
	virtual bool SetThreadResume( void ) { if( hThread_ == NULL ) return false; ::ResumeThread( hThread_ ); return true; };
	virtual bool SetThreadSuspend( void ) { if( hThread_ == NULL ) return false; ::SuspendThread( hThread_ ); return true; }

	virtual bool Start( void );
	virtual bool Stop( void );

	virtual bool IsRunning( void ) { return bIsRunning_; }


	// Constructor & Destructor
public:
	CGeneralThread( void );
	virtual ~CGeneralThread( void );
	// Static Member Function
// 	static unsigned int __stdcall threadProc( void* pParam )
// 	{
// 		CGeneralThread*		pThread = static_cast<CGeneralThread *>( pParam );
// 		return pThread->running();
// 	}
	static DWORD threadProc( LPVOID* pParam ) 
	{
		CGeneralThread* pThread = (CGeneralThread*)pParam;	//static_cast<CGeneralThread*>(pParam);
		return pThread->running();
	}
};


//////////////////////////////////////////////////////////////////////////
// MMTimer Thread�� �����.
//////////////////////////////////////////////////////////////////////////
// class CMMTimerThread : public IThread
// {
// 	// Attribute
// private:
// 	DWORD			dwCycleTime_;
// 	DefThreadType	hThreadType_;
// 	HANDLE			hThread_;
// 	HANDLE			evtRunning_;
// 	MMRESULT		hMMTImer_;
// 
// protected:
// 	HWND			hParentWnd_;
// 	UINT			nMsgNo_;
// 	bool			bIsRunning_;
// 
// public:
// 
// 	// Implement 
// private:
// 	unsigned int running( void );
// 	virtual void Execute( void ) = 0;
// 
// public:
// 	virtual bool Create( DWORD dwCycleTime, DefThreadType hThreadType, HWND hParentWnd=NULL, UINT nMsgNo=0 );
// 	virtual void Destroy( void );
// 
// 	virtual bool InitializeExternal( void ) { return true; }
// 	virtual bool DestroyExternal( void ) { return true; }
// 
// 	virtual void SetThreadType( DefThreadType hThreadType );
// 	virtual void SetParentWnd( HWND hParentWnd ) { hParentWnd_ = hParentWnd; }
// 	virtual void SetMessageNo( UINT nMsgNo ) { nMsgNo_ = nMsgNo; }
// 	virtual void SetCycleTime( DWORD dwCycleTime );
// 
// 	// MultiMedia Timer������ �Ʒ� Thread �Ӽ��� �ǹ̰� ����. �Ϲ����̱� ���� ����� ������.
// 	virtual bool SetThreadPriority( int nPriority ) { return true; }
// 	virtual bool SetThreadResume( void ) { return true; };
// 	virtual bool SetThreadSuspend( void ) { return true; }
// 
// 	virtual bool Start( void );
// 	virtual bool Stop( void );
// 
// 	virtual bool IsRunning( void ) { return bIsRunning_; }
// 
// 
// 	// Constructor & Destructor 
// public:
// 	CMMTimerThread( void );
// 	virtual ~CMMTimerThread( void );
// 
// 	// Static Member Function
// 	static unsigned int __stdcall threadProc( void* pParem )
// 	{
// 		CMMTimerThread*		pThread = static_cast<CMMTimerThread *>( pParem );
// 		return pThread->running();
// 	}
// };


//////////////////////////////////////////////////////////////////////////
// IThread Class���� ��ӵ� Thread ��ü�� �����ϱ� ���� Manager Class 
//////////////////////////////////////////////////////////////////////////
/*
class CThreadMgr
{
	// Attribute
private:
	map< CString, IThread* >	hMap_;

public:

	// Implement 
private:

public:
	bool Initialize( void );

	void Destroy( void );

	// Thread�� Map�� ����Ѵ�.
	bool Add( const CString& strKey, IThread* pThread );
	// Thread�� Map���� �����ϰ�, ���ǿ� ���� Thread ��ü�� �����Ѵ�.
	bool Remove( const CString& strKey, bool bDeleteThread );
	// strKey�� Thread ��ü�� �����͸� �����Ѵ�.
	IThread* Find( const CString& strKey );

public:
	CThreadMgr( void );
	virtual ~CThreadMgr( void );
};
*/
