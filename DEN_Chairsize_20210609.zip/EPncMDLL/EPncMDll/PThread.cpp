#include "StdAfx.h"
#include "PThread.h"
#include "HomeDlg.h"
#include "math.h"
#include "AutoCalDlg.h"

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

#define SEND_CMD_MDA(StepVar, StepNo, NextStepNo, LineCmd)					\
	case StepNo:															\
		PAMotion->MDA(FALSE, LineCmd);										\
		Sleep(300);															\
		StepVar = NextStepNo;												\
		break;																\

#define MOVE_DNE_MDA(StepVar, StepNo, NextStepNo)							\
	case StepNo:															\
		if( PAMotion->MotionDone(CPAAsyncComm::CMD_RND_MDA, TRUE) )			\
			StepVar = NextStepNo;											\
		break;																\
/*
#define MOVE_DNE_Mxxx(StepVar, StepNo, NextStepNo, Mxxx)					\
	case StepNo:															\
		if( PAMotion->MotionDone(Mxxx, TRUE) )								\
			StepVar = NextStepNo;											\
	break;																	\
*/
#define MOVE_DNE_Mxxx(StepVar, StepNo, NextStepNo, Mxxx)					\
	case StepNo:															\
		if( PAMotion->MotionDone(Mxxx, FALSE) )								\
			StepVar = NextStepNo;											\
	break;																	\


#define SEND_STREAM_CMD(StepVar, StepNo, NextStepNo, StreamCmd, WaitCmd)	\
	case StepNo:															\
		PAMotion->SendStreamCommand(StreamCmd, TRUE);						\
		PAMotion->SendStreamCommand(WaitCmd, TRUE);							\
		Sleep(100);															\
		StepVar = NextStepNo;												\
		break;																\

#define MOVE_DNE_STREAM(StepVar, StepNo, NextStepNo)						\
	case StepNo:															\
		if( PAMotion->SendStreamCommand("?\r\n", FALSE) == 0 )				\
			StepVar = NextStepNo;											\
		Sleep(100);															\
		break;

#define TO_G54(axis, val) ( val - (PConfig->pConfig_->fCoordOffset[pa::COORD_G54][axis]) )	

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

/*
	TCHAR	*PATH = _T("/Flash Disk/rnd");	//_T("/SD Card/EPNC/rnd")
	FILE *pf = _tfopen( PATH, _T("wb") );

	if( pf == NULL )
		return ;

	fwrite( (void*)&(PPAStatus->GetThreadState()->dwTOTAL_SPINDLE_RUN_TIME), 1, sizeof(DWORD), pf );

	fclose( pf ); pf = NULL;
*/

void pa::CPThread::WRITE_TOOL_INFO( int direction, int tool_no, double tool_length, int tool_length_update_flag )
{
	// direction : 0 - left, 1 - right
	struct STemp
	{
		int i;
		double f;
		int j;
	};
	TCHAR	*PATH;

	if( direction == 0 )
	{
		PATH = TOOL_INFO_PATH1;
	}
	
	else
	{
		PATH = TOOL_INFO_PATH2;
	}
	
	FILE* pf = _tfopen( PATH, _T("wb") );
	STemp s;
	s.i = tool_no;
	s.f = tool_length;
	s.j = tool_length_update_flag;

	if( pf==NULL )
		return ;

	fwrite( (void*)&s, 1, sizeof(STemp), pf );

	fclose( pf ); pf = NULL;
}

void pa::CPThread::READ_TOOL_INF0( int direction, int* tool_no, double* tool_length, int* tool_length_update_flag )
{
	// direction : 0 - left, 1 - right
	struct STemp
	{
		int i;
		double f;
		int j;
	};

	TCHAR	*PATH;

	if (direction == 0)
	{
		PATH = TOOL_INFO_PATH1;
	}

	else
	{
		PATH = TOOL_INFO_PATH2;
	}
	
	FILE* pf = _tfopen( PATH, _T("rb") );
	STemp s;

	if( pf == NULL ) {
		*tool_no = 0;
		*tool_length = 0.0;
		*tool_length_update_flag = 0;
		return ;
	}

	fread( (void*)&s, 1, sizeof(STemp), pf );

	*tool_no = s.i;
	*tool_length = s.f;
	*tool_length_update_flag = s.j;

	fclose( pf ); pf = NULL;
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

pa::CPThread::CPThread(void)
{
	InitializeCriticalSection( &cs_ );

	for( int i = 0; i<RUNMODE_NUM; i++ ) {
		nStep_[i] = 0;
	}

	nStartLineNo_			= 0;
	bIsPressStopButton_		= FALSE;
	bIsSensingExistBlock_	= FALSE;
	bIsNeedBlockLoading_	= FALSE;
	bIsNeedBlockUnloading_	= FALSE;
	hasRescanForRefill_		= FALSE;

	hPrevRunMode_			= RUNMODE_NUM;
	PREV_SPINDLE_AIR_PURGE_	= -1;
	nCurrSpindleAirPurge_	= 0;
// 	dwSpindleAirPurgeOffTime_ = 0;

	nToolErrorHandlingCode_	= -1;

	bIsToolError_ = FALSE;
	bIsEMOError_ = FALSE;
}

pa::CPThread::~CPThread(void)
{
	DeleteCriticalSection( &cs_ );
	Destoy();
}

BOOL pa::CPThread::Initialize( DWORD dwCycleTime, CString& strErrMsg )
{
	if( !Create( dwCycleTime, IThread::ThreadType_Continue, NULL, 0 ) ) {
		strErrMsg.Format( _T("create thread error for pa::CPThread") );
		return FALSE;
	}

	try {
		if( PPAAsyncComm[0]->GetConnectState() == pa::CONNECT_STATUS_CONNECTED ||
			PPAAsyncComm[1]->GetConnectState() == pa::CONNECT_STATUS_CONNECTED ) 
		{
// 			change_external_button_led( pa::RUNMODE_STOP );
		}
	}
	catch( CPException& e ) {
		PPAAsyncComm[0]->Close();
		PPAAsyncComm[1]->Close();
	}

	PPAStatus->GetThreadState()->bCheckStatus = TRUE;

	change_external_button_led( pa::RUNMODE_STOP );		// LED ���¸� Stop �� ����� 

	changeRunMode( pa::RUNMODE_STOP, TRUE );

	return TRUE;
}

void pa::CPThread::Destoy()
{
	Stop();
}

//////////////////////////////////////////////////////////////////////////

// �ʱ�ȭ �ϱ� ��, autoloader�� �� ���� ���¸� checking �Ѵ� 
pa::EN_PNC_ERR pa::CPThread::checkAutoloaderStartInterlock()
{
// #ifdef _USE_PMAC_
// 	// 1. ���� �δ��� ������ ������ �ִ��� Ȯ�� 
// 	if( PState->GetPmacState()->nOut24_BlockLoader_PNC_Gripper_Grip ||
// 		PState->GetPmacState()->nIn26_BlockLoader_Gripper_Grip )
// 	{
// 		return PNC_ERR_AutoLoader_Interlock_GripBlock;
// 	}
// 
// 	// 2. ���� �δ��� ���� �����Ǿ� �ִ��� 
// 	if( PState->GetPmacState()->nIn24_BlockLoader_EXT_ARM ) 
// 	{
// 		return PNC_ERR_AutoLoader_Interlock_ExtArm;
// 	}
// 
// 	// 3. ���� �δ��� PNC ������ ���ϰ� �ִ��� Ȯ�� 
// 	if( PState->GetPmacState()->nIn30_BlockLoader_ROT_ARM_ToPNC ) 
// 	{
// 		return PNC_ERR_AutoLoader_Interlock_RotPNC;
// 	}
// #endif
	return PNC_ERR_NONE;
}

//////////////////////////////////////////////////////////////////////////

void pa::CPThread::DoInit()
{
	if( PPAStatus->GetRunMode() == pa::RUNMODE_STOP ) {
		changeRunMode( pa::RUNMODE_INIT, TRUE );
	}
	else {
		// ���� 
		throw CPException( ERR_PNC, PNC_ERR_INVALID_RUNMODE, _T("pa::CPThread::DoInit(1)") );
	}
}

void pa::CPThread::DoStop( BOOL bUseToStop )
{
	bIsPressStopButton_ = TRUE;

	if( bUseToStop == TRUE ) {
		changeRunMode( pa::RUNMODE_TOSTOP, TRUE );
	} else {
		changeRunMode( pa::RUNMODE_STOP, TRUE );
	}
}

void pa::CPThread::DoPause()
{
//	if( PPAStatus->GetRunMode() == pa::RUNMODE_RUN ) {
//		changeRunMode( pa::RUNMODE_PAUSE, TRUE );
//	}
//	else {
//		// ���� 
//		CString strEx;
//		strEx.Format( _T("pa::CPThread::DoPause(1) - %d"), PPAStatus->GetRunMode() );
// 		throw CPException( ERR_PNC, PNC_ERR_INVALID_RUNMODE, _T("pa::CPThread::DoPause(1)") );
//		throw CPException( ERR_PNC, PNC_ERR_INVALID_RUNMODE, strEx );
//	}

	EnterCriticalSection(&cs_);

	EN_RUNMODE runMode = PPAStatus->GetRunMode();

	if (runMode == pa::RUNMODE_PAUSE) 
	{

	}
	else if (runMode == pa::RUNMODE_RUN) 
	{
		changeRunMode( pa::RUNMODE_PAUSE, TRUE );
	}
	else 
	{
		LeaveCriticalSection(&cs_);
		// ���� 
		CString strEx;
		strEx.Format( _T("pa::CPThread::DoPause(1) - %d"), PPAStatus->GetRunMode() );
		throw CPException( ERR_PNC, PNC_ERR_INVALID_RUNMODE, strEx );
	}

	LeaveCriticalSection(&cs_);
}

// nStartLineNo�� 1���� ��� 
// - ����⿡�� �������� ���� ���� ��ȣ�� 1���� ���� 
// - thread state�� nCurrentNCCodeStepNo�� StartLineNo-1�� �ʱ�ȭ 
// - �� �� update status���� ������� line number�� ������, �� ���� ���ؼ� nCurrentNCCodeStepNo ���� 
void pa::CPThread::DoRun( int nStartLineNo, BOOL bRestoreBeforeRun )
{
	bIsPressStopButton_		= FALSE;
	bIsNeedBlockLoading_	= FALSE;
	bIsNeedBlockUnloading_	= FALSE;
	
	bIsSensingExistBlock_	= FALSE;

	SET_ERROR_LINENO( 0 );

	if( nStartLineNo <= 1 ) {
		nStartLineNo = 1;
	}

	pa::PPAStatus->GetThreadState()->nPauseByDoorOpen = 0;	// ���� �ʱ�ȭ 

	if( PPAStatus->GetRunMode() == pa::RUNMODE_PAUSE )
	{
		// pa ������ �̾ ���� ������ �����Ѵ� 
		PAMotion->CONTINUE();
		Sleep( 500 );
		// RunMode�� �����ϰ�,
		changeRunMode( RUNMODE_RUN, FALSE );
	}
	else if( PPAStatus->GetRunMode() == RUNMODE_STOP )
	{
		pa::PPAStatus->GetThreadState()->bIsPauseAirLimit_ = FALSE;		// ���� ���� ���� ������ ���߾����� TRUE

		PPAStatus->GetThreadState()->nStartingNCCodeStepNo	= nStartLineNo - 1;
		PPAStatus->GetThreadState()->nCurrentNCCodeStepNo	= nStartLineNo - 1;
		PPAStatus->GetThreadState()->nNumberOfPreparingStep = 0;

		nStartLineNo_		= nStartLineNo;
		bRestoreBeforeRun_	= bRestoreBeforeRun;

		if( nStartLineNo_ == 1 ) {
			// ���� ������ 1�̸�, PNCFile�� WorkLine�� �ʱ�ȭ �Ѵ� 
			PNCFile->ResetWorkLine();
		}

		//////////////////////////////////////////////////////////////////////////
		// ���� �ε��� �ʿ����� Ȯ���Ѵ�
		//////////////////////////////////////////////////////////////////////////
#ifdef _USE_AUTOLOADER_
		if( nStartLineNo == 1 ) 
		{
			// ó������ ����. AutoLoader�� ����ϸ� ������ �ε�  
			bIsNeedBlockLoading_ = PAutoLoader->IsUsingAutoLoader();
		}
		else 
		{
			// NC ������ ���� �ִ��� Ȯ�� 
			if( PPAStatus->GetThreadState()->bIsOpenNCFile == FALSE ) {
				// ����. �̾ ������ NC ������ Open �Ǿ� ���� ���� 
				throw CPException( ERR_PNC, PNC_ERR_NOT_OPENED_NCFIEL_FOR_CONTINUE, _T("pmac::CThread::DoRun(1)") );
			}

			// �̾ ����. ������ ���� ���� ������ ���� 
			bIsNeedBlockLoading_ = FALSE;
// 			if( PConfig->pConfig_->bUsingDetectBlock && ( PPAStatus->GetPAStatus()->bInput[pa::IN20017_DetectedBlock] == FALSE ) ) {
// 				// ����. �̾ ������ ������ ���� 
// 				throw CPException( ERR_PNC, PNC_ERR_NO_BLOCK_FOR_CONTINU_RUN, _T("pmac::CPThread::DoRun(2)") );
// 			}
		}

		// AutoLoader�� ������� ���� ���, FALSE�� ����� 
		if( PAutoLoader->IsUsingAutoLoader() == FALSE ) {
			bIsNeedBlockLoading_ = FALSE;
		}

#else 
		bIsNeedBlockLoading_ = FALSE;
#endif

		if (PAutoLoader->IsUsingAutoLoader() && !PAutoLoader->IsThisNCFileValid(pa::PPAStatus->GetThreadState()->hNCFileInfo.file_name)) {
			changeRunMode( pa::RUNMODE_TOSTOP, TRUE );
		} else {
			changeRunMode( pa::RUNMODE_TORUN, TRUE );
		}
	} 
	else {
		// ����. �߸��� ��� ����
		throw CPException( ERR_PNC, PNC_ERR_INVALID_RUNMODE, _T("pmac::CPThread::DoRun(4)") );
	}
}

// AutoLoader�� ReFill ���� 
void pa::CPThread::DoAutoLoaderReFill()
{
	PAutoLoader->ResetAutoLoaderItemNumberState();

	// ���� ���� ������ ��Ȱ��ȭ �Ѵ� 
	bIsSensingExistBlock_ = FALSE;

	// 
	nStep_[RUNMODE_RUN] = 10000;	// 10000���� AutoLoader�� ReFill ��� 
	changeRunMode( RUNMODE_RUN, FALSE );
}

void pa::CPThread::DoStopAutoLoaderReFill()
{
	changeRunMode( RUNMODE_STOP, TRUE );
}

void pa::CPThread::DoReturnItems()
{
	// PAMotion->MoveReadyPos();
	bIsSensingExistBlock_ = FALSE;

	nStep_[RUNMODE_RUN] = 14000;	// 10000���� AutoLoader�� ReFill ��� 
	changeRunMode( RUNMODE_RUN, FALSE );
}
//////////////////////////////////////////////////////////////////////////

void pa::CPThread::DoStartAutoCalCoordinateOffset()
{
	nStep_[RUNMODE_RUN] = 50000;			// 50000���� AutoCal CoordinateOffset 
	changeRunMode( RUNMODE_RUN, FALSE );
}

void pa::CPThread::DoStopAutoCalCoordinateOffset()
{	
	//////////////////////////////////////////////////////////////////////////
	// ��ũ�� ���� 
	PAMotion->STOP();
	Sleep(10);
	PAMotion->STOP();
	Sleep(10);
	PAMotion->HALT();
	Sleep(10);
	PAMotion->HALT();
	//////////////////////////////////////////////////////////////////////////
	changeRunMode( RUNMODE_STOP, TRUE );
}


void pa::CPThread::DoStartAutoTeachMultiOrigin()
{
	nStep_[RUNMODE_RUN] = 56000;	// 56000���� AutoCal CoordinateOffset 
	changeRunMode( RUNMODE_RUN, FALSE );
}

void pa::CPThread::DoStopAutoTeachMultiOrigin()
{
	//////////////////////////////////////////////////////////////////////////
	// ��ũ�� ���� 
	PAMotion->STOP();
	Sleep(10);
	PAMotion->STOP();
	Sleep(10);
	PAMotion->HALT();
	Sleep(10);
	PAMotion->HALT();
	//////////////////////////////////////////////////////////////////////////
	changeRunMode( RUNMODE_STOP, TRUE );
}

void pa::CPThread::DoStartAutoTeachToolPocket()
{
	nStep_[RUNMODE_RUN] = 52000;	// 52000 ~ 54000���� Auto Teaching for Tool Pocket 
	changeRunMode( RUNMODE_RUN, FALSE );
}

void pa::CPThread::DoStopAutoTeachToolPocket()
{
	//////////////////////////////////////////////////////////////////////////
	// ��ũ�� ����
	PAMotion->STOP();
	Sleep(10);
	PAMotion->STOP();
	Sleep(10);
	PAMotion->HALT();
	Sleep(10);
	PAMotion->HALT();
	Sleep(10);
	//////////////////////////////////////////////////////////////////////////
	changeRunMode( RUNMODE_STOP, TRUE );
}


void pa::CPThread::DoStartAutoCalSingleAbutmentCoordinateOffset()
{
	nStep_[RUNMODE_RUN] = 58000;	// 58000 ~ 59999 
	changeRunMode( RUNMODE_RUN, FALSE );
}

void pa::CPThread::DoStopAutoCalSingleAbutmentCoordinateOffset()
{
	//////////////////////////////////////////////////////////////////////////
	// ��ũ�� ����
	PAMotion->STOP();
	Sleep(10);
	PAMotion->STOP();
	Sleep(10);
	PAMotion->HALT();
	Sleep(10);
	PAMotion->HALT();
	Sleep(10);
	//////////////////////////////////////////////////////////////////////////
	changeRunMode( RUNMODE_STOP, TRUE );
}

void pa::CPThread::DoStartAutoCalSingleAbutmentCoordinateOffset_A()
{
	nStep_[RUNMODE_RUN] = 60000;	// 60000 ~ 61999 
	changeRunMode( RUNMODE_RUN, FALSE );
}

void pa::CPThread::DoStopAutoCalSingleAbutmentCoordinateOffset_A()
{
	//////////////////////////////////////////////////////////////////////////
	// ��ũ�� ����
	PAMotion->STOP();
	Sleep(10);
	PAMotion->STOP();
	Sleep(10);
	PAMotion->HALT();
	Sleep(10);
	PAMotion->HALT();
	Sleep(10);
	//////////////////////////////////////////////////////////////////////////
	changeRunMode( RUNMODE_STOP, TRUE );
}

void pa::CPThread::DoStartATCTest()
{
	nStep_[RUNMODE_RUN] = 62000;	// 62000 ~ 62999 
	changeRunMode( RUNMODE_RUN, FALSE );
}

void pa::CPThread::DoStopATCTest()
{
	//////////////////////////////////////////////////////////////////////////
	// ��ũ�� ����
	PAMotion->STOP();
	Sleep(10);
	PAMotion->STOP();
	Sleep(10);
	PAMotion->HALT();
	Sleep(10);
	PAMotion->HALT();
	Sleep(10);
	//////////////////////////////////////////////////////////////////////////
	changeRunMode( RUNMODE_STOP, TRUE );
}

//////////////////////////////////////////////////////////////////////////
// index ��° NC File�� Open �Ѵ�  
BOOL pa::CPThread::OpenNCFile( int nNCFileIndex, CString& strErrMsg )
{
	PPAStatus->GetThreadState()->bIsFileOpening = TRUE;

	SNCFileInfo* pInfo = PNCFileMgr->GetNCFileInfo( nNCFileIndex );

	ASSERT( pInfo );

	CString strFilePath;
	strFilePath.Format( _T("%s\\%s"), NCFILE_PATH, pInfo->file_name );

	CString strSendmessage;
	strSendmessage.Format(_T("g0.txt=\"%s\""), pInfo->file_name);
	pGLCD->SendCommand(strSendmessage); // Graphic LCD�� ���ϸ� ����

	// 2015.09.10 Open �Լ� �׽�Ʈ 
	// Open2 �Լ� ���ο��� while loop ���. 
	// �ð��� ���� �ɸ� 
	if( !PNCFile->Open2( strFilePath, strErrMsg ) ) {
		PPAStatus->GetThreadState()->bIsFileOpening = FALSE;
		return FALSE;
	}

	// ���� NC File�� �� ���μ��� ���� 
	int nNumTotalLines = PNCFile->GetNumTotalLines();
	
	// NCFileMgr�� ���� �۾����� �ε��� ���� 
	PNCFileMgr->SetCurrentWorkIndex( nNCFileIndex, FALSE );

	// PState�� ���� �۾� ���� ���� ���� 
	PPAStatus->SetNCFileInfo( nNCFileIndex );

	// NC File ������ �� ���� ���� �����Ѵ�
	PPAStatus->SetNCFileTotalLine( nNumTotalLines, TRUE );

	// 
	PPAStatus->GetThreadState()->bIsFileOpening = FALSE;

	return TRUE;
}

// NC File�� Close �Ѵ� 
void pa::CPThread::CloseNCFile()
{
	//
	static int isFirstTime = 0;
	PNCFile->Close();

	PNCFileMgr->SetNCFileSelect( PNCFileMgr->GetCurrentWorkNCFileIndex(), 0, TRUE );

	// NCFileMgr�� ���� �۾����� �ε��� �ʱ�ȭ 
	PNCFileMgr->SetCurrentWorkIndex( -1, FALSE );

	// PState�� ���� �۾� ���� ���� �ʱ�ȭ 
	PPAStatus->ResetNCFileInfo();

	if ( isFirstTime != 0)	// ó�� ���α׷� ���� ��, Graphci LCD�� NC���ϸ� �ʱ�ȭ �ڵ尡 ����Ǹ� pGLCDComm->Recv���� �̻��� Return�� �´�. �̸� ����
	{
		CString strSendmessage;
		strSendmessage.Format(_T("g0.txt=\"\""));
		pGLCD->SendCommand(strSendmessage); // Graphic LCD ���ϸ� �ʱ�ȭ
	}

	isFirstTime++;
}

void pa::CPThread::updateLCDProgressbar()
{
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetThreadState()->hRunMode;
	if (hRunMode == pa::RUNMODE_ERROR) return ;

	double fTotalLines	= (double)(pa::PPAStatus->GetThreadState()->hNCFileInfo.total_lines);
	double fCurrStep	= (double)(pa::PPAStatus->GetThreadState()->hNCFileInfo.machining_lines);
	int fCurrRate	= 0;
	static int PREV_RATE = 0;

	if( fCurrStep < 0.1 || fTotalLines < 0.1 ) {
		fCurrRate = 0.0;
	} else {
		fCurrRate = ( fCurrStep / fTotalLines ) * 100.0;
		fCurrRate = fCurrRate > 100.0 ? 100.0 : fCurrRate;	// �������� 100.0�� ���� �ʵ��� �Ѵ� 
	}

	if (PREV_RATE != fCurrRate)
	{
		PREV_RATE = fCurrRate;
		CString strSendmessage;
		strSendmessage.Format(_T("page0.j0.val=%d"), fCurrRate);
		pGLCD->SendCommand(strSendmessage);
		strSendmessage.Format(_T("page0.t6.txt=\"%d%%\""), fCurrRate);
		pGLCD->SendCommand(strSendmessage);
	}
}

void pa::CPThread::updateLCDMillingTime()
{
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetThreadState()->hRunMode;
	if (hRunMode == pa::RUNMODE_ERROR) return ;

	DWORD dwRunningTime = pa::PPAStatus->GetThreadState()->dwRunningTime;
	static DWORD PREV_RUNNING_TIME = 999999999;
	CTimeSpan	tms( dwRunningTime );
	int			milling_time[3] = { tms.GetHours(), tms.GetMinutes(), tms.GetSeconds() };

	if (PREV_RUNNING_TIME != dwRunningTime)
	{
		PREV_RUNNING_TIME = dwRunningTime;
		CString strSendmessage;
		strSendmessage.Format(_T("page0.t0.txt=\"%02d:%02d:%02d\""), milling_time[0], milling_time[1], milling_time[2]);
		pGLCD->SendCommand(strSendmessage);
	}
}

void pa::CPThread::updateLCDChairmanState()
{
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetThreadState()->hRunMode;
	if (hRunMode == pa::RUNMODE_ERROR) return ;

	static CString PREV_RUNMODE = _T("");
	CString curr_Runmode;
	pa::EN_RUNMODE runMode;
	runMode = pa::PPAStatus->GetRunMode();
	BOOL	bPAConnected = (pa::PPAStatus->GetThreadState()->nIsConnectedPAController != 0) ? 1 : 0;
	BOOL	bIOConnected = (pa::PPAStatus->GetThreadState()->nIsConnectedIOBoard != 0) ? 1 : 0;

	if (!bPAConnected || !bIOConnected)
	{
		curr_Runmode = _T("Not Connected");
	}

	else
	{
		switch (runMode)
		{
		case pa::RUNMODE_INIT:
		case pa::RUNMODE_STOP:
			curr_Runmode = _T("Connected");
			break;
		case pa::RUNMODE_TOSTOP:
		case pa::RUNMODE_TORUN:
		case pa::RUNMODE_RUN:
			curr_Runmode = _T("Running");
			break;
		case pa::RUNMODE_ERROR:
			curr_Runmode = _T("Error");
			break;
		}
	}

	if ( curr_Runmode.Compare(PREV_RUNMODE) )
	{
		CString strSendmessage;
		strSendmessage.Format(_T("page0.t1.txt=\"%s\""), curr_Runmode);
		pGLCD->SendCommand(strSendmessage);
		PREV_RUNMODE = curr_Runmode;
	}
}

void pa::CPThread::updateLCDToolState()
{
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetThreadState()->hRunMode;
	if (hRunMode == pa::RUNMODE_ERROR) return ;

	static CString PREV_TOOL_NUM = _T("");
	static CString PREV_TOOL2_NUM = _T("");
	static CString PREV_SPINDLE_RPM = _T("");
	static CString PREV_SPINDLE2_RPM = _T("");

	CString curr_tool_num;
	CString curr_tool2_num;
	CString curr_spindle_rpm;
	CString curr_spindle2_rpm;

	curr_tool_num.Format(_T("%d"), pa::PPAStatus->GetPAStatus()->nCurrentToolNo);
	curr_tool2_num.Format(_T("%d"), pa::PPAStatus->GetPAStatus()->nCurrentTool2No);
	curr_spindle_rpm.Format(_T("%d"), pa::PPAStatus->GetPAStatus()->nSpindleSpeed);
	curr_spindle2_rpm.Format(_T("%d"), pa::PPAStatus->GetPAStatus()->nSpindleSpeed2);

	if (curr_tool_num.Compare(PREV_TOOL_NUM))
	{
		CString strSendmessage;
		strSendmessage.Format(_T("page0.t2.txt=\"%s\""), curr_tool_num);
		pGLCD->SendCommand(strSendmessage);
		PREV_TOOL_NUM = curr_tool_num;
	}
	if (curr_tool2_num.Compare(PREV_TOOL2_NUM))
	{
		CString strSendmessage;
		strSendmessage.Format(_T("page0.t4.txt=\"%s\""), curr_tool2_num);
		pGLCD->SendCommand(strSendmessage);
		PREV_TOOL2_NUM = curr_tool2_num;
	}
	if (curr_spindle_rpm.Compare(PREV_SPINDLE_RPM))
	{
		CString strSendmessage;
		strSendmessage.Format(_T("page0.t3.txt=\"%s\""), curr_spindle_rpm);
		pGLCD->SendCommand(strSendmessage);
		PREV_SPINDLE_RPM = curr_tool2_num;
	}
	if (curr_spindle2_rpm.Compare(PREV_SPINDLE2_RPM))
	{
		CString strSendmessage;
		strSendmessage.Format(_T("page0.t5.txt=\"%s\""), curr_spindle2_rpm);
		pGLCD->SendCommand(strSendmessage);
		PREV_SPINDLE2_RPM = curr_spindle2_rpm;
	}
}

// PC�ּ��� LCD�� var0.val�� �ֱ������� 0���� �ʱ�ȭ 
// LCD������ page0�� tm(Timer), va0(val0)�� ����Ǿ� �ְ�,
// Timer���� va0�� 100�� ����, 10000�̻� ������ page3���� ȭ�� ��ȯ 
// "va0.val=0" �̶�� �ϸ�, LCD�� ���� page�� �ִ� va0.val�� 0���� ������ 
void pa::CPThread::sendLCDConnectionFlag()
{
	static int flag_time = 0;		// PThread�� 100ms ���� �����ϹǷ�, 1000ms���� �ѹ��� Flag�� �������� ����
	if (flag_time == 10)
	{
		CString strSendmessage;
		strSendmessage.Format(_T("page2.va0.val=0"));
		pGLCD->SendCommand(strSendmessage);
		flag_time = 0;
	}
	flag_time++;
}

// ������ ��ȣ�� �������� "page0" ���� index ��ȣ�� ������ �Ѵ� 
// page no : no�� page�̸��� �ƴ�, ���� index ��ȣ�� ������ 
// page �� index ���� ������ �� �־�� �Ѵ� 
void pa::CPThread::updateLCDPage()
{
	static int nPage = 99;
	static int PREV_PAGE = 100;
	CString strSendmessage;
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetThreadState()->hRunMode;
	BOOL bOriginComplete = pa::PPAStatus->GetThreadState()->bIsOriginComplete_;

	if (bOriginComplete && ( hRunMode == pa::RUNMODE_STOP ) )
	{
		nPage = 1;
	}

	else if (bOriginComplete && ( hRunMode == pa::RUNMODE_TORUN || hRunMode == pa::RUNMODE_RUN ) )
	{
		nPage = 2;
	}

	else if (!bOriginComplete)
	{
		nPage = 4;
	}

	else if (bOriginComplete && (hRunMode == pa::RUNMODE_ERROR))
	{
		nPage = 5;
	}

	if (PREV_PAGE != nPage)
	{
		PREV_PAGE = nPage;
		strSendmessage.Format(_T("page %d"), nPage);
		pGLCD->SendCommand(strSendmessage);
	}
}

// ��ư ���� ���� ��� 
void pa::CPThread::updateLCDButtonstate()
{
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetThreadState()->hRunMode;
	if (hRunMode == pa::RUNMODE_ERROR) return ;

	BOOL isLeftToolClampOpened = pa::PPAStatus->GetPAStatus()->nSpindle1ColletOpenFlag;
	BOOL isRightToolClampOpened = pa::PPAStatus->GetPAStatus()->nSpindle2ColletOpenFlag;

	static BOOL PREV_LEFT_CLAMP = FALSE;
	static BOOL PREV_RIGHT_CLAMP = FALSE;
	CString strSendmessage;

	if (isLeftToolClampOpened != PREV_LEFT_CLAMP)
	{
		PREV_LEFT_CLAMP = isLeftToolClampOpened;
		if (isLeftToolClampOpened == FALSE)
		{
			strSendmessage.Format(_T("b4.val=0"));
			pGLCD->SendCommand(strSendmessage);
		}
		else
		{
			strSendmessage.Format(_T("b4.val=1"));
			pGLCD->SendCommand(strSendmessage);
		}
	}

	if (isRightToolClampOpened != PREV_RIGHT_CLAMP)
	{
		PREV_RIGHT_CLAMP = isRightToolClampOpened;
		if (isRightToolClampOpened == FALSE)
		{
			strSendmessage.Format(_T("b3.val=0"));
			pGLCD->SendCommand(strSendmessage);
		}
		else
		{
			strSendmessage.Format(_T("b3.val=1"));
			pGLCD->SendCommand(strSendmessage);
		}
	}
}

void pa::CPThread::updateLDCState()
{
	static int nPrevPageNo = -1;
	static int flag_Time = 0;
	static int PREV_RATE = 0;

	BOOL bOriginComplete = pa::PPAStatus->GetThreadState()->bIsOriginComplete_;
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetThreadState()->hRunMode;
	int nPageNo = 0;
	int nPageNoCtrl = 0;

	CString strSendMessage;

	// 1. 
// 	if (flag_Time++ >= 10)
// 	{
// 		strSendMessage.Format(_T("page2.va0.val=0"));
// 		pGLCD->SendCommand(strSendMessage);
// 		flag_Time = 0;
// 	}

	// 2. ���� RunMode�� �´� Page ���� 
	if (bOriginComplete)
	{
		switch (hRunMode)
		{
		case RUNMODE_TORUN:
		case RUNMODE_RUN:
			PREV_RATE = -1;
		case RUNMODE_TOSTOP:
		case RUNMODE_PAUSE:
			nPageNo = 2;
			nPageNoCtrl = 1;
			break;
		case RUNMODE_STOP:
			nPageNo = 1;
			nPageNoCtrl = 0;
			break;
		case RUNMODE_INIT:
			nPageNo = 1;
			nPageNoCtrl = 0;
			break;
		case RUNMODE_ERROR:
			nPageNo = 5;
			nPageNoCtrl = 5;
			break;
		}
	}
	else 
	{
		nPageNo = 4;
	}
	if (nPrevPageNo != nPageNo)
	{
		nPrevPageNo = nPageNo;
		strSendMessage.Format(_T("page %d"), nPageNo);
		pGLCD->SendCommand(strSendMessage);
	}

	// 3. update lcd progressbar 
	if (nPageNoCtrl == 1 || nPageNoCtrl == 0)
	{
		int fCurrRate = 0;
		double fTotalLines	= (double)(pa::PPAStatus->GetThreadState()->hNCFileInfo.total_lines);
		double fCurrStep	= (double)(pa::PPAStatus->GetThreadState()->hNCFileInfo.machining_lines);
		if (fCurrStep <= 0 || fTotalLines <=0) {
			fCurrRate = 0;
		}
		else {
			fCurrRate = (fCurrStep / fTotalLines) * 100.0;
			fCurrRate = fCurrRate > 100.0 ? 100.0 : fCurrRate;	// �������� 100.0�� ���� �ʵ��� 
		}
		if (PREV_RATE != fCurrRate)
		{
// 			strSendMessage.Format(_T("page%d.j0.val=%d"), nPageNoCtrl, fCurrRate);
// 			pGLCD->SendCommand(strSendMessage);
// 			strSendMessage.Format(_T("page%d.t6.txt=\"%d%%\""), nPageNoCtrl, fCurrRate);
// 			pGLCD->SendCommand(strSendMessage);

			strSendMessage.Format(_T("page0.j0.val=%d"), fCurrRate);
			pGLCD->SendCommand(strSendMessage);
			strSendMessage.Format(_T("page0.t6.txt=\"%d%%\""), fCurrRate);
			pGLCD->SendCommand(strSendMessage);

			strSendMessage.Format(_T("page1.j0.val=%d"), fCurrRate);
			pGLCD->SendCommand(strSendMessage);
			strSendMessage.Format(_T("page1.t6.txt=\"%d%%\""), fCurrRate);
			pGLCD->SendCommand(strSendMessage);
		}
	}

	// 4. Milling time 
	if (nPageNoCtrl == 1 || nPageNoCtrl == 0)
	{
		static DWORD PREV_RUNNING_TIME = 99999999;
		DWORD		dwRunningTime = pa::PPAStatus->GetThreadState()->dwRunningTime;
		CTimeSpan	tms(dwRunningTime);

		if (PREV_RUNNING_TIME != dwRunningTime)
		{
			PREV_RUNNING_TIME = dwRunningTime;
// 			strSendMessage.Format(_T("page%d.t0.txt=\"%02d:%02d:%02d\""), nPageNoCtrl, 
// 				tms.GetHours(), tms.GetMinutes(), tms.GetSeconds());
// 			pGLCD->SendCommand(strSendMessage);
			strSendMessage.Format(_T("page0.t0.txt=\"%02d:%02d:%02d\""), 
				tms.GetHours(), tms.GetMinutes(), tms.GetSeconds());
			pGLCD->SendCommand(strSendMessage);
			strSendMessage.Format(_T("page1.t0.txt=\"%02d:%02d:%02d\""),
				tms.GetHours(), tms.GetMinutes(), tms.GetSeconds());
			pGLCD->SendCommand(strSendMessage);
		}
	}

	// 5. Chairman State
	if (nPageNoCtrl == 1 || nPageNoCtrl == 0)
	{
		static CString PREV_RUNMODE = _T("");
		CString curr_Runmode;
		pa::EN_RUNMODE runMode = pa::PPAStatus->GetRunMode();
		BOOL	bPAConnected = (pa::PPAStatus->GetThreadState()->nIsConnectedPAController != 0) ? 1 : 0;
		BOOL	bIOConnected = (pa::PPAStatus->GetThreadState()->nIsConnectedIOBoard != 0) ? 1 : 0;

		if (!bPAConnected || !bIOConnected)
		{
			curr_Runmode = _T("Not Connected");
		}
		else
		{
			switch (runMode)
			{
			case pa::RUNMODE_INIT:
			case pa::RUNMODE_STOP:
				curr_Runmode = _T("Connected");
				break;
			case pa::RUNMODE_TOSTOP:
			case pa::RUNMODE_TORUN:
			case pa::RUNMODE_RUN:
				curr_Runmode = _T("Running");
				break;
			case pa::RUNMODE_ERROR:
				curr_Runmode = _T("Error");
				break;
			}
		}

		if ( curr_Runmode.Compare(PREV_RUNMODE) )
		{
			CString strSendmessage;
			strSendmessage.Format(_T("page%d.t1.txt=\"%s\""), nPageNoCtrl, curr_Runmode);
			pGLCD->SendCommand(strSendmessage);
			PREV_RUNMODE = curr_Runmode;
		}
	}

	// 6. LCD Tool State 
	if (nPageNoCtrl == 1 || nPageNoCtrl == 0)
	{
		static int PREV_TOOL1_NO = -1;
		static int PREV_TOOL2_NO = -1;
		static int PREV_SPINDLE1_RPM = -1;
		static int PREV_SPINDLE2_RPM = -1;

		int tool1_no	= pa::PPAStatus->GetPAStatus()->nCurrentToolNo;
		int tool2_no	= pa::PPAStatus->GetPAStatus()->nCurrentTool2No;
		int spindle1_rpm= pa::PPAStatus->GetPAStatus()->nSpindleSpeed;
		int spindle2_rpm= pa::PPAStatus->GetPAStatus()->nSpindleSpeed2;

		if (PREV_TOOL1_NO != tool1_no)
		{
			PREV_TOOL1_NO = tool1_no;
// 			strSendMessage.Format(_T("page%d.t2.txt=\"%d\""), nPageNoCtrl, tool1_no);
// 			pGLCD->SendCommand(strSendMessage);
			strSendMessage.Format(_T("page0.t2.txt=\"%d\""), tool1_no);
			pGLCD->SendCommand(strSendMessage);
			strSendMessage.Format(_T("page1.t2.txt=\"%d\""), tool1_no);
			pGLCD->SendCommand(strSendMessage);
		}
		if (PREV_TOOL2_NO != tool2_no)
		{
			PREV_TOOL2_NO = tool2_no;
// 			strSendMessage.Format(_T("page%d.t4.txt=\"%d\""), nPageNoCtrl, tool2_no);
// 			pGLCD->SendCommand(strSendMessage);
			strSendMessage.Format(_T("page0.t4.txt=\"%d\""), tool2_no);
			pGLCD->SendCommand(strSendMessage);
			strSendMessage.Format(_T("page1.t4.txt=\"%d\""), tool2_no);
			pGLCD->SendCommand(strSendMessage);
		}
		if (PREV_SPINDLE1_RPM != spindle1_rpm)
		{
			PREV_SPINDLE1_RPM = spindle1_rpm;
// 			strSendMessage.Format(_T("page%d.t3.txt=\"%d\""), nPageNoCtrl, spindle1_rpm);
// 			pGLCD->SendCommand(strSendMessage);
			strSendMessage.Format(_T("page0.t3.txt=\"%d\""), spindle1_rpm);
			pGLCD->SendCommand(strSendMessage);
			strSendMessage.Format(_T("page1.t3.txt=\"%d\""), spindle1_rpm);
			pGLCD->SendCommand(strSendMessage);
		}
		if (PREV_SPINDLE2_RPM != spindle2_rpm)
		{
			PREV_SPINDLE2_RPM = spindle2_rpm;
// 			strSendMessage.Format(_T("page%d.t5.txt=\"%d\""), nPageNoCtrl, spindle2_rpm);
// 			pGLCD->SendCommand(strSendMessage);
			strSendMessage.Format(_T("page0.t5.txt=\"%d\""), spindle2_rpm);
			pGLCD->SendCommand(strSendMessage);
			strSendMessage.Format(_T("page1.t5.txt=\"%d\""), spindle2_rpm);
			pGLCD->SendCommand(strSendMessage);
		}
	}

}

// ���� �޽����� ã�Ƽ� pThreadState_->szErrorMessage[128] �� �����Ѵ� 
void pa::CPThread::errorProc(CPException& e)
{
	CString strErrType(_T(""));
	CString strErrCode(_T(""));
	CString strErrMssg(_T(""));
	int		nErrorTypeIsAlarm;
	BOOL bLogging = TRUE;

	hBackupExecpt_ = e;

	memset((void*)PPAStatus->GetThreadState()->szErrorType, 0, sizeof(TCHAR)*64 );
	memset((void*)PPAStatus->GetThreadState()->szErrorCode, 0, sizeof(TCHAR)*128 );
	memset((void*)PPAStatus->GetThreadState()->szErrorMessage, 0, sizeof(TCHAR)*512 );
	nErrorTypeIsAlarm = 0;

	CString strTempComment = e.strComment;

	switch( e.hErr )
	{
		// ���� ����. Solutuon/Comment ���� 
	case pa::ERR_NOTCONNECT:		
		//PState->GetThreadState()->bConnectedPmac = FALSE;
		strErrType.Format( _T("ERR_NOTCONNECT") );
		strErrCode.Format( _T("not connected pa controller") );
		break;

		// ���ɿ� ���� ���� ����. nErrCode�� ���� �ε��� 
	case pa::ERR_TIMEOUT:
		strErrType.Format( _T("ERR_TIMEOUT") );
		{
			TCHAR szTempCommand[64];
			hcutil::ASCII_TO_UNICODE( CPAAsyncComm::STR_COMMAND[e.nErrCode], szTempCommand, 64 );
			strErrCode.Format( _T("command is %s"), szTempCommand );
		}
		break;

	case pa::ERR_SOCKET:			
		strErrType.Format( _T("ERR_SOCKET") );
		pa::GET_SOCKET_ERROR_MESSAGE( e.nErrCode, strErrCode );
		strErrCode.Format( _T("%d"), e.nErrCode );
		break;

	case ERR_RND_CMD:
		pa::GET_PA_ERROR_MESSAGE( (int)e.hErr, e.nErrCode, strErrType, nErrorTypeIsAlarm, strErrCode, strErrMssg );
		strErrMssg += "\r\n\r\n";
		strErrMssg += strTempComment;
		memset((void*)CPAAsyncComm::SZ_RND_ERR_MSG, 0, sizeof(TCHAR)*256);
		break;

	case ERR_PNC:
		pa::GET_PA_ERROR_MESSAGE( (int)e.hErr, e.nErrCode, strErrType,  nErrorTypeIsAlarm, strErrCode, strErrMssg );
		break;

	case ERR_PA_STREAM:
		strErrType.Format( _T("STREAM") );
		pa::GET_PA_ERROR_MESSAGE( (int)e.hErr, e.nErrCode, strErrType, nErrorTypeIsAlarm,  strErrCode, strErrMssg );
		break;

	default:
		strErrType.Format( _T("unknown [%d]"), e.hErr );
		strErrCode.Format( _T("unknown error [%d]"), e.nErrCode );
		break;
	}

	//////////////////////////////////////////////////////////////////////////
	pa::PPAStatus->GetThreadState()->nErrorType		= e.hErr;
	pa::PPAStatus->GetThreadState()->nErrorCode		= e.nErrCode;

	CString strTmp[2];
	strTmp[0] = strErrCode.GetLength() > 126 ? strErrCode.Left(126) : strErrCode;
	strTmp[1] = strErrMssg.GetLength() > 512 ? strErrMssg.Left(512) : strErrMssg;

	_stprintf_s( PPAStatus->GetThreadState()->szErrorType, 63, _T("%s"), (LPCTSTR)strErrType );
	PPAStatus->GetThreadState()->nErrorTypeIsAlarm = nErrorTypeIsAlarm;
	_stprintf_s( PPAStatus->GetThreadState()->szErrorCode, 127, _T("%s [%d]"), strTmp[0], e.nErrCode );
	_stprintf_s( PPAStatus->GetThreadState()->szErrorMessage, 513, _T("%s"), strTmp[1] );

	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	// log 
	if( TRUE )
	{
		writeLog_EXT( PPAStatus->GetThreadState()->szErrorType );
		writeLog_EXT( PPAStatus->GetThreadState()->szErrorCode );
		writeLog_EXT( PPAStatus->GetThreadState()->szErrorMessage );

		writeLog_Error(
			PPAStatus->GetThreadState()->szErrorType,
			PPAStatus->GetThreadState()->szErrorCode,
			PPAStatus->GetThreadState()->szErrorMessage
		);

		// DW_SEND_RUNNING_COMMAND[], DE_RECV_RUNNING_COMMAND[] �ð��� �α� ���Ͽ� �����Ѵ� 
		CString strLog;
		writeLog_AutoCal( _T("COMMAND Send-Recv Time"), FALSE );
		for( int i = 0; i<pa::CPAAsyncComm::CMD_NUM; i++ )
		{
			strLog.Format( _T("[%02d] SEND[%d] RECV[%d] %d %d"), 
				i, 
				pa::CPAAsyncComm::DW_SEND_RUNNING_COMMAND[i],
				pa::CPAAsyncComm::DW_RECV_RUNNING_COMMAND[i],
				pa::CPAAsyncComm::DW_RECV_RUNNING_COMMAND[i] - pa::CPAAsyncComm::DW_SEND_RUNNING_COMMAND[i],
				pa::CPAAsyncComm::DW_SEND_RECV_MAX[i] );
			writeLog_EXT( strLog );
		}

		// ����� ���� �����͸� �α� ���Ͽ� �����Ѵ� 
		logging_pa_status();
	}

	//////////////////////////////////////////////////////////////////////////

	changeRunMode( RUNMODE_ERROR, TRUE );
}

//////////////////////////////////////////////////////////////////////////

void pa::CPThread::changeRunMode( EN_RUNMODE runMode, BOOL resetStep )
{
	CString strDbg;

	strDbg.Format( _T("CPThread::changeRunMode() : %s\n"), STR_RUNMODE[runMode] );
	TRACE(strDbg);

	if( PPAStatus->GetRunMode() == runMode ) {
		return;
	}

	strDbg.Format( _T("prev_runmode:%s, runmode:%s\n"), STR_RUNMODE[hPrevRunMode_], STR_RUNMODE[runMode] );
	TRACE( strDbg );

	hPrevRunMode_ = runMode;

	if( runMode == RUNMODE_ERROR )
	{
		runMode = runMode;
	}

	PPAStatus->SetRunMode( runMode );

	if( resetStep ) {
		nStep_[runMode] = 1;
	}

	//////////////////////////////////////////////////////////////////////////
	// log 
	CString strLog;
	strLog.Format( _T("thread runmode change. %s"), STR_RUNMODE[runMode] );
	writeLog_ChangeRunMode( strLog );
	//////////////////////////////////////////////////////////////////////////
}

void pa::CPThread::Execute()
{
	//////////////////////////////////////////////////////////////////////////
// 	static int N_COUNT = 0;
// 	CString strCount;
// 	strCount.Format(_T("CPThread::Execute() Count is %d\n"), N_COUNT++);
// 	TRACE(strCount);
	//////////////////////////////////////////////////////////////////////////

	try 
	{
#ifdef _USE_PA_
		if( pa::PPAAsyncComm[0]->GetConnectState() == hcsock::ISocket::CONNECTED &&
			pa::PPAAsyncComm[1]->GetConnectState() == hcsock::ISocket::CONNECTED )
		{
			PPAStatus->GetThreadState()->hConnectStatus = pa::CONNECT_STATUS_CONNECTED;
		}
		else 
		{
			PPAStatus->GetThreadState()->hConnectStatus = pa::CONNECT_STATUS_NOT;
		}

		//////////////////////////////////////////////////////////////////////////
		//
		if( pa::CPAMotion::NOT_CHECK_STATUS == TRUE )
		{
			CString str;
			static int i = 0;
			str.Format( _T("[%05d] pa::CPAMotion::NOT_CHECK_STATUS\n"), i++ );
			TRACE( str );
			return ;
		}
		//////////////////////////////////////////////////////////////////////////
		//
		BOOL bTemp = PPAStatus->GetThreadState()->bCheckStatus;	// �� ���� 1730�� ����Ǿ� �־, �Ʒ� if������ true�� ���ϸ� 
	//	if( PPAStatus->GetThreadState()->bCheckStatus == TRUE )
		if( PPAStatus->GetThreadState()->bCheckStatus != FALSE )
		{
			checkState();
#ifdef _DEBUG
// 			CString strDbg;
// 			strDbg.Format(_T("line number : %d\n"), PPAStatus->GetPAStatus()->nLineNumber );
// 			TRACE( strDbg );
#endif
			//
			checkHome();
			//
			checkOpPanel();
			//
			checkDoorOpen();
			//
			check_abnormal_stop();
		}
#endif 
		//
		checkRemoteUploadData();

#ifdef _USE_PA_
		//
		checkSpindleAirPurge();
#endif 

		// 
		switch( PPAStatus->GetRunMode() ) 
		{
		case RUNMODE_STOP:
			doStop();
			break;
		case RUNMODE_TOSTOP:
			doToStop();
			break;
		case RUNMODE_TORUN:
			doToRun2();
			break;
		case RUNMODE_RUN:
			doRun();
			doAutoCal_CoordinateOffset();					// 50000 ~ 52000-
//			doAutoTeaching_ToolPocket1();					// 52000 ~ 54000 (ToolBox ������)
//			doAutoTeaching_ToolPocket2();					// 52000 ~ 54000 (Tray ������)
			doAutoTeaching_ToolPocket3();					// 52000 ~ 54000 (Offset �����͸� ����ؼ� ���) 
			doAutoTeaching_MultiOrigin();					// 56000 ~ 58000 
			doAutoCal_SingleAbutmentCoordinateOffset();		// 58000 ~ 59999
			doAutoCal_SingleAbutmentCoordinateOffset_A();	// 60000 ~ 61999
			doATCTest();									// 62000 ~ 62999
			break;
		case RUNMODE_INIT:
			doInit();
			break;
		case RUNMODE_ERROR:
			doError();
			break;
		case RUNMODE_PAUSE:
			doPause();
			break;
		}

		pa::PPAStatus->GetThreadState()->nRunMode_StepNo = nStep_[RUNMODE_RUN];

		// LCD�� ���� ���¸� Ȯ���ϰ�, ������ ���������� ���� �õ� �Ѵ� 
// 		updateLCDProgressbar();
// 		updateLCDMillingTime();
// 		updateLCDToolState();
// 		sendLCDConnectionFlag();
// 		updateLCDPage();
// 		updateLCDChairmanState();
// 		updateLCDButtonstate();
		updateLDCState();
	}
	catch( CPException& e )
	{
		TRACE("3. CALL PThread->ERROR_PROC()\n");
		ERROR_PROC( e );
	}
}

void pa::CPThread::checkHome()
{
	EN_RUNMODE	hRunMode = PPAStatus->GetRunMode(); 
	BOOL bShowDlg = FALSE;

	//////////////////////////////////////////////////////////////////////////
	// Stop ����̰� ���� Power=1�̰� Homing=0�� ���, Homing Dialog�� ���� 
	if( hRunMode == pa::RUNMODE_STOP || hRunMode == pa::RUNMODE_INIT )
	{
		if( ( pa::PPAStatus->GetPAStatus()->nServoPower != 0 ) &&			// �Ŀ� o
			( pa::PPAStatus->GetPAStatus()->nServoHomeState == 0 ) )		// �������� x
		{
			bShowDlg = TRUE;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// ERROR ����� ��� HOME_DLG�� HIDE �� 
	if (bShowDlg && !CHomeDlg::IS_SHOW())
	{
		CHomeDlg::SHOW_DLG();
	}
	else if (!bShowDlg && CHomeDlg::IS_SHOW()) 
	{
		CHomeDlg::HIDE_DLG();
	}
}

void pa::CPThread::checkState()
{
	EN_RUNMODE	hRunMode = PPAStatus->GetRunMode();

	//////////////////////////////////////////////////////////////////////////
	// pa ����� ���¸� ������Ʈ �ϰ�, 
	PPAStatus->UpdatePAState();
#ifdef _SAVE_RUNTIME_
	PPAStatus->SAVE_RUNNING_TIME(FALSE, _T(""));	
#endif

	static int	N_PREV_AIR_SENSING = -1;
	static EN_RUNMODE H_PREV_RUNMODE = RUNMODE_NUM;
	static DWORD AIR_LOW_TICKCOUNT = 0;
	CString strLog;

	if( PConfig->pConfig_->bUsingAirLimitSensor == TRUE )
	{
		if( pa::MODEL_INFO.GetAirPressureSensorType() == pa::SModelInfo2::AIR_PRESSURE_TYPE_SINGLE ) {
			checkAirLimit_SingleSensor();
		}

		switch( pa::MODEL_INFO.GetAirPressureSensorType() )
		{
		case pa::SModelInfo2::AIR_PRESSURE_TYPE_SINGLE:
		default:
			checkAirLimit_SingleSensor();
			break;
		case pa::SModelInfo2::AIR_PRESSURE_TYPE_DUAL:
			checkAirLimit_DaulSensor();
			break;
		}
	}

	// �ʿ��� ���, Flow Sensor�� üũ �Ѵ� 
	// 2018.05.16 Flow ���� üũ �ϴ� ����� ���� �Ѵ� 
	// checkFlowSensor();

	//////////////////////////////////////////////////////////////////////////
	// I/O Board ���� Checking 
	if( PPAStatus->GetPAStatus()->nIO_Board_Status != 1 )
	{
		if( PPAStatus->GetPAStatus()->nServoPower != 0 ) 
		{
			throw CPException( ERR_PNC, PNC_ERR_IOBOARD_NOT_CONNECT, _T("") );
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// Spindle Board ���� Checking 
	if( PPAStatus->GetPAStatus()->nSpindle_Board_Status != 1 ) 
	{
		if( PPAStatus->GetPAStatus()->nServoPower != 0 ) 
		{
			throw CPException( ERR_PNC, PNC_ERR_SPINDLEBOARD_NOT_CONNECT, _T("") );
		}
	} 

	//////////////////////////////////////////////////////////////////////////
	// RUNMODE_RUN�� ���, Push-Limit ���� ���¸� Ȯ�� 
	/*
	if( TRUE )
	{
#ifdef _PA_G2400_
#endif
#ifdef _PA_G1600_
		int nATCPushLimitSensor = PPAStatus->GetPAStatus()->bInput[IN20010_AtcPushLimit];
#endif
		BOOL bIsRunning = ( PPAStatus->GetPAStatus()->nRunStatus == pa::PA_RUN_STATUS_RUN || PPAStatus->GetPAStatus()->nRunStatus == pa::PA_RUN_STATUS_PAUSE )
							|| ( PPAStatus->GetPAStatus()->nMDCode == 3 );	// MDCode = [OFF/AUTO/STEP/MDA]
			
		if( (nATCPushLimitSensor != 0) &&
			(hRunMode == RUNMODE_RUN || hRunMode == RUNMODE_TORUN || hRunMode == RUNMODE_TOSTOP || (hRunMode == RUNMODE_STOP && bIsRunning)) )
		{
			PAMotion->EMO( PNC_ERR_ATC_PUSH_LIMIT_SENSOR );
		//	throw CPException( ERR_PNC, PNC_ERR_ATC_PUSH_LIMIT_SENSOR, _T("") );
		}
	}
	*/

#ifdef _USE_AUTOLOADER_
	// ���� ���� ���� Ȯ�� 
// 	if( hRunMode == RUNMODE_RUN && PConfig->pConfig_->bUsingDetectBlock && bIsSensingExistBlock_ ) {
// 		if( PPAStatus->GetPAStatus()->bInput[pa::IN20017_DetectedBlock] == FALSE ) {
// 			// ���� ���� ���� 
// 			throw CPException( ERR_PNC, PNC_ERR_BLOCK_NOT_DETECT, _T("") );
// 		}
// 	}
#endif
}

//////////////////////////////////////////////////////////////////////////
// 2018.05.16. STOP ��忡���� ��� üũ�ϰ�, RUN ����� ��� üũ ���� �ʴ´� 
// STOP ����� ��쿡�� ���� ���¸� ��� üũ �ؼ�, ���� �ð��̻� LOW�� �����Ǹ� ���� 
//////////////////////////////////////////////////////////////////////////
void pa::CPThread::checkAirLimit_SingleSensor()
{
// 	static int	N_PREV_AIR_SENSING = -1;
// 	static EN_RUNMODE H_PREV_RUNMODE = RUNMODE_NUM;
// 	static DWORD AIR_LOW_TICKCOUNT = 0;
// 	EN_RUNMODE	hRunMode = PPAStatus->GetRunMode();
// 	CString strLog;
// 
// 	// runmode�� �ٲ��, �ٽ� üũ 
// 	if( H_PREV_RUNMODE != hRunMode ) {
// 		H_PREV_RUNMODE = hRunMode;
// 		N_PREV_AIR_SENSING = -1;
// 	}
// 
// 	// ���� ���� ���� ���� 
// 	int curr_air_sensor = PPAStatus->GetPAStatus()->bInput[pa::IN20006_MainAirCheck];
// 
// 	// RUN_MODE�� Stop ����̰�, ���� ���� ���¿� �޶� ���� ���...
// 	if( hRunMode == RUNMODE_STOP )
// 	{
// 		if( N_PREV_AIR_SENSING != curr_air_sensor )
// 		{
// 			N_PREV_AIR_SENSING = curr_air_sensor;
// 			if( curr_air_sensor == FALSE )
// 			{
// 				// HIGH -> LOW �� ������ ���, ������ �ð��� ���� �Ѵ� 
// 				AIR_LOW_TICKCOUNT = GetTickCount();
// 			}
// 			else 
// 			{
// 				// LOW -> HIGH �� �ö� ���,
// 				AIR_LOW_TICKCOUNT = 0;
// 			}
// 		}
// 
// 		if( curr_air_sensor == FALSE)
// 		{
// 			if( (GetTickCount() - AIR_LOW_TICKCOUNT) > (DWORD)(PConfig->pConfig_->nAirLimitInterval))
// 			{
// 				N_PREV_AIR_SENSING = -1;
// 				AIR_LOW_TICKCOUNT = 0;
// 				throw CPException( ERR_PNC, PNC_ERR_AIR_LIMIT, _T("") );
// 			}
// 		}
// 	}
}

// Doul ��ȣ Ÿ���� ���,
// - ������ ����ϴ� 20006_Main_Air_Sensor�� Low ��ȣ�� ����ϰ�,
// - �߰��� 10006_Main_Air_Sensor2�� Low ��ȣ�� High ��ȣ�� ����Ѵ�
// ���� ��� 
// - 20006_Main_Air_Sensor�� ���, Off �Ǹ� ���� 
// - 10006_Main_Air_Sensor2�� ���,
//   �ݷ��� ������ ��쿡�� Ȯ�� 
void pa::CPThread::checkAirLimit_DaulSensor()
{
	static int	N_PREV_AIR_SENSING = -1;
	static EN_RUNMODE H_PREV_RUNMODE = RUNMODE_NUM;
	static DWORD AIR_LOW_TICKCOUNT = 0;
	EN_RUNMODE	hRunMode = PPAStatus->GetRunMode();
	CString strLog;

	// runmode�� �ٲ��, �ٽ� üũ 
	if( H_PREV_RUNMODE != hRunMode ) {
		H_PREV_RUNMODE = hRunMode;
		N_PREV_AIR_SENSING = -1;
	}
	// ���� ���� ���� ���� 
//	int curr_main_air1 = PPAStatus->GetPAStatus()->bInput[pa::IN20006_MainAirCheck];
	int curr_main_air1 = 1;
//	int curr_main_air2 = PPAStatus->GetPAStatus()->bInput[pa::IN10006_MainAirCheck2];
	int curr_main_air2 = 1;
// 	int curr_collet_state = PPAStatus->GetPAStatus()->bOutput[pa::OUT20040_ToolClamp];

	// Error ����� ���, ���� 
	if( hRunMode == RUNMODE_ERROR ) {
		return ;
	}

	// Low Limit�� ��� üũ 
	if( curr_main_air1 == 0 ) 
	{
		N_PREV_AIR_SENSING = -1;
		H_PREV_RUNMODE = RUNMODE_NUM;
		AIR_LOW_TICKCOUNT = 0;
		// ����
		throw CPException( ERR_PNC, PNC_ERR_AIR_LIMIT, _T("BASIC-AIR-VOLUME LOW LIMIT") );
	}

	// �ݷ��� ���� ���� ��,  
	// if( curr_collet_state != 0 )
	if( pa::PPAStatus->GetPAStatus()->nDuringToolChaneFlag != 0 )
	{
		if( N_PREV_AIR_SENSING != curr_main_air2 )
		{
			N_PREV_AIR_SENSING = curr_main_air2;
			if( curr_main_air2 == FALSE )
			{
				// HIGH -> LOW 
				switch( hRunMode )
				{
				case pa::RUNMODE_RUN:
					if( nStep_[RUNMODE_RUN]>0 && nStep_[RUNMODE_RUN]<6000 ) 
					{
						AIR_LOW_TICKCOUNT = GetTickCount();
						strLog.Format( _T("Low air pressure... change pause mode") );
						writeLog_AutoCal( strLog, FALSE );
						// Pause ���� ��ȯ 
						pa::PPAStatus->GetThreadState()->bIsPauseAirLimit_ = TRUE;
						DoPause();
					}
					break;
				default:
					// Runmode�� �ƴϸ� ���� 
					// - Tool ȭ�鿡�� ��ü������ �ϴµ�. �Ŵ��� ����� ���, ���ʿ��� ���� �߻� 
					throw CPException( ERR_PNC, PNC_ERR_AIR_LIMIT, _T("COLLET-OPEN LOW LIMIT (Manual Mode)") );
				}
			}
			else 
			{
				// LOW -> HIGH �� �Íﰣ ���, DoPause() �Լ��� ���߾��ٸ� �̾ �����Ѵ� 
				if( nStep_[RUNMODE_RUN]>0 && nStep_[RUNMODE_RUN]<6000 )
				{
					strLog.Format( _T("High air pressure... change run mode") );
					writeLog_AutoCal( strLog, FALSE );

					N_PREV_AIR_SENSING = -1;
					pa::PPAStatus->GetThreadState()->bIsPauseAirLimit_ = FALSE;
					PAMotion->CONTINUE();
					Sleep( 500 );
					changeRunMode( RUNMODE_RUN, FALSE );
				}
			}
		}
		else 
		{
			// ���� �������� pause ���� ��ȯ�� ���°� ���� �ð� �̻� ������ ���, ���� 
			if( curr_main_air2 == FALSE )
			{
				DWORD curr_time = GetTickCount();
				if( pa::PPAStatus->GetThreadState()->bIsPauseAirLimit_ == TRUE )
				{
					if( ( curr_time - AIR_LOW_TICKCOUNT ) > (DWORD)(PConfig->pConfig_->nAirLimitInterval) )
					{
						N_PREV_AIR_SENSING = -1;
						pa::PPAStatus->GetThreadState()->bIsPauseAirLimit_ = FALSE;
						throw CPException( ERR_PNC, PNC_ERR_AIR_LIMIT, _T("COLLET-OPEN LOW LIMIT (Run Mode)") );
					}
				}
			}
		}
	}
}

void pa::CPThread::checkFlowSensor()
{
	static int		PREV_FLOW_SENSING = -1;
	static DWORD	FLOW_SENSING_TICKCOUNT = 0;
	EN_RUNMODE	hRunMode = PPAStatus->GetRunMode();

	if( (pa::MODEL_INFO.GetM28Type()==pa::SModelInfo2::M28_TYPE_WET) &&
		(PConfig->pConfig_->bUsingFlowSensor == TRUE ) )
	{
		int water_pump = PPAStatus->GetPAStatus()->bOutput[pa::OUT20037_WaterVacuumPumpOnSignal] == FALSE ? 0 : 1;
		int curr_flow_sensor = PPAStatus->GetPAStatus()->bInput[pa::IN20011_WaterFlowCheckSensor] == FALSE ? 0 : 1;
		int sensor_state = ( water_pump == 1 && curr_flow_sensor == 0 ) ? 0 : 1;

		if( PREV_FLOW_SENSING != sensor_state ) 
		{
			PREV_FLOW_SENSING = sensor_state;
			if( sensor_state == 0 ) 
			{
				// False �� ��, �ð� ���� 
				FLOW_SENSING_TICKCOUNT = GetTickCount();
			}
		}
		else {
			if( ( hRunMode != RUNMODE_ERROR ) && ( sensor_state == 0 ) ) 
			{
				// �ð� �� 
				DWORD curr_time = GetTickCount();
				if( ( curr_time - FLOW_SENSING_TICKCOUNT ) > (DWORD)(PConfig->pConfig_->nFlowSensorTimeout ) ) 
				{
					PREV_FLOW_SENSING = -1;
					throw CPException( ERR_PNC, PNC_ERR_WATER_FLOW_SENSOR, _T("") );
				}
			}
		}
	}
}

pa::CPThread::EN_CHECK_NC_CODE pa::CPThread::checkNCCode( char* pNCCode, int* pnErrorToolNo, int* pnToolNo )
{
	// �ּ��� ���� 
	CGCodeHelper::RemoveCommentFromGCode( pNCCode );

	// M30 Ȯ�� 
	if( CGCodeHelper::CheckM30_Stop( pNCCode ) ) {
		return CHECK_NC_CODE_M30;
	}

	// M47 Ȯ�� 
	if( CGCodeHelper::CheckM47_Repeat( pNCCode ) ) {
// 		sprintf_s( pNCCode, 256, "DUMMY" );
		sprintf_s( pNCCode, 256, "M999" );
		return CHECK_NC_CODE_M47;
	}

	// M140-M148 Ȯ��. ��ü�� ����� ����� ���, ��ü �� ��ȣ�� ��ü 
	// ����� �� �ִ� ���� ���� ���, ���� �߻�. 
	// (nErrorToolNo�� ���ؼ� ������ �߻��Ѵ�)
	if( CGCodeHelper::CheckM140_M147_ToolChange( pNCCode, pnErrorToolNo, pnToolNo ) == FALSE ) {
		return CHECK_NC_CODE_TOOL_OVERTIME;
	}

	// Replace Command�� �ִ��� Ȯ���Ѵ� 
//	CGCodeHelper::CheckReplaceCommand( pNCCode );	// NC ���� Open���� ���� �ϰ� ����. ���⼭�� ���� 

	//////////////////////////////////////////////////////////////////////////
	// 2015.06.11 ��ǥ ��ȯ 
	//	- �����Ʈ ������, ȯ���� ���� �ɼ� ���
	if( hTransformVPst_.TRANSFORM2( pNCCode, 256 ) == FALSE ) {
		// nc-code ���� 
		return CHECK_NC_CODE_ERROR;
	}
	//////////////////////////////////////////////////////////////////////////

	// ������ �ִ��� Ȯ�� 
	if( strlen(pNCCode) == 0 ) {
		return CHECK_NC_CODE_SKIP;
	}

	return CHECK_NC_CODE_RUN;
}

void pa::CPThread::checkOpPanel()
{
#ifdef _PA_G2400_
	static DWORD BTN_DELAY = 500;
	static DWORD BTN_TIME = GetTickCount();
	BOOL	bBtnProcess = FALSE;
	BOOL	bRet = TRUE;
	CString strErrMsg;
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetRunMode();

	//////////////////////////////////////////////////////////////////////////
	//
	if( PConfig->pConfig_->bUsingOpPanel == FALSE ) {
		return ;
	}
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	// ERROR RESET. ����ġ �Է� ó�� 
	//////////////////////////////////////////////////////////////////////////
	static int PREV_OPPANEL_BTN_ALARMCLEAR = -1;
	int currOpPanelBtnAlarmClear = PPAStatus->GetPAStatus()->bInput[pa::IN115_ALARM_CLEAR_SWITCH];
	
	if( PREV_OPPANEL_BTN_ALARMCLEAR != currOpPanelBtnAlarmClear ) {
		PREV_OPPANEL_BTN_ALARMCLEAR = currOpPanelBtnAlarmClear;
		if( (BTN_TIME-GetTickCount()) < BTN_DELAY ) { return ; }
		if( PREV_OPPANEL_BTN_ALARMCLEAR == 0 && hRunMode == RUNMODE_ERROR ) {
			//////////////////////////////////////////////////////////////////////////
			// log
			writeLog_OpPanel( _T("oppanel reset button press") );
			//////////////////////////////////////////////////////////////////////////
			// ���� ���� 
			PMotion->ErrorReset();
			bBtnProcess = TRUE;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// RUN. ����ġ �Է� ó�� 
	//////////////////////////////////////////////////////////////////////////
	CString strLog;
	static int PREV_OPPANEL_BTN_RUN = -1;
	int currOpPanelBtnRun = PPAStatus->GetPAStatus()->bInput[pa::IN113_RUN_SWITCH];

	if( PREV_OPPANEL_BTN_RUN != currOpPanelBtnRun ) {
		PREV_OPPANEL_BTN_RUN = currOpPanelBtnRun;
		if( (BTN_TIME-GetTickCount()) < BTN_DELAY ) { return ; }
		if( PREV_OPPANEL_BTN_RUN == 0 ) //&& ( hRunMode_ == RunMode_Stop || hRunMode_ == RunMode_Pause ) ) {
		{
			//////////////////////////////////////////////////////////////////////////
			// log
			writeLog_OpPanel( _T("oppanel run button press") );
			//////////////////////////////////////////////////////////////////////////
			switch( hRunMode )
			{
			case pa::RUNMODE_PAUSE:
				//////////////////////////////////////////////////////////////////////////
				// log
				writeLog_OpPanel( _T("run from pause mode") );
				//////////////////////////////////////////////////////////////////////////
				DoRun(-1);
				bBtnProcess = TRUE;
				break;
			case pa::RUNMODE_STOP:
				{
					int		nStartLine = 0;
					BOOL	bRun = TRUE;
					if( PPAStatus->GetThreadState()->bIsOpenNCFile )
					{
						// ���� �ִ� ������ ������, �̾ ���� 
						nStartLine = PPAStatus->GetThreadState()->hNCFileInfo.machining_lines;
						if( nStartLine > 0 ) {
							nStartLine -= 1;
						}
						//////////////////////////////////////////////////////////////////////////
						// log 
						strLog.Format( _T("run from continuous [line:%d]"), nStartLine );
						writeLog_OpPanel( strLog );
						//////////////////////////////////////////////////////////////////////////
					}
					else 
					{
						// ���� �ִ� ������ ������, ýũ�� ������ ã�� ó������ ���� 
						int nNCFileIndex = PNCFileMgr->FindFirstCheckingNCFileIndex();
						if( nNCFileIndex != -1 )
						{
							//////////////////////////////////////////////////////////////////////////
							// log 
							strLog.Format( _T("open ncfile(%d), and run from begining"), nNCFileIndex );
							writeLog_OpPanel( strLog );
							//////////////////////////////////////////////////////////////////////////
							// ������ Open �Ѵ� 
							if( OpenNCFile( nNCFileIndex, strErrMsg ) == FALSE )
							{
								// ����.
								throw CPException( ERR_PNC, PNC_ERR_FILE_OPEN, (LPCTSTR)strErrMsg );
							}
							nStartLine = 0;
						}
						else 
						{
							// ýũ�� ���ϵ� ������, �۾��� ������ ���ٴ� �޽��� �ڽ��� ���� 
							bRun = FALSE;
							//////////////////////////////////////////////////////////////////////////
							// log 
							strLog.Format( _T("not selected ncfile") );
							writeLog_OpPanel( strLog );
							//////////////////////////////////////////////////////////////////////////
						}
					}
					
					if( bRun )
					{
						DoRun( nStartLine );
					}
				}

				bBtnProcess = TRUE;

				break;
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// STOP. ����ġ �Է� ó�� 
	//////////////////////////////////////////////////////////////////////////
	static int PREV_OPPANEL_BTN_STOP = -1;
	int currOpPanelBtnStop = PPAStatus->GetPAStatus()->bInput[IN114_STOP_SWITCH];
	if( PREV_OPPANEL_BTN_STOP != currOpPanelBtnStop ) {
		PREV_OPPANEL_BTN_STOP = currOpPanelBtnStop;
		if( (BTN_TIME-GetTickCount()) < BTN_DELAY ) { return ; }
		if( PREV_OPPANEL_BTN_STOP == 0 ) {
			//////////////////////////////////////////////////////////////////////////
			// log
			P_LOG->WriteLog( CLog::TYPE_OPER, 8, _T("oppanel stop button press") );
			//////////////////////////////////////////////////////////////////////////
			switch( hRunMode )
			{
			case pa::RUNMODE_PAUSE:
				DoStop(TRUE);
				bBtnProcess = TRUE;
				break;
			case pa::RUNMODE_RUN:
				DoPause();
				bBtnProcess = TRUE;
				break;
			}
		}
	}

	if( bBtnProcess ) {
		BTN_TIME = GetTickCount();
	}

	//////////////////////////////////////////////////////////////////////////
	// ����ġ LED ó�� 
	//////////////////////////////////////////////////////////////////////////
	// Rotary buffer�� �����ִ� ���, ��� ������ �߻��� �� �ֱ� ������
	// LED�� On/Off�� toRun, toStop, toError ���� �Լ����� ó�� �Ѵ� 
#endif
}

/** 
 * ���� �������� ����. ���� ���� �ٽ� �����ϸ� �����ϴ� ���� 
 */
void pa::CPThread::checkDoorOpen()
{
	static int PREV_DOOR_STATE = -1;		// 0:����. 1:���� 
// 	static int nDoorCode = 0;
	static int N_DOOR_CODE = 0;			

	pa::EN_RUNMODE hRunMode = PPAStatus->GetThreadState()->hRunMode;
	int IN20012_FRONTDOORCHECK = PPAStatus->GetPAStatus()->bInput[pa::IN20012_DoorSensor] == TRUE ? 1 : 0;

	N_DOOR_CODE = 0;	// static ������ �����ؼ� �Ź� �ʱ�ȭ �ؾ� �� 

	if( PConfig->pConfig_->bUsingOpPanel == FALSE ) {
		pa::PPAStatus->GetThreadState()->nPauseByDoorOpen = 0;
		return ;
	}

	if( hRunMode==pa::RUNMODE_STOP || hRunMode==pa::RUNMODE_ERROR ||
		hRunMode==pa::RUNMODE_TORUN ||
		hRunMode==pa::RUNMODE_PAUSE || hRunMode==pa::RUNMODE_INIT )
	{
		pa::PPAStatus->GetThreadState()->nPauseByDoorOpen = 0;
		return ;
	}

	//////////////////////////////////////////////////////////////////////////
	// 2016.10.29. Auto Cal./Teaching �� Door Open�� ���Ͷ��� ���� �Ѵ� 
	if( (hRunMode==pa::RUNMODE_RUN) && !(nStep_[pa::RUNMODE_RUN]>0 && nStep_[pa::RUNMODE_RUN]<6000) )
	{
		return ;
	}

	//////////////////////////////////////////////////////////////////////////

	if( PREV_DOOR_STATE != IN20012_FRONTDOORCHECK ) {
		if( PREV_DOOR_STATE != 0 && IN20012_FRONTDOORCHECK == 0 ) {
			// door is open 		
			N_DOOR_CODE = 1;
		}
		else if( PREV_DOOR_STATE == 0 && IN20012_FRONTDOORCHECK != 0 ) {
			// door is close 
			N_DOOR_CODE = 2;
		}
		PREV_DOOR_STATE = IN20012_FRONTDOORCHECK; 
	}

	if( N_DOOR_CODE == 1 )
	{
		// Run ���̾����� Pause ���·� ��ȯ, ToRun, ToStop �����̸� Stop ���·� ��ȯ 
		if( hRunMode == pa::RUNMODE_RUN )
		{
			// pause ���·� ��ȯ 
			DoStop( TRUE );
			//////////////////////////////////////////////////////////////////////////
			// log 
			writeLog_Door( _T("front door is open. change runmode to stop") );
			//////////////////////////////////////////////////////////////////////////
			// �˸� ���� �� 
			pa::PPAStatus->GetThreadState()->nPauseByDoorOpen = 1;
			TRACE( _T("front door is open. change runmode to stop") );
		}
		else if( hRunMode==pa::RUNMODE_TOSTOP || hRunMode==pa::RUNMODE_TORUN )
		{
			// stop ���·� ��ȯ 
			DoStop( TRUE );
			//////////////////////////////////////////////////////////////////////////
			// log 
		//	writeLog_Door( _T("front door is open. change runmode to stop") );
			//////////////////////////////////////////////////////////////////////////
		}
		else 
		{
			// ������� ���� �� �� 
			//////////////////////////////////////////////////////////////////////////
			// log 
			writeLog_Door( _T("front door is open. change runmode to emo") );
			//////////////////////////////////////////////////////////////////////////
			//	pa::PMotion->EMO( PNC_ERR_INTERNAL_EMO_OPEN_DOOR );
			throw CPException( ERR_PNC, PNC_ERR_OPEN_DOOR, _T("") );
		}
	}
	else if( N_DOOR_CODE == 2 )
	{
		//////////////////////////////////////////////////////////////////////////
		// log 
	//	writeLog_Door( _T("front door is close") );
		//////////////////////////////////////////////////////////////////////////
	}
}

// Client�� ����Ǿ� �ְ�, 
// bRemoteAutoUpdate_�� True �� ���, 
// Flag�� ���¸� Ȯ���ؼ�, True �̸� �ش� �����͸� ���� �Ѵ� 
// thread�� cycle�� 10msec �̹Ƿ� 10ȸ�� �ѹ��� �����Ѵ� 
void pa::CPThread::checkRemoteUploadData()
{
}

void pa::CPThread::checkLimitSensor()
{
	if( PPAStatus->GetPAStatus()->bInput[IN20009_X_P_Limit] ) 
	{
		throw CPException( ERR_PNC, PNC_ERR_LIMIT_SENSOR_XP, _T("") );
	}
	else if( PPAStatus->GetPAStatus()->bInput[IN20010_X_M_Limit] )
	{
		throw CPException( ERR_PNC, PNC_ERR_LIMIT_SENSOR_XM, _T("") );
	}
	else if( PPAStatus->GetPAStatus()->bInput[IN20001_Y1_P_Limit] )
	{
		throw CPException( ERR_PNC, PNC_ERR_LIMIT_SENSOR_Y1P, _T("") );
	}
	else if( PPAStatus->GetPAStatus()->bInput[IN20002_Y1_M_Limit] )
	{
		throw CPException( ERR_PNC, PNC_ERR_LIMIT_SENSOR_Y1M, _T("") );
	}
	else if( PPAStatus->GetPAStatus()->bInput[IN20003_Z1_P_Limit] ) 
	{
		throw CPException( ERR_PNC, PNC_ERR_LIMIT_SENSOR_Z1P, _T("") );
	}
	else if( PPAStatus->GetPAStatus()->bInput[IN20004_Z1_M_Limit] ) 
	{
		throw CPException( ERR_PNC, PNC_ERR_LIMIT_SENSOR_Z1M, _T("") );
	}
	else if( PPAStatus->GetPAStatus()->bInput[IN20005_Y2_P_Limit] )
	{
		throw CPException( ERR_PNC, PNC_ERR_LIMIT_SENSOR_Y2P, _T("") );
	}
	else if( PPAStatus->GetPAStatus()->bInput[IN20006_Y2_M_Limit] )
	{
		throw CPException( ERR_PNC, PNC_ERR_LIMIT_SENSOR_Y2M, _T("") );
	}
	else if( PPAStatus->GetPAStatus()->bInput[IN20007_Z2_P_Limit] ) 
	{
		throw CPException( ERR_PNC, PNC_ERR_LIMIT_SENSOR_Z2P, _T("") );
	}
	else if( PPAStatus->GetPAStatus()->bInput[IN20008_Z2_M_Limit] ) 
	{
		throw CPException( ERR_PNC, PNC_ERR_LIMIT_SENSOR_Z2M, _T("") );
	}
}

// ������ �����ð� ���߾� ���� ���, ���� ó�� �Ѵ� 
void pa::CPThread::check_abnormal_stop()
{
	static const int		TIME_LIMIT = 5 * 60 * 1000;	// 5�� 
	static pa::EN_RUNMODE	PREV_RUNMODE = pa::RUNMODE_NUM;
	static int				PREV_NCCODE_STEP_NO = -1;
	static int				PREV_NC_FILE_INDEX = -1;
	static DWORD			TIME_UPDATE = 0;
	
	pa::EN_RUNMODE run_mode = pa::PPAStatus->GetThreadState()->hRunMode;
	int curr_nccode_step_no = pa::PPAStatus->GetThreadState()->nCurrentNCCodeStepNo;
	int curr_run_step = nStep_[RUNMODE_RUN];

	// runmode�� �ٲ���� ��, run �� �ƴϸ� prev_step ���� �ʱ�ȭ 
	if( PREV_RUNMODE != run_mode ) 
	{
		if( PREV_RUNMODE == pa::RUNMODE_PAUSE && run_mode == pa::RUNMODE_RUN )
		{
			// pause->run���� �Ѿ ���... �ʱ�ȭ. 
			// Step ��ȣ�� �ʱ�ȭ �ϱ� ������, �Ʒ� �κп��� TIME_UPDATE �� �缳�� �ȴ� 
			PREV_NCCODE_STEP_NO = -1;	
		}
		else if( run_mode == pa::RUNMODE_STOP || 
			run_mode == pa::RUNMODE_ERROR || 
			run_mode == pa::RUNMODE_INIT )
		{
			// Ȥ�� STOP, ERROR, INIT �� ���... �ʱ�ȭ 
			// Step ��ȣ�� �ʱ�ȭ �ϱ� ������, �Ʒ� �κп��� TIME_UPDATE �� �缳�� �ȴ� 
			PREV_NCCODE_STEP_NO = -1;
		}
		PREV_RUNMODE = run_mode;
	}

	// run ����� ���,
	if( run_mode == pa::RUNMODE_RUN )
	{
		//////////////////////////////////////////////////////////////////////////
		// RUNMODE_RUN �̰�,
		// step�� 0~6000 ������ ��쿡�� ���� �Ѵ� 
		if( curr_run_step>0 && curr_run_step<6000 )
		{
			int currWorkNcFileIndex = PNCFileMgr->GetCurrentWorkNCFileIndex();
			if( PREV_NCCODE_STEP_NO != curr_nccode_step_no )
			{
				PREV_NCCODE_STEP_NO = curr_nccode_step_no;
				TIME_UPDATE = GetTickCount();
			}
			else if( PREV_NC_FILE_INDEX != currWorkNcFileIndex )
			{
				PREV_NC_FILE_INDEX = currWorkNcFileIndex;
				TIME_UPDATE = GetTickCount();
			}
			else 
			{
				// ������ �ٲ��� ���� ���...
				if( (GetTickCount() - TIME_UPDATE) > TIME_LIMIT )
				{
					//////////////////////////////////////////////////////////////////////////
					// �α� ���� 
					//	- �� ���� ��ġ 
					//	- input/output ���� 
					//	- spindle, io-board ���� ����
					//	- spindle RPM 
					//	- �� ���� ���� (motion done / waiting)
					//	- ���� �Ǿ� �ִ� NC �ڵ� ���� ��ȣ 
					//	- pa���� �������� ��� �̸� (lock�� Ǯ��� ��)
					//	- network ���� ���� ��� 

					//////////////////////////////////////////////////////////////////////////
					// ���� ó��
					throw CPException( ERR_PNC, PNC_ERR_ABNORMAL_STOP, _T("") );
					//////////////////////////////////////////////////////////////////////////
				}
			}
		}
	}
}

void pa::CPThread::checkFilterTime()
{
	int nFilterTimeOut = pa::PConfig->pConfig_->nFilterTimeout_sec;
	DWORD dwTotalFilterTime = pa::PPAStatus->GetThreadState()->dwTOTAL_FILTER_TIME;

	if (dwTotalFilterTime > nFilterTimeOut)
	{
		throw CPException( ERR_PNC, PNC_ERR_FILTER_TIMEOUT, _T("") );
	}
}

//////////////////////////////////////////////////////////////////////////

void pa::CPThread::doStop()
{
	int& step = nStep_[RUNMODE_STOP];

	//////////////////////////////////////////////////////////////////////////
	static int PREV_STEP_NO = -1;
	if( PREV_STEP_NO != step ) {
		PREV_STEP_NO = step;
		CString strLog;
		strLog.Format( _T("doStop step = %d"), step );
		writeLog_EXT( strLog );
	}
	//////////////////////////////////////////////////////////////////////////

	switch( step )
	{
	case 0: break;
	case 1:
		hBackupExecpt_.hErr = ERR_NONE;
		hBackupExecpt_.nErrCode = 0;
		//////////////////////////////////////////////////////////////////////////
		// STOP ��ư�� LED�� ON
		//PMotion->SendCommand( "P1022=1 P1021=0 P1040=0", NULL, 0 );			
		change_external_button_led( pa::RUNMODE_STOP );
		//////////////////////////////////////////////////////////////////////////
		step = 2;
	case 2:
		PContinueRunInfo->Terminate();
		step = 0;
		break;
	}
}

void pa::CPThread::doToStop()
{
	static int DELAY;
	int& step = nStep_[RUNMODE_TOSTOP];

	//////////////////////////////////////////////////////////////////////////
	static int PREV_STEP_NO = -1;
	if( PREV_STEP_NO != step ) {
		PREV_STEP_NO = step;
		CString strLog;
		strLog.Format( _T("doToStop step = %d"), step );
		writeLog_EXT( strLog );
	}
	//////////////////////////////////////////////////////////////////////////

	switch( step )
	{
	case 0: break;
	case 1: 
		step = 100;
		break;

	case 100:
		// ����ڰ� Stop ��ư�� ������ ���, 
		// pause ��Ų ��, ���� �۾� ������ ������ ��, Strame ��带 ����� 
		if( bIsPressStopButton_ == TRUE ) 
		{
			int nCurrNCFileIndex = PNCFileMgr->GetCurrentWorkNCFileIndex();
			if( nCurrNCFileIndex != -1 ) 
			{
				// ���� ���ι�ȣ ���� 
				int nTemp = PPAStatus->GetThreadState()->nCurrentNCCodeStepNo;
				PPAStatus->SetNCFileMachiningLine( PPAStatus->GetThreadState()->nCurrentNCCodeStepNo, TRUE );			
			}

			PAMotion->StopStreamMode();
			Sleep(100);
			PAMotion->STOP( 1 );
		//	Sleep(50);
		//	PAMotion->STOP( 1 );
		}
		step = 400;
		break;

	case 400:
		if( bIsPressStopButton_ == TRUE ) {
			step = 410;
		} else {
			step = 500;
		}
		break;
	case 410:
		PAMotion->MDA( TRUE, "M05" );	// spindle stop
		Sleep( 100 );
		step = 420;
		break;
	case 420:
		PAMotion->MDA( TRUE, "M29" );	// ������(������) stop
		Sleep( 100 );
		step = 430;
		break;
	case 430:
		PAMotion->MDA( TRUE, "M136" );	// spindle blow stop
		Sleep( 100 );
		step = 500;
		break;

		// ����ڰ� Stop ��ư�� ���ȴ��� ���ο� ����, ���� �ٸ� �������� �����Ѵ� 
	case 500:
		{
			P_LOG->WriteLog_EXT( _T("doToStop [step:500]") );
			int nCurrNCFileIndex = PNCFileMgr->GetCurrentWorkNCFileIndex();
			if( nCurrNCFileIndex != -1 ) 
			{
				if( !bIsPressStopButton_ ) 
				{
					// ����ڰ� Stop ��ư�� ������ ���� ���.. �۾� �Ϸ� 
					PPAStatus->SetNCFileMachiningLine( 0, FALSE );
					if( PPAStatus->GetNCFileState() != pa::NCFILE_STATE_ERROR ) 
					{

						SNCFileInfo* fileInfo = PNCFileMgr->GetNCFileInfo(nCurrNCFileIndex);
						if( PAutoLoader->IsUsingAutoLoader() && !PAutoLoader->IsThisNCFileValid(fileInfo->file_name) ) {
							// 
						} else {
							PPAStatus->SetNCFileFinish( 1, FALSE );
							PPAStatus->SetNCFileState( NCFILE_STATE_COMPLETE, FALSE );
						}
					}
					PPAStatus->SetNCFileWorkTime( PPAStatus->GetThreadState()->dwRunningTime, TRUE ); //FALSE );
					step = 1100;
				} 
				else 
				{
					// ����ڰ� Stop ��ư�� ���� ���,
					PPAStatus->SetNCFileState( NCFILE_STATE_STOP, TRUE ); //FALSE );
					step = 1000;
				}
			}
			else 
			{
				step = 1000;
			}

			if( step == 1100 ) 
			{
				// Autolaoder�� ����ϰ�, ������ �����Ǹ� ���� �۾��� �̾ ���� �ʴ´� 
			//	if( PAutoLoader->IsUsingAutoLoader() == TRUE && PConfig->pConfig_->nModelID != 5) {
// 				if( PAutoLoader->IsUsingAutoLoader() == TRUE && pa::MODEL_INFO.GetAutoLoaderType() != pa::SModelInfo2::AL_TYPE_DISK ) {
// 					if( PConfig->pConfig_->bUsingDetectBlock && PPAStatus->GetPAStatus()->bInput[pa::IN20017_DetectedBlock] != 0 ) {
						step = 1000;
// 					}
// 				}
			}
		}
		break;

	case 1000: {
		//////////////////////////////////////////////////////////////////////////
		// 2016.08.19. COMPLETE�� ���� ��츸 ������ �ݴ´� 
		if( PPAStatus->GetNCFileState() == pa::NCFILE_STATE_COMPLETE )
		{
//			CloseNCFile();
		} else {
			int nCurrNCFileIndex = PNCFileMgr->GetCurrentWorkNCFileIndex();
			SNCFileInfo* fileInfo = PNCFileMgr->GetNCFileInfo(nCurrNCFileIndex);
			if( PAutoLoader->IsUsingAutoLoader() && (!PAutoLoader->IsThisNCFileValid(fileInfo->file_name) || PPAStatus->GetNCFileState() == pa::NCFILE_STATE_ERROR ) ) {

				CloseNCFile();
			} 	
		}

		changeRunMode( RUNMODE_STOP, TRUE );
		step = 0;
		break;

		//////////////////////////////////////////////////////////////////////////
		// ����ڰ� Stop ��ư�� ������ �ʾ��� ���, 
		// ���� Checking ������ ������, �ٷ� ���� �Ѵ� 
	}
	case 1100:
		// ���� �۾��� NC ������ �ִ��� Ȯ���Ѵ� 
		nNextNCFileIndex_ = PNCFileMgr->GetNextWorkNCFileIndex();
		if( nNextNCFileIndex_ != -1 ) {
			step = 1200;
		} 
		else {
			step = 1000;
			// ���� ����� ���, 
			// ��ϵ� NC ���� ��� Checking �� �� �ٽ� ã�´� 
			if( PPAStatus->GetThreadState()->bIsDemoMode_ && PNCFileMgr->GetNumNCFile() > 0 ) {
				PNCFileMgr->SetCurrentWorkIndex( -1, FALSE );
				PNCFileMgr->SetAllNCFileSelectAndFinish( 1, 0, NCFILE_STATE_BEFORE );	// is_select, finish, state 
				step = 1100;
			}
		}
		break;

	case 1200:
		CloseNCFile();
		step = 1210;
		break;
	case 1210:
		{
			// TODO: will need to clean this logic up. This is a edge-casing code.
			// ���� ������ Valid ���� ������ ���� �ʴ´�. DoRun���� ��ŵ�� ���̴�.
			SNCFileInfo* nextValidFileInfo = PNCFileMgr->GetNCFileInfo(nNextNCFileIndex_);
			if( PAutoLoader->IsUsingAutoLoader() && !PAutoLoader->IsThisNCFileValid(nextValidFileInfo->file_name) ) {
				// Open �Ԥ��ʤ����� �����ϴ� �ε����� Invalid�� NC File�϶��� �����Ѵ�.
				// Invalid ������ DoToStop �Լ��� �ҷ������� ������ Complete ���·� ����� ���� ���� index�� �����Ѵ�.

				// NCFileMgr�� ���� �۾����� �ε��� ���� 
				PNCFileMgr->SetCurrentWorkIndex( nNextNCFileIndex_, FALSE );

				// PState�� ���� �۾� ���� ���� ���� 
				PPAStatus->SetNCFileInfo( nNextNCFileIndex_ );
			} else {
				CString strErrMsg(_T(""));
				if( OpenNCFile( nNextNCFileIndex_, strErrMsg ) == FALSE ) {
					// ����.
					throw CPException( ERR_PNC, PNC_ERR_FILE_OPEN, _T("pmac::CPThread::doToStop(1)") );
				}
			}

			step = 1220;
			break;
		}
	case 1220:
		step = 0;
		changeRunMode( RUNMODE_STOP, TRUE );
		DoRun( 0, FALSE );
		break;
		//////////////////////////////////////////////////////////////////////////
	}
}

void pa::CPThread::doInit()
{
	static int		DELAY_COUNT = 0;
	static double	F_POS[pa::AXIS_NUM] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
	int& step = nStep_[RUNMODE_INIT];
	

	switch( step )
	{
	case 0: break;
	case 1: 
		//////////////////////////////////////////////////////////////////////////
		// ��ü ��ư�� LED ON
		// PMotion->SendCommand( "P1022=1 P1021=1 P1040=1", NULL, 0 );
		change_external_button_led( pa::RUNMODE_INIT );
		step = 100;
		break;

	case 100:
		PAMotion->INIT();
		DELAY_COUNT = 10;
		step = 200;
		break;

	case 200:
		if( --DELAY_COUNT < 0 ) {
			step = 1000;
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// AutoLoader�� ����� ���
		// 	case 1000:
		// 		step = PAutoLoader->IsUsingAutoLoader() == TRUE ? 1100 : 2000;
		// 		break;
		// 	case 1100:
		// 		PMotion->AL_Init_Loader_ARM( TRUE );
		// 		step = 1110;
		// 		break;
		// 	case 1110:
		// 		if( PMotion->AL_Init_Loader_ARM( FALSE ) ) {
		// 			step = 1200;
		// 		}
		// 		break;
		// 	case 1200:
		// 		PMotion->AL_Origin();
		// 		Sleep( 100 );
		// 		step = 1300;
		// 		break;
		// 	case 1300:
		// 		PMotion->AL_Init_PNC_ARM( TRUE );
		// 		step = 1310;
		// 		break;
		// 	case 1310:
		// 		if( PMotion->AL_Init_PNC_ARM( FALSE ) == TRUE ) {
		// 			step = 1400;
		// 		}
		// 		break;
		// 	case 1400:
		// 		step = 2000;
		// 		break;
	case 1000:
		step = 2000;
		break;

		//////////////////////////////////////////////////////////////////////////
		// XYZAB�� ��������
// 	case  2000:
// 		PAMotion->HOME( TRUE );
// 		Sleep(500);
// 		step = 2010;
// 		break;
	case 2000:
		PAMotion->HOME(FALSE);
		step = 2010;
		break;
	case 2010:
		step = 2020;
		break;
	case 2020:
		step = 2030;
		break;
	case 2030:
		step = 2100;
		break;
	case 2100:
		if( PPAStatus->GetPAStatus()->nServoHomeState != 0 ) {
			step = 2200;
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// XY, AB���� Ready ��ġ�� �̵��Ѵ� 
		//////////////////////////////////////////////////////////////////////////
	case 2200:
		{
			int fTempPosA = (int)(PPAStatus->GetPAStatus()->fPosition[pa::AXIS_A] + 0.5) % 360;
			int fTempPosB = (int)(PPAStatus->GetPAStatus()->fPosition[pa::AXIS_B] + 0.5) % 360;

			if( fTempPosA < 90 && fTempPosA > -90 ) {
				F_POS[pa::AXIS_A] = 0.0;
			}
			else if( fTempPosA >= 90 ) {
				F_POS[pa::AXIS_A] = 180.0;
			}
			else {
				F_POS[pa::AXIS_A] = -180.0;
			}

			if( fTempPosB < 90 && fTempPosB > -90 ) {
				F_POS[pa::AXIS_B] = 0.0;
			}
			else if( fTempPosB >= 90 ) {
				F_POS[pa::AXIS_B] = 180.0;
			}
			else {
				F_POS[pa::AXIS_B] = -180.0;
			}
		}
		step = 2210;
		break;

		//////////////////////////////////////////////////////////////////////////
		// ZUp & AB ����
	case 2210:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z%.3f A%.3f B %.3f",
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X],
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y],
			0.0,
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_A],
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_B] );
		step = 2220;
		break;

		SEND_CMD_MDA( step, 2220, 2230, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 2230, 2240 )

		//////////////////////////////////////////////////////////////////////////
		// A�� ����
	case 2240:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z%.3f A%.3f B %.3f",
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X],
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y],
			0.0,
			F_POS[pa::AXIS_A],
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_B] );
		step = 2250;
		break;

		SEND_CMD_MDA( step, 2250, 2260, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 2260, 2270 )

		//////////////////////////////////////////////////////////////////////////
		// B�� ���� 
	case 2270:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z%.3f A%.3f B %.3f",
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X],
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y],
			0.0,
			F_POS[pa::AXIS_A],
			F_POS[pa::AXIS_B] );
		step = 2280;
		break;

		SEND_CMD_MDA( step, 2280, 2290, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 2290, 2300 )

		//////////////////////////////////////////////////////////////////////////
		// XY �̵� 
	case 2300:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z%.3f A%.3f B%.3f",
			PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_READYPOS][pa::AXIS_X],
			PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_READYPOS][pa::AXIS_Y],
			0.0,
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_A],
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_B] );
		step = 2310;
		break;

		SEND_CMD_MDA( step, 2310, 2320, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 2320, 2330 )

		//////////////////////////////////////////////////////////////////////////
		// AB �̵� 
	case 2330:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z%.3f A%.3f B%.3f",
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X],
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y],
			0.0,
			PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_READYPOS][pa::AXIS_A],
			PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_READYPOS][pa::AXIS_B] );
		step = 2340;
		break;

		SEND_CMD_MDA( step, 2340, 2350, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 2350, 2360 )

	case 2360:
	//	step = 2500;
		step = 5000;
		break;

		//////////////////////////////////////////////////////////////////////////
		// AutoLoader �Ϸ� Ȯ�� 
		// 	case 2500:
		// 		step = ( PAutoLoader->IsUsingAutoLoader() == TRUE ) ? 2510 : 5000;
		// 		break;
		// 	case 2510:
		// 		if( PState->GetPmacState()->nOriginComplete_BlockLoader != 0 ) {
		// 			step = 3000;
		// 		}
		// 		break;
		// 
		// 		// Door Close 
		// 	case 3000:
		// 		PMotion->SendLineCommand( "M772" );
		// 		step = 3010;
		// 		break;
		// 	case 3010:
		// 		if( PMotion->MotionDone( TRUE ) ) {
		// 			step = 3020;
		// 		}
		// 		break;
		// 	case 3020:
		// 		step = 5000;
		// 		break;

		// �Ϸ� 
	case 5000:
		changeRunMode( RUNMODE_STOP, TRUE );
		step = 0;
		break;
	}
}

void pa::CPThread::doError()
{
	int& step = nStep_[RUNMODE_ERROR];

	//////////////////////////////////////////////////////////////////////////
	static int PREV_STEP_NO = -1;
	if( PREV_STEP_NO != step ) {
		PREV_STEP_NO = step;
		CString strLog;
		strLog.Format( _T("doError step = %d"), step );
		writeLog_EXT( strLog );
	}
	//////////////////////////////////////////////////////////////////////////

	switch( step )
	{
	case 0: break;
	case 1: 
		//////////////////////////////////////////////////////////////////////////
		// 2017.08.28. Error �α� �߰� 
		PAMotion->RND_MSC();
		//////////////////////////////////////////////////////////////////////////
		// 2017.08.23 ERROR ��� �񱳴� �� ���� �� 
		if( hPrevRunMode_ == RUNMODE_RUN || hPrevRunMode_ == RUNMODE_PAUSE || hPrevRunMode_ == RUNMODE_ERROR ) { 
			if( PAMotion->IsStopStreamMode() == FALSE || bIsEMOError_ == TRUE ) {
				PPAStatus->SetNCFileState( NCFILE_STATE_ERROR, TRUE );
				if( !( hBackupExecpt_.hErr == pa::ERR_PNC && hBackupExecpt_.nErrCode == pa::PNC_ERR_NO_BLOCK_FOR_CONTINU_RUN ) ) {
				//	PPAStatus->SetNCFileMachiningLine( PPAStatus->GetThreadState()->nCurrentNCCodeStepNo, TRUE );
					PPAStatus->SetNCFileMachiningLine( nErrorLineNo_, TRUE );
				}
			}
		}

		//////////////////////////////////////////////////////////////////////////
		// ERROR ��ư�� LED�� ON
		// PMotion->SendCommand( "P1022=0 P1021=0 P1040=1", NULL, 0 );
		change_external_button_led( pa::RUNMODE_ERROR );

		//////////////////////////////////////////////////////////////////////////
		//
		if( bIsToolError_ == TRUE )
		{
			if( PAMotion->IsStopStreamMode() == TRUE ) 
			{
				step = 100;
			}
			else
			{
				//////////////////////////////////////////////////////////////////////////
				// �� �����̰�, StreamMode�� ��� 10�� step����...
				step = 10;
				//////////////////////////////////////////////////////////////////////////
				// 2016.08.19 
				// => �� ���ǿ� hPrevRunMode�� RUN/PAUSE �϶� ������ ���δ� 
				// 2016.09.28 
				// => op ��忡�� �� ������ ���, hPrevRunMode�� RUNMODE_ERROR ��. �Ʒ� ������ ����� �� ���� 
/*				if( hPrevRunMode_ == RUNMODE_RUN || hPrevRunMode_ == RUNMODE_PAUSE )
				{
					step = 10;
				}
				else 
				{
					PPAStatus->SetNCFileState( NCFILE_STATE_ERROR, TRUE );
				//	PPAStatus->SetNCFileMachiningLine( nErrorLineNo_, TRUE );	// TORUN���� ������ ������, Error LineNo�� �������� �ʴ´� 
					PAMotion->StopStreamMode();
				//	CloseNCFile();	// 2016.09.26
					step = 100;
				}
*/				//////////////////////////////////////////////////////////////////////////
				// �� �κ� �ּ�ó���ϸ� �Ʒ� �ڵ� �ʿ�
				PPAStatus->SetNCFileState( NCFILE_STATE_ERROR, TRUE );
				PAMotion->StopStreamMode();
			}
		}
		else 
		{
			PPAStatus->SetNCFileState( NCFILE_STATE_ERROR, TRUE );
			// 2016.09.10 ���� �߰�  
			//  toStop���� STOP ���ɿ� ���� ��ſ����� ���� ���, ���� ��ȣ�� ���µǴ� ���󶧹��� �Ʒ� ���� �߰� 
			if( hPrevRunMode_ == RUNMODE_RUN || hPrevRunMode_ == RUNMODE_PAUSE ) {
				PPAStatus->SetNCFileMachiningLine( nErrorLineNo_, TRUE );
			}
			PAMotion->StopStreamMode();
//			CloseNCFile();
			step = 100;
		}
		/*
		2016.09.28 �� ���ǽ� ���濡 ���� ���� 
		if( step == 100 )
		{
		//	pa::PPAStatus->GetThreadState()->hCurrentScreen == SCRN_OPERATION
			// 2016.09.28. ���� ȭ�� ��尡 OPERATION �� ��쿡��, tool ���� ȭ������ ��ȯ 
			if( bIsToolError_ == TRUE ) // && ( pa::PPAStatus->GetThreadState()->hCurrentScreen == SCRN_OPERATION ) )
			{
				step = 10;
			}
		}
		*/
		if( step == 100 )
		{
//			CloseNCFile();
		}

		break;

		//////////////////////////////////////////////////////////////////////////
		// 2017.11.28 
		//	- ���� ���� ���� ���ο� ����, M149�� ȣ������ (���� ���� ok), ������ �������� (���̺���x) ���� 
	case 10:
		if( pa::PPAStatus->GetPAStatus()->nToolLengthUpdateFlag == 0 &&
			pa::PPAStatus->GetPAStatus()->nTool2LengthUpdateFlag == 0) 
		{
			// ���� ���� 
			step = 100;
			break;
		}

		// M149 ȣ���ϴ� ��ƾ����...
		change_external_button_led( pa::RUNMODE_RUN );

		PAMotion->RST();
		Sleep( 10 );
//		PAMotion->STOP();
		PAMotion->STOP(1);
		Sleep( 10 );

		PPAAsyncComm[0]->Reset();
		PPAAsyncComm[1]->Reset();
		step = 20;
		break;

	case  20:
		PPAStatus->GetThreadState()->bRemoteReset_ = TRUE;	// ERROR DIALOG�� ����� 
		nToolErrorHandlingCode_ = PConfig->pConfig_->nToolErrorOccure_HandlingCode;
		if( nToolErrorHandlingCode_ < 0 || nToolErrorHandlingCode_ >= 4 )
		{
			//////////////////////////////////////////////////////////////////////////
			// UserConfirm Dialog�� ���� 
			CUserConfirmDlg::SHOW_DLG(bToolDirection_);
			// ����� ������ ��� �Ѵ� 
			nToolErrorHandlingCode_ = CUserConfirmDlg::WAIT_FOR_SELECT();
			// UserConfirm Dialog�� ����� 
			CUserConfirmDlg::HIDE_DLG();
		}

		nStep_[RUNMODE_RUN] = 20000;
		changeRunMode( RUNMODE_RUN, FALSE );
		step = 0;
		break;

		//////////////////////////////////////////////////////////////////////////
		// Spindle Stop, ������ Stop
	case 100:
// 		PAMotion->STOP();
// 		Sleep(10);
// 		PAMotion->STOP();
// 		Sleep(10);
// 		PAMotion->HALT();
// 		Sleep(10);
// 		PAMotion->HALT();
// 		Sleep(10);
		PAMotion->STOP(1);
		Sleep(100);
		PAMotion->M05();
		Sleep(100);
		PAMotion->M29();
		step = 0;
		break;
		//////////////////////////////////////////////////////////////////////////
	}

	if( step == 0 ) 
	{
		bIsToolError_ = FALSE;
		bIsEMOError_ = FALSE;
	}
}

void pa::CPThread::doPause()
{
	int& step = nStep_[RUNMODE_PAUSE];

	switch( step )
	{
	case 0: break;
	case 1: 
		PAMotion->PAUSE();
		step = 0;
		break;
	}
}

void pa::CPThread::doToRun2()
{
	static int DELAY;
	static int COUNT_SPINDLE_RUN;
	int& step = nStep_[RUNMODE_TORUN];
	char sztemp[128];
	int	 ntemp;

	//////////////////////////////////////////////////////////////////////////
	static int PREV_STEP_NO = -1;
	if( PREV_STEP_NO != step ) {
		PREV_STEP_NO = step;
		CString strLog;
		strLog.Format( _T("doToRun2 step = %d"), step );
		writeLog_EXT( strLog );
	}
	//////////////////////////////////////////////////////////////////////////

	switch( step )
	{
	case 0: break;
	case 1: 

#ifdef _SAVE_RUNTIME_
		pa::PPAStatus->SAVE_RUNNING_TIME(TRUE, pa::PPAStatus->GetThreadState()->hNCFileInfo.file_name );	// �ʱ�ȭ 
#endif
		logging_tool_status();

		checkLimitSensor();

		checkFilterTime();

		SET_ERROR_LINENO( 0 );
		//////////////////////////////////////////////////////////////////////////
		// �����ϱ� �� ���� 
		hTransformVPst_.RESET();
		//////////////////////////////////////////////////////////////////////////
		// RUN ���� LED�� ON
		change_external_button_led( pa::RUNMODE_RUN );
		//////////////////////////////////////////////////////////////////////////
		PPAStatus->GetThreadState()->RESET_LAST_USED_TOOL_CHANGED_LINENO();
		//////////////////////////////////////////////////////////////////////////
		// 2015.10.05 -> �� ���� ������, �̾ ������ ��� ���� ���� 
		// 		if( pmac::PState->GetPmacState()->nOperationOfM28_ == 1 )
		// 		{
		// 			// OperationOfM28_�� DRY(1)�� ���, ������ ON
		// 			PMotion->SendLineCommand( "M28" );
		// 		}
		//////////////////////////////////////////////////////////////////////////
		// DS200-5Z�� ���, �����⸦ Spindle�� �����Ѵ� 
		if( pa::MODEL_INFO.IsUsingCleanRoomSol() )
		{
// 			if( PPAStatus->GetPAStatus()->bInput[pa::IN20011_VacuumSelectSpindle_] == 0 ) {
// 				step = 2;
// 			}
// 			else {
				step = 8;
//			}
		}
		else
		{
			// 4W(A/S) ���� ���, �������� ���� 
			step = 4;
		}
		break;
	case 2:
		//PAMotion->IOT( pa::OUT20041_RoomCleaning, 0 );
		step = 8;
		break;
	case 4:
// 		switch( PConfig->pConfig_->nModelID )
// 		{
// 		case 1:	// 4W
// 		case 2:	// 4WA
// 		case 3:	// 4WAS 
// 			// �������� ����
// 			if( PPAStatus->GetPAStatus()->bOutput[pa::OUT20048_WaterPumpOnSignal] != 0 ) {
// 				PAMotion->IOT( pa::OUT20048_WaterPumpOnSignal, 0 );
// 			}
// 			break;
// 		}
		if( pa::MODEL_INFO.GetM28Type() == pa::SModelInfo2::M28_TYPE_WET )
		{
			// �������� ����
			if( PPAStatus->GetPAStatus()->bOutput[pa::OUT20037_WaterVacuumPumpOnSignal] != 0 ) {
				PAMotion->IOT( pa::OUT20037_WaterVacuumPumpOnSignal, 0 );
			}
		}
		step = 5;
		break;

		//////////////////////////////////////////////////////////////////////////
		// DS200-4WAS ���� ���, ó������ �����Ҷ�, SORZ ������ �����Ѵ� (0:5Z, 1:4W, 2:4WA, 3:4WAS, 4:5P)
	case 5:
//		if( (PConfig->pConfig_->nModelID == 3) && !(nStartLineNo_ > 1) ) {
		if( pa::MODEL_INFO.IsUsingSORZCommandWhenToRun() && !(nStartLineNo_ > 1) ) {
			// SORZ ���� ���� 
			PAMotion->SORZ( TRUE );
			step = 6;
		}
		else {
			step = 8;
		}
		break;
	case 6:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_SORZ, TRUE ) ) {
			step = 8;
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// Stream Mode�� ���� �Ѵ� 
// 	case 8:
// 		PAMotion->StartStreamMode();
// 		//////////////////////////////////////////////////////////////////////////
// 		step = 10; 
// 		break;
// 
// 		//////////////////////////////////////////////////////////////////////////
// 		// Z�� Up �ϰ�, ATC ��� �ݴ´� 
// 		// -> Z-UP �� ���ÿ� A, B�� 0���� �̵� 
// 		SEND_STREAM_CMD( step, 10, 20, "G00 G90 G53 Z0.0\r\n", "G00\r\n")
// 		MOVE_DNE_STREAM( step, 20, 30 )

		// 2017.08.23
		// prepare command ������ �þ��, ��Ȯ�� ���� ��ȣ ī��Ʈ�� �ȵ�
		// startstreammode �������� ����� 
		SEND_CMD_MDA( step, 8, 10, "G00 G90 G53 Z0.0 B0.0" )
		MOVE_DNE_MDA( step, 10, 20 )

	case 20:
		PAMotion->StartStreamMode();
		step = 30;
		break;

#ifdef _PA_G2400_
	case 30:
		if( PPAStatus->GetPAStatus()->bInput[pa::IN102_ATC_DOOR_CLOSE] == 0 ) {
			// ATC DOOR�� �ݴ´� (M702) 
			PAMotion->MDA( "M702" );
			step = 40;
		} else {
			step = 100;
		}
		break;
	case 40:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_MDA, TRUE ) == TRUE ) {
			step = 100;
		}
		break;
#endif 
#ifdef _PA_G1600_
		// DS200-5Z�� ���, �����⸦ Spindle ������ ������ 
	case 30:
	//	if(pa::PConfig)
		step = 100;
		break;
#endif 

	case 100:
		//////////////////////////////////////////////////////////////////////////
		// �̾ ���� ���� Ȯ�� 
		//////////////////////////////////////////////////////////////////////////
		step = ( nStartLineNo_ > 1) ? 190 : 3000;
		if( step == 3000 ) {
			// ó������ ������ ���, �۾� �ð��� �ʱ�ȭ �Ѵ�
		//	PPAStatus->GetThreadState()->dwRunningTime = 0;
			PPAStatus->ResetRunningTime();
		}
		PPAStatus->GetThreadState()->dwFirstHalfRunningTime = 0;
		PPAStatus->GetThreadState()->dwSecondHalfRunningTime = 0;
		break;
	case 190:
		// �̾ �����ϴ���, ���� ���¸� �����ϴ��� Ȯ���Ѵ� 
		if( bRestoreBeforeRun_ == TRUE ) {
			step = 200;
		} else {
			// �۾� �ð��� �ʱ�ȭ ���� �ʴ´� 
			step = 3000;
		}
		break;

	case 200:
		// �̾ ������ ���, �̾ ������ ������ �����Ѵ� 
		// 2015.07.20. nStartLineNo_-1���� �����ϰ�, nStartLineNo ���� ��-���� 
		PContinueRunInfo->StartCheckingRunInfo( nStartLineNo_-1, &hTransformVPst_ );
		step = 210;
		break;
	case 210:
		if( PContinueRunInfo->IsComplete() == TRUE ) {
			step = 220;
		}
		break;
	case 220:
		if( PContinueRunInfo->IsError() == FALSE ) {
			step = 1000;
		} else {
			// ����.
			throw CPException( ERR_PNC, PNC_ERR_INVALID_NCCODE, _T("pmac::CPThread::doToRun2(1)") );
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// �̾ ����. 
		// ��� ���� �ֱ� ��ġ�� �̵� 
		//////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////
		// Z�� UP -> A,B���� ���ÿ� 0���� �̵� -> PA ���� -> �׷��� stream ���� �̵� 
		SEND_STREAM_CMD( step, 1000, 1100, "G00 G90 G53 Z0.0 B0.0\r\n", "G00\r\n")
		MOVE_DNE_STREAM( step, 1100, 1200 )

		//////////////////////////////////////////////////////////////////////////
		// 3, 4, 5 �࿡ ���� �ٸ��� ���� (chairside�� 5��ۿ� �����Ƿ� �ʿ����) 
	case 1200:
		step = 1400; 
		break;

		// 5�� : Z0 B0 -> X0 Y0 A0
		SEND_STREAM_CMD( step, 1400, 1410, "G01 F1000 G90 G53 X0 Y0 A0\r\n", "G01\r\n" )
		MOVE_DNE_STREAM( step, 1410, 1480 )

	case 1480:
		step = 1500;
		break;

		//////////////////////////////////////////////////////////////////////////
		// Left Tool ����. 
	case 1500:
		if( PContinueRunInfo->GetLeftToolNo() == 0 && 
			PPAStatus->GetPAStatus()->nCurrentToolNo != 0 )
		{
			PAMotion->SendStreamCommand( "M1480\r\n", TRUE );
			PAMotion->SendStreamCommand( "G01\r\n", TRUE );
			Sleep( 300 );
			step = 1505;
		}
		else 
		{
			if( PContinueRunInfo->GetLeftToolNo() == 0 ) 
			{
				// ���� ��� ���� �ʿ� ���� 
				step = 1505;
			}
			else 
			{
				// TOOL_NO�� NC �ڵ�� ��Ÿ���� ����ȣ�� �������� ����� �� �ִ� �� ��ȣ�� ã�� �� 
				int TOOL_NO = CGCodeHelper::CheckM140_M145_Restart( PContinueRunInfo->GetLeftToolNo() );
				if( TOOL_NO == 0 ) 
				{
					// ����� �� �ִ� ���� ���� 
					throw CPException( ERR_PNC, PNC_ERR_Tool01+PContinueRunInfo->GetLeftToolNo()-1, _T("pmac::CPThread::doToRun(1)") );
				}
				else 
				{
					if( TOOL_NO == PPAStatus->GetPAStatus()->nCurrentToolNo ) 
					{
						// �̹� ���� ������ ���� 
						//////////////////////////////////////////////////////////////////////////
						// 2017.08.22. ���� ������ ���� ���, 
						// �� ���� ���� ���θ� Ȯ�� �ϰ�, �ȵǾ� ���� ���, M207 ��ũ�θ� ȣ�� �Ѵ� 
						if( pa::PPAStatus->GetPAStatus()->nToolLengthUpdateFlag == 0 ) 
						{
							PAMotion->SendStreamCommand( "M207\r\n", TRUE );
							PAMotion->SendStreamCommand( "G01\r\n", TRUE );
						}
						//////////////////////////////////////////////////////////////////////////
						step = 1505;
					}
					else 
					{
						// ������ �ִ� ���� �ٸ��� �� 
					//	sprintf_s( sztemp, 128, "M%d", 140+TOOL_NO-1 );
					//	PMotion->SendMDACommand( sztemp );
						sprintf_s( sztemp, 128, "M%d\r\n", 140+TOOL_NO-1 );
						PAMotion->SendStreamCommand( sztemp, TRUE );
						PAMotion->SendStreamCommand( "G01\r\n", TRUE );
						Sleep( 300 );
						step = 1505;
					}
				}
			}
		}
		step = 1505;
		break;

		//////////////////////////////////////////////////////////////////////////
		// Right Tool ����. 
	case 1505:
		if( PContinueRunInfo->GetRightToolNo() == 0 && 
			PPAStatus->GetPAStatus()->nCurrentTool2No != 0 )
		{
			PAMotion->SendStreamCommand( "M1481\r\n", TRUE );
			PAMotion->SendStreamCommand( "G01\r\n", TRUE );
			Sleep( 300 );
			step = 1510;
		}
		else 
		{
			if( PContinueRunInfo->GetRightToolNo() == 0 ) 
			{
				// ���� ��� ���� �ʿ� ���� 
				step = 1510;
			}
			else 
			{
				// TOOL_NO�� NC �ڵ�� ��Ÿ���� ����ȣ�� �������� ����� �� �ִ� �� ��ȣ�� ã�� �� 
				int TOOL_NO = CGCodeHelper::CheckM140_M145_Restart( PContinueRunInfo->GetRightToolNo() );
				if( TOOL_NO == 0 ) 
				{
					// ����� �� �ִ� ���� ���� 
					throw CPException( ERR_PNC, PNC_ERR_Tool01+PContinueRunInfo->GetRightToolNo()-1, _T("pmac::CPThread::doToRun(1)") );
				}
				else 
				{
					if( TOOL_NO == PPAStatus->GetPAStatus()->nCurrentTool2No ) 
					{
						// �̹� ���� ������ ���� 
						//////////////////////////////////////////////////////////////////////////
						// 2017.08.22. ���� ������ ���� ���, 
						// �� ���� ���� ���θ� Ȯ�� �ϰ�, �ȵǾ� ���� ���, M207 ��ũ�θ� ȣ�� �Ѵ� 
						if( pa::PPAStatus->GetPAStatus()->nTool2LengthUpdateFlag == 0 ) 
						{
							PAMotion->SendStreamCommand( "M208\r\n", TRUE );
							PAMotion->SendStreamCommand( "G01\r\n", TRUE );
						}
						//////////////////////////////////////////////////////////////////////////
						step = 1510;
					}
					else 
					{
						// ������ �ִ� ���� �ٸ��� �� 
						//	sprintf_s( sztemp, 128, "M%d", 140+TOOL_NO-1 );
						//	PMotion->SendMDACommand( sztemp );
						sprintf_s( sztemp, 128, "M%d\r\n", 140+TOOL_NO-1 );
						PAMotion->SendStreamCommand( sztemp, TRUE );
						PAMotion->SendStreamCommand( "G01\r\n", TRUE );
						Sleep( 300 );
						step = 1510;
					}
				}
			}
		}
		step = 1510;
		break;

	case 1510:
		//////////////////////////////////////////////////////////////////////////
		// 2016.08.24
		//	- �� tool change ���� ������ ���� ���,
		//	- ����Ⱑ ���� �����̱� ������ "?" ���ɿ� ���� ������ �ȿ´� 
		//	- �׷��� timeout ������ ���, ���� ó�� �ϵ��� ���� 
		try 
		{
			if( PAMotion->SendStreamCommand( "?\r\n", FALSE ) == 0 ) {
				step = 1520; 
			}
		}
		catch( CPException& e )
		{
			if( e.hErr == ERR_PNC && e.nErrCode == PNC_ERR_STREAM_SOCKET_TIMEOUT )
			{
				step = 0;
			}
			else 
			{
				throw e;
			}
		}
		//////////////////////////////////////////////////////////////////////////
		break;
	case 1520:
		step = 1600;
		break; 

		//////////////////////////////////////////////////////////////////////////
		// ���� �۾� ��ġ�� �̵� 
		// 3,4,5 �� ���� ���� �̵� 
		//////////////////////////////////////////////////////////////////////////
	case 1600:
		step = 1800;		// 5��
		break;

		// 5�� : A0 -> B -> Y -> X -> A -> (Z)
		// Chairside : Z0B0 -> X, Y, A-> (Z), (B)
		SEND_STREAM_CMD( step, 1800, 1810, "G00 G90 G53 Z0 B0\r\n", "G00\r\n" )
		MOVE_DNE_STREAM( step, 1810, 1820 )

	case 1820:	// X
		sprintf_s( sztemp, 128, "G01 F1000 G%d X%.3f\r\n", PContinueRunInfo->GetPositionCoordinate( AXIS_X ), PContinueRunInfo->GetPosition( AXIS_X ) );
		PAMotion->SendStreamCommand( sztemp, TRUE );
		PAMotion->SendStreamCommand( "G01\r\n", TRUE );
		Sleep( 100 );
		step = 1830;
		break;
		MOVE_DNE_STREAM( step, 1830, 1840 )


	case 1840:	// Y
		sprintf_s( sztemp, 128, "G01 F1000 G%d Y%.3f\r\n", PContinueRunInfo->GetPositionCoordinate( AXIS_Y ), PContinueRunInfo->GetPosition( AXIS_Y ) );
		PAMotion->SendStreamCommand( sztemp, TRUE );
		PAMotion->SendStreamCommand( "G01\r\n", TRUE );
		Sleep( 100 );
		step = 1850;
		break;
		MOVE_DNE_STREAM( step, 1850, 1860 )

	case 1860:	// A
		sprintf_s( sztemp, 128, "G01 F1000 G%d A%.3f\r\n", PContinueRunInfo->GetPositionCoordinate( AXIS_A ), PContinueRunInfo->GetPosition( AXIS_A ) );
		PAMotion->SendStreamCommand( sztemp, TRUE );
		PAMotion->SendStreamCommand( "G01\r\n", TRUE );
		Sleep( 100 );
		step = 1870;
		break;
		MOVE_DNE_STREAM( step, 1870, 1900 )

	case 1900:
		step = 2000;
		break;

		//////////////////////////////////////////////////////////////////////////
		// Spindle(M3/4/5), ������(M28/29), G90/91, Spindle �ӵ�(S0000), FeedRate(F000), �ӵ����(G0/1) ����
	case 2000:
		//////////////////////////////////////////////////////////////////////////
		// 2016.06.09. 
		// ����۽� Ƣ�� ���� ������ �Ʒ� profile ���� ��ġ ���� �� �׽�Ʈ 
		sprintf_s( sztemp, 128, "profile %d\r\n", PContinueRunInfo->GetProfileNo() );
		PAMotion->SendStreamCommand( sztemp, TRUE );
		//////////////////////////////////////////////////////////////////////////

		sprintf_s( sztemp, 128, "G%02d\r\n", PContinueRunInfo->GetCoordinate() );		// G53
		PAMotion->SendStreamCommand( sztemp, TRUE );
		sprintf_s( sztemp, 128, "G%02d\r\n", PContinueRunInfo->GetMovingMode() );		// G90
		PAMotion->SendStreamCommand( sztemp, TRUE );
		sprintf_s( sztemp, 128, "F%d\r\n", PContinueRunInfo->GetFeedRate() );			// F1000
		PAMotion->SendStreamCommand( sztemp, TRUE );
		sprintf_s( sztemp, 128, "M%02d\r\n", PContinueRunInfo->GetDustCollection() );	// M28
		PAMotion->SendStreamCommand( sztemp, TRUE );
		Sleep( 100 );
		step = 2010;
		break;

		//////////////////////////////////////////////////////////////////////////
		// Spindle ���� 
	case 2010:
		COUNT_SPINDLE_RUN = 0;
		step = 2020;
		break;
	case 2020:		// ���� ��
		sprintf_s( sztemp, 128, "SL%d\r\n", PContinueRunInfo->nLeftSpindleSpeedValues_[COUNT_SPINDLE_RUN] );	// S10000
		PAMotion->SendStreamCommand( sztemp, TRUE );
		if( COUNT_SPINDLE_RUN == 0 ) {
			sprintf_s( sztemp, 128, "M%03d\r\n", PContinueRunInfo->GetLeftSpindle() );	// M03
			PAMotion->SendStreamCommand( sztemp, TRUE );
		}
		DELAY = GetTickCount();
		step = 2025;
		break;
	case 2025:		// ������ ��
		sprintf_s( sztemp, 128, "SR%d\r\n", PContinueRunInfo->nRightSpindleSpeedValues_[COUNT_SPINDLE_RUN] );	// S10000
		PAMotion->SendStreamCommand( sztemp, TRUE );
		if( COUNT_SPINDLE_RUN == 0 ) {
			sprintf_s( sztemp, 128, "M%03d\r\n", PContinueRunInfo->GetRightSpindle() );	// M03
			PAMotion->SendStreamCommand( sztemp, TRUE );
		}
		DELAY = GetTickCount();
		step = 2030;
		break;
	case 2030:
		{
			DWORD dwTimeout = PContinueRunInfo->nDwellValues_[COUNT_SPINDLE_RUN] * 1000;
			DWORD dwTime = GetTickCount() - DELAY;
			if( dwTime > dwTimeout ) {
				step = 2040;
			}
		}
		break;

	case 2040:
		COUNT_SPINDLE_RUN += 1;
		if( COUNT_SPINDLE_RUN >= PContinueRunInfo->nNumSpindleDwell_ ) {
			step = 2100;
		} else {
			step = 2020;
		}
		break;
		//////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////
		// Z��, B�� �̵� 
	case 2100:
		sprintf_s( sztemp, 128, "G01 G%d Z%.3f\r\n", PContinueRunInfo->GetPositionCoordinate(AXIS_Z), PContinueRunInfo->GetPosition(AXIS_Z) );
		PAMotion->SendStreamCommand( sztemp, TRUE );
		sprintf_s( sztemp, 128, "G%02d\r\n", PContinueRunInfo->GetMovingVel() );		// G01 
		PAMotion->SendStreamCommand( sztemp, TRUE );
		Sleep( 100 );
		step = 2110;
		break;
		MOVE_DNE_STREAM( step, 2110, 2120 )

	case 2120:
		sprintf_s( sztemp, 128, "G01 G%d B%.3f\r\n", PContinueRunInfo->GetPositionCoordinate(AXIS_B), PContinueRunInfo->GetPosition(AXIS_B) );
		PAMotion->SendStreamCommand( sztemp, TRUE );
		sprintf_s( sztemp, 128, "G%02d\r\n", PContinueRunInfo->GetMovingVel() );		// G01 
		PAMotion->SendStreamCommand( sztemp, TRUE );
		Sleep( 100 );
		step = 2130;
		break;
		MOVE_DNE_STREAM( step, 2130, 2140 )

	case 2140:
		step = 2200;
		break;

		// G53 or G54 ...
	case 2200:
		sprintf_s( sztemp, 128, "G%d\r\n", PContinueRunInfo->GetCoordinate() );
		PAMotion->SendStreamCommand( sztemp, TRUE );
		step = 2210;
		break;
		// profile 10 or 11 ...
	case 2210:
	//	sprintf_s( sztemp, 128, "profile %d\r\n", PContinueRunInfo->GetProfileNo() );
	//	PAMotion->SendStreamCommand( sztemp, TRUE );
		step = 3000;
		break;

		//////////////////////////////////////////////////////////////////////////
		// ���� ���� 
		//////////////////////////////////////////////////////////////////////////
	case 3000:
		step = 3100;
		break;

	case 3100:
		// �۾� ���� ���� 
		ntemp = PNCFileMgr->GetCurrentWorkNCFileIndex();
		// ���� �ð� ���� 
		PPAStatus->SetNCFileStartTime( FALSE );
		// �۾� ���� ���� 
		PPAStatus->SetNCFileState( NCFILE_STATE_RUNNING, TRUE );
		//////////////////////////////////////////////////////////////////////////
		// NC File�� ������ Finish�� 0���� ����� 
		PPAStatus->SetNCFileFinish( 0, TRUE );
		//////////////////////////////////////////////////////////////////////////
		changeRunMode( RUNMODE_RUN, TRUE );
		step = 0;
		break;
	}
}

void pa::CPThread::doRun()
{
	static DWORD	CHECK_TIME = 0;
	static BOOL		GET_NEW_LINE = FALSE;
	static BOOL		IS_LAST_COMMAND = FALSE;
	static BOOL		IS_M47_REPEAT = FALSE;
	static BOOL		IS_M30_PGM_END = FALSE;
	static BOOL		IS_NO_TOOL_FOR_USING = FALSE;		// ����� �� �ִ� ���� ���� 
	static int		ERROR_TOOL_NO = 0;
	static int		AL_FIRST_SENSING_INDEX = 0;
//	static int		N_BUFFERED_LINES = 0;
	static int		N_BUFFERED_COUNT = 0;
	static int		N_BUFFERING_COUNT= 0;
	static int		N_100_LINE_BUFFERING = 0;			// 100������ ���۸� �Ǹ�, ���¸� ���� �� �ֵ��� ���� �Ѵ� 
	static int		DELAY_COUNT = 0; 

	static int	N_BUFF_MIN = 0;
	static int	N_BUFF_MAX = 0;
	static int	N_BUFF_OVER_5000 = 0;	// ���۸��� 5000���� �̻��̸� min ���� �����Ѵ� 
	static int	N_PREV_BUFF_COUNT = 0;

	int& step = nStep_[RUNMODE_RUN];
	char sztemp[64];

	//////////////////////////////////////////////////////////////////////////
	// mechining_line�� ���� �Ѵ� 
	// 2016.09.26. tool ���� ó���� �ϴ� ����, ��� ����� 
	if( !( step >= 20000 && step <= 25010 ) )
	{
		PPAStatus->GetThreadState()->hNCFileInfo.machining_lines = PPAStatus->GetThreadState()->nCurrentNCCodeStepNo;
	}
	//////////////////////////////////////////////////////////////////////////

	switch( step )
	{
	case 0: break;
	case 1:
		GET_NEW_LINE	= TRUE;
		IS_LAST_COMMAND	= FALSE;
		IS_M47_REPEAT	= FALSE;
		IS_M30_PGM_END	= FALSE;
		IS_NO_TOOL_FOR_USING = FALSE;
		N_BUFFERING_COUNT= 10000; //20000; //10000; //5000;
		N_100_LINE_BUFFERING = 0;
		SET_ERROR_LINENO( 0 );

		N_BUFF_MIN = 10000;
		N_BUFF_MAX = 0;
		N_BUFF_OVER_5000 = 0;
		N_PREV_BUFF_COUNT= 0;
		step = 100;
		break;

#ifdef _USE_AUTOLOADER_
		//////////////////////////////////////////////////////////////////////////
		// ���� �ε� 
		//////////////////////////////////////////////////////////////////////////
	case 100:
		step = bIsNeedBlockLoading_ ? 300 : 900;
		break;

	case 300:
		doItemLoading( TRUE );
		step = 310;
		break;
	case 310:
		if ( doItemLoading( FALSE ) ) {
			step = 320;
		}
		break;
	case 320:
		// 2015.02.28. ���� ��� ��� �߰� 
		if( PAutoLoader->GetWorkIndex() == -1 ) {
			// ���� ��� ��� ���θ� Ȯ���ϰ�, 
			if( !PPAStatus->GetThreadState()->bIsDemoMode_ ) {
				// For 5A, do not throw error but skip.
//				if (PConfig->pConfig_->nModelID == 5) {
				if( pa::MODEL_INFO.GetModelID() == pa::SModelInfo2::MODEL_5A ) {
					PAMotion->StopStreamMode();
					Sleep(100);
					PAMotion->STOP( 1 );
					step = 5900;	
				} else {
					// ���� ��尡 �ƴ� ���, 
					// ����� �� �ִ� ������ ���� ���� 
					throw CPException( ERR_PNC, PNC_ERR_AutoLoaderEmpty, _T("pmac::CPThread::doRun(1)") );
				}
				break;
			} 
			else {
				// ���� ����� ���,
				// ��� ������ ���¸� Ready�� �����, �ٽ� �ε� �Ѵ� 
//				if (PConfig->pConfig_->nModelID == 5) {
				if( pa::MODEL_INFO.GetModelID() == pa::SModelInfo2::MODEL_5A ) {
					PAMotion->StopStreamMode();
					Sleep(100);
					PAMotion->STOP( 1 );
					step = 5900;	
				} else {
					PAutoLoader->SetBlockState_All_Before( -1 );
					step = 300;
				}
				break;
			}
		} else {
			// ������ �ε� ���� 
			PAutoLoader->SetBlockState( PAutoLoader->GetValidItemSlotIndex(), BLOCK_STATE_RUNNING );
		}
		step = 900;
		break;
#else 
	case 100:
		step = 900;
		break;
#endif

		//////////////////////////////////////////////////////////////////////////
		// Stream ��带 ���� �Ѵ� 
		//////////////////////////////////////////////////////////////////////////
	case 900:
		SET_ERROR_LINENO( 0 );			// ���� �߻� ���� ��ȣ�� 0����...
		GET_NEW_LINE = TRUE;
		bIsSensingExistBlock_ = TRUE;
		if( bIsNeedBlockLoading_ ) {
			PAutoLoader->SetBlockState( PAutoLoader->GetWorkIndex(), BLOCK_STATE_RUNNING );
		}

		//////////////////////////////////////////////////////////////////////////
		step = 1000;
		break;

		//////////////////////////////////////////////////////////////////////////
		// NC Code �ٿ�ε� 
		//////////////////////////////////////////////////////////////////////////
	case 1000:
		{
			static char	STR_CMD[256];
			static char STR_COMMAND[256];

NEXT_LINE:

			//////////////////////////////////////////////////////////////////////////
			// mechining_line�� ���� �Ѵ� 
			// 2016.09.27. ���� ���� �ڵ尡 ���� 
// 			PPAStatus->GetThreadState()->hNCFileInfo.machining_lines = PPAStatus->GetThreadState()->nCurrentNCCodeStepNo;
			//////////////////////////////////////////////////////////////////////////

			if( GET_NEW_LINE==TRUE ) 
			{
				// 2017.03.16. �ѹ��� 10 ���ξ� ���۸� �ϵ��� �׽�Ʈ 
				// NC ���� �ڵ带 �д´� 
				memset((void*)STR_CMD, 0, sizeof(char)*256);
				IS_LAST_COMMAND = PNCFile->GetNextLine( STR_CMD );	// copy
				IS_LAST_COMMAND = !IS_LAST_COMMAND;

				//////////////////////////////////////////////////////////////////////////

				//////////////////////////////////////////////////////////////////////////
				// GCode�� Ȯ���Ѵ�. �ּ��� ����. M30, M47�� Ȯ�� 
				int nToolNo = 0;
				EN_CHECK_NC_CODE hCheckNCCode = checkNCCode( STR_CMD, &ERROR_TOOL_NO, &nToolNo );
	
				//////////////////////////////////////////////////////////////////////////
				// ������ ����� �� ��ȣ�� NC-File�� ���� ��ȣ�� �����Ѵ� 
				if( nToolNo != 0 ) {
					int line_no = PNCFile->GetWorkLine();
					PPAStatus->GetThreadState()->ADD_LAST_USED_TOOL_LINENO( line_no );	// tool change ������ ��� ���� �Ѵ� 
				}

// 				//////////////////////////////////////////////////////////////////////////
				
				sprintf_s( STR_COMMAND, 256, "%s\r\n", STR_CMD );

				switch( hCheckNCCode )
				{
				case CHECK_NC_CODE_RUN:				// ���� ó�� 
					N_BUFFERED_COUNT= PAMotion->SendStreamCommand( STR_COMMAND, FALSE );
					GET_NEW_LINE	= N_BUFFERED_COUNT >= N_BUFFERING_COUNT ? FALSE : TRUE;
					IS_M30_PGM_END	= FALSE;
					IS_M47_REPEAT	= FALSE;
					break;	
				case CHECK_NC_CODE_M30:				// �ڵ忡 M30 ���� 
					N_BUFFERED_COUNT= PAMotion->SendStreamCommand( STR_COMMAND, FALSE );				
					GET_NEW_LINE	= N_BUFFERED_COUNT >= N_BUFFERING_COUNT ? FALSE : TRUE;
					IS_M30_PGM_END	= TRUE;
					IS_M47_REPEAT	= FALSE;
					break;
				case CHECK_NC_CODE_M47:				// �ڵ忡 M47 ���� 
//					N_BUFFERED_COUNT= PAMotion->SendStreamCommand( STR_COMMAND, FALSE );
//					GET_NEW_LINE	= N_BUFFERED_COUNT >= N_BUFFERING_COUNT ? FALSE : TRUE;
					N_BUFFERED_COUNT= PAMotion->SendStreamCommand( "M30\r\n", FALSE );
					GET_NEW_LINE	= FALSE;
					IS_M30_PGM_END	= FALSE;
					IS_M47_REPEAT	= TRUE;
					break;
				case CHECK_NC_CODE_ERROR:			// �ڵ� ���� (checkNCCode �Լ����� �� ���� �������� ����)
					// ����. 
					throw CPException( ERR_PNC, PNC_ERR_INVALID_NCCODE, _T("pmac::CPThread::doRun(2)") );
					break;
				case CHECK_NC_CODE_SKIP:			// ���� ��ŵ
// 					N_BUFFERED_COUNT= PAMotion->SendStreamCommand( STR_COMMAND, FALSE );
// 					GET_NEW_LINE	= N_BUFFERED_COUNT >= N_BUFFERING_COUNT ? FALSE : TRUE;
// 					IS_M30_PGM_END	= FALSE;
// 					IS_M47_REPEAT	= FALSE;
					break;
				case CHECK_NC_CODE_TOOL_OVERTIME:	// �� ����. �� ��� �ð��� ������, ����� �� �ִ� ���� ���� ����  
					IS_NO_TOOL_FOR_USING= TRUE;
					IS_M30_PGM_END		= FALSE;
					IS_M47_REPEAT		= FALSE; 
					GET_NEW_LINE		= FALSE;
					// NCFile ���� Work Line�� ��-���� �Ѵ� 
					{
						int n = PNCFile->GetWorkLine();
						n = n -1;
					}
					PNCFile->SetWorkLine( PNCFile->GetWorkLine() - 1 );
					break;
				}
			}
			else 
			{
				//////////////////////////////////////////////////////////////////////////
				// ����⿡ ���۸� ������ �Ԥ��Ȥ� ã�� ������ "?"�� ������ ���� �����͸� ������Ʈ �Ѵ� 
				N_BUFFERED_COUNT= PAMotion->SendStreamCommand( "?\r\n", FALSE );		
				GET_NEW_LINE	= N_BUFFERED_COUNT >= N_BUFFERING_COUNT ? FALSE : TRUE;
				//////////////////////////////////////////////////////////////////////////
			}
// 2017.03.13
#ifdef _DEBUG
			{
				CString strDbg;
				strDbg.Format( _T("BUFFERED COUNT : %d\n"), N_BUFFERED_COUNT );
				TRACE( strDbg );
			}
#endif

			// 2017.03.13 
// 			static int N_DBG_SSS = 0;
// 			if( N_BUFFERED_COUNT < 10 ) {
// 				if( N_DBG_SSS == 0 ) {
// 					N_DBG_SSS = 1;
// 					// logging 
// 					writeLog_AutoCal( _T("\n<<<BUFFERING UNDER 10>>>\n"), FALSE );
// 					TRACE( _T("<<<BUFFERING UNDER 10>>>\n") );
// 				}				
// 			} else {
// 				N_DBG_SSS = 0;
// 			}
			if( N_BUFFERED_COUNT > 2500 ) { N_BUFF_OVER_5000 = 1; }
// 			if( N_BUFFERED_COUNT > N_BUFF_MAX ) {
// 				N_BUFF_MAX = N_BUFFERED_COUNT; 
// 			}
// 			if( N_BUFF_OVER_5000==1 ) {
// 				if( N_BUFFERED_COUNT < N_BUFF_MIN ) {
// 					N_BUFF_MIN = N_BUFFERED_COUNT;
// 				}
// 			}

			if( N_BUFF_OVER_5000==1 && abs(N_PREV_BUFF_COUNT - N_BUFFERED_COUNT) > 1000 ) { // 500
				N_PREV_BUFF_COUNT = N_BUFFERED_COUNT;
				static TCHAR SZ_LOG[128];
				_stprintf_s( SZ_LOG, 128, _T("<<< BD : %d - %d"), PNCFile->GetWorkLine(), N_BUFFERED_COUNT );
				writeLog_AutoCal( SZ_LOG, FALSE );
			}

			if( GET_NEW_LINE ) 
			{
				N_100_LINE_BUFFERING += 1;

				//////////////////////////////////////////////////////////////////////////
				// update buffering line no.
				PPAStatus->GetThreadState()->nBufferingLine = PNCFile->GetWorkLine();
				//////////////////////////////////////////////////////////////////////////

				// push�� ���� �߰�,
				if( IS_LAST_COMMAND ) {
					// ������ �����̸� ���� 
					step = 2000;
				}
				else
				{
					// ������ ������ �ƴϸ�,
					if( IS_M30_PGM_END == TRUE || IS_M47_REPEAT == TRUE ) {
						// M30 or M47�̸� ����
						step = 2000;
					} 
					else {
						// ������ ������ �ƴϸ�, �ٷ� ���� ���� �ٿ� �ε� 
						if( PPAStatus->GetRunMode() != pa::RUNMODE_RUN ) {
							break;
						}
						// 100������ �������� ���۸� �ߴٸ�, ������ ���� ���� 
						if( N_100_LINE_BUFFERING >= 300 ) { //400 ) {		// 50 -> 100 -> 200 -> 500 2017.03.17
							N_100_LINE_BUFFERING = 0;
							break;
						}
						goto NEXT_LINE;
					}
				}
			} 
			else {
				// push ���� �������Ƿ�, �� ���� ���� ���� 
				N_100_LINE_BUFFERING = 0;
				// ���� tool ���� ��Ȳ�̸�, 2000 step����...���� ���� ���۸��� �ڵ带 �����Ѵ� 
				if( IS_NO_TOOL_FOR_USING == TRUE ) {
					step = 2000;
				}
				break;	
			}
		}
		break;

	case 2000:
		// PNCFile�� WorkLine�� ���� ���� ������ ���ؼ�, ���� ���� ���� ��� 
		// PA ������� ���, Stream ��忡�� ���� �ڵ带 ��� �����ؼ� ������ LineNumber�� 1�� ���� �Ѵ�
		// �׸��� Stream Stop �ϸ� LineNumber�� 0�� �����Ѵ� 
		step = 2100;	// MotionDone�� PA����� ����� IDLE ���¸� ���� ������, �Ʒ� �Լ����� �������� Ȯ���Ѵ� 
		DELAY_COUNT = 10;
		break;
	case 2100:
		// ������ ������ ���� ���. "?" ������ ������ ���� ������(status-code, line-number, buffer-count)�� ������Ʈ �Ѵ� 
// 		if( --DELAY_COUNT <= 0 ) 
// 		{
// 			N_BUFFERED_COUNT= PAMotion->SendStreamCommand( "?\r\n", FALSE );		
// 			DELAY_COUNT = 10;
// 		}
// 		else 
// 		{
// 			break;
// 		}
// 		{
// 			int rnd_state = PPAStatus->GetPAStatus()->nRunStatus;
// 			CString strdbg;
// 			strdbg.Format( _T("rnd_state : %d\n"), rnd_state );
// 			TRACE( strdbg );
// 		}
// 		if( PPAStatus->GetPAStatus()->nRunStatus == 0 || N_BUFFERED_COUNT <= 0 ) { 
// 			// ���� ������ 0���� �ʱ�ȭ �Ѵ� 
// 			PPAStatus->GetThreadState()->nStartingNCCodeStepNo = 0;
// 			PPAStatus->GetThreadState()->nNumberOfPreparingStep= 0;
// 			step = 2200;
// 		}
		// 2016.09.27
		// �Ʒ� �ڵ忡�� 0���� �ʱ�ȭ �ؼ�, tool ������ �߸��� ���� ��ȣ�� ���� ������ ������.
		// ������ �ʱ�ȭ �ϴ� �ڵ�� StopStreamMode���� �ϴ� ������ �����ؼ� �׽�Ʈ �غ��� �� 
		//if( PPAStatus->GetPAStatus()->nRunStatus == 0 || N_BUFFERED_COUNT <= 10 ) 
		
		// 2016.10.12 debug 
#ifdef _DEBUG
		{
			CString strDbg;
			strDbg.Format( _T("RunStatus(%d) N_BUFFERED_COUNT(%d)\n"), PPAStatus->GetPAStatus()->nRunStatus, N_BUFFERED_COUNT );
			TRACE( strDbg );
		}
#endif
		
		// 2016.10.17. <=1 �ϸ� M30 ������ "?" ������ ��� ������, "?"�� ���� ������ �� �޴� ������ �ִ°� ���� 
		// �ϴ� �ٽ� <=10���� ���� �� ���� 
		if( PPAStatus->GetPAStatus()->nRunStatus == 0 || N_BUFFERED_COUNT <= 10 ) //N_BUFFERED_COUNT <= 1)
		{
			// ���� ������ 0���� �ʱ�ȭ �Ѵ� 
		//	PPAStatus->GetThreadState()->nStartingNCCodeStepNo = 0;
		//	PPAStatus->GetThreadState()->nNumberOfPreparingStep= 0;
			step = 2200;
			break;
		}
		else 
		{
			if( --DELAY_COUNT <= 0 ) 
			{
				N_BUFFERED_COUNT= PAMotion->SendStreamCommand( "?\r\n", FALSE );		
				DELAY_COUNT = 20;
			}
		}
		break;
	case 2200:
		// 0(idle), 1(running), 2(paused), 3(error)
		{
			int temp = PPAStatus->GetPAStatus()->nRunStatus;
			if( PPAStatus->GetPAStatus()->nRunStatus == 0 || IS_NO_TOOL_FOR_USING == TRUE ) 
			{
				step = 2210;
			}
		}
		break;
	case 2210:
		if( IS_M47_REPEAT ) {
			PAMotion->StopStreamMode();
			Sleep( 100 );
			// ���� NC ���� �� ����.
			PNCFile->ResetWorkLine();
			step = 1;	// step = 900; // 2020.09.22 Re �ȵǾ� ���� ��ġ�� ���� 
			PAMotion->StartStreamMode();
		} else {
			step = 2300;
		}
		break;
	case 2300:
		if( IS_M30_PGM_END ) {
			// NC ������ ù ��° ������ ����Ű���� ���� 
			PNCFile->ResetWorkLine();
		}
		step = 2400;
		break;
	case 2400:
		if( IS_NO_TOOL_FOR_USING ) 
		{
			IS_NO_TOOL_FOR_USING = FALSE;	// ���� �ʱ�ȭ 

			switch( ERROR_TOOL_NO )  
			{
			case 1: throw CPException( ERR_PNC, PNC_ERR_Tool01, _T("pmac::CPThread::doRun(3)") ); break;
			case 2: throw CPException( ERR_PNC, PNC_ERR_Tool02, _T("pmac::CPThread::doRun(4)") ); break;
			case 3: throw CPException( ERR_PNC, PNC_ERR_Tool03, _T("pmac::CPThread::doRun(5)") ); break;
			case 4: throw CPException( ERR_PNC, PNC_ERR_Tool04, _T("pmac::CPThread::doRun(6)") ); break;
			case 5: throw CPException( ERR_PNC, PNC_ERR_Tool05, _T("pmac::CPThread::doRun(7)") ); break;
			case 6: throw CPException( ERR_PNC, PNC_ERR_Tool06, _T("pmac::CPThread::doRun(8)") ); break;
			case 7: throw CPException( ERR_PNC, PNC_ERR_Tool07, _T("pmac::CPThread::doRun(9)") ); break;
			case 8: throw CPException( ERR_PNC, PNC_ERR_Tool08, _T("pmac::CPThread::doRun(10)") ); break;
			default:throw CPException( ERR_PNC, PNC_ERR_ToolUK, _T("pmac::CPThread::doRun(11)") ); break;
			}
		}

		//////////////////////////////////////////////////////////////////////////
		// Steram ��� ���� 
		PAMotion->StopStreamMode();
		//////////////////////////////////////////////////////////////////////////
		// 2017.03.13 
// 		{
// 			CString strDbg;
// 			strDbg.Format( _T("<<< BUFFERED_MIN : %d >>>\n"), N_BUFF_MIN );
// 			writeLog_AutoCal( strDbg, FALSE );
// 			strDbg.Format( _T("<<< BUFFERED_MAX : %d >>>\n"), N_BUFF_MAX );
// 			writeLog_AutoCal( strDbg, FALSE );
// 		}
		step = 5000;	// ���� 
		break;

		//////////////////////////////////////////////////////////////////////////
		// ���� �ڵ� ���� �� ���� ��ε� 
	case 5000: {
		bIsSensingExistBlock_ = FALSE;

		if( PAutoLoader->IsUsingAutoLoader() == TRUE ) {
			// 
			int nWorkIndex = PAutoLoader->GetWorkIndex();
			if( nWorkIndex != -1 ) 
			{
				// �ڵ����� ������ �ε����� ���,
				BOOL bExistUnloadingPos = ( PAutoLoader->GetBlockState( nWorkIndex ) == BLOCK_STATE_RUNNING ||
											PAutoLoader->GetBlockState( nWorkIndex ) == BLOCK_STATE_ERROR );
				if( bIsPressStopButton_ == FALSE && bExistUnloadingPos == TRUE ) {
					// ���� Unloading. ����ڰ� Stop ��ư�� ������ �ʰ�, ��ε� ��ġ�� running / error �� ���,
					bIsNeedBlockUnloading_ = TRUE;
				} 
				else 
				{
					if( bIsPressStopButton_ == FALSE )
					{
						// ����ڰ� Stop ��ư�� ������ �ʾ����Ƿ�, 
						// �۾��� Complete, NC ���� �ݰ�,
						if( bIsNeedBlockLoading_ == TRUE ) 
						{
							PAutoLoader->SetBlockState( nWorkIndex, BLOCK_STATE_COMPLETE );
						}
					}
					bIsNeedBlockUnloading_ = FALSE;
				}
			}
			else 
			{
				bIsNeedBlockUnloading_ = FALSE;
			}
		} 
		else 
		{
			bIsNeedBlockUnloading_ = FALSE;
		}

		// TODO: This is an edge case senario. This will be removed after we clean up the logic.
		int nextValidItemSlotIndex = PAutoLoader->GetNextValidItemSlotIndex();
		// No need to unload if the next valid item is from the same slot.
		if ( PAutoLoader->IsUsingAutoLoader() && nextValidItemSlotIndex != -1 && nextValidItemSlotIndex == PAutoLoader->GetWorkIndex() ) {
			bIsNeedBlockUnloading_ = FALSE;
		}

		//////////////////////////////////////////////////////////////////////////
		// ���� ��ε��� ���� ���� ���,
		if( bIsNeedBlockUnloading_ == FALSE ) {
			step = 5900;
		} else {
			step = 5100;
		}
		//////////////////////////////////////////////////////////////////////////
		break;
	}

		//////////////////////////////////////////////////////////////////////////
		// ���� ��ε� 
		//////////////////////////////////////////////////////////////////////////
	case 5100:
		step = 5300;
		break;
#ifdef _USE_AUTOLOADER_
	case 5300:
		if( PAutoLoader->IsUsingAutoLoader() == TRUE && bIsNeedBlockUnloading_ == TRUE ) {
			step = 5400;
		} else {
			step = 5900;
		}
		break;
	case 5400:
// 		if( ( PConfig->pConfig_->bUsingDetectBlock == TRUE ) && 
// 			( PPAStatus->GetPAStatus()->bInput[pa::IN20017_DetectedBlock] == FALSE ) )	//  TODO: might have to fix this	
// 		{
// 			// ������ ���� 
// 			PAutoLoader->SetBlockState( PAutoLoader->GetWorkIndex(), BLOCK_STATE_LOST );
// 			step = 5900;
// 		}
// 		else 
// 		{
			step = 5410;
// 		}
		break;

	case 5410:
		doItemUnloading( TRUE );
		step = 5420;
		break;
	case 5420:
		if( doItemUnloading( FALSE ) ) {
			step = 5430;
		}
		break;
	case 5430:
		step = 5900;
		break;
#else 
	case 5300:
		step = 5900;
		break;
#endif

		//////////////////////////////////////////////////////////////////////////
	case 5900:
		step = 6000;
		break;
	case 6000:
		changeRunMode( RUNMODE_TOSTOP, TRUE );
		step = 0;
		break;

		//////////////////////////////////////////////////////////////////////////
		// AutoLoader ReFill ���� 
		//////////////////////////////////////////////////////////////////////////
	case 10000:
		AL_FIRST_SENSING_INDEX = -1;
		// �� ����, Cassette ��������..
		PAMotion->AL_Init_Loader_ARM( TRUE );
		step = 10010;
		break;
	case 10010:
		if( PAMotion->AL_Init_Loader_ARM( FALSE ) ) {
			step = 10100;
		}
		break;

	case 10100:
		ReturnItem( TRUE );
		step  = 10101;
		break;
	case 10101:
		if ( ReturnItem( FALSE ) ) {
			// If rescan happens inside `ReturnItem`, no need to rescan again.
			step = hasRescanForRefill_ ? 13000 : 10102;
			hasRescanForRefill_ = FALSE;
		}
		break;

	case 10102:
		doAutoloaderRescan(TRUE);
		step = 11000;
		break;
	case 11000:
		if (doAutoloaderRescan(FALSE)) {
			step = 13000;
		}
		break;

	// ���� 
	case 13000:
		changeRunMode( RUNMODE_STOP, TRUE );
		step = 0;
		break;

	case 14000:
		ReturnItem( TRUE );
		step  = 14001;
		break;
	case 14001:
		if ( ReturnItem( FALSE ) ) {
			changeRunMode( RUNMODE_STOP, TRUE );
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// Tool ����. ��Ŀ����
		// �۾� NC������ �۾� ��ġ�� �� ��ü ��ġ�� ���� �Ѵ� - 20151121
		//////////////////////////////////////////////////////////////////////////
		// ������ ���� ���� ���´� 
// 		SEND_CMD_MDA( step, 20000, 20010, "M149" )		// �� ���� 
// 		MOVE_DNE_MDA( step, 20010, 20020 )
// 		SEND_CMD_MDA( step, 20020, 20030, "M139" )		// �� ��ȣ ���� 
// 		MOVE_DNE_MDA( step, 20030, 21000 )
		// ������ ���� ���� ���´� 
		// �� ���⿡���� �ٸ� ���� ��� 
	case 20000:
		if (bToolDirection_ == FALSE) {
			// Left 
			step = 20010;
		} else {
			// Rigith
			step = 20100;
		}
		break;

		// Left 
		SEND_CMD_MDA(step, 20010, 20020, "M1490") 
		MOVE_DNE_MDA(step, 20020, 20030)
		SEND_CMD_MDA(step, 20030, 20040, "M138")
		MOVE_DNE_MDA(step, 20040, 21000)
		
		// Rigiht
		SEND_CMD_MDA(step, 20100, 20110, "M1491")
		MOVE_DNE_MDA(step, 20110, 20120)
		SEND_CMD_MDA(step, 20120, 20130, "M139")
		MOVE_DNE_MDA(step, 20130, 21000)

	case 21000: 
		switch( nToolErrorHandlingCode_ )
		{
		case 0: // *Stop
			step = 22000;
			break;
		case 1: // *Restart from tool changed line
			step = 23000;
			break;
		case 2: // Restart from beginning 
			step = 24000;
			break;
		case 3: // *Start from next nc-file 
			step = 25000;
			break;
		default: // Stop ���� ó�� 
			step = 22000;
			break;
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// Stop 
		// ���� �۾��� ERROR�� �����, ������ ���µ� ERROR�� �����. 
		// �۾��� �����. 
		// ������ AutoLoader�� ���� ������ �ʴ´� 
	case 22000:
		// PState->SetNCFileState( NCFILE_STATE_ERROR, TRUE );
		if( PAutoLoader->IsUsingAutoLoader() && bIsNeedBlockLoading_ ) {
			PAutoLoader->SetBlockState( PAutoLoader->GetWorkIndex(), BLOCK_STATE_ERROR );
		}
		PPAStatus->SetNCFileState( NCFILE_STATE_ERROR, TRUE );
		// NC ���� ����Ʈ�� ������Ʈ �Ѵ� 
		pa::PPAStatus->GetThreadState()->bUpdateNcFileList_ = TRUE;
		step = 22010;
		break;
	case 22010:
		bIsPressStopButton_ = FALSE;	
		// 2016.09.26. �������� ���, TOSTOP���� ��ȯ�� �ʿ������ ����. �׷��� ���� 
		// changeRunMode( pa::RUNMODE_TOSTOP, TRUE );		// ������, ���ɵ�... ���� ���� ����...
		changeRunMode( pa::RUNMODE_STOP, TRUE );
		step = 0;
		break;

		//////////////////////////////////////////////////////////////////////////
		// Restart from tool changed line 
		// ���� �۾��� dwLastUsedToolChangeLineNo_ ���κ��� �ٽ� �����Ѵ� 
		/*
	case 23000:
		// ���� �۾����ΰ� ���� ������ Tool ��ü ������ ã�Ƽ� ����Ѵ� 
		// ���� �� ó������ ������ ���, ���� �� ��ü ���� -1�� ���� �ؾ� �Ѵ�. 
		// �ֳ� �ϸ� �����Ҷ� GetNextLine() �Լ����� ���� ������ �о� ���� �����δ� 
		{
			PAMotion->StopStreamMode();

			int start_line = nErrorLineNo_;

			int nccode_stepno = PPAStatus->GetThreadState()->SEARCH_LAST_USED_TOOL_LINENO( start_line );
// 			if( nccode_stepno > 0 ) {
// 				nccode_stepno -= 1;
// 			}
// 			PNCFile->SetWorkLine( nccode_stepno );
// 			PPAStatus->SetNCFileMachiningLine( nccode_stepno, TRUE );
			if( nccode_stepno <= 1 ) {
				nccode_stepno = 1;
			} else {
				nccode_stepno -= 1;
			}
			PPAStatus->GetThreadState()->nStartingNCCodeStepNo = nccode_stepno;
			PPAStatus->GetThreadState()->nCurrentNCCodeStepNo  = nccode_stepno;
			PPAStatus->GetThreadState()->nNumberOfPreparingStep= 0;
			nStartLineNo_ = nccode_stepno;

			PPAStatus->GetThreadState()->RESET_LAST_USED_TOOL_CHANGED_LINENO();

			if( nStartLineNo_ == 1 ) {
				// ���۶����� 1�̸�, PNCFile�� WorkLine�� �ʱ�ȭ �Ѵ� 
				PNCFile->ResetWorkLine();
			} else {
				PNCFile->SetWorkLine( nStartLineNo_ );
			}
		}
		step = 23010;
		break;
	case 23010:
		PPAStatus->SetNCFileState( NCFILE_STATE_RUNNING, TRUE );
		// NC ���� ����Ʈ�� ������Ʈ �Ѵ� 
		PPAStatus->GetThreadState()->bUpdateNcFileList_ = TRUE;
		PAMotion->StartStreamMode();
		PAMotion->SendStreamCommand( "profile 11", FALSE );
		step = 900;
		break;
		*/
	case 23000:
		{
			PAMotion->StopStreamMode();
			int start_line_no = nErrorLineNo_;
			start_line_no = PPAStatus->GetThreadState()->SEARCH_LAST_USED_TOOL_LINENO( start_line_no );
			if( start_line_no <= 1 ) {
				start_line_no = 1;
			} else {
				start_line_no -= 0; //1;
			}
			changeRunMode( RUNMODE_STOP, TRUE );
			DoRun( start_line_no, TRUE ); //FALSE );
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// Restart from beginning 
		// ó������ �ٽ� ���� 
	case 24000:
		SET_ERROR_LINENO( 0 );
		PAMotion->StopStreamMode();
	//	PNCFile->SetWorkLine( 0 );
		PNCFile->ResetWorkLine();
		PPAStatus->SetNCFileMachiningLine( 0, TRUE );
		PPAStatus->GetThreadState()->RESET_LAST_USED_TOOL_CHANGED_LINENO();
		step = 24010;
		break;
	case 24010:
		PPAStatus->SetNCFileState( NCFILE_STATE_RUNNING, TRUE );
		// NC ���� ����Ʈ�� ������Ʈ �Ѵ� 
		PPAStatus->GetThreadState()->bUpdateNcFileList_ = TRUE;
		step = 24020;
		break;
	case 24020:
		PAMotion->StartStreamMode();
		step = 900;	// 900 ���ο��� StartRotaryBuffer() �Լ��� ȣ���Ѵ�
		break;

		//////////////////////////////////////////////////////////////////////////
		// Start from next nc-file
		// ���� �۾��� ERROR�� �����, �ҷ��� ���µ� ERROR�� ����� 
		// ���� NC ���� ���� ���� �Ѵ� 
	case 25000:
		if( PAutoLoader->IsUsingAutoLoader() && bIsNeedBlockLoading_ ) 
		{
			PAutoLoader->SetBlockState( PAutoLoader->GetWorkIndex(), BLOCK_STATE_ERROR );
		}
		{
			int nStartLineNo = PPAStatus->GetThreadState()->SEARCH_LAST_USED_TOOL_LINENO( PPAStatus->GetThreadState()->nCurrentNCCodeStepNo );
			PPAStatus->GetThreadState()->nStartingNCCodeStepNo	= nStartLineNo - 1;
			PPAStatus->GetThreadState()->nCurrentNCCodeStepNo	= nStartLineNo - 1;
			PPAStatus->GetThreadState()->nNumberOfPreparingStep = 0;
			nStartLineNo_ = nStartLineNo;
		}
		PPAStatus->SetNCFileState( NCFILE_STATE_ERROR, TRUE );
		// NC ���� ����Ʈ�� ������Ʈ �Ѵ� 
		PPAStatus->GetThreadState()->bUpdateNcFileList_ = TRUE;
		step = 25010;
		break;
		// ���� �۾��� ���� �ϰ�, ���� �۾����� �ٽ� �����ϵ��� �Ѵ� 
		// 2016.09.27. Start...()�ϸ� -750 ���� (Thread �����)
		//	StopStreamMode()�� ���� �ؼ� �׽�Ʈ �Ѵ� 
	case 25010:
	//	PAMotion->StartStreamMode();
		PAMotion->StopStreamMode();
		step = 5000;
		break;
	}
}

//////////////////////////////////////////////////////////////////////////
// Block�� ���� ���, 
//	TRUE�� ���� �ϰ� 
//	PBlockLoaderState->GetWorkIndex()�� -1�� �����ȴ� 
BOOL pa::CPThread::doItemLoading( BOOL bResetStep )
{
	static int step = 0;
	static int toDoItemNumber;

	step = bResetStep ? 100 : step;

	switch( step ) 
	{
	case 100:
		PAMotion->PAUSE_MCODE_THREAD();
		toDoItemNumber = PAutoLoader->GetToDoItemNumber();
		GetItem( TRUE, toDoItemNumber );
		step = 101;
		break;
	case 101:
		if ( GetItem( FALSE, toDoItemNumber ) ) {
			PAMotion->RESUME_MCODE_THREAD();
			step = 99999;
		}
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::doAutoloaderRescan( BOOL bResetStep )
{
	static int step = 0;
	static int scanIndex = 0;

	step = bResetStep ? 1 : step;

	switch( step )
	{
	case 1: step = 100; break;
	case 100:
		scanIndex = 0;
		PAutoLoader->RefreshBlockStateStruct();
		step = 110;
		break;

		// 1->20 ������, ���� ���� Ȯ�� 
	case 110:
		PAMotion->AL_MoveBlockSensingPosition_M753( FALSE, scanIndex );
		step = 120;
		break;
		MOVE_DNE_Mxxx( step, 120, 130, CPAAsyncComm::CMD_M753 )
	case 130:
		PAutoLoader->RecordSlotExistance( scanIndex );	// ���� ��/���� ����Ѵ� 
		step = 140;
		break;
	case 140:
		scanIndex += 1;
		if( scanIndex < PAutoLoader->GetNumBlock() ) {
			step = 110;
		} else {
			step = 200;
		}
		break;

		// 20->1 ������, ���ڵ� Ȯ�� 
	case 200:
		step = (PAutoLoader->IsThereSlotData() == TRUE) ? 210 : 400;
		break;
	case 210:
		scanIndex -= 1;
		step = ( PAutoLoader->GetBlockState(scanIndex) == BLOCK_STATE_BEFORE ) ? 220 : 300; 
		break;
	case 220:
		PAMotion->AL_MoveDiskBarcodeReadingPosition_M754( FALSE, scanIndex );
		step = 230;
		break;
		MOVE_DNE_Mxxx( step, 230, 240, CPAAsyncComm::CMD_M754 )
	case 240:
		PAutoLoader->RecordSlotData( scanIndex );
		step = 300;
		break;
	case 300:
		step = ( scanIndex <= 0 ) ? 310 : 210;
		break;
	case 310:
		if (PAutoLoader->IsThereDuplicateItemNumber()) {
			throw CPException( ERR_PNC, PNC_ERR_AL_DUPLICATE_ITEM_DETECTED, _T("Duplicate barcode item detected. Please remove the duplicate item and rescan.") );
		}
		step = 400;
		break;

		//////////////////////////////////////////////////////////////////////////
	case 400:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::doAutoloaderExistanceScan( BOOL bResetStep )
{
	static int step = 0;
	static int scanIndex = 0;

	step = bResetStep ? 1 : step;

	switch( step )
	{
	case 1: step = 100; break;
	case 100:
		scanIndex = 0;
		PAutoLoader->RefreshBlockStateStruct();
		step = 110;
		break;

		// 1->20 ������, ���� ���� Ȯ�� 
	case 110:
		PAMotion->AL_MoveBlockSensingPosition_M753( FALSE, scanIndex );
		step = 120;
		break;
		MOVE_DNE_Mxxx( step, 120, 130, CPAAsyncComm::CMD_M753 )
	case 130:
		PAutoLoader->RecordSlotExistance( scanIndex );	// ���� ��/���� ����Ѵ� 
		step = 140;
		break;
	case 140:
		scanIndex += 1;
		if( scanIndex < PAutoLoader->GetNumBlock() ) {
			step = 110;
		} else {
			step = 99999;
		}
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::doAutoloaderBarcodeScan( BOOL bResetStep )
{
	static int step = 0;
	static int scanIndex = 0;

	step = bResetStep ? 1 : step;

	switch( step )
	{
	case 1: step = 100; break;
	case 100:
		scanIndex = PAutoLoader->GetNumBlock();
		PAutoLoader->ResetBlockNumbers();
		step = 101;
		break;

	case 101:
		scanIndex -= 1;
		step = ( PAutoLoader->GetBlockState(scanIndex) == BLOCK_STATE_BEFORE ) ? 102 : 200; 
		break;

	case 102:
		PAMotion->AL_MoveDiskBarcodeReadingPosition_M754( FALSE, scanIndex );
		step = 103;
		break;
	MOVE_DNE_Mxxx( step, 103, 104, CPAAsyncComm::CMD_M754 )

	case 104:
		PAutoLoader->RecordSlotData( scanIndex );
		step = 200;
		break;

	case 200:
		step = ( scanIndex <= 0 ) ? 99999 : 101;
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

// �۾��� ���� ������ ���� ���´� 
BOOL pa::CPThread::doItemUnloading( BOOL bResetStep )
{
	static int step = 0;
	static int itemNumber = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100:
		if ( !PPAStatus->GetThreadState()->bIsDemoMode_ ) {
			PAMotion->workSpaceClean_787( 1 );
			step = 101;
		} else {
			step = 102;
		}
		break;
	MOVE_DNE_Mxxx( step, 101, 102, CPAAsyncComm::CMD_M787 )

	case 102:
		// PAMotion->PAUSE_MCODE_THREAD();
		itemNumber = PAutoLoader->GetWorkSpaceItemNumber();
		ReturnItem( TRUE );
		step = 103;
		break;

	case 103:
		if ( ReturnItem( FALSE ) ) {
			step = 104;
		}
		break;

	case 104:
		// PAMotion->RESUME_MCODE_THREAD();
		// TODO: bottom handle might be helpful but currently not necessary.
		// PAutoLoader->WorkDoneHandler( PAutoLoader->GetSlotIndexFromItemNumber( itemNumber ) );
		step = 99999;
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

//////////////////////////////////////////////////////////////////////////

void pa::CPThread::writeLog_OpPanel( LPCTSTR logMsg )
{
	P_LOG->WriteLog( CLog::TYPE_OPER, 8, logMsg );
}

void pa::CPThread::writeLog_Door( LPCTSTR logMsg )
{
	P_LOG->WriteLog( CLog::TYPE_OPER, 9, logMsg );
}

void pa::CPThread::writeLog_EXT( LPCTSTR logMsg )
{
	P_LOG->WriteLog_EXT( logMsg );
}

void pa::CPThread::writeLog_Error( LPCTSTR type, LPCTSTR message, LPCTSTR solution )
{
	SYSTEMTIME stm;
	CString header;

	GetLocalTime( &stm );
	header.Format(
		_T("[%04d-%02d-%02d %02d:%02d:%02d] Error Raised!"),
		stm.wYear, stm.wMonth, stm.wDay, 
		stm.wHour, stm.wMinute, stm.wSecond );

	P_LOG->WriteLog_PLAIN( header, _T("err") );
	P_LOG->WriteLog_EXT( type, _T("err") );
	P_LOG->WriteLog_EXT( message, _T("err") );
	P_LOG->WriteLog_EXT( solution, _T("err") );
	P_LOG->WriteLog_PLAIN( _T(""), _T("err") );
}

void pa::CPThread::writeLog_ChangeRunMode( LPCTSTR logMsg )
{
	P_LOG->WriteLog( CLog::TYPE_THREAD, 1, logMsg );
}

void pa::CPThread::writeLog_AutoCal( LPCTSTR logMsg, BOOL bExt )
{
	if( !bExt ) {
		P_LOG->WriteLog( CLog::TYPE_OPER, 99, logMsg );
	}
	else {
		P_LOG->WriteLog_EXT( logMsg );
	}	
}

void pa::CPThread::writeLog_UploadData( LPCTSTR logMsg )
{
	P_LOG->WriteLog_EXT( logMsg );
}

//////////////////////////////////////////////////////////////////////////

void pa::CPThread::change_external_button_led( pa::EN_RUNMODE runMode )
{
// 	int	nCurrSpindleAirPurge = 0;

#ifdef _PA_G2400_
	switch( runMode )
	{
	case pa::RUNMODE_INIT:
		PAMotion->IOT( pa::OUT113_RUN_LAMP, 1 );
		PAMotion->IOT( pa::OUT114_STOP_LAMP, 1 );
		PAMotion->IOT( pa::OUT115_ALARM_CLEAR_LAMP, 1 );
		nCurrSpindleAirPurge_ = 1;
		break;

	case pa::RUNMODE_TORUN:
	case pa::RUNMODE_RUN:
	case pa::RUNMODE_PAUSE:
	case pa::RUNMODE_TOSTOP:
		PAMotion->IOT( pa::OUT113_RUN_LAMP, 1 );
		PAMotion->IOT( pa::OUT114_STOP_LAMP, 0 );
		PAMotion->IOT( pa::OUT115_ALARM_CLEAR_LAMP, 0 );
		nCurrSpindleAirPurge_ = 1;
		break;

	case pa::RUNMODE_STOP:
		PAMotion->IOT( pa::OUT113_RUN_LAMP, 0 );
		PAMotion->IOT( pa::OUT114_STOP_LAMP, 1 );
		PAMotion->IOT( pa::OUT115_ALARM_CLEAR_LAMP, 0 );
		nCurrSpindleAirPurge_ = 0;
		break;

	case pa::RUNMODE_ERROR:
		PAMotion->IOT( pa::OUT113_RUN_LAMP, 0 );
		PAMotion->IOT( pa::OUT114_STOP_LAMP, 0 );
		PAMotion->IOT( pa::OUT115_ALARM_CLEAR_LAMP, 1 );
		nCurrSpindleAirPurge_ = 0;
		break;
	}
#endif 
#ifdef _PA_G1600_
	switch( runMode )
	{
	case pa::RUNMODE_INIT:
		PAMotion->IOT( pa::OUT20040_LampGreen, 1 );
		PAMotion->IOT( pa::OUT20041_LampBlue, 1 );
		PAMotion->IOT( pa::OUT20042_LampRed, 1 );
// 		nCurrSpindleAirPurge_ = 1;
// 		PREV_SPINDLE_AIR_PURGE_ = -1;
		break;

	case pa::RUNMODE_TORUN:
	case pa::RUNMODE_RUN:
	case pa::RUNMODE_PAUSE:
	case pa::RUNMODE_TOSTOP:
		PAMotion->IOT( pa::OUT20040_LampGreen, 1 );
		PAMotion->IOT( pa::OUT20041_LampBlue, 0 );
		PAMotion->IOT( pa::OUT20042_LampRed, 0 );
// 		nCurrSpindleAirPurge_ = 1;
// 		PREV_SPINDLE_AIR_PURGE_ = -1;
		break;

	case pa::RUNMODE_STOP:
		PAMotion->IOT( pa::OUT20040_LampGreen, 0 );
		PAMotion->IOT( pa::OUT20041_LampBlue, 1 );
		PAMotion->IOT( pa::OUT20042_LampRed, 0 );
// 		nCurrSpindleAirPurge_ = 0;
// 		dwSpindleAirPurgeOffTime_ = GetTickCount() + ( 3 * 1000 );	// �ð��� �Ѿ�� �ٷ� ���� �� �ִ� 24�� ���� �ѹ���...)
// 		PREV_SPINDLE_AIR_PURGE_ = -1;
		break;

	case pa::RUNMODE_ERROR:
		PAMotion->IOT( pa::OUT20040_LampGreen, 0 );
		PAMotion->IOT( pa::OUT20041_LampBlue, 0 );
		PAMotion->IOT( pa::OUT20042_LampRed, 1 );
// 		nCurrSpindleAirPurge_ = 0;									// ERROR ��忡���� Purge Air�� ���� 
// 		dwSpindleAirPurgeOffTime_ = GetTickCount() + ( 3 * 1000 );	// 
// 		PREV_SPINDLE_AIR_PURGE_ = -1;
		break;
	}

	//////////////////////////////////////////////////////////////////////////
// 	if( pa::PConfig->pConfig_->bUsingSpindleAirPurge == FALSE )
// 	{
// 		// Spindle Air Purge�� �ڵ����� ���� ��尡 �ƴ϶��, 
// 		// ��� �ѳ��´� 
// 		nCurrSpindleAirPurge_ = 1;
// 		dwSpindleAirPurgeOffTime_ = 0;
// 		PREV_SPINDLE_AIR_PURGE_ = -1;
// 	}
	//////////////////////////////////////////////////////////////////////////

#endif

// 	//////////////////////////////////////////////////////////////////////////
// 	// ��忡 ���� spindle air purge ���� 
// 	nCurrSpindleAirPurge = pa::PConfig->pConfig_->bUsingSpindleAirPurge ? nCurrSpindleAirPurge : 1;
// 
// 	if( PREV_SPINDLE_AIR_PURGE_ != nCurrSpindleAirPurge )
// 	{
// 		PREV_SPINDLE_AIR_PURGE_ = nCurrSpindleAirPurge;
// 		
// 		if( PREV_SPINDLE_AIR_PURGE_ == 0 )
// 		{
// 			TRACE( _T("Spindle Air Purge -> OFF\n") );
// #ifdef _PA_G2400_
// 			PAMotion->IOT( pa::OUT110_SPINDLE_AIR_BLOW, 0 );
// #endif 
// #ifdef _PA_G1600_
// // 			PAMotion->IOT( pa::OUT20035_PurgeAirOpen, 0 );
// // 			PAMotion->IOT( pa::OUT20036_PurgeAirClose, 1 );
// 			// 2016.08.01. Air Purge�� �ٷ� ���� �ʰ�, 30�� �Ŀ� ������ �Ѵ� 
// 
// #endif
// 		}
// 		else 
// 		{
// 			TRACE( _T("Spindle Air Purge -> ON\n") );
// #ifdef _PA_G2400_
// 			PAMotion->IOT( pa::OUT110_SPINDLE_AIR_BLOW, 1 );
// #endif 
// #ifdef _PA_G1600_
// 			PAMotion->IOT( pa::OUT20035_PurgeAirOpen, 1 );
// 			PAMotion->IOT( pa::OUT20036_PurgeAirClose, 0 );
// #endif 
// 		}
// 	}
// 	/////////////////////////////////////////////////////////////////////////
}

// void pa::CPThread::checkSpindleAirPurge()
// {
// 	//////////////////////////////////////////////////////////////////////////
// 	// STOP ��忡���� ���� 
// 	// ERROR ��忡���� ���� (2016.08.01)
// 	if( PPAStatus->GetRunMode() == pa::RUNMODE_STOP || PPAStatus->GetRunMode() == pa::RUNMODE_ERROR )
// 	{
// 		int nCurrSpindleAirPurge = 0;
// 
// 		nCurrSpindleAirPurge = pa::PConfig->pConfig_->bUsingSpindleAirPurge ? nCurrSpindleAirPurge : 1;
// 
// 		if( PREV_SPINDLE_AIR_PURGE_ != nCurrSpindleAirPurge )
// 		{
// 			PREV_SPINDLE_AIR_PURGE_ = nCurrSpindleAirPurge;
// 
// 			if( PREV_SPINDLE_AIR_PURGE_ == 0 )
// 			{
// 				TRACE( _T("Spindle Air Purge -> OFF\n") );
// #ifdef _PA_G2400_
// 				PAMotion->IOT( pa::OUT110_SPINDLE_AIR_BLOW, 0 );
// #endif 
// #ifdef _PA_G1600_
// 				PAMotion->IOT( pa::OUT20035_PurgeAirOpen,  0 );
// 				PAMotion->IOT( pa::OUT20036_PurgeAirClose, 1 );
// #endif 
// 			}
// 			else 
// 			{
// 				TRACE( _T("Spindle Air Purge -> ON\n") );
// #ifdef _PA_G2400_
// 				PAMotion->IOT( pa::OUT110_SPINDLE_AIR_BLOW, 1 );
// #endif 
// #ifdef _PA_G1600_
// 				PAMotion->IOT( pa::OUT20035_PurgeAirOpen,  1 );
// 				PAMotion->IOT( pa::OUT20036_PurgeAirClose, 0 );
// #endif 
// 			}
// 		}
// 	}
// 	/////////////////////////////////////////////////////////////////////////
// }

// Stop/Error ��忡�� �����ð��� ������, Air Purge�� �������� ���� 
void pa::CPThread::checkSpindleAirPurge()
{
	static pa::EN_RUNMODE hPREV_RUNMODE = pa::RUNMODE_NUM;
	static int nPREV_IS_SHOW_USER_CONFIRM_DLG = -1;
	static int nPREV_LEFT_SPINDLE_RUN = -1;		// spindle stop:0 run:1
	static int nPREV_RIGHT_SPINDLE_RUN = -1;
	static int nPREV_M28 = -1;				// water pump/vacuum ���� off:0 on:1
	static int nPREV_AUTO_AIR_PURGE = 0;	// 0���� �ʱ�ȭ 
	int d18 = 10;	// SW Config���� ����
	// 	int d18 = 3;	// 3�� => �׽�Ʈ������ �ð��� 3������ �ٿ���  

	//////////////////////////////////////////////////////////////////////////
	// 
	if( pa::PConfig->pConfig_->bUsingSpindleAirPurge == FALSE )
	{
		// Spindle Air Purge�� �ڵ����� ���� ��尡 �ƴ϶��, 
		// ��� �ѳ��´� 
		// air purge on
		if( nPREV_AUTO_AIR_PURGE != 1 )
		{
			nPREV_AUTO_AIR_PURGE = 1;
			PREV_SPINDLE_AIR_PURGE_ = nCurrSpindleAirPurge_;
			tmSpindleAirPurgeOffTime_ = 0;
			// 			PAMotion->IOT( pa::OUT20035_PurgeAirOpen,  1 );
			// 			PAMotion->IOT( pa::OUT20036_PurgeAirClose, 0 );
			// 			TRACE( _T("===>>> AIR PURGE ON \n") );
			// 			Sleep( 250 );
			// 			PAMotion->IOT( pa::OUT20035_PurgeAirOpen,  0 );

			TRACE( _T("===>>> AIR PURGE ON \n") );
			PAMotion->SendMotionCommand(pa::CPAAsyncComm::CMD_M131, TRUE);
		}
		hPREV_RUNMODE = pa::RUNMODE_NUM;
		return ;
	}
	else 
	{
		nPREV_AUTO_AIR_PURGE = 0;

		if( hPREV_RUNMODE != pa::PPAStatus->GetRunMode() )
		{
			hPREV_RUNMODE = pa::PPAStatus->GetRunMode();

			switch( pa::PPAStatus->GetRunMode() )
			{
			case pa::RUNMODE_INIT:
				nCurrSpindleAirPurge_ = 1;
				tmSpindleAirPurgeOffTime_ = 0;
				PREV_SPINDLE_AIR_PURGE_ = -1;
				break;
			case pa::RUNMODE_TORUN:
			case pa::RUNMODE_RUN:
			case pa::RUNMODE_PAUSE:
			case pa::RUNMODE_TOSTOP:
				nCurrSpindleAirPurge_ = 1;
				tmSpindleAirPurgeOffTime_ = 0;
				PREV_SPINDLE_AIR_PURGE_ = -1;
				break;
			case pa::RUNMODE_STOP:
				nCurrSpindleAirPurge_ = 0;
				tmSpindleAirPurgeOffTime_ = CTime::GetCurrentTime() + CTimeSpan(0, 0, d18, 0);	// 30�� 
				PREV_SPINDLE_AIR_PURGE_ = -1;
				break;
			case pa::RUNMODE_ERROR:
				nCurrSpindleAirPurge_ = 0;									// ERROR ��忡���� Purge Air�� ���� 
				tmSpindleAirPurgeOffTime_ = CTime::GetCurrentTime() + CTimeSpan(0, 0, d18, 0);	// 30��
				PREV_SPINDLE_AIR_PURGE_ = -1;
				break;
			}
		}

		// 2016.10.07. UserConfirm ���̾�αװ� ���� ��쵵 Purge air�� ���ߵ��� ���� 
		if( nPREV_IS_SHOW_USER_CONFIRM_DLG != CUserConfirmDlg::IS_SHOW_DLG() )
		{
			nPREV_IS_SHOW_USER_CONFIRM_DLG = CUserConfirmDlg::IS_SHOW_DLG();
			if( nPREV_IS_SHOW_USER_CONFIRM_DLG != 0 )
			{
				nCurrSpindleAirPurge_ = 0;
				tmSpindleAirPurgeOffTime_ = CTime::GetCurrentTime() + CTimeSpan(0, 0, d18, 0);	// 30�� 
				PREV_SPINDLE_AIR_PURGE_ = -1;
				TRACE( _T("AIR PURGE OFF becase SHOW USER_CONFIRM_DLG\n") );
			}
			else 
			{
			}
		}

		//////////////////////////////////////////////////////////////////////////
		// 2016.12.24. spindle run/stop ���¿� m28/m29 ���� �ݿ� 
		// �׽�Ʈ �غ��� �� ���� ������ �Ƚ� 
		{
			pa::EN_RUNMODE run_mode = pa::PPAStatus->GetRunMode();
			if(  run_mode == pa::RUNMODE_STOP || run_mode == pa::RUNMODE_ERROR )
			{
				int curr_left_spindle_run = pa::PPAStatus->GetPAStatus()->nSpindleRun;
				int curr_right_spindle_run = pa::PPAStatus->GetPAStatus()->nSpindle2Run;
				int curr_m28 = ( pa::PPAStatus->GetPAStatus()->bOutput[pa::OUT20037_WaterVacuumPumpOnSignal] ) ? 1 : 0;

				if( (nPREV_LEFT_SPINDLE_RUN != curr_left_spindle_run) || (nPREV_RIGHT_SPINDLE_RUN != curr_right_spindle_run) || (nPREV_M28 != curr_m28) )
				{
					nPREV_LEFT_SPINDLE_RUN = curr_left_spindle_run;
					nPREV_RIGHT_SPINDLE_RUN = curr_right_spindle_run;
					nPREV_M28 = curr_m28;

					if( curr_left_spindle_run == 1 || curr_right_spindle_run == 1 || curr_m28 == 1 )
					{
						// spindle run 
						nCurrSpindleAirPurge_ = 1;
						tmSpindleAirPurgeOffTime_ = 0;
						PREV_SPINDLE_AIR_PURGE_ = -1;
					}
					else 
					{
						// spindle stop 
						nCurrSpindleAirPurge_ = 0;									// ERROR ��忡���� Purge Air�� ���� 
						tmSpindleAirPurgeOffTime_ = CTime::GetCurrentTime() + CTimeSpan(0, 0, d18, 0);	//30�� 
						PREV_SPINDLE_AIR_PURGE_ = -1;
					}
				}
			}
		}
		//////////////////////////////////////////////////////////////////////////
	}

	//////////////////////////////////////////////////////////////////////////
	//
	if( PREV_SPINDLE_AIR_PURGE_ != nCurrSpindleAirPurge_ )
	{
		if( nCurrSpindleAirPurge_ == 1 )
		{
			// air purge on
			PREV_SPINDLE_AIR_PURGE_ = nCurrSpindleAirPurge_;
			tmSpindleAirPurgeOffTime_ = 0;

			TRACE( _T("===>>> AIR PURGE ON \n") );
			PAMotion->SendMotionCommand(pa::CPAAsyncComm::CMD_M131, TRUE);
		}
		else if( nCurrSpindleAirPurge_ == 0 && tmSpindleAirPurgeOffTime_ != 0 )
		{
			// air purge off 
			CTime curr_time = CTime::GetCurrentTime();
			if( curr_time > tmSpindleAirPurgeOffTime_ )
			{
				PREV_SPINDLE_AIR_PURGE_	= nCurrSpindleAirPurge_;
				tmSpindleAirPurgeOffTime_ = 0;

				TRACE( _T("===>>> AIR PURGE OFF \n") );
				PAMotion->SendMotionCommand(pa::CPAAsyncComm::CMD_M132, TRUE);
			}
		}
	}
}

//////////////////////////////////////////////////////////////////////////
// step : 50000 ~ 52000 ���� ��� 
//////////////////////////////////////////////////////////////////////////

#include "AutoCalDlg.h"

void pa::CPThread::doAutoCal_CoordinateOffset()
{
	static int TOOL_NO = 0;
	static int TOOL2_NO = 0;
	int&	step = nStep_[RUNMODE_RUN];

	switch( step )
	{
	case 50000:
		TOOL_NO = 0;
		TOOL2_NO = 0;
		pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 0;
		pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable2 = 0;
		step = 50010; 
		break;

		//////////////////////////////////////////////////////////////////////////
		// ������ ���� ��´�
	case 50010:
		// Get left tool
		TOOL_NO = (int)( pa::PPAStatus->GetAutoCalCoordinateOffsetParam()->fParam[SAutoCalCoordinateOffsetParam::PARAM_TOOL_NUMBER_LEFT] );
		step = ( TOOL_NO == pa::PPAStatus->GetPAStatus()->nCurrentToolNo ) ? 50020 : 50011;
		break;

	case 50011:
		doAutoCal_Prepare( TRUE, TOOL_NO );
		step = 50012;
		break;

	case 50012:
		if( doAutoCal_Prepare( FALSE, TOOL_NO ) == TRUE ) {
			step = 50030;
		}
		break;

	case 50020:
		// If tool number is same, but tool length is not updated yet 
		if( pa::PPAStatus->GetPAStatus()->nToolLengthUpdateFlag == 0 ) {
			step = 50022;
		} else {
			step = 50030;
		}
		break;
		SEND_CMD_MDA( step, 50022, 50024, "M207" ) 
		MOVE_DNE_MDA( step, 50024, 50030 )

	case 50030:
		// Get right tool
		TOOL2_NO = (int)( pa::PPAStatus->GetAutoCalCoordinateOffsetParam()->fParam[SAutoCalCoordinateOffsetParam::PARAM_TOOL_NUMBER_RIGHT] );
		step = ( TOOL2_NO == pa::PPAStatus->GetPAStatus()->nCurrentTool2No ) ? 50040 : 50031;
		break;

	case 50031:
		doAutoCal_Prepare( TRUE, TOOL2_NO );
		step = 50032;
		break;
	case 50032:
		if( doAutoCal_Prepare( FALSE, TOOL2_NO ) == TRUE ){
			step = 50050;
		}
		break;

	case 50040:
		// If tool number is same, but tool length is not updated yet
		if( pa::PPAStatus->GetPAStatus()->nTool2LengthUpdateFlag == 0 ) {
			step = 50042;
		} else {
			step = 50050;
		}
		break;
		SEND_CMD_MDA( step, 50042, 50044, "M208" ) 
		MOVE_DNE_MDA( step, 50044, 50050 )

		// XYZAB �ʱ� ��ġ�� �̵� �Ѵ� 
	case 50050:
		doAutlCal_MoveReadyPos( TRUE );
		step = 50060;
		break;
	case 50060:
		if( doAutlCal_MoveReadyPos( FALSE ) == TRUE ) {
			step = 50070;
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// ���̺� ���� �޽��� �ڽ��� ����. ��޷� ����� ���...Ȯ�� ! 
		//////////////////////////////////////////////////////////////////////////
	case 50070:
		step = 50071;
		break;
// 		{
// 			CAutoCalDlg::SHOW_DLG();
// 			int sel = CAutoCalDlg::WAIT_FOR_SELECT();
// 			CAutoCalDlg::HIDE_DLG();
// 			if( sel == IDOK ) {
// 				pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 1;
// 				pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable2 = 1;
// 			}
// 			else {
// 				pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 2;
// 				pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable2 = 2;
// 			}
// 		}
// 		step = 50080;
// 		break;

	case 50071:
		CAutoCalDlg::SHOW_DLG();
		step = 50072;
		break;
	case 50072:
		{
			int sel = CAutoCalDlg::WAIT_FOR_SELECT2();
			if (sel == -1) break;
			else {
				if (sel == IDOK) {
					pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 1;
					pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable2 = 1;
				}
				else {
					pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 2;
					pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable2 = 2;
				}
				CAutoCalDlg::HIDE_DLG();
				step = 50073;
			}
		}
		break;
	case 50073:
		step = 50080;
		break;

		//////////////////////////////////////////////////////////////////////////
		// ���� ���̺� ������ ��� ���� 
	case 50080:
		if( pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable != 0 && pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable2 != 0 ) {
			if( pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable == 1 && pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable2 == 1) {
				step = 50200;	// �۾� ����  
			} else {
				step = 0;		// �۾� ��� 
				changeRunMode( RUNMODE_STOP, TRUE );
			}
		}
		break;

// 		//////////////////////////////////////////////////////////////////////////
// 		// ���� ����
// 		// 1. Dummy
// 	case 50100:
// 		if( pa::PPAStatus->GetThreadState()->nAutoCal_CheckingItem[0] != 0 ) {
// 			//doAutoCal_Dummy( TRUE );
// 			step = 50110;
// 		} else {
// 			step = 50200;
// 		}
// 		break;
// 	case 50110:
// 		//if( doAutoCal_Dummy( FALSE ) == TRUE ) {
// 			step = 50200;
// 			pa::PPAStatus->GetThreadState()->nAutoCal_CheckingItem[0] = 0;		// �۾��� ��������, 0���� ����
// 		//}
// 		break;

		// 2. X�� Center 
	case 50200:
		if( pa::PPAStatus->GetThreadState()->nAutoCal_CheckingItem[1] == 0 ) {
			doAutoCal_X( TRUE );
			step = 50210;
		} else {
			step = 50300;
		}
		break;
	case 50210:
		if( doAutoCal_X( FALSE ) == TRUE ) {
			step = 50300;
			pa::PPAStatus->GetThreadState()->nAutoCal_CheckingItem[1] = 1;		// �۾��� ��������, 1�� ����			
		}
		break;

		// 3. Y1�� Center 
	case 50300:
		if( pa::PPAStatus->GetThreadState()->nAutoCal_CheckingItem[2] == 0 ) {
			doAutoCal_Y1( TRUE );
			step = 50310;
		} else {
			step = 50400;
		}
		break;
	case 50310:
		if( doAutoCal_Y1( FALSE ) == TRUE ) {
			step = 50400;
			pa::PPAStatus->GetThreadState()->nAutoCal_CheckingItem[2] = 1;		// �۾��� ��������, 1�� ����
		}
		break;

		// 4. Y2�� ���� 
	case 50400:
		if( pa::PPAStatus->GetThreadState()->nAutoCal_CheckingItem[3] == 0 ) {
			doAutoCal_Y2( TRUE );
			step = 50410;
		} else {
			step = 50500;
		}
		break;
	case 50410:
		if( doAutoCal_Y2( FALSE ) == TRUE ) {
			step = 50500;
			pa::PPAStatus->GetThreadState()->nAutoCal_CheckingItem[3] = 1;		// �۾��� ��������, 1�� ����
		}
		break;

		// 5. Z1 Origin offset 
	case 50500:
		if( pa::PPAStatus->GetThreadState()->nAutoCal_CheckingItem[4] == 0 ) {
			doAutoCal_Z1( TRUE );
			step = 50510;
		} else {
			step = 50600;
		}
		break;
	case 50510:
		if( doAutoCal_Z1( FALSE ) == TRUE ) {
			step = 50600;
			pa::PPAStatus->GetThreadState()->nAutoCal_CheckingItem[4] = 1;		// �۾��� ��������, 1�� ����
		}
		break;

		// 6. Z2 Origin Offset 
	case 50600:
		if( pa::PPAStatus->GetThreadState()->nAutoCal_CheckingItem[5] == 0 ) {
			doAutoCal_Z2( TRUE );
			step = 50610;
		} else {
			step = 50700;
		}
		break;
	case 50610:
		if( doAutoCal_Z2( FALSE ) == TRUE ) {
			step = 50800;
			pa::PPAStatus->GetThreadState()->nAutoCal_CheckingItem[5] = 1;		// �۾��� ��������, 1�� ����
		}
		break;

	case 50800:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z%.3f A%.3f B%.3f",
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X],
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y],
			0.0,
			PPAStatus->GetPAStatus()->fPosition[pa::AXIS_A],
			0.0 );
		step = 50810;
		break;

		SEND_CMD_MDA(step, 50810, 50820, szCommandBuffer_)
		MOVE_DNE_MDA(step, 50820, 50830)
		
	case 50830:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z%.3f A%.3f B%.3f",
			PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_READYPOS][pa::AXIS_X],
			PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_READYPOS][pa::AXIS_Y],
			0.0,
			PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_READYPOS][pa::AXIS_A],
			0.0);
		step = 50840;
		break;

		SEND_CMD_MDA(step, 50840, 50850, szCommandBuffer_)
		MOVE_DNE_MDA(step, 50850, 50860)

		// ���� 
	case 50860:
		changeRunMode( RUNMODE_STOP, TRUE );
		step = 0;
		break;
	}
}

// ���� ��� ��� 
BOOL pa::CPThread::doAutoCal_Prepare( BOOL bResetStep, int tool_no )
{
	static int	step;

	step = bResetStep ? 1 : step;

	switch( step )
	{
	case 0: break;
	case 1:
		sprintf_s( szCommandBuffer_, 256, "M%d", 140 + tool_no - 1 );
		step = 10;
		break;

		SEND_CMD_MDA( step, 10, 20, szCommandBuffer_ );
		MOVE_DNE_MDA( step, 20, 30 )

	case 30:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

// 
BOOL pa::CPThread::doAutoCal_Dummy( BOOL bResetStep )
{
 	static int step = 0;
// 	pa::SAutoCalCoordinateOffsetParam* pSCCOP = pa::PPAStatus->GetAutoCalCoordinateOffsetParam();
// 	double	fVal[100];
// 	CString strLog;
// 
// 	step = bResetStep ? 1 : step;
// 
// 	switch( step )
// 	{
// 	case 0: break;
// 	case 1:
// 		writeLog_AutoCal( _T("start measure. dummy"), FALSE );
// 		step = 10;
// 		break;
// 
// 		// Z-UP, A0, B0
// 		SEND_CMD_MDA( step, 10, 20, "G00 G90 G53 Z0 A0 B0" )
// 		MOVE_DNE_MDA( step, 20, 100 )
// 
// 	case 100:
// 		// X, Y���� ���� ��ġ�� �̵� 
// 		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f", 
// 			pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_DUMMY_POS_X],
// 			pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_DUMMY_POS_Y] );
// 		step = 110;
// 		break;
// 		SEND_CMD_MDA( step, 110, 120, szCommandBuffer_ )
// 		MOVE_DNE_MDA( step, 120, 130 )
// 
// 		// A, B���� ���� ��ġ�� �̵� 
// 		SEND_CMD_MDA( step, 130, 140, "G00 G90 G54 A0 B0" )
// 		MOVE_DNE_MDA( step, 140, 150 )
// 
// 	case 150:
// 		// Z���� ���� ��ġ�� �̵� 
// 		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_MEASURE_POS_Z_AB0] );
// 		step = 160;
// 		break;
// 		SEND_CMD_MDA( step, 160, 170, szCommandBuffer_ )
// 		MOVE_DNE_MDA( step, 170, 180 )
// 
// 	case 180:
// 		// ���� 
// 		PAMotion->DO_MEASURE( FALSE, 
// 			pa::AXIS_Z,
// 			-0.01, 0.001, 
//  			(int)(pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_MOVESPEED_FOR_MEAS_POS]), 
// 			(int)(pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_MEASURE_COUNT]), 
// 			(pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_ZAXIS_1ST_MAX_DISTANCE])*-1.0,
// 			(pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_ZAXIS_2ST_MEASURE_OFFSET]) );
// 		Sleep( 300 );
// 		step = 190;
// 		break;
// 	case 190:
// 		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
// 			step = 200;
// 		}
// 		break;
// 			
// 	case 200:
// 		// ���� ��� 
// 		PAMotion->GET_MEASURE_RESULT();
// 		fVal[0] = TO_G54( pa::AXIS_Z, CPAAsyncComm::F_TEMP_MEASURE_RESULT );
// 		strLog.Format( _T("result : %.5f"), fVal[0] );
// 		writeLog_AutoCal( strLog, TRUE );
// 		step = 210;
// 
// 		// Z�� Up
// 		SEND_CMD_MDA( step, 210, 220, "G00 G90 G53 Z0" )
// 		MOVE_DNE_MDA( step, 220, 230 )
// 		
// 	case 230:
// 		writeLog_AutoCal( _T("stop measure. dummy"), FALSE );
// 		step = 0;
// 		break;
// 	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::doAutoCal_X( BOOL bResetStep )
{
	static int step = 0;
	static int measure_count = 0;
	static double fResult[2];
	static double X_AXIS_OFFSET;
	static double SPINDLE_OFFSET;
	pa::SAutoCalCoordinateOffsetParam* pSCCOP = pa::PPAStatus->GetAutoCalCoordinateOffsetParam();
	CString strLog;

	step = ( bResetStep ) ? 1 : step;

	switch( step )
	{
	case 0: break;
	case 1:
		strLog.Format( _T("start measure. x-axis") );
		writeLog_AutoCal( strLog, FALSE );
		measure_count = 1;
		step = 10;
		break;

	case 10:
		fResult[0] = fResult[1] = X_AXIS_OFFSET = SPINDLE_OFFSET = 0.0;
		for( int i = 0; i<pa::COORD_NUM; i++ )
		{
			pa::PAMotion->RCFG( (pa::EN_COORDINATE)i );
			Sleep(10);
		}
		step = 20;
		break;

		SEND_CMD_MDA( step, 20, 30, "G00 G90 G53 Z0 B0" )
		MOVE_DNE_MDA( step, 30, 100)

	case 100:
		// X��, Y2�� ���� �̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f A%.3f",pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_X2POS_FOR_XAXIS_MEAS], pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_Y2POS_FOR_XAXIS_MEAS] );
		step = 110;
		break;

		SEND_CMD_MDA( step, 110, 120, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 120, 130 )

	case 130:
		// Z2�� ���� �̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 B%.3f", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_Z2POS_FOR_XAXIS_MEAS] );
		step = 140;
		break;

		SEND_CMD_MDA( step, 140, 150, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 150, 160 )

	case 160:
		// ����. x���� ���� �ö���� �������� ���� (-����)
		// bychul2. X�� �̵����� ���� 
		PAMotion->SCAL( FALSE, 
			pa::AXIS_X,
			2,
			//-0.01, 0.001,	
			0.01, -0.001,	
			100,
			(int)(pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_MEASURE_COUNT]),
			20,
			// 0.4, 
			-0.4);
		Sleep( 300 );
		step = 170;
		break;

	case 170:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 180;
		}
		break;

	case 180:
		// ���� ��� ����
		PAMotion->GET_MEASURE_RESULT();
		fResult[0] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		strLog.Format( _T("result : %.5f"), fResult[0] );
		writeLog_AutoCal( strLog, TRUE );
		if( fabs( fResult[0] ) < 0.001 ) {
			step = 100;		// �ٽ� ���� (���� ����)
		} else {
			step = 190;
		}
		break;

		// Z2 Up
		SEND_CMD_MDA( step, 190, 200, "G00 G90 G53 B0" )
		MOVE_DNE_MDA( step, 200, 210 )

		// X Down
		SEND_CMD_MDA( step, 210, 220, "G00 G90 G53 X0" )
		//SEND_CMD_MDA( step, 210, 220, "G00 G90 G53 X-25" )
		MOVE_DNE_MDA( step, 220, 230 )
	
		// ���� ���ɵ� ����
	case 230:
		// X��, Y1�� ���� �̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_X1POS_FOR_XAXIS_MEAS], pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_Y1POS_FOR_XAXIS_MEAS] );
		step = 240;
		break;

		SEND_CMD_MDA( step, 240, 250, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 250, 260 )


	case 260:
		// Z1�� ���� �̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_Z1POS_FOR_XAXIS_MEAS] );
		step = 270;
		break;

		SEND_CMD_MDA( step, 270, 280, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 280, 290 )

	case 290:
		// ����
		// bychul2. X�� ���� ���� ���� 
		PAMotion->SCAL( FALSE,
			pa::AXIS_X,
			1,
			//-0.01, 0.001,
			0.01, -0.001,
			100,
			(int)(pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_MEASURE_COUNT]),
			20,
			//0.4
			-0.4);
		Sleep( 300 );
		step = 300;
		break;

	case 300:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 310;
		}
		break;

	case 310:
		// ���� ��� ����
		PAMotion->GET_MEASURE_RESULT();
		fResult[1] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		strLog.Format( _T("result : %.5f"), fResult[1] );
		writeLog_AutoCal( strLog, TRUE );
		if( fabs( fResult[1] ) < 0.001 ) {
			step = 230;
		} else {
			step = 320;
		}
		break;

		// Z1 Up
		SEND_CMD_MDA( step, 320, 330, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 330, 340 )

		// X Down
		SEND_CMD_MDA( step, 340, 350, "G00 G90 G53 X0" )
		//SEND_CMD_MDA( step, 340, 350, "G00 G90 G53 X-25" )
		MOVE_DNE_MDA( step, 350, 360 )

	case 360:
		// ���� ����� ����ؼ� X�� ���
		{
			double XCal2 = fResult[0];	// R
			double XCal1 = fResult[1];	// L

			double RTool2 = pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_TOOL_DIAMETER_RIGHT] / 2;
			double RTool1 = pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_TOOL_DIAMETER_LEFT] / 2;

			//X_AXIS_OFFSET = XCal1 - RTool1 + 10;
			//X_AXIS_OFFSET = XCal1 + RTool1 - 10;
			X_AXIS_OFFSET = XCal1 + RTool1;
			//SPINDLE_OFFSET = ( XCal1 - RTool1 ) - ( XCal2 - RTool2 );	// L-R
			SPINDLE_OFFSET = ( XCal2 - RTool2 ) - ( XCal1 - RTool1 );	// R-L

			strLog.Format( _T("X offset : %.5f, spindle offset : %.5f"), X_AXIS_OFFSET, SPINDLE_OFFSET );
			writeLog_AutoCal( strLog, TRUE );

			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G54][AXIS_X] = X_AXIS_OFFSET;
			PAMotion->WCFG( pa::COORD_G54, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G54] );
			PAMotion->WTDATA( "spindleoffset", SPINDLE_OFFSET );

			step = 400;
			break;
		}

	case 400:
		writeLog_AutoCal( _T("stop measure"), FALSE );
		step = 500;
		break;

		SEND_CMD_MDA( step, 500, 510, "G00 G90 G53 Z0 B0" )
		MOVE_DNE_MDA( step, 510, 520 )

		//SEND_CMD_MDA( step, 520, 530, "G00 G90 G53 X-25 Y0 A0" )
		SEND_CMD_MDA( step, 520, 530, "G00 G90 G53 X0 Y0 A0" )
		MOVE_DNE_MDA( step, 530, 1000 )

	case 1000:
		step = 0;
		break;
	}

	return (BOOL)(step == 0);
}

BOOL pa::CPThread::doAutoCal_Y1( BOOL bResetStep )
{
	static int step = 0;
	static int measure_count = 0;
	static double fResult[2];
	static double Y1_AXIS_OFFSET;
	pa::SAutoCalCoordinateOffsetParam* pSCCOP = pa::PPAStatus->GetAutoCalCoordinateOffsetParam();
	CString strLog;

	step = ( bResetStep ) ? 1 : step;

	switch( step )
	{
	case 0: break;
	case 1:
		strLog.Format( _T("start measure. y1-axis") );
		writeLog_AutoCal( strLog, FALSE );
		measure_count = 1;
		step = 10;
		break;

	case 10:
		fResult[0] = fResult[1] = Y1_AXIS_OFFSET = 0.0;
		for( int i = 0; i<pa::COORD_NUM; i++ )
		{
			pa::PAMotion->RCFG( (pa::EN_COORDINATE)i );
			Sleep(10);
		}
		step = 20;
		break;

		SEND_CMD_MDA( step, 20, 30, "G00 G90 G53 Z0 B0" )
		MOVE_DNE_MDA( step, 30, 100)

	// +Y ���� ����
	case 100:
		// X, Y1�� ���� �̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_X1POS_FOR_YZAXIS_MEAS], pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_Y1POS_FOR_YAXIS_MEAS]);
		step = 110;
		break;

		SEND_CMD_MDA( step, 110, 120, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 120, 130 )

	case 130:
		// Z1�� ���� �̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_Z1POS_FOR_YAXIS_MEAS]);
		step = 140;
		break;

		SEND_CMD_MDA( step, 140, 150, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 150, 160 )

	case 160:
		// ����
		PAMotion->SCAL( FALSE, 
			pa::AXIS_Y,
			1,
			-0.01, 0.001,
			100,
			(int)(pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_MEASURE_COUNT]),
			-20,
			0.4);
		Sleep( 300 );
		step = 170;
		break;

	case 170:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 180;
		}
		break;

	case 180:
		// ���� ��� ����
		PAMotion->GET_MEASURE_RESULT();
		fResult[0] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		strLog.Format( _T("result : %.5f"), fResult[0] );
		writeLog_AutoCal( strLog, TRUE );
		if( fabs( fResult[0] ) < 0.001 ) {
			step = 100;		// �ٽ� ���� (���� ����)
		} else {
			step = 190;
		}
		break;

		// Z1 UP
		SEND_CMD_MDA( step, 190, 200, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 200, 230 )

	// -Y ���� ����
	case 230:
		// X, Y1�� ���� �̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_X1POS_FOR_YZAXIS_MEAS], pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_Y1POS_FOR_YAXIS_MEAS] * -1.0 );
		step = 240;
		break;

		SEND_CMD_MDA( step, 240, 250, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 250, 260 )

	case 260:
		// Z1�� ���� �̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_Z1POS_FOR_YAXIS_MEAS] );
		step = 270;
		break;

		SEND_CMD_MDA( step, 270, 280, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 280, 290 )

	case 290:
		// ����
		PAMotion->SCAL( FALSE,
			pa::AXIS_Y,
			1,
			0.01, -0.001,
			100,
			(int)(pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_MEASURE_COUNT]),
			20,
			-0.4);
		Sleep( 300 );
		step = 300;
		break;

	case 300:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 310;
		}
		break;

	case 310:
		// ���� ��� ����
		PAMotion->GET_MEASURE_RESULT();
		fResult[1] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		strLog.Format( _T("result : %.5f"), fResult[1] );
		writeLog_AutoCal( strLog, TRUE );
		if( fabs( fResult[1] ) < 0.001 ) {
			step = 230;
		} else {
			step = 320;
		}
		break;

		// Z1 UP
		SEND_CMD_MDA( step, 320, 330, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 330, 360 )

	case 360:
		{
			// ���� ����� ����ؼ� Y1�� ���
			double Y1Cal1 = fResult[0];
			double Y1Cal2 = fResult[1];

			Y1_AXIS_OFFSET = ( Y1Cal1 + Y1Cal2 ) / 2;

			strLog.Format( _T("Y1 offset : %.5f"), Y1_AXIS_OFFSET );
			writeLog_AutoCal( strLog, TRUE );

			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G54][AXIS_Y] = Y1_AXIS_OFFSET;
			PAMotion->WCFG( pa::COORD_G54, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G54] );

			step = 400;
			break;
		}

	case 400:
		writeLog_AutoCal( _T("stop measure"), FALSE );
		step = 500;
		break;

		SEND_CMD_MDA( step, 500, 510, "G00 G90 G53 Z0 B0" )
		MOVE_DNE_MDA( step, 510, 520 )

		//SEND_CMD_MDA( step, 520, 530, "G00 G90 G53 X-25 Y0 A0" )
		SEND_CMD_MDA( step, 520, 530, "G00 G90 G53 X0 Y0 A0" )
		MOVE_DNE_MDA( step, 530, 1000 )

	case 1000:
		step = 0;
		break;
	}

	return (BOOL)(step == 0);
}

BOOL pa::CPThread::doAutoCal_Y2( BOOL bResetStep )
{
	static int step = 0;
	static int measure_count = 0;
	static double fResult[2];
	static double Y2_AXIS_OFFSET;
	pa::SAutoCalCoordinateOffsetParam* pSCCOP = pa::PPAStatus->GetAutoCalCoordinateOffsetParam();
	CString strLog;

	step = ( bResetStep ) ? 1 : step;

	switch( step )
	{
	case 0: break;
	case 1:
		strLog.Format( _T("start measure. y1-axis") );
		writeLog_AutoCal( strLog, FALSE );
		measure_count = 1;
		step = 10;
		break;

	case 10:
		fResult[0] = fResult[1] = Y2_AXIS_OFFSET = 0.0;
		for( int i = 0; i<pa::COORD_NUM; i++ )
		{
			pa::PAMotion->RCFG( (pa::EN_COORDINATE)i );
			Sleep(10);
		}
		step = 20;
		break;

		SEND_CMD_MDA( step, 20, 30, "G00 G90 G53 Z0 B0" )
		MOVE_DNE_MDA( step, 30, 100)

	// +Y ���� ����
	case 100:
		// X, Y2�� ���� �̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f A%.3f", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_X2POS_FOR_YZAXIS_MEAS], pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_Y2POS_FOR_YAXIS_MEAS]);
		step = 110;
		break;

		SEND_CMD_MDA( step, 110, 120, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 120, 130 )

	case 130:
		// Z2�� ���� �̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 B%.3f", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_Z2POS_FOR_YAXIS_MEAS] );
		step = 140;
		break;

		SEND_CMD_MDA( step, 140, 150, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 150, 160 )

	case 160:
		// ����
		PAMotion->SCAL( FALSE, 
			pa::AXIS_A,
			2,
			-0.01, 0.001,
			100,
			(int)(pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_MEASURE_COUNT]),
			-20,
			0.4);
		Sleep( 300 );
		step = 170;
		break;

	case 170:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 180;
		}
		break;

	case 180:
		// ���� ��� ����
		PAMotion->GET_MEASURE_RESULT();
		fResult[0] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		strLog.Format( _T("result : %.5f"), fResult[0] );
		writeLog_AutoCal( strLog, TRUE );
		if( fabs( fResult[0] ) < 0.001 ) {
			step = 100;		// �ٽ� ���� (���� ����)
		} else {
			step = 190;
		}
		break;

		// Z2 UP
		SEND_CMD_MDA( step, 190, 200, "G00 G90 G53 B0" )
		MOVE_DNE_MDA( step, 200, 230 )

			// -Y ���� ����
	case 230:
		// X, Y1�� ���� �̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f A%.3f", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_X2POS_FOR_YZAXIS_MEAS], pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_Y2POS_FOR_YAXIS_MEAS] * -1.0 );
		step = 240;
		break;

		SEND_CMD_MDA( step, 240, 250, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 250, 260 )

	case 260:
		// Z2�� ���� �̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 B%.3f", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_Z2POS_FOR_YAXIS_MEAS] );
		step = 270;
		break;

		SEND_CMD_MDA( step, 270, 280, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 280, 290 )

	case 290:
		// ����
		PAMotion->SCAL( FALSE,
			pa::AXIS_A,
			2,
			0.01, -0.001,
			100,
			(int)(pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_MEASURE_COUNT]),
			20,
			-0.4);
		Sleep( 300 );
		step = 300;
		break;

	case 300:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 310;
		}
		break;

	case 310:
		// ���� ��� ����
		PAMotion->GET_MEASURE_RESULT();
		fResult[1] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		strLog.Format( _T("result : %.5f"), fResult[1] );
		writeLog_AutoCal( strLog, TRUE );
		if( fabs( fResult[1] ) < 0.001 ) {
			step = 230;
		} else {
			step = 320;
		}
		break;

		// Z2 UP
		SEND_CMD_MDA( step, 320, 330, "G00 G90 G53 B0" )
		MOVE_DNE_MDA( step, 330, 360 )

	case 360:
		// ���� ����� ����ؼ� Y2�� ���
		{
			double Y2Cal1 = fResult[0];
			double Y2Cal2 = fResult[1];

			Y2_AXIS_OFFSET = ( Y2Cal1 + Y2Cal2 ) / 2;

			strLog.Format( _T("Y2 offset : %.5f"), Y2_AXIS_OFFSET );
			writeLog_AutoCal( strLog, TRUE );

			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G54][AXIS_A] = Y2_AXIS_OFFSET;
			PAMotion->WCFG( pa::COORD_G54, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G54] );

			// Jig ���� ���
			double RTool2 = pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_TOOL_DIAMETER_RIGHT] / 2;
			double dwJigDiameter;
			dwJigDiameter = (Y2Cal1 - RTool2) - (Y2Cal2 + RTool2);

			strLog.Format( _T("Jig Diameter : %.5f"), pSCCOP->fJigDiameter );
			writeLog_AutoCal( strLog, TRUE );

			pSCCOP->fJigDiameter = dwJigDiameter;

			step = 400;
			break;
		}

	case 400:
		writeLog_AutoCal( _T("stop measure"), FALSE );
		step = 500;
		break;

		SEND_CMD_MDA( step, 500, 510, "G00 G90 G53 Z0 B0" )
		MOVE_DNE_MDA( step, 510, 520 )

		//SEND_CMD_MDA( step, 520, 530, "G00 G90 G53 X-25 Y0 A0" )
		SEND_CMD_MDA( step, 520, 530, "G00 G90 G53 X0 Y0 A0" )
		MOVE_DNE_MDA( step, 530, 1000 )

	case 1000:
		step = 0;
		break;
	}

	return (BOOL)(step == 0);
}

BOOL pa::CPThread::doAutoCal_Z1( BOOL bResetStep )
{
	static int step = 0;
	static int measure_count = 0;
	static double fResult[3];
	static double fJigDiameter;
	static double Z1_AXIS_ORIGIN_OFFSET;
	pa::SAutoCalCoordinateOffsetParam* pSCCOP = pa::PPAStatus->GetAutoCalCoordinateOffsetParam();
	CString strLog;

	step = ( bResetStep ) ? 1 : step;

	switch( step )
	{
	case 0: break;
	case 1:
		strLog.Format( _T("start measure. z1-axis") );
		writeLog_AutoCal( strLog, FALSE );
		measure_count = 1;
		step = 10;
		break;

	case 10:
		fResult[0] = fResult[1] = Z1_AXIS_ORIGIN_OFFSET = fJigDiameter = 0.0;
		for( int i = 0; i<pa::COORD_NUM; i++ )
		{
			pa::PAMotion->RCFG( (pa::EN_COORDINATE)i );
			Sleep(10);
		}
		step = 20;
		break;

		SEND_CMD_MDA( step, 20, 30, "G00 G90 G53 Z0 B0" )
		MOVE_DNE_MDA( step, 30, 100)

	// Z1 Origin Offset ����
	case 100:
		// X, Y1�� �����̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y0", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_X1POS_FOR_YZAXIS_MEAS] );
		step = 110;
		break;

		SEND_CMD_MDA( step, 110, 120, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 120, 130 )

	case 130:
		// Z1�� �����̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_Z1POS_FOR_ZAXIS_MEAS] );
		step = 140;

		SEND_CMD_MDA( step, 140, 150, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 150, 160 )

	case 160:
		// ����
		PAMotion->SCAL( FALSE,
			pa::AXIS_Z,
			1,
			-0.01, 0.001,
			100,
			(int)(pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_MEASURE_COUNT]),
			-20,
			0.4);
		Sleep( 300 );
		step = 170;
		break;

	case 170:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 180;
		}
		break;

	case 180:
		// ���� ��� ����
		PAMotion->GET_MEASURE_RESULT();
		fResult[2] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		strLog.Format( _T("result : %.5f"), fResult[2] );
		writeLog_AutoCal( strLog, TRUE );
		if( fabs( fResult[2] ) < 0.001 ) {
			step = 100;
		} else {
			step = 190;
		}
		break;

		// Z1 UP
		SEND_CMD_MDA( step, 190, 200, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 200, 210 )

	case 210:
		// ���� ����� ����ؼ� Z1 Origin Offset ���
		{
			// Z1 Origin Offset ���
			double Z1Cal3 = fResult[2];
			double LTool1 = pa::PPAStatus->GetPAStatus()->fCurrentToolLenght;
			double fJigDiameter = pSCCOP->fJigDiameter;
			
			Z1_AXIS_ORIGIN_OFFSET = -( fJigDiameter / 2 ) + Z1Cal3 - LTool1;

			strLog.Format( _T("Z1 origin offset : %.5f"), Z1_AXIS_ORIGIN_OFFSET );
			writeLog_AutoCal( strLog, TRUE );
			PAMotion->WTOO( 1, Z1_AXIS_ORIGIN_OFFSET);
			step = 500;
			break;
		}

	case 500:
		writeLog_AutoCal( _T("stop measure"), FALSE );
		step = 600;
		break;

		SEND_CMD_MDA( step, 600, 610, "G00 G90 G53 Z0 B0" )
		MOVE_DNE_MDA( step, 610, 620 )

		//SEND_CMD_MDA( step, 620, 630, "G00 G90 G53 X-25 Y0 A0" )
		SEND_CMD_MDA( step, 620, 630, "G00 G90 G53 X0 Y0 A0" )
		MOVE_DNE_MDA( step, 630, 1000 )

	case 1000:
		step = 0;
		break;
	}

	return (BOOL)(step == 0);
}

BOOL pa::CPThread::doAutoCal_Z2( BOOL bResetStep )
{
	static int step = 0;
	static int measure_count = 0;
	static double fResult[3];
	static double fJigDiameter;
	static double Z2_AXIS_ORIGIN_OFFSET;
	pa::SAutoCalCoordinateOffsetParam* pSCCOP = pa::PPAStatus->GetAutoCalCoordinateOffsetParam();
	CString strLog;

	step = ( bResetStep ) ? 1 : step;

	switch( step )
	{
	case 0: break;
	case 1:
		strLog.Format( _T("start measure. z2-axis") );
		writeLog_AutoCal( strLog, FALSE );
		measure_count = 1;
		step = 10;
		break;

	case 10:
		fResult[0] = fResult[1] = Z2_AXIS_ORIGIN_OFFSET = fJigDiameter = 0.0;
		for( int i = 0; i<pa::COORD_NUM; i++ )
		{
			pa::PAMotion->RCFG( (pa::EN_COORDINATE)i );
			Sleep(10);
		}
		step = 20;
		break;

		SEND_CMD_MDA( step, 20, 30, "G00 G90 G53 Z0 B0" )
		MOVE_DNE_MDA( step, 30, 100)

	// Z2 Origin Offset ����
	case 100:
		// X, Y2�� �����̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f A0", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_X2POS_FOR_YZAXIS_MEAS] );
		step = 110;
		break;

		SEND_CMD_MDA( step, 110, 120, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 120, 130 )

	case 130:
		// Z2�� �����̵�
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 B%.3f", pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_Z2POS_FOR_ZAXIS_MEAS] );
		step = 140;
		break;

		SEND_CMD_MDA( step, 140, 150, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 150, 160 )

	case 160:
		// ����
		PAMotion->SCAL( FALSE,
			pa::AXIS_B,
			2,
			0.01, -0.001,
			100,
			(int)(pSCCOP->fParam[pa::SAutoCalCoordinateOffsetParam::PARAM_MEASURE_COUNT]),
			20,
			-0.4);
		Sleep( 300 );
		step = 170;
		break;

	case 170:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 180;
		}
		break;

	case 180:
		// ���� ��� ����
		PAMotion->GET_MEASURE_RESULT();
		fResult[2] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		strLog.Format( _T("result : %.5f"), fResult[2] );
		writeLog_AutoCal( strLog, TRUE );
		if( fabs( fResult[2] ) < 0.001 ) {
			step = 100;
		} else {
			step = 190;
		}
		break;

		// Z2 UP
		SEND_CMD_MDA( step, 190, 200, "G00 G90 G53 B0" )
		MOVE_DNE_MDA( step, 200, 210 )

	case 210:
		// ���� ����� ����ؼ� Z2 Origin Offset ���
		{
			// Z2 Origin Offset ���
			double Z2Cal3 = fResult[2];
			double LTool2 = pa::PPAStatus->GetPAStatus()->fCurrentTool2Lenght;
			double fJigDiameter = pSCCOP->fJigDiameter;

			Z2_AXIS_ORIGIN_OFFSET = ( fJigDiameter / 2 ) + Z2Cal3 - LTool2;

			strLog.Format( _T("Z2 origin offset : %.5f"), Z2_AXIS_ORIGIN_OFFSET );
			writeLog_AutoCal( strLog, TRUE );
			PAMotion->WTOO( 2, Z2_AXIS_ORIGIN_OFFSET);
			step = 500;
			break;
		}

	case 500:
		writeLog_AutoCal( _T("stop measure"), FALSE );
		step = 600;
		break;

		SEND_CMD_MDA( step, 600, 610, "G00 G90 G53 Z0 B0" )
		MOVE_DNE_MDA( step, 610, 620 )

		//SEND_CMD_MDA( step, 620, 630, "G00 G90 G53 X-25 Y0 A0" )
		SEND_CMD_MDA( step, 620, 630, "G00 G90 G53 X0 Y0 A0" )
		MOVE_DNE_MDA( step, 630, 1000 )

	case 1000:
		step = 0;
		break;
	}

	return (BOOL)(step == 0);
}

// ���� ���� �� ��� ��ġ(G54 X0 Y0)�� �̵��Ѵ� 
BOOL pa::CPThread::doAutlCal_MoveReadyPos( BOOL bResetStep )
{
	static int step = 0;

	step = ( bResetStep ) ? 1 : step;

	switch( step )
	{
	case 1:
		step = 10;
		break;
		
	case 10:
		// Z1, Z2-UP
// 		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z%.3f A%.3f B%.3f",
// 			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X],
// 			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y],
// 			0.0,
// 			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_A],
// 			0.0 );

// 		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z%.3f A%.3f B%.3f",
// 			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X],
// 			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y],
// 			0.0,
// 			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_A],
// 			0.0 );
// 		{
// 			TRACE("doAutlCal_MoveReadyPos \n");
// 			CString strTrace = hcutil::ASCII_TO_CSTRING(szCommandBuffer_);
// 			TRACE(strTrace); TRACE("\n");
// 		}

		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 Z0 B0" );
		step = 20;
		break;

		SEND_CMD_MDA( step, 20, 30, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 30, 40 )

	case 40:
		// X, Y1, Z1 ����
// 		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z%.3f A%.3f B%.3f",
// 			0,
// 			0,
// 			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Z],
// 			0.0,
// 			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_B] );

// 		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X-25 Y%.3f Z%.3f A%.3f B%.3f",
// 			0,
// 			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Z],
// 			0.0,
// 			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_B] );

		// sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X-25 Y0 A0");
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X0 Y0 A0");
		step = 60;
		break;

		SEND_CMD_MDA( step, 60, 70, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 70, 80 )

	case 80:
		//sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X0 Y0 Z0 A0 B0" );
		//sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X-25 Y0 Z0 A0 B0" );
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X0 Y0 Z0 A0 B0" );
		step = 90;
		break;

		SEND_CMD_MDA( step, 90, 100, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 100, 110 )

		SEND_CMD_MDA( step, 110, 120, "G00 G90 G54 Y0 A0" )
		MOVE_DNE_MDA( step, 120, 130 )

	case 130:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
void pa::CPThread::doAutoTeaching_ToolPocket1()		// Tool Pocket ��� ���
{
/*	static double	F_MEASURE_RESULT[3][2][2];	// ��� ��ġ ��, X/Y, Left/Right
	static int		LEFT_TOOL_NO = 0;
	static int		RIGHT_TOOL_NO = 0;
	int&	step = nStep_[RUNMODE_RUN];
	int		ntemp= 0;
	CString strLog;

	pa::SAutoTeachToolPocketParam* p = (pa::SAutoTeachToolPocketParam*)(PPAStatus->GetAutoTeachToolPocketParam());

	switch( step )
	{
	case 52000:
		strLog.Format( _T("start. auto teaching for tool pocket") );
		writeLog_AutoCal( strLog, FALSE );

		F_MEASURE_RESULT[0][0][0] = F_MEASURE_RESULT[0][1][0] = 0.0;
		F_MEASURE_RESULT[1][0][0] = F_MEASURE_RESULT[1][1][0] = 0.0;
		F_MEASURE_RESULT[2][0][0] = F_MEASURE_RESULT[2][1][0] = 0.0;
		F_MEASURE_RESULT[0][0][1] = F_MEASURE_RESULT[0][1][1] = 0.0;
		F_MEASURE_RESULT[1][0][1] = F_MEASURE_RESULT[1][1][1] = 0.0;
		F_MEASURE_RESULT[2][0][1] = F_MEASURE_RESULT[2][1][1] = 0.0;

		pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 0;
		pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable2 = 0;
		LEFT_TOOL_NO = 0;
		RIGHT_TOOL_NO = 0;
		step = 52010;
		break;

		//////////////////////////////////////////////////////////////////////////
		// ������ ���� ��´�
	case 52010:
		// Get Left tool
		if (pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[0] == 0)
		{
			step = 52030;
			break;
		}

		LEFT_TOOL_NO = p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_NUMBER_LEFT];
		if( LEFT_TOOL_NO != 0 ) 
		{
			if( LEFT_TOOL_NO == pa::PPAStatus->GetPAStatus()->nCurrentToolNo ) {
				step = 52020;	
			} else {
				step = 52011; // ���� �ٲ۴� 
			}
		}
		else 
		{
			// �� ��ȣ�� 0�̸�, �� ��� ������ ���� �ʴ´� 
			step = 52030;	// ���� ������ ���� 
		}
		break;
	case 52011:
		doAutoCal_Prepare( TRUE, LEFT_TOOL_NO );
		step = 52012;
		break;
	case 52012:
		if( doAutoCal_Prepare( FALSE, LEFT_TOOL_NO ) == TRUE ) {
			step = 52030;
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// 2017.08.22. Tool ��ȣ�� ���� ���, ���� ���� �÷��׸� Ȯ�� �Ѵ� 
	case 52020:
		if( LEFT_TOOL_NO != 0 && pa::PPAStatus->GetPAStatus()->nToolLengthUpdateFlag == 0 ) {
			step = 52022;
		} else {
			step = 52030;
		}
		break;
		SEND_CMD_MDA( step, 52022, 52024, "M207" )
		MOVE_DNE_MDA( step, 52024, 52030 )

	case 52030:
		// Get Right tool
		if (pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[1] == 0)
		{
			step = 52050;
			break;
		}

		RIGHT_TOOL_NO = p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_NUMBER_RIGHT];
		if( RIGHT_TOOL_NO != 0)
		{
			if( RIGHT_TOOL_NO == pa::PPAStatus->GetPAStatus()->nCurrentTool2No ) {
				step = 52040;
			}
			else {
				step = 52031;
			}
		}
		else
		{
			// �� ��ȣ�� 0�̸�, �� ��� ������ ���� �ʴ´�
			step = 52050;
		}
		break;
	case 52031:
		doAutoCal_Prepare( TRUE, RIGHT_TOOL_NO);
		step = 52032;
		break;
	case 52032:
		if( doAutoCal_Prepare( FALSE, RIGHT_TOOL_NO ) == TRUE ) {
			step = 52050;
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// Tool ��ȣ�� ���� ���, ���� ���� �÷��׸� Ȯ�� �Ѵ�
	case 52040:
		if( RIGHT_TOOL_NO != 0 && pa::PPAStatus->GetPAStatus()->nTool2LengthUpdateFlag == 0 ) {
			step = 52042;
		} else {
			step = 52050;
		}
		break;

		SEND_CMD_MDA( step, 52042, 52044, "M208" )
		MOVE_DNE_MDA( step, 52044, 52050 )

		//////////////////////////////////////////////////////////////////////////
		// ���� ���̺� ���� �޽��� �ڽ��� ����
		//////////////////////////////////////////////////////////////////////////
	case 52050:
		step = 52051;
		break;
// 		{
// 			CAutoCalDlg::SHOW_DLG();
// 			int sel = CAutoCalDlg::WAIT_FOR_SELECT();
// 			CAutoCalDlg::HIDE_DLG();
// 			if( sel == IDOK ) {
// 				pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 1;	// ��� ���� 
// 			} else {
// 				pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 2;	// ���� ���� 
// 			}
// 		}
// 		step = 52060;
// 		break;

	case 52051:
		CAutoCalDlg::SHOW_DLG();
		step = 52052;
		break;
	case 52052:
		{
			int sel = CAutoCalDlg::WAIT_FOR_SELECT2();
			if (sel == -1) break;
			else {
				if (sel == IDOK) {
					pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 1;
				}
				else {
					pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 2;
				}
				CAutoCalDlg::HIDE_DLG();
				step = 52053;
			}
		}
		break;
	case 52053:
		step = 52060;
		break;

		// ���� ���̺� ������ ��ٸ��� 
	case 52060:
		if( pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable != 0 ) {
			if( pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable == 1 ) {
				step = 52070;	// �۾� ���� 
			} else {
				step = 53400;	// �۾� ��� 
			}
		}

		// Left, Right �� �� Check�� �ȵ�������, �۾� ���
		if (pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[0] == 0 && pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[1] == 0)
		{
			step = 53400;	// �۾� ���
		}

		break;

		// ATC Door�� ���� 
	case 52070:
// 		pa::PAMotion->ATCDoor( CPAMotion::OPEN );	// Blocking �� 
// 		Sleep( 300 );
		step = 52080;
		break;

	case 52080:
		step = 52090;
		break;

		//////////////////////////////////////////////////////////////////////////
		// ���� ����
		//////////////////////////////////////////////////////////////////////////
		// ���� Pocket
	case 52090:
		// Left Check�� �ȵ�������, Right�� �Ѿ
		if (pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[0] == 0)
		{
			step = 52690;
		}

		else
		{
			step = 52100;
		}
		break;

		// Z Up
	case 52100:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z0 A%.3f B0",
			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X],
			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y],
			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_A]);
		step = 52110;
		break;
		SEND_CMD_MDA( step, 52110, 52120, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52120, 52130 )

		// P1 ���� 
	case 52130:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z0 A0 B0",
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_X1POS],
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_Y1POS] );	
		step = 52140;
		break;
		SEND_CMD_MDA( step, 52140, 52150, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52150, 52160 )

	case 52160:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 Z%.3f", p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_Z1POS] );
		step = 52170;
		break;
		SEND_CMD_MDA( step, 52170, 52180, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52180, 52190 )

		// ���� 
	case 52190:
		{ 
			PAMotion->SCAL( FALSE, 
				pa::AXIS_Y, 
				1,
				0.01, -0.001,
				100,
				(int)p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_COUNT], 
				20,
				-0.4 );
		}
		Sleep( 300 );
		step = 52200;
		break;
	case 52200:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 52210;
		}
		break;
		// ���� ��� ���� 
	case 52210:
		PAMotion->GET_MEASURE_RESULT();
		F_MEASURE_RESULT[0][0][0] = p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_X1POS];
		F_MEASURE_RESULT[0][1][0] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;

		strLog.Format( _T("Left point 1 = [%.4f, %.4f]"), F_MEASURE_RESULT[0][0][0], F_MEASURE_RESULT[0][1][0] );
		writeLog_AutoCal( strLog, TRUE );
		step = 52220;
		break;
		
		// Z Up
		SEND_CMD_MDA( step, 52220, 52230, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 52230, 52300 )

	case 52300:
		step = 52330;
		break;

		// P2 ����
	case 52330:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z0 A0 B0",
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_X1POS], 
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_Y1POS] ); 
		step = 52340;
		break;
		SEND_CMD_MDA( step, 52340, 52350, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52350, 52360 )

	case 52360:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 Z%.3f", p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_Z1POS] );
		step = 52370;
		break;
		SEND_CMD_MDA( step, 52370, 52380, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52380, 52390 )

		// ���� 
	case 52390:
		{
			PAMotion->SCAL( FALSE, 
				pa::AXIS_Y, 
				1,
				0.01, -0.001,
				100,
				(int)p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_COUNT], 
				20,
				-0.4 );
		}
		Sleep( 300 );
		step = 52400;
		break;
	case 52400:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 52410;
		}
		break;
		// ���� ��� ���� 
	case 52410:
		PAMotion->GET_MEASURE_RESULT();
		F_MEASURE_RESULT[1][0][0] = p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_X1POS];
		F_MEASURE_RESULT[1][1][0] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		strLog.Format( _T("Left point 2 = [%.4f, %.4f]"), F_MEASURE_RESULT[1][0][0], F_MEASURE_RESULT[1][1][0] );
		writeLog_AutoCal( strLog, TRUE );
		step = 52420;
		break;

		SEND_CMD_MDA( step, 52420, 52430, "G00 G90 G53 Z0.0" )
		MOVE_DNE_MDA( step, 52430, 52500 )

		// P3 ����
	case 52500:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z0 A0 B0",
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_X1POS],
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_Y1POS] );
		step = 52510;
		break;
		SEND_CMD_MDA( step, 52510, 52520, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52520, 52530 )

	case 52530:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 Z%.3f", p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_Z1POS] );
		step = 52540;
		break;
		SEND_CMD_MDA( step, 52540, 52550, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52550, 52560 )

		// ���� 
	case 52560:
		{
			PAMotion->SCAL( FALSE, 
				pa::AXIS_X, 
				1,
				-0.01, 0.001,
				100,
				(int)p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_COUNT], 
				-20,
				0.4 );
		}
		Sleep( 300 );
		step = 52570;
		break;
	case 52570:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 52580;
		}
		break;

		// ���� ��� ���� 
	case 52580:
		PAMotion->GET_MEASURE_RESULT();
		F_MEASURE_RESULT[2][0][0] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		F_MEASURE_RESULT[2][1][0] = p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_Y1POS];
		strLog.Format( _T("Left point 3 = [%.4f, %.4f]"), F_MEASURE_RESULT[2][0][0], F_MEASURE_RESULT[2][1][0] );
		writeLog_AutoCal( strLog, TRUE );
		step = 52590;
		break;

		SEND_CMD_MDA( step, 52590, 52600, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 52600, 52610 )

		// XY-Z-AB �ʱ� ��ġ�� �̵�
	case 52610:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X0 Y0 Z0 A0 B0" ); 
		step = 52620;
		break;
		SEND_CMD_MDA( step, 52620, 52630, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52630, 52690 )

		// ������ Pocket
	case 52690:
		// Right Check�� �ȵ�������, ��� ������� �Ѿ
		if (pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[1] == 0)
		{
			step = 53300;
		}

		else
		{
			step = 52700;
		}
		break;

		// Z Up
	case 52700:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z0 A%.3f B0",
			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X],
			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y],
			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_A]);
		step = 52710;
		break;
		SEND_CMD_MDA( step, 52710, 52720, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52720, 52730 )

		// P1 ����
	case 52730:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y0 Z0 A%.3f B0" ,
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_X2POS],
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_Y2POS] );
		step = 52740;
		break;
		SEND_CMD_MDA( step, 52740, 52750, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52750, 52760 )

	case 52760:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 B%.3f", p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_Z2POS] );
		step = 52770;
		break;
		SEND_CMD_MDA( step, 52770, 52780, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52780, 52790 )

	case 52790:
		{
			PAMotion->SCAL( FALSE, 
				pa::AXIS_A, 
				2,
				0.01, -0.001,
				100,
				(int)p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_COUNT], 
				20,
				-0.4 );
		}
		Sleep( 300 );
		step = 52800;
		break;
	case 52800:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 52810;
		}
		break;
		// ���� ��� ����
	case 52810:
		PAMotion->GET_MEASURE_RESULT();
		F_MEASURE_RESULT[0][0][1] = p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_X2POS];
		F_MEASURE_RESULT[0][1][1] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;

		strLog.Format( _T("Right point 1 = [%.4f, %.4f]"), F_MEASURE_RESULT[0][0][1], F_MEASURE_RESULT[0][1][1] );
		writeLog_AutoCal( strLog, TRUE );
		step = 52820;
		break;

		// Z Up
		SEND_CMD_MDA( step, 52820, 52830, "G00 G90 G53 B0" )
		MOVE_DNE_MDA( step, 52830, 52900 )

	case 52900:
		step = 52930;
		break;

		// P2 ����
	case 52930:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y0 Z0 A%.3f B0",
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_X2POS], 
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_Y2POS] ); 
		step = 52940;
		break;
		SEND_CMD_MDA( step, 52940, 52950, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52950, 52960 )

	case 52960:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 B%.3f", p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_Z2POS] );
		step = 52970;
		break;
		SEND_CMD_MDA( step, 52970, 52980, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52980, 52990 )

		// ����
	case 52990:
		{
			PAMotion->SCAL( FALSE, 
				pa::AXIS_A, 
				2,
				0.01, -0.001,
				100,
				(int)p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_COUNT], 
				20,
				-0.4 );
		}
		Sleep( 300 );
		step = 53000;
		break;
	case 53000:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 53010;
		}
		break;
		// ���� ��� ����
	case 53010:
		PAMotion->GET_MEASURE_RESULT();
		F_MEASURE_RESULT[1][0][1] = p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_X2POS];
		F_MEASURE_RESULT[1][1][1] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		strLog.Format( _T("Right point 2 = [%.4f, %.4f]"), F_MEASURE_RESULT[1][0][1], F_MEASURE_RESULT[1][1][1] );
		writeLog_AutoCal( strLog, TRUE );
		step = 53020;
		break;

		SEND_CMD_MDA( step, 53020, 53030, "G00 G90 G53 B0" )
		MOVE_DNE_MDA( step, 53030, 53100 )

		// P3 ����
	case 53100:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y0 Z0 A%.3f B0",
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_X2POS],
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_Y2POS] );
		step = 53110;
		break;
		SEND_CMD_MDA( step, 53110, 53120, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 53120, 53130 )

	case 53130:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 B%.3f", p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_Z2POS] );
		step = 53140;
		break;
		SEND_CMD_MDA( step, 53140, 53150, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 53150, 53160 )

		// ����
	case 53160:
		{
			PAMotion->SCAL( FALSE, 
				pa::AXIS_X, 
				2,
				-0.01, 0.001,
				100,
				(int)p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_COUNT],
				-20,
				0.4 );
		}
		Sleep( 300 );
		step = 53170;
		break;
	case 53170:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 53180;
		}
		break;

		// ���� ��� ����
	case 53180:
		PAMotion->GET_MEASURE_RESULT();
		F_MEASURE_RESULT[2][0][1] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		F_MEASURE_RESULT[2][1][1] = p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_Y2POS];
		strLog.Format( _T("Right point 3 = [%.4f, %.4f]"), F_MEASURE_RESULT[2][0][1], F_MEASURE_RESULT[2][1][1] );
		writeLog_AutoCal( strLog, TRUE );
		step = 53190;
		break;

		SEND_CMD_MDA( step, 53190, 53200, "G00 G90 G53 B0" )
		MOVE_DNE_MDA( step, 53200, 53210 )

		// �ʱ� ��ġ�� �̵�
	case 53210:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X0 Y0 Z0 A0 B0" );
		step = 53220;
		break;
		SEND_CMD_MDA( step, 53220, 53230, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 53230, 53300 )

		//////////////////////////////////////////////////////////////////////////
		// ��� ��� 
		//////////////////////////////////////////////////////////////////////////
	case 53300:
 		{
 			// ���� ��ġ 
 			double fToolPocket1PosX = p->fParam[SAutoTeachToolPocketParam::PARAM_1ST_POCKET_X_DIST];
 			double fToolPocket1PosY = p->fParam[SAutoTeachToolPocketParam::PARAM_1ST_POCKET_Y_DIST];
 			double fToolPocket4PosX = p->fParam[SAutoTeachToolPocketParam::PARAM_4TH_POCKET_X_DIST];
 			double fToolPocket4PosY = p->fParam[SAutoTeachToolPocketParam::PARAM_4TH_POCKET_Y_DIST];
  			double fToolPocketDistX = p->fParam[SAutoTeachToolPocketParam::PARAM_POCKET_X_DIST];
			double fToolPocketDistY = p->fParam[SAutoTeachToolPocketParam::PARAM_POCKET_Y_DIST];

 			double fSensor1XDist = p->fParam[SAutoTeachToolPocketParam::PARAM_SENSOR1_X_DIST];
 			double fSensor1YDist = p->fParam[SAutoTeachToolPocketParam::PARAM_SENSOR1_Y_DIST];
 			double fSensor2XDist = p->fParam[SAutoTeachToolPocketParam::PARAM_SENSOR2_X_DIST];
 			double fSensor2YDist = p->fParam[SAutoTeachToolPocketParam::PARAM_SENSOR2_Y_DIST];

			double ToolPoint[2][3][2];
			double SensorPoint[2][2];

			///////////////////////////////////////////////////////////////////////////////////
			// ���� �� ���
			if ( pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[0] == 1 )
			{
				double LeftX1 = F_MEASURE_RESULT[0][0][0];
				double LeftY1 = F_MEASURE_RESULT[0][1][0];
				double LeftX2 = F_MEASURE_RESULT[1][0][0];
				double LeftY2 = F_MEASURE_RESULT[1][1][0];
				double LeftX3 = F_MEASURE_RESULT[2][0][0];
				double LeftY3 = F_MEASURE_RESULT[2][1][0];

				double LeftP1, LeftQ1, LeftP2, LeftQ2, LeftP3, LeftQ3, LeftP4, LeftQ4;
				
				// Ʋ���� ���� ���ϱ�
				double fdX_Left = LeftX2 - LeftX1;
				double fdY_Left = LeftY2 - LeftY1;

				double fRadian_Left = atan( fdY_Left / fdX_Left );
				double fcos_Left = cos(fRadian_Left);
				double fsin_Left = sin(fRadian_Left);

				LeftP1 = LeftY1 + ( p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_DIAMETER_LEFT] / 2 ) * fcos_Left;
				LeftQ1 = LeftX1 + ( p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_DIAMETER_LEFT] / 2 ) * fsin_Left;

				LeftP2 = LeftY2 + ( p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_DIAMETER_LEFT] / 2 ) * fcos_Left;
				LeftQ2 = LeftX2 + ( p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_DIAMETER_LEFT] / 2 ) * fsin_Left;

				LeftP3 = LeftY3 - ( p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_DIAMETER_LEFT] / 2 ) * fsin_Left;
				LeftQ3 = LeftX3 - ( p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_DIAMETER_LEFT] / 2 ) * fcos_Left;

				// ������ ��ǥ ���ϱ�
				LeftP4 = ((LeftQ2 - LeftQ1)*(LeftP1*LeftQ2 - LeftP2*LeftQ1) + LeftP3*(LeftP2 - LeftP1)*(LeftP2 - LeftP1) + LeftQ3*(LeftQ2 - LeftQ1)*(LeftP2 - LeftP1)) / ((LeftP2 - LeftP1)*(LeftP2 - LeftP1) + (LeftQ2 - LeftQ1)*(LeftQ2 - LeftQ1)); 

				LeftQ4 = ((LeftP2 - LeftP1)*(LeftP2*LeftQ1 - LeftP1*LeftQ2) + LeftQ3*(LeftQ2 - LeftQ1)*(LeftQ2 - LeftQ1) + LeftP3*(LeftP2 - LeftP1)*(LeftQ2 - LeftQ1)) / ((LeftP2 - LeftP1)*(LeftP2 - LeftP1) + (LeftQ2 - LeftQ1)*(LeftQ2 - LeftQ1));

				// Tool Pocket ��ǥ ���ϱ�
				// 1�� ����
				ToolPoint[0][0][0] = LeftQ4 + fToolPocket1PosX * fcos_Left + fToolPocket1PosY * fsin_Left;
				ToolPoint[0][0][1] = LeftP4 - fToolPocket1PosX * fsin_Left + fToolPocket1PosY * fcos_Left;

				// 2�� ����
				ToolPoint[0][1][0] = LeftQ4 + (fToolPocket1PosX - fToolPocketDistX) * fcos_Left + fToolPocket1PosY * fsin_Left;
				ToolPoint[0][1][1] = LeftP4 - (fToolPocket1PosX - fToolPocketDistX) * fsin_Left + fToolPocket1PosY * fcos_Left;

				// 3�� ����
				ToolPoint[0][2][0] = LeftQ4 + (fToolPocket1PosX - fToolPocketDistX * 2) * fcos_Left + fToolPocket1PosY * fsin_Left;
				ToolPoint[0][2][1] = LeftP4 - (fToolPocket1PosX - fToolPocketDistX * 2) * fsin_Left + fToolPocket1PosY * fcos_Left;

				// 1�� ����
				SensorPoint[0][0] = LeftQ4 + fSensor1XDist * fcos_Left + fSensor1YDist * fsin_Left;
				SensorPoint[0][1] = LeftP4 - fSensor1XDist * fsin_Left + fSensor1YDist * fcos_Left;

				//////////////////////////////////////////////////////////////////////////
				// ������ ���� �� �ٿ�ε�. 
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL1][pa::AXIS_X] = ToolPoint[0][0][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL1][pa::AXIS_Y] = ToolPoint[0][0][1];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL2][pa::AXIS_X] = ToolPoint[0][1][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL2][pa::AXIS_Y] = ToolPoint[0][1][1];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL3][pa::AXIS_X] = ToolPoint[0][2][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL3][pa::AXIS_Y] = ToolPoint[0][2][1];

				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_UP1][pa::AXIS_X] = SensorPoint[0][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_UP1][pa::AXIS_Y] = SensorPoint[0][1];

				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_DN1][pa::AXIS_X] = SensorPoint[0][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_DN1][pa::AXIS_Y] = SensorPoint[0][1];

				pa::PAMotion->WTCP( 0, 1, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL1] );
				pa::PAMotion->WTCP( 1, 2, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL2] );
				pa::PAMotion->WTCP( 2, 3, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL3] );
				pa::PAMotion->WTCP( 7, 19, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_UP1] );
				pa::PAMotion->WTCP( 8, 20, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_DN1] );
			}

			///////////////////////////////////////////////////////////////////////////////////
			// ������ �� ���
			if ( pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[1] == 1 )
			{
				double RightX1 = F_MEASURE_RESULT[0][0][1];
				double RightY1 = F_MEASURE_RESULT[0][1][1];
				double RightX2 = F_MEASURE_RESULT[1][0][1];
				double RightY2 = F_MEASURE_RESULT[1][1][1];
				double RightX3 = F_MEASURE_RESULT[2][0][1];
				double RightY3 = F_MEASURE_RESULT[2][1][1];

				double RightP1, RightQ1, RightP2, RightQ2, RightP3, RightQ3, RightP4, RightQ4;

				// Ʋ���� ���� ���ϱ�
				double fdX_Right = RightX2 - RightX1;
				double fdY_Right = RightY2 - RightY1;

				double fRadian_Right = atan( fdY_Right / fdX_Right );
				double fcos_Right = cos(fRadian_Right);
				double fsin_Right = sin(fRadian_Right);

				RightP1 = RightY1 + ( p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_DIAMETER_RIGHT] / 2 ) * fcos_Right;
				RightQ1 = RightX1 + ( p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_DIAMETER_RIGHT] / 2 ) * fsin_Right;

				RightP2 = RightY2 + ( p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_DIAMETER_RIGHT] / 2 ) * fcos_Right;
				RightQ2 = RightX2 + ( p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_DIAMETER_RIGHT] / 2 ) * fsin_Right;

				RightP3 = RightY3 - ( p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_DIAMETER_RIGHT] / 2 ) * fsin_Right;
				RightQ3 = RightX3 - ( p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_DIAMETER_RIGHT] / 2 ) * fcos_Right;

				// ������ ��ǥ ���ϱ�
				RightP4 = ((RightQ2 - RightQ1)*(RightP1*RightQ2 - RightP2*RightQ1) + RightP3*(RightP2 - RightP1)*(RightP2 - RightP1) + RightQ3*(RightP2 - RightP1)*(RightQ2 - RightQ1)) / ((RightP2 - RightP1)*(RightP2 - RightP1) + (RightQ2 - RightQ1)*(RightQ2 - RightQ1));

				RightQ4 = ((RightP2 - RightP1)*(RightP2*RightQ1 - RightP1*RightQ2) + RightQ3*(RightQ2 - RightQ1)*(RightQ2 - RightQ1) + RightP3*(RightP2 - RightP1)*(RightQ2 - RightQ1)) / ((RightP2 - RightP1)*(RightP2 - RightP1) + (RightQ2 - RightQ1)*(RightQ2 - RightQ1));

				// Tool Pocket ��ǥ ���ϱ�
				// 4�� ����
				ToolPoint[1][0][0] = RightQ4 + fToolPocket1PosX * fcos_Right + fToolPocket1PosY * fsin_Right;
				ToolPoint[1][0][1] = RightP4 - fToolPocket1PosX * fsin_Right + fToolPocket1PosY * fcos_Right;

				// 5�� ����
				ToolPoint[1][1][0] = RightQ4 + (fToolPocket1PosX - fToolPocketDistX) * fcos_Right + fToolPocket1PosY * fsin_Right;
				ToolPoint[1][1][1] = RightP4 - (fToolPocket1PosX - fToolPocketDistX) * fsin_Right + fToolPocket1PosY * fcos_Right;

				// 6�� ����
				ToolPoint[1][2][0] = RightQ4 + (fToolPocket1PosX - fToolPocketDistX * 2) * fcos_Right + fToolPocket1PosY * fsin_Right;
				ToolPoint[1][2][1] = RightP4 - (fToolPocket1PosX - fToolPocketDistX * 2) * fsin_Right + fToolPocket1PosY * fcos_Right;

				// 2�� ����
				SensorPoint[1][0] = RightQ4 + fSensor2XDist * fcos_Right + fSensor2YDist * fsin_Right;
				SensorPoint[1][1] = RightP4 - fSensor2XDist * fsin_Right + fSensor2YDist * fcos_Right;

				//////////////////////////////////////////////////////////////////////////
				// ������ ���� �� �ٿ�ε�. 
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL4][pa::AXIS_X] = ToolPoint[1][0][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL4][pa::AXIS_A] = ToolPoint[1][0][1];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL5][pa::AXIS_X] = ToolPoint[1][1][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL5][pa::AXIS_A] = ToolPoint[1][1][1];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL6][pa::AXIS_X] = ToolPoint[1][2][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL6][pa::AXIS_A] = ToolPoint[1][2][1];

				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_UP2][pa::AXIS_X] = SensorPoint[1][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_UP2][pa::AXIS_A] = SensorPoint[1][1];

				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_DN2][pa::AXIS_X] = SensorPoint[1][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_DN2][pa::AXIS_A] = SensorPoint[1][1];

				pa::PAMotion->WTCP( 3, 4, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL4] );
				pa::PAMotion->WTCP( 4, 5, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL5] );
				pa::PAMotion->WTCP( 5, 6, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL6] );
				pa::PAMotion->WTCP( 9, 21, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_UP2] );
				pa::PAMotion->WTCP( 10, 22, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_DN2] );
			}

// 			// tp_no�� ����ϴ� ���� �ֽ� �ڵ� 
// 			int tp_no[11] = { 1, 2, 3, 4, 5, 6, 9, 19, 20, 21, 22};
// 			for( int i = 0; i<pa::TEACHING_POINT_NUM; i++ ) 
// 			{
// 				pa::PAMotion->WTCP( i, (pa::EN_TEACHING_POINT)tp_no[i], pa::PConfig->pConfig_->fTeachingPoint[i] );
// 			}
 			//////////////////////////////////////////////////////////////////////////
 		}
		step = 53400;
		break;

	case 53400:
		strLog.Format( _T("stop. auto teaching for tool teaching") );
		writeLog_AutoCal( strLog, FALSE );

		changeRunMode( RUNMODE_STOP, TRUE );
		step = 0;
		break;
	}
	*/
}

void pa::CPThread::doAutoTeaching_ToolPocket2()		// Tray�κ� ��� ���
{
/*	static double	F_MEASURE_RESULT[3][2][2];	// ��� ��ġ ��, X/Y, Left/Right
	static int		LEFT_TOOL_NO = 0;
	static int		RIGHT_TOOL_NO = 0;
	int&	step = nStep_[RUNMODE_RUN];
	int		ntemp = 0;
	CString strLog;

	pa::SAutoTeachToolPocketParam* p = (pa::SAutoTeachToolPocketParam*)(PPAStatus->GetAutoTeachToolPocketParam());

	switch( step )
	{
	case 52000:
		strLog.Format( _T("start. auto teaching for tool pocket") );
		writeLog_AutoCal( strLog, FALSE );

		F_MEASURE_RESULT[0][0][0] = F_MEASURE_RESULT[0][1][0] = 0.0;
		F_MEASURE_RESULT[1][0][0] = F_MEASURE_RESULT[1][1][0] = 0.0;
		F_MEASURE_RESULT[2][0][0] = F_MEASURE_RESULT[2][1][0] = 0.0;
		F_MEASURE_RESULT[0][0][1] = F_MEASURE_RESULT[0][1][1] = 0.0;
		F_MEASURE_RESULT[1][0][1] = F_MEASURE_RESULT[1][1][1] = 0.0;
		F_MEASURE_RESULT[2][0][1] = F_MEASURE_RESULT[2][1][1] = 0.0;

		pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 0;
		pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable2 = 0;
		LEFT_TOOL_NO = 0;
		RIGHT_TOOL_NO = 0;
		step = 52010;
		break;

		//////////////////////////////////////////////////////////////////////////
		// ������ ���� ��´�
	case 52010:
		// Get Left tool
		if (pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[0] == 0)
		{
			step = 52030;
			break;
		}

		LEFT_TOOL_NO = p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_NUMBER_LEFT];
		if( LEFT_TOOL_NO != 0 ) 
		{
			if( LEFT_TOOL_NO == pa::PPAStatus->GetPAStatus()->nCurrentToolNo ) {
				step = 52020;	
			} else {
				step = 52011; // ���� �ٲ۴� 
			}
		}
		else 
		{
			// �� ��ȣ�� 0�̸�, �� ��� ������ ���� �ʴ´� 
			step = 52030;	// ���� ������ ���� 
		}
		break;
	case 52011:
		doAutoCal_Prepare( TRUE, LEFT_TOOL_NO );
		step = 52012;
		break;
	case 52012:
		if( doAutoCal_Prepare( FALSE, LEFT_TOOL_NO ) == TRUE ) {
			step = 52030;
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// 2017.08.22. Tool ��ȣ�� ���� ���, ���� ���� �÷��׸� Ȯ�� �Ѵ� 
	case 52020:
		if( LEFT_TOOL_NO != 0 && pa::PPAStatus->GetPAStatus()->nToolLengthUpdateFlag == 0 ) {
			step = 52022;
		} else {
			step = 52030;
		}
		break;
		SEND_CMD_MDA( step, 52022, 52024, "M207" )
		MOVE_DNE_MDA( step, 52024, 52030 )

	case 52030:
		// Get Right tool
		if (pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[1] == 0)
		{
			step = 52050;
			break;
		}

		RIGHT_TOOL_NO = p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_NUMBER_RIGHT];
		if( RIGHT_TOOL_NO != 0)
		{
			if( RIGHT_TOOL_NO == pa::PPAStatus->GetPAStatus()->nCurrentTool2No ) {
				step = 52040;
			}
			else {
				step = 52031;
			}
		}
		else
		{
			// �� ��ȣ�� 0�̸�, �� ��� ������ ���� �ʴ´�
			step = 52050;
		}
		break;
	case 52031:
		doAutoCal_Prepare( TRUE, RIGHT_TOOL_NO);
		step = 52032;
		break;
	case 52032:
		if( doAutoCal_Prepare( FALSE, RIGHT_TOOL_NO ) == TRUE ) {
			step = 52050;
		}
		break;

		/////////////////////////////////////////////////////////////////////////
		// Tool ��ȣ�� ���� ���, ���� ���� �÷��׸� Ȯ�� �Ѵ�
	case 52040:
		if( RIGHT_TOOL_NO != 0 && pa::PPAStatus->GetPAStatus()->nTool2LengthUpdateFlag == 0 ) {
			step = 52042;
		} else {
			step = 52050;
		}
		break;

		SEND_CMD_MDA( step, 52042, 52044, "M208" )
		MOVE_DNE_MDA( step, 52044, 52050 )

		//////////////////////////////////////////////////////////////////////////
		// ���� ���̺� ���� �޽��� �ڽ��� ����
		//////////////////////////////////////////////////////////////////////////
	case 52050:
		step = 52051;
		break;
// 		{
// 			CAutoCalDlg::SHOW_DLG();
// 			int sel = CAutoCalDlg::WAIT_FOR_SELECT();
// 			CAutoCalDlg::HIDE_DLG();
// 			if( sel == IDOK ) {
// 				pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 1;	// ��� ���� 
// 			} else {
// 				pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 2;	// ���� ���� 
// 			}
// 		}
// 		step = 52060;
// 		break;

	case 52051:
		CAutoCalDlg::SHOW_DLG();
		step = 52052;
		break;
	case 52052:
		{
			int sel = CAutoCalDlg::WAIT_FOR_SELECT2();
			if (sel == -1) break;
			else {
				if (sel == IDOK) {
					pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 1;
				}
				else {
					pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 2;
				}
				CAutoCalDlg::HIDE_DLG();
				step = 52053;
			}
		}
		break;
	case 52053:
		step = 52060;
		break;

		// ���� ���̺� ������ ��ٸ��� 
	case 52060:
		if( pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable != 0 ) {
			if( pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable == 1 ) {
				step = 52070;	// �۾� ���� 
			} else {
				step = 53400;	// �۾� ��� 
			}
		}

		// Left, Right �� �� Check�� �ȵ�������, �۾� ���
		if (pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[0] == 0 && pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[1] == 0)
		{
			step = 53400;	// �۾� ���
		}

		break;

		// ATC Door�� ���� 
	case 52070:
		// 		pa::PAMotion->ATCDoor( CPAMotion::OPEN );	// Blocking �� 
		// 		Sleep( 300 );
		step = 52080;
		break;

	case 52080:
		step = 52090;
		break;

		//////////////////////////////////////////////////////////////////////////
		// ���� ����
		//////////////////////////////////////////////////////////////////////////
		// ���� Pocket
	case 52090:
		// Left Check�� �ȵ�������, Right�� �Ѿ
		if (pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[0] == 0)
		{
			step = 52690;
		}

		else
		{
			step = 52100;
		}
		break;

		// Z Up
	case 52100:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z0 A%.3f B0",
			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X],
			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y],
			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_A]);
		step = 52110;
		break;
		SEND_CMD_MDA( step, 52110, 52120, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52120, 52130 )

		// P1 ���� 
	case 52130:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z0 A0 B0",
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_X1POS],
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_Y1POS] );	
		step = 52140;
		break;
		SEND_CMD_MDA( step, 52140, 52150, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52150, 52160 )

	case 52160:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 Z%.3f", p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_Z1POS] );
		step = 52170;
		break;
		SEND_CMD_MDA( step, 52170, 52180, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52180, 52190 )

		// ���� 
	case 52190:
		{ 
			PAMotion->SCAL( FALSE, 
				pa::AXIS_Y, 
				1,
				0.01, -0.001,
				100,
				(int)p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_COUNT], 
				20,
				-0.4 );
		}
		Sleep( 300 );
		step = 52200;
		break;
	case 52200:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 52210;
		}
		break;
		// ���� ��� ����
	case 52210:
		PAMotion->GET_MEASURE_RESULT();
		F_MEASURE_RESULT[0][0][0] = p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_X1POS];
		F_MEASURE_RESULT[0][1][0] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;

		strLog.Format( _T("Left point 1 = [%.4f, %.4f]"), F_MEASURE_RESULT[0][0][0], F_MEASURE_RESULT[0][1][0] );
		writeLog_AutoCal( strLog, TRUE );
		step = 52220;
		break;

		// Z Up
		SEND_CMD_MDA( step, 52220, 52230, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 52230, 52300 )

	case 52300:
		step = 52330;
		break;

		// P2 ����
	case 52330:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z0 A0 B0",
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_X1POS], 
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_Y1POS] ); 
		step = 52340;
		break;
		SEND_CMD_MDA( step, 52340, 52350, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52350, 52360 )

	case 52360:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 Z%.3f", p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_Z1POS] );
		step = 52370;
		break;
		SEND_CMD_MDA( step, 52370, 52380, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52380, 52390 )

		// ���� 
	case 52390:
		{
			PAMotion->SCAL( FALSE, 
				pa::AXIS_Y, 
				1,
				-0.01, 0.001,
				100,
				(int)p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_COUNT], 
				-20,
				0.4 );
		}
		Sleep( 300 );
		step = 52400;
		break;
	case 52400:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 52410;
		}
		break;
		// ���� ��� ���� 
	case 52410:
		PAMotion->GET_MEASURE_RESULT();
		F_MEASURE_RESULT[1][0][0] = p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_X1POS];
		F_MEASURE_RESULT[1][1][0] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		strLog.Format( _T("Left point 2 = [%.4f, %.4f]"), F_MEASURE_RESULT[1][0][0], F_MEASURE_RESULT[1][1][0] );
		writeLog_AutoCal( strLog, TRUE );
		step = 52420;
		break;

		SEND_CMD_MDA( step, 52420, 52430, "G00 G90 G53 Z0.0" )
		MOVE_DNE_MDA( step, 52430, 52500 )

		// P3 ����
	case 52500:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z0 A0 B0",
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_X1POS],
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_Y1POS] );
		step = 52510;
		break;
		SEND_CMD_MDA( step, 52510, 52520, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52520, 52530 )

	case 52530:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 Z%.3f", p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_Z1POS] );
		step = 52540;
		break;
		SEND_CMD_MDA( step, 52540, 52550, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52550, 52560 )

		// ���� 
	case 52560:
		{
			PAMotion->SCAL( FALSE, 
				pa::AXIS_X, 
				1,
				-0.01, 0.001,
				100,
				(int)p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_COUNT], 
				-20,
				0.4 );
		}
		Sleep( 300 );
		step = 52570;
		break;
	case 52570:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 52580;
		}
		break;

		// ���� ��� ���� 
	case 52580:
		PAMotion->GET_MEASURE_RESULT();
		F_MEASURE_RESULT[2][0][0] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		F_MEASURE_RESULT[2][1][0] = p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_Y1POS];
		strLog.Format( _T("Left point 3 = [%.4f, %.4f]"), F_MEASURE_RESULT[2][0][0], F_MEASURE_RESULT[2][1][0] );
		writeLog_AutoCal( strLog, TRUE );
		step = 52590;
		break;

		SEND_CMD_MDA( step, 52590, 52600, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 52600, 52610 )

		// XY-Z-AB �ʱ� ��ġ�� �̵�
	case 52610:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X0 Y0 Z0 A0 B0" ); 
		step = 52620;
		break;
		SEND_CMD_MDA( step, 52620, 52630, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52630, 52690 )

		// ������ Pocket
	case 52690:
		// Right Check�� �ȵ�������, ��� ������� �Ѿ
		if (pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[1] == 0)
		{
			step = 53300;
		}

		else
		{
			step = 52700;
		}
		break;

		// Z Up
	case 52700:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f Z0 A%.3f B0",
			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X],
			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y],
			pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_A]);
		step = 52710;
		break;
		SEND_CMD_MDA( step, 52710, 52720, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52720, 52730 )

		// P1 ����
	case 52730:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y0 Z0 A%.3f B0" ,
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_X2POS],
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_Y2POS] );
		step = 52740;
		break;
		SEND_CMD_MDA( step, 52740, 52750, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52750, 52760 )

	case 52760:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 B%.3f", p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_Z2POS] );
		step = 52770;
		break;
		SEND_CMD_MDA( step, 52770, 52780, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52780, 52790 )

	case 52790:
		{
			PAMotion->SCAL( FALSE, 
				pa::AXIS_A, 
				2,
				0.01, -0.001,
				100,
				(int)p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_COUNT], 
				20,
				-0.4 );
		}
		Sleep( 300 );
		step = 52800;
		break;
	case 52800:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 52810;
		}
		break;
		// ���� ��� ����
	case 52810:
		PAMotion->GET_MEASURE_RESULT();
		F_MEASURE_RESULT[0][0][1] = p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P1_X2POS];
		F_MEASURE_RESULT[0][1][1] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;

		strLog.Format( _T("Right point 1 = [%.4f, %.4f]"), F_MEASURE_RESULT[0][0][1], F_MEASURE_RESULT[0][1][1] );
		writeLog_AutoCal( strLog, TRUE );
		step = 52820;
		break;

		// Z Up
		SEND_CMD_MDA( step, 52820, 52830, "G00 G90 G53 B0" )
		MOVE_DNE_MDA( step, 52830, 52900 )

	case 52900:
		step = 52930;
		break;

		// P2 ����
	case 52930:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y0 Z0 A%.3f B0",
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_X2POS], 
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_Y2POS] ); 
		step = 52940;
		break;
		SEND_CMD_MDA( step, 52940, 52950, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52950, 52960 )

	case 52960:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 B%.3f", p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_Z2POS] );
		step = 52970;
		break;
		SEND_CMD_MDA( step, 52970, 52980, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 52980, 52990 )

		// ����
	case 52990:
		{
			PAMotion->SCAL( FALSE, 
				pa::AXIS_A, 
				2,
				-0.01, 0.001,
				100,
				(int)p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_COUNT], 
				-20,
				0.4 );
		}
		Sleep( 300 );
		step = 53000;
		break;
	case 53000:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 53010;
		}
		break;
		// ���� ��� ����
	case 53010:
		PAMotion->GET_MEASURE_RESULT();
		F_MEASURE_RESULT[1][0][1] = p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P2_X2POS];
		F_MEASURE_RESULT[1][1][1] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		strLog.Format( _T("Right point 2 = [%.4f, %.4f]"), F_MEASURE_RESULT[1][0][1], F_MEASURE_RESULT[1][1][1] );
		writeLog_AutoCal( strLog, TRUE );
		step = 53020;
		break;

		SEND_CMD_MDA( step, 53020, 53030, "G00 G90 G53 B0" )
		MOVE_DNE_MDA( step, 53030, 53100 )

		// P3 ����
	case 53100:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y0 Z0 A%.3f B0",
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_X2POS],
			p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_Y2POS] );
		step = 53110;
		break;
		SEND_CMD_MDA( step, 53110, 53120, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 53120, 53130 )

	case 53130:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 B%.3f", p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_Z2POS] );
		step = 53140;
		break;
		SEND_CMD_MDA( step, 53140, 53150, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 53150, 53160 )

		// ����
	case 53160:
		{
			PAMotion->SCAL( FALSE, 
				pa::AXIS_X, 
				2,
				-0.01, 0.001,
				100,
				(int)p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_COUNT],
				-20,
				0.4 );
		}
		Sleep( 300 );
		step = 53170;
		break;
	case 53170:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_SCAL, TRUE ) == TRUE ) {
			step = 53180;
		}
		break;

		// ���� ��� ����
	case 53180:
		PAMotion->GET_MEASURE_RESULT();
		F_MEASURE_RESULT[2][0][1] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		F_MEASURE_RESULT[2][1][1] = p->fParam[SAutoTeachToolPocketParam::PARAM_MEASURE_P3_Y2POS];
		strLog.Format( _T("Right point 3 = [%.4f, %.4f]"), F_MEASURE_RESULT[2][0][1], F_MEASURE_RESULT[2][1][1] );
		writeLog_AutoCal( strLog, TRUE );
		step = 53190;
		break;

		SEND_CMD_MDA( step, 53190, 53200, "G00 G90 G53 B0" )
		MOVE_DNE_MDA( step, 53200, 53210 )

		// �ʱ� ��ġ�� �̵�
	case 53210:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X0 Y0 Z0 A0 B0" );
		step = 53220;
		break;
		SEND_CMD_MDA( step, 53220, 53230, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 53230, 53300 )

		//////////////////////////////////////////////////////////////////////////
		// ��� ��� 
		//////////////////////////////////////////////////////////////////////////
	case 53300:
		{
			// ���� ��ġ 
			double fToolPocket1PosX = p->fParam[SAutoTeachToolPocketParam::PARAM_1ST_POCKET_X_DIST];
			double fToolPocket1PosY = p->fParam[SAutoTeachToolPocketParam::PARAM_1ST_POCKET_Y_DIST];
			double fToolPocket4PosX = p->fParam[SAutoTeachToolPocketParam::PARAM_4TH_POCKET_X_DIST];
			double fToolPocket4PosY = p->fParam[SAutoTeachToolPocketParam::PARAM_4TH_POCKET_Y_DIST];
			double fToolPocketDistX = p->fParam[SAutoTeachToolPocketParam::PARAM_POCKET_X_DIST];
			double fToolPocketDistY = p->fParam[SAutoTeachToolPocketParam::PARAM_POCKET_Y_DIST];

			double fSensor1XDist = p->fParam[SAutoTeachToolPocketParam::PARAM_SENSOR1_X_DIST];
			double fSensor1YDist = p->fParam[SAutoTeachToolPocketParam::PARAM_SENSOR1_Y_DIST];
			double fSensor2XDist = p->fParam[SAutoTeachToolPocketParam::PARAM_SENSOR2_X_DIST];
			double fSensor2YDist = p->fParam[SAutoTeachToolPocketParam::PARAM_SENSOR2_Y_DIST];

			double ToolPoint[2][3][2];
			double SensorPoint[2][2];

			///////////////////////////////////////////////////////////////////////////////////
			// ���� �� ���
			if ( pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[0] == 1 )
			{
				double LeftX1 = F_MEASURE_RESULT[0][0][0];
				double LeftY1 = F_MEASURE_RESULT[0][1][0];
				double LeftX2 = F_MEASURE_RESULT[1][0][0];
				double LeftY2 = F_MEASURE_RESULT[1][1][0];
				double LeftX3 = F_MEASURE_RESULT[2][0][0];
				double LeftY3 = F_MEASURE_RESULT[2][1][0];

				double LeftCenterX, LeftCenterY;
				
				// Tray �߾� ��ǥ ���ϱ�
				LeftCenterX = LeftX3 - (p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_DIAMETER_LEFT] / 2);
				LeftCenterY = (LeftY1 + LeftY2) / 2;

				// Tool Pocket ��ǥ ���ϱ�
				// 1�� ����
				ToolPoint[0][0][0] = LeftCenterX + fToolPocket1PosX;
				ToolPoint[0][0][1] = LeftCenterY + fToolPocket1PosY;

				// 2�� ����
				ToolPoint[0][1][0] = LeftCenterX + fToolPocket1PosX - fToolPocketDistX;
				ToolPoint[0][1][1] = LeftCenterY + fToolPocket1PosY;

				// 3�� ����
				ToolPoint[0][2][0] = LeftCenterX + fToolPocket1PosX - fToolPocketDistX * 2;
				ToolPoint[0][2][1] = LeftCenterY + fToolPocket1PosY;

				// 1�� ����
				SensorPoint[0][0] = LeftCenterX + fSensor1XDist;
				SensorPoint[0][1] = LeftCenterY + fSensor1YDist;

				//////////////////////////////////////////////////////////////////////////
				// ������ ���� �� �ٿ�ε�. 
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL1][pa::AXIS_X] = ToolPoint[0][0][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL1][pa::AXIS_Y] = ToolPoint[0][0][1];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL2][pa::AXIS_X] = ToolPoint[0][1][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL2][pa::AXIS_Y] = ToolPoint[0][1][1];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL3][pa::AXIS_X] = ToolPoint[0][2][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL3][pa::AXIS_Y] = ToolPoint[0][2][1];

				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_UP1][pa::AXIS_X] = SensorPoint[0][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_UP1][pa::AXIS_Y] = SensorPoint[0][1];

				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_DN1][pa::AXIS_X] = SensorPoint[0][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_DN1][pa::AXIS_Y] = SensorPoint[0][1];

				pa::PAMotion->WTCP( 0, 1, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL1] );
				pa::PAMotion->WTCP( 1, 2, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL2] );
				pa::PAMotion->WTCP( 2, 3, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL3] );
				pa::PAMotion->WTCP( 7, 19, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_UP1] );
				pa::PAMotion->WTCP( 8, 20, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_DN1] );
			}

			///////////////////////////////////////////////////////////////////////////////////
			// ������ �� ���
			if ( pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[1] == 1 )
			{
				double RightX1 = F_MEASURE_RESULT[0][0][1];
				double RightY1 = F_MEASURE_RESULT[0][1][1];
				double RightX2 = F_MEASURE_RESULT[1][0][1];
				double RightY2 = F_MEASURE_RESULT[1][1][1];
				double RightX3 = F_MEASURE_RESULT[2][0][1];
				double RightY3 = F_MEASURE_RESULT[2][1][1];

				double RightCenterX, RightCenterY;

				// Tray �߾� ��ǥ ���ϱ�
				RightCenterX = RightX3 - (p->fParam[SAutoTeachToolPocketParam::PARAM_TOOL_DIAMETER_RIGHT] / 2);
				RightCenterY = (RightY1 + RightY2) / 2;

				// Tool Pocket ��ǥ ���ϱ�
				// 4�� ����
				ToolPoint[1][0][0] = RightCenterX + fToolPocket4PosX;
				ToolPoint[1][0][1] = RightCenterY + fToolPocket4PosY;

				// 5�� ����
				ToolPoint[1][1][0] = RightCenterX + fToolPocket4PosX - fToolPocketDistX;
				ToolPoint[1][1][1] = RightCenterY + fToolPocket4PosY;

				// 6�� ����
				ToolPoint[1][2][0] = RightCenterX + fToolPocket4PosX - fToolPocketDistX * 2;
				ToolPoint[1][2][1] = RightCenterY + fToolPocket4PosY;

				// 2�� ����
				SensorPoint[1][0] = RightCenterX + fSensor2XDist;
				SensorPoint[1][1] = RightCenterY + fSensor2YDist;

				//////////////////////////////////////////////////////////////////////////
				// ������ ���� �� �ٿ�ε�. 
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL4][pa::AXIS_X] = ToolPoint[1][0][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL4][pa::AXIS_A] = ToolPoint[1][0][1];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL5][pa::AXIS_X] = ToolPoint[1][1][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL5][pa::AXIS_A] = ToolPoint[1][1][1];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL6][pa::AXIS_X] = ToolPoint[1][2][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL6][pa::AXIS_A] = ToolPoint[1][2][1];

				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_UP2][pa::AXIS_X] = SensorPoint[1][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_UP2][pa::AXIS_A] = SensorPoint[1][1];

				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_DN2][pa::AXIS_X] = SensorPoint[1][0];
				pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_DN2][pa::AXIS_A] = SensorPoint[1][1];

				pa::PAMotion->WTCP( 3, 4, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL4] );
				pa::PAMotion->WTCP( 4, 5, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL5] );
				pa::PAMotion->WTCP( 5, 6, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL6] );
				pa::PAMotion->WTCP( 9, 21, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_UP2] );
				pa::PAMotion->WTCP( 10, 22, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_SENSING_DN2] );
			}
		}
		step = 53400;
		break;

	case 53400:
		strLog.Format( _T("stop. auto teaching for tool teaching") );
		writeLog_AutoCal( strLog, FALSE );

		changeRunMode( RUNMODE_STOP, TRUE );
		step = 0;
		break;
	}
	*/
}

// Coordinate Offset �����Ϳ� 
// �� ���� ���� Offset �����͸� ����ؼ� 
// ���� Teaching Point ��� 
void pa::CPThread::doAutoTeaching_ToolPocket3()	
{
	int&	step = nStep_[RUNMODE_RUN];
	pa::SAutoTeachToolPocketParam*	param = (pa::SAutoTeachToolPocketParam*)(PPAStatus->GetAutoTeachToolPocketParam());
	pa::SConfigData*	pSCD = (pa::PConfig->pConfig_);
	CString strLog;

	switch (step)
	{
	case 52000:
		strLog.Format(_T("start. auto teaching for tool pocket (type=3)"));
		writeLog_AutoCal(strLog, FALSE);
		step = 52010;
		break;

		//////////////////////////////////////////////////////////////////////////
		// �ڵ� ��� ���� 
		//////////////////////////////////////////////////////////////////////////
	case 52010:
		step = (pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[0] == 0) ? 52100 : 52020;
		break;

		//////////////////////////////////////////////////////////////////////////
		// Left tool pocket 
	case 52020:
		// #1
		pSCD->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL1][pa::AXIS_X] = pSCD->fCoordOffset[COORD_G54][pa::AXIS_X] + param->fParam[pa::SAutoTeachToolPocketParam::PARAM_LEFT_TOOL1_X_OFFSET];
		pSCD->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL1][pa::AXIS_Y] = pSCD->fCoordOffset[COORD_G54][pa::AXIS_Y] + param->fParam[pa::SAutoTeachToolPocketParam::PARAM_LEFT_TOOL1_Y_OFFSET];
		// #2
		pSCD->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL2][pa::AXIS_X] = pSCD->fCoordOffset[COORD_G54][pa::AXIS_X] + param->fParam[pa::SAutoTeachToolPocketParam::PARAM_LEFT_TOOL2_X_OFFSET];
		pSCD->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL2][pa::AXIS_Y] = pSCD->fCoordOffset[COORD_G54][pa::AXIS_Y] + param->fParam[pa::SAutoTeachToolPocketParam::PARAM_LEFT_TOOL2_Y_OFFSET];
		// #3 
		pSCD->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL3][pa::AXIS_X] = pSCD->fCoordOffset[COORD_G54][pa::AXIS_X] + param->fParam[pa::SAutoTeachToolPocketParam::PARAM_LEFT_TOOL3_X_OFFSET];
		pSCD->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL3][pa::AXIS_Y] = pSCD->fCoordOffset[COORD_G54][pa::AXIS_Y] + param->fParam[pa::SAutoTeachToolPocketParam::PARAM_LEFT_TOOL3_Y_OFFSET];

		pa::PAMotion->WTCP(0, 1, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL1]);
		pa::PAMotion->WTCP(1, 2, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL2]);
		pa::PAMotion->WTCP(2, 3, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_LEFT_TOOL3]);

		step = 52100;
		break;

		//////////////////////////////////////////////////////////////////////////
		// Right tool pocket 
	case 52100:
		step = (pa::PPAStatus->GetThreadState()->nAutoTeach_CheckingItem[1] == 0) ? 52200 : 52110;
		break;

	case 52110:
		// #4 
		pSCD->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL4][pa::AXIS_X] = pSCD->fCoordOffset[COORD_G54][pa::AXIS_X] + param->fParam[pa::SAutoTeachToolPocketParam::PARAM_RIGHT_TOOL4_X_OFFSET] + pSCD->fOptionData[pa::OPTION_SPINDLE_OFFSET];
		pSCD->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL4][pa::AXIS_A] = pSCD->fCoordOffset[COORD_G54][pa::AXIS_A] + param->fParam[pa::SAutoTeachToolPocketParam::PARAM_RIGHT_TOOL4_Y_OFFSET];
		// #5 
		pSCD->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL5][pa::AXIS_X] = pSCD->fCoordOffset[COORD_G54][pa::AXIS_X] + param->fParam[pa::SAutoTeachToolPocketParam::PARAM_RIGHT_TOOL5_X_OFFSET] + pSCD->fOptionData[pa::OPTION_SPINDLE_OFFSET];
		pSCD->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL5][pa::AXIS_A] = pSCD->fCoordOffset[COORD_G54][pa::AXIS_A] + param->fParam[pa::SAutoTeachToolPocketParam::PARAM_RIGHT_TOOL5_Y_OFFSET];
		// #6 
		pSCD->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL6][pa::AXIS_X] = pSCD->fCoordOffset[COORD_G54][pa::AXIS_X] + param->fParam[pa::SAutoTeachToolPocketParam::PARAM_RIGHT_TOOL6_X_OFFSET] + pSCD->fOptionData[pa::OPTION_SPINDLE_OFFSET];
		pSCD->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL6][pa::AXIS_A] = pSCD->fCoordOffset[COORD_G54][pa::AXIS_A] + param->fParam[pa::SAutoTeachToolPocketParam::PARAM_RIGHT_TOOL6_Y_OFFSET];

		pa::PAMotion->WTCP(3, 4, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL4]);
		pa::PAMotion->WTCP(4, 5, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL5]);
		pa::PAMotion->WTCP(5, 6, pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_RIGHT_TOOL6]);

		step = 52200;
		break;

		//////////////////////////////////////////////////////////////////////////
		// ���� 
	case 52200:
		strLog.Format(_T("stop. auto teaching for tool teaching (type=3)"));
		writeLog_AutoCal(strLog, FALSE);
		changeRunMode(RUNMODE_STOP, TRUE);
		step = 0;
		break;
	}
}

BOOL pa::CPThread::getCrossPoint( double A1[2], double A2[2], double B1[2], double Ret[2] )
{
	double B2[2] = { 0.0, 0.0 };
	double m = ( A1[0] - A2[0] ) / ( A1[1] - A2[1] );
	double dx= 10.0;

	B2[0] = B1[0] + dx;
	B2[1] = m * ( B1[0] + dx ) + ( B1[1] - m * B1[0] );

	//////////////////////////////////////////////////////////////////////////

	double t;
	double s;
	double under = (B2[1] - B1[1]) * (A2[0] - A1[0]) - (B2[0] - B1[0]) * (A2[1] - A1[1]);

	if( under == 0.0 ) return FALSE;

	double _t = (B2[0] - B1[0]) * (A1[1] - B1[1]) - (B2[1] - B1[1]) * (A1[0] - B1[0]);
	double _s = (A2[0] - A1[0]) * (A1[1] - B1[1]) - (A2[1] - A1[1]) * (A1[0] - B1[0]);

	t = _t / under;
	s = _s / under;

	// �μ����� ���, �Ʒ� ������ �����Ѵ� 
	// �����̱� ������ �Ʒ� ������ �������� �ʴ´� 
	// 	if( t<0.0 || t>0.0 || s<0.0 || s>1.0 ) return false;
	if( _t==0.0 && _s==0.0 ) return FALSE;

	Ret[0] = A1[0] + t * (A2[0] - A1[0]);
	Ret[1] = A1[1] + t * (A2[1] - A1[1]);

	return TRUE;
}

//////////////////////////////////////////////////////////////////////////
// 56000 < step < 58000 
void pa::CPThread::doAutoTeaching_MultiOrigin()
{
	static int TOOL_NO = 0;
	static int NUM_OBJECT = 0;
	static int CUR_OBJECT = 0;

	int&	step = nStep_[RUNMODE_RUN];
	int		ntemp=  0;
	CString strLog;

	//////////////////////////////////////////////////////////////////////////
// 	static int PREV_STEP_NO = -1;
// 	if( PREV_STEP_NO != step ) {
// 		PREV_STEP_NO = step;
// 		CString strLog;
// 		strLog.Format( _T("doAutoTeaching_MultiOrigin step = %d"), step );
// 		writeLog_ErrMsg( strLog );
// 	}
	//////////////////////////////////////////////////////////////////////////

	pa::SAutoTeachMultiOrgParam* p = pa::PPAStatus->GetAutoTeachMultiIOrgParam();

	switch( step )
	{
	case 56000:
		strLog.Format( _T("start. auto teaching for multi origin") );
		writeLog_AutoCal( strLog, FALSE );

		NUM_OBJECT = pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_NumRoundBar;
		CUR_OBJECT = 0;
		TOOL_NO = 0;
		pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 0;
		//////////////////////////////////////////////////////////////////////////
		// upload g54 coordinate offset
// 		for( int i = 0; i<pa::COORD_NUM; i++ ) {
// 			pa::PAMotion->RCFG( (pa::EN_COORDINATE)i );
// 			Sleep( 10 );
// 		}
		//////////////////////////////////////////////////////////////////////////
		step = 56010;
		break;

		//////////////////////////////////////////////////////////////////////////
		// ������ ���� ��´� 
		//////////////////////////////////////////////////////////////////////////
	case 56010:
		TOOL_NO = (int)p->fParam[pa::SAutoTeachMultiOrgParam::PARAM_TOOL_NO];
		if( TOOL_NO == pa::PPAStatus->GetPAStatus()->nCurrentToolNo ) {
			step = 56040;	//
		} else {
			step = 56020;	// ���� �ٲ۴� 
		}
		break;
	case 56020:
		doAutoCal_Prepare( TRUE, TOOL_NO );
		step = 56030;
		break;
	case 56030:
		if( doAutoCal_Prepare( FALSE, TOOL_NO ) == TRUE ) {
		//	step = 56100;
			step = 56050;
		} 
		break;

		//////////////////////////////////////////////////////////////////////////
		// 2017.08.22. Tool ��ȣ�� ���� ���, ���� ���� �÷��׸� Ȯ�� �Ѵ� 
	case 56040:
		if( pa::PPAStatus->GetPAStatus()->nToolLengthUpdateFlag == 0 ) {
			step = 56042;
		} else {
			step = 56050;
		}
		break;
		SEND_CMD_MDA( step, 56042, 56044, "M207" )
		MOVE_DNE_MDA( step, 56044, 56050 )

		//////////////////////////////////////////////////////////////////////////
		// upload coordinate offset 
	case 56050:
		for( int i = 0; i<pa::COORD_NUM; i++ )
		{
			pa::PAMotion->RCFG( (pa::EN_COORDINATE)i );
			Sleep( 100 );
		}
		step = 56100;
		break;
		//////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////
		// ��� ��ġ�� �̵� - G54 ���� 
		//////////////////////////////////////////////////////////////////////////

		SEND_CMD_MDA( step, 56100, 56110, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 56110, 56120 )

	case 56120:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X0 Y0 A0 B0" );
		step = 56130;
		break;

		SEND_CMD_MDA( step, 56130, 56140, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 56140, 56200 )

		//////////////////////////////////////////////////////////////////////////
		// ���̺� ���� �޽��� �ڽ��� ���� 
		//////////////////////////////////////////////////////////////////////////
	case 56200:
		step = 56201;
		break;
// 		{
// #ifdef _WRITE_LOG_PA_COMMAND_
// 			pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 1;
// #else 
// 			CAutoCalDlg::SHOW_DLG();
// 			int sel = CAutoCalDlg::WAIT_FOR_SELECT();
// 			CAutoCalDlg::HIDE_DLG();
// 			if( sel == IDOK ) {
// 				pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 1;	// ��� ���� 
// 			} else {
// 				pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 2;	// ���� ���� 
// 			}
// #endif 
// 		}
// 		step = 56210;
// 		break;

	case 56201:
		CAutoCalDlg::SHOW_DLG();
		step = 56202;
		break;
	case 56202:
		{
			int sel = CAutoCalDlg::WAIT_FOR_SELECT2();
			if (sel == -1) break;
			else {
				if (sel == IDOK) {
					pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 1;
				}
				else {
					pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 2;
				}
				CAutoCalDlg::HIDE_DLG();
				step = 56203;
			}
		}
		break;
	case 56203:
		step = 56210;
		break;

		// ���� ���̺� ������ ��ٸ��� 
	case 56210:
		if( pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable != 0 ) {
			if( pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable == 1 ) {
				step = 56300;	// �۾� ���� 
			} else {
				step = 56900;	// �۾� ��� 
			}
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// ���� ���� 
		//////////////////////////////////////////////////////////////////////////
	case 56300:
		if( CUR_OBJECT >= NUM_OBJECT ) {
			step = 56900;	// ���� 
		} else {
			step = 56400;
		}
		break;

	case 56400:
		if( pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[CUR_OBJECT] != 0 ) {
			step = 56500;
		} else {
			step = 56600;
		}
		break;

	case 56500:
// 		strLog.Format( _T("start measure : coordinate(%d) - object(%d)"), pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_CoordinateNo+1, CUR_OBJECT+1 );
// 		writeLog_AutoCal( strLog, FALSE );
// 		measure_RoundBar( TRUE, pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_CoordinateNo, CUR_OBJECT );
		strLog.Format( _T("start measure : coord_index(%d) - coordinate(%d) - object(%d)"),
			pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_CoordIndex+1, 
			pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_CoordinateNo, 
			CUR_OBJECT+1 );
		writeLog_AutoCal( strLog, FALSE );
		measure_RoundBar( 
			TRUE, 
			pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_CoordIndex,
			pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_CoordinateNo, 
			CUR_OBJECT );
		step = 56510;
		break;
	case 56510:
		if( measure_RoundBar( 
				FALSE, 
				pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_CoordIndex,
				pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_CoordinateNo, 
				CUR_OBJECT ) == TRUE ) 
		{
			strLog.Format( _T("stop measure") );
			writeLog_AutoCal( strLog, FALSE );
			step = 56600;
			pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[CUR_OBJECT] = 0;	// �۾��� ��������, 0���� ����� 
		}
		break;

	case 56600:
		CUR_OBJECT += 1;
		if( CUR_OBJECT < NUM_OBJECT ) {
			step = 56300;
		} else {
			step = 56900;
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// X,Y,Z ���� �������� �̵� 
		SEND_CMD_MDA( step, 56900, 56910, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 56910, 56920 )

		SEND_CMD_MDA( step, 56920, 56930, "G00 G90 G53 X0 Y0" )
		MOVE_DNE_MDA( step, 56930, 56940 )

		//////////////////////////////////////////////////////////////////////////
		// ����. ������ ������ ����ڰ�...  
	case 56940:
		strLog.Format( _T("stop. auto teaching for multi origin") );
		writeLog_AutoCal( strLog, FALSE );
		step = 56950;
		break;

		//////////////////////////////////////////////////////////////////////////
		// 2016.12.19 
		//	- ���� �Ϸ� ��, ���� ������ ���� 
	case 56950:
		strLog.Format( _T("save. auto teaching for multi origin result") );
		writeLog_AutoCal( strLog, FALSE );
// 		pa::PPAStatus->GetMultiOriginData()->Save( MULTIORIGIN_FILE_PATH );
		pa::PPAStatus->GetMultiOriginData()->Save( INI_MULTI_ORIGIN_CONFIG_PATH );
		step = 56960;
		break;
		//////////////////////////////////////////////////////////////////////////

	case 56960:
		changeRunMode( RUNMODE_STOP, TRUE );
		step = 0;
		break;
	}
}

// 2018.08.21 
//	- coordno ������ �Ѿ���� �����Ϳ� ���ؼ�,
//	- ó�� ����� ������ �ش� 
//	- 57, 56, 55�� ���� ��Ĵ�� ���� ���� ���� 
//	- 59, 58�� ���� �߰��Ǵ� ���� ���� ���� 

BOOL pa::CPThread::measure_RoundBar( BOOL bResetStep, int coord_index, int coord_no, int objectno )
{
	static int step = 0;
	static double fTemp[2];
	static double fXOffset, fYOffset, fZOffset;
	static double fObjectDiameter;
	pa::SMultiOriginData*			pMultiOriginData = pa::PPAStatus->GetMultiOriginData();
	pa::SAutoTeachMultiOrgParam*	p = pa::PPAStatus->GetAutoTeachMultiOrgParam();
	CString strLog;

	step = ( bResetStep == TRUE ) ? 1 : step;

	//////////////////////////////////////////////////////////////////////////
// 	static int PREV_STEP_NO = -1;
// 	if( PREV_STEP_NO != step ) {
// 		PREV_STEP_NO = step;
// 		CString strLog;
// 		strLog.Format( _T("measure_RoundBar step = %d"), step );
// 		writeLog_ErrMsg( strLog );
// 	}
	//////////////////////////////////////////////////////////////////////////

	switch( step )
	{
	case 0: break;
	case 1:
		fTemp[0] = fTemp[1] = 0.0;
		fXOffset = fYOffset = fZOffset = 0.0;
		step = 10;
		break;

		// Z-Up
		SEND_CMD_MDA( step, 10, 20, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 20, 50 )

		//////////////////////////////////////////////////////////////////////////
		//
		//////////////////////////////////////////////////////////////////////////
	case 50:
		switch( coord_no )
		{
		case 57: // [H] D-Type
		case 56: // [H] R-Type
		case 55: // [H] Single 
			step = 100;
			break;
		case 59: // [V] D-Type
		case 58: // [V] R-Type 
			step = 2000;
			break;
		default:
			step = 0;
			break;
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// X�� ���� 
		//////////////////////////////////////////////////////////////////////////
	case 100:
		{
			strLog.Format( _T("x-axis") );
			writeLog_AutoCal( strLog, TRUE );

			double fXPos = 0.0;
			double fYPos = 0.0;
			fXPos = pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][0] 
					+ ( p->fParam[SAutoTeachMultiOrgParam::PARAM_ROUNDBAR_DIAMETER] / 2.0 )
					+ ( p->fParam[SAutoTeachMultiOrgParam::PARAM_H_MEASURE_OFFSET_XAXIS] );
			double fBasePos = pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][1];
			double fTempOffset	= 0.0;
		//	switch( coord_index )
		//	{
		//	default:
		//	case 0: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G57]; break;
		//	case 1: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G56]; break;
		//	case 2: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G55]; break;	// 2016.10.12 Single Abutment ��� �߰� 
		//	}
			switch( coord_no )
			{
			default:
			case 57: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G57]; break;
			case 56: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G56]; break;
			case 55: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G55]; break;	// 2016.10.12 Single Abutment ��� �߰�
			}
			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) 
			{
				fYPos = fBasePos + fTempOffset;
			}
			else
			{
				fYPos = fBasePos - fTempOffset; 
			}

			sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f", fXPos, fYPos );
		}
		step = 110;
		break;
		
		SEND_CMD_MDA( step, 110, 120, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 120, 130 )
	
	case 130:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", 
			p->fParam[SAutoTeachMultiOrgParam::PARAM_H_ZPOS_FOR_XAXIS] );
		step = 140;
		break;

		SEND_CMD_MDA( step, 140, 150, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 150, 160 )

		// X- �������� ���� 
	case 160:
		{
			int		measure_count = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MEASURE_COUNT];
			double	f1st_max_distance	= p->fParam[SAutoTeachMultiOrgParam::PARAM_1ST_MAX_DISTANCE] * -1.0;
			double	f2nd_measure_offset	= p->fParam[SAutoTeachMultiOrgParam::PARAM_2ST_MEASURE_OFFSET];
			int		move_spd = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MOVESPEED_FOR_MEAS_POS];
			
			PAMotion->DO_MEASURE( FALSE,
				pa::AXIS_X,
				-0.01, 0.001, 
				move_spd, 
				measure_count,
				f1st_max_distance,
				f2nd_measure_offset );
		}
		Sleep( 300 );
		step = 170;
		break;
	case 170:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
			step = 180;
		}
		break;
		// ���� ��� ����
	case 180:
		PAMotion->GET_MEASURE_RESULT();
		fTemp[0] = TO_G54( pa::AXIS_X, CPAAsyncComm::F_TEMP_MEASURE_RESULT );
		fTemp[0] -= ( p->fParam[pa::SAutoTeachMultiOrgParam::PARAM_TOOL_DIAMETER] / 2.0 );
		strLog.Format( _T("x-axis result #1 : %.5f"), fTemp[0] );
		writeLog_AutoCal( strLog, TRUE );
		step = 190;
		break;

		SEND_CMD_MDA( step, 190, 200, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 200, 210 )

	case 210:
		{
			double fXPos = 0.0;
			double fYPos = 0.0;
			fXPos = pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][0] 
				- ( p->fParam[SAutoTeachMultiOrgParam::PARAM_ROUNDBAR_DIAMETER] / 2.0 )
				- ( p->fParam[SAutoTeachMultiOrgParam::PARAM_H_MEASURE_OFFSET_XAXIS] );

			double fBasePos = pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][1];
			double fTempOffset	= 0.0;
// 			switch( coord_index )
// 			{
// 			default:
// 			case 0: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G57]; break;
// 			case 1: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G56]; break;
// 			case 2: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G55]; break;	// 2016.10.12 Single Abutment ��� �߰� 
// 			}
			switch( coord_no )
			{
			default:
			case 57: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G57]; break;
			case 56: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G56]; break;
			case 55: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G55]; break;
			}
			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) 
			{
				fYPos = fBasePos + fTempOffset;
			}
			else
			{
				fYPos = fBasePos - fTempOffset; 
			}

			sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f", fXPos, fYPos );
		}
		step = 220;
		break;

		SEND_CMD_MDA( step, 220, 230, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 230, 240 )

	case 240:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f",
			p->fParam[SAutoTeachMultiOrgParam::PARAM_H_ZPOS_FOR_XAXIS] );
		step = 250;
		break;

		SEND_CMD_MDA( step, 250, 260, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 260, 270 )

		// X+ �������� ���� 
	case 270:
		{
			int		measure_count = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MEASURE_COUNT];
			double	f1st_max_distance	= p->fParam[SAutoTeachMultiOrgParam::PARAM_1ST_MAX_DISTANCE];
			double	f2nd_measure_offset	= p->fParam[SAutoTeachMultiOrgParam::PARAM_2ST_MEASURE_OFFSET] * -1.0;
			int		move_spd = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MOVESPEED_FOR_MEAS_POS];

			PAMotion->DO_MEASURE( FALSE,
				pa::AXIS_X,
				0.01, -0.001, 
				move_spd, 
				measure_count,
				f1st_max_distance,
				f2nd_measure_offset );
		}
		Sleep( 300 );
		step = 280;
		break;
	case 280:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
			step = 290;
		}
		break;
		// ���� ��� ����
	case 290:
		PAMotion->GET_MEASURE_RESULT();
		fTemp[1] = TO_G54( pa::AXIS_X, CPAAsyncComm::F_TEMP_MEASURE_RESULT );
		fTemp[1] += ( p->fParam[pa::SAutoTeachMultiOrgParam::PARAM_TOOL_DIAMETER] / 2.0 );
		strLog.Format( _T("x-axis result #2 : %.5f"), fTemp[1] );
		writeLog_AutoCal( strLog, TRUE );
		// ȯ���� ���� ��� 
		fObjectDiameter = fabs(fTemp[0] - fTemp[1]);
		strLog.Format( _T("round bar's diameter is %.4f"), fObjectDiameter );
		writeLog_AutoCal( strLog, TRUE );
		step = 300;
		break;

		SEND_CMD_MDA( step, 300, 310, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 310, 320 )

	case 320:
		fXOffset = ( fTemp[0] + fTemp[1] ) / 2.0;
		strLog.Format( _T("x-axis result = %.4f"), fXOffset );
		writeLog_AutoCal( strLog, TRUE );
		step = 400;

		//////////////////////////////////////////////////////////////////////////
		// 2016.08.25. �� ���� ���ؼ� ���� ���̸� ���� 
		if( fabs(fTemp[0]-fTemp[1]) < 0.001 )
		{
			throw CPException( ERR_PNC, PNC_ERR_MEASURE_RETURN_SAME_DATA, _T("do_measure return same data") );
		}
		//////////////////////////////////////////////////////////////////////////
		break;

		//////////////////////////////////////////////////////////////////////////
		// Y�� ���� 
		//	- X�� ���� ��ġ�� Y�� ���� +Offset ��ġ, Z�� ���� ��ġ���� �����Ѵ� 
		//////////////////////////////////////////////////////////////////////////
	case 400:
		{
			strLog.Format( _T("y-axis") );
			writeLog_AutoCal( strLog, TRUE );

			double	fYPos = 0.0;

			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) {
				fYPos = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_MEASURE_BASEPOS_YAXIS] + p->fParam[SAutoTeachMultiOrgParam::PARAM_H_MEASURE_OFFSET_YAXIS];
			} else {
				fYPos = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_MEASURE_BASEPOS_YAXIS]*-1.0 - p->fParam[SAutoTeachMultiOrgParam::PARAM_H_MEASURE_OFFSET_YAXIS];
			}

			sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f", fXOffset, fYPos );
		}
		step = 410;
		break;

		SEND_CMD_MDA( step, 410, 420, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 420, 430 )

	case 430:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", p->fParam[SAutoTeachMultiOrgParam::PARAM_H_ZPOS_FOR_YAXIS] );
		step = 440;
		break;

		SEND_CMD_MDA( step, 440, 450, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 450, 460 )
		
	case 460:
		{
			double	fApproach = 0.0;
			double	fBack = 0.0;
			int		measure_count = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MEASURE_COUNT];
			double	f1st_max_distance	= p->fParam[SAutoTeachMultiOrgParam::PARAM_1ST_MAX_DISTANCE];
			double	f2nd_measure_offset	= p->fParam[SAutoTeachMultiOrgParam::PARAM_2ST_MEASURE_OFFSET];
			int		move_spd = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MOVESPEED_FOR_MEAS_POS];

			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) {
				// - ���� ���� 
				fApproach = -0.01;
				fBack = 0.001;
				f1st_max_distance *= -1.0;
			} else {
				// + ���� ���� 
				fApproach = 0.01;
				fBack = -0.001;
				f2nd_measure_offset *= -1.0;	// 2017.06.17 ���� ���� "="�� ���� �־��� 
			}

			PAMotion->DO_MEASURE( FALSE,
				pa::AXIS_Y, 
				fApproach, 
				fBack, 
				move_spd, 
				measure_count,
				f1st_max_distance, 
				f2nd_measure_offset );
		}
		Sleep( 300 );
		step = 470;
		break;
	case 470:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
			step = 480;
		}
		break;
		// ���� ��� ���� 
	case 480:
		PAMotion->GET_MEASURE_RESULT();

		fYOffset = TO_G54( pa::AXIS_Y, CPAAsyncComm::F_TEMP_MEASURE_RESULT );

		if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) {
			fYOffset -= ( p->fParam[SAutoTeachMultiOrgParam::PARAM_TOOL_DIAMETER] / 2.0 );
		} else {
			fYOffset += ( p->fParam[SAutoTeachMultiOrgParam::PARAM_TOOL_DIAMETER] / 2.0 );
		}

		strLog.Format( _T("y-axis result = %.5f"), fYOffset );
		writeLog_AutoCal( strLog, TRUE );
		step = 490;
		break;

		SEND_CMD_MDA( step, 490, 500, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 500, 600 )


		//////////////////////////////////////////////////////////////////////////
		// Z�� ���� 
		//	- X�� ���� ��ġ ��� 
		//////////////////////////////////////////////////////////////////////////
	case 600:
		{
			strLog.Format( _T("z-axis") );
			writeLog_AutoCal( strLog, TRUE );

			double fYPos = 0.0;
			double fBasePos = pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][1];
			double fTempOffset = 0.0;
// 			switch( coord_index )
// 			{
// 			default:
// 			case 0: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G57]; break;
// 			case 1: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G56]; break;
// 			case 2: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G55]; break;	// 2016.10.12 Single Abutment ��� �߰� 
// 			}
			switch( coord_no )
			{
			default:
			case 57: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G57]; break;
			case 56: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G56]; break;
			case 55: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_H_YPOS_FOR_XZAXIS_G55]; break;
			}

			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) {
				fYPos = fBasePos + fTempOffset;
			} else {
				fYPos = fBasePos - fTempOffset;
			}

			sprintf_s( szCommandBuffer_, 256, 
				"G00 G90 G54 X%.3f Y%.3f", 
				fXOffset, fYPos );
		}
		step = 610;
		break;

		SEND_CMD_MDA( step, 610, 620, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 620, 640 )

	case 640:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", p->fParam[SAutoTeachMultiOrgParam::PARAM_H_ZPOS_FOR_ZAXIS] );
		step = 650;
		break;

		SEND_CMD_MDA( step, 650, 660, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 660, 670 )

		// Z�� ���� 
	case 670:
		{
			double	fApproach = -0.01;
			double	fBack = 0.001;
			int		measure_count = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MEASURE_COUNT];
			double	f1st_max_distance	= p->fParam[SAutoTeachMultiOrgParam::PARAM_1ST_MAX_DISTANCE] * -1.0;
			double	f2nd_measure_offset	= p->fParam[SAutoTeachMultiOrgParam::PARAM_2ST_MEASURE_OFFSET];
			int		move_spd = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MOVESPEED_FOR_MEAS_POS];

			PAMotion->DO_MEASURE(
				FALSE, pa::AXIS_Z, fApproach, fBack, 
				move_spd, measure_count, f1st_max_distance, f2nd_measure_offset );
		}
		step = 680;
		break;
	case 680:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
			step = 690;
		}
		break;
		// ���� ��� ���� 
	case 690:
		PAMotion->GET_MEASURE_RESULT();

		fZOffset = TO_G54(pa::AXIS_Z, CPAAsyncComm::F_TEMP_MEASURE_RESULT);

		strLog.Format( _T("z-axis result = %.5f"), fZOffset );
		writeLog_AutoCal( strLog, TRUE );
		step = 700;
		break;

		SEND_CMD_MDA( step, 700, 710, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 710, 1000 )

		//////////////////////////////////////////////////////////////////////////
		// ���� ����� hMeasure... �� ���� 
		//////////////////////////////////////////////////////////////////////////
	case 1000:
		{
			double fdX = fXOffset - pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][0];
			double fdY = 0.0;
			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) {
				fdY = fYOffset - ( p->fParam[SAutoTeachMultiOrgParam::PARAM_H_MEASURE_BASEPOS_YAXIS] );
			} else {
				fdY = fYOffset - ( p->fParam[SAutoTeachMultiOrgParam::PARAM_H_MEASURE_BASEPOS_YAXIS] * -1.0 );
			}
			double fdZ = fZOffset - ( fObjectDiameter / 2.0 );

			strLog.Format( _T("x-offset = %.5f"), fdX ); writeLog_AutoCal( strLog, TRUE );
			strLog.Format( _T("y-offset = %.5f"), fdY ); writeLog_AutoCal( strLog, TRUE );
			strLog.Format( _T("z-offset = %.5f"), fdZ ); writeLog_AutoCal( strLog, TRUE );

			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == TRUE ) {
				fdX *= -1.0;
				fdY *= -1.0;
			}

			//////////////////////////////////////////////////////////////////////////
			// 2017.04.27 
			// �� ��ǥ���� ������ Ȯ�� �Ѵ� 
			{
				double	fMin = pMultiOriginData->fOffset_Min_;
				double	fMax = pMultiOriginData->fOffset_Max_;
				BOOL	bError = FALSE;
				CString	strErrMsg;
				CString strTemp;
				strErrMsg.Format( _T("") );
				if( fdX < fMin || fdX > fMax ) {
					bError = TRUE;
					strTemp.Format( _T("X-Axis (%.3f. %.3f~%.3f)\n"), fdX, fMin, fMax );
					strErrMsg += strTemp;
				}
				if( fdY < fMin || fdY > fMax ) {
					bError = TRUE;
					strTemp.Format( _T("Y-Axis (%.3f. %.3f~%.3f)\n"), fdY, fMin, fMax );
					strErrMsg += strTemp;
				}
				if( fdZ < fMin || fdZ > fMax ) {
					bError = TRUE;
					strTemp.Format( _T("Z-Axis (%.3f. %.3f~%.3f)\n"), fdZ, fMin, fMax );
					strErrMsg += strTemp;
				}
				if( bError == TRUE ) {
					strTemp.Format( _T("RB[%d]\n"), objectno+1 ); 
					strErrMsg = strTemp + strErrMsg;
				}
				
				if( bError == TRUE ) 
				{
					throw CPException( ERR_PNC, PNC_ERR_MULTIORG_RESULT_OUTOFRANGE, (LPCTSTR)strErrMsg );
				}
			}
			//////////////////////////////////////////////////////////////////////////

			pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][3] = fdX;
			pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][4] = fdY;
			pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][5] = fdZ;
		}
		// ���� 
		step = 0;
		break;

		//////////////////////////////////////////////////////////////////////////
		// 2018.08.21 
		//	- ���� Ÿ�� ���� ���� ��� �߰� 
		//	- G59(D-Type), G58(R-Type) ��� 
		//	- 1-5�� ������ 6-10�� ������ Z�� ��ġ�� ZAxis_Reverse_Offset �� �����ؾ� �Ѵ� 
		//////////////////////////////////////////////////////////////////////////
	case 2000:
		step = 2100;
		//////////////////////////////////////////////////////////////////////////
		// Y�� ���� 
		//////////////////////////////////////////////////////////////////////////
	case 2100:
		{
			strLog.Format( _T("y-axis") );
			writeLog_AutoCal( strLog, TRUE );

			double fXPos = 0.0;
			double fYPos = 0.0;
			fYPos = pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][1]
				+ ( p->fParam[SAutoTeachMultiOrgParam::PARAM_ROUNDBAR_DIAMETER] / 2.0 )
				+ ( p->fParam[SAutoTeachMultiOrgParam::PARAM_V_MEASURE_OFFSET_YAXIS] );
			double fBasePos = pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][0];
			double fTempOffset = 0.0;
// 			switch( coord_index )
// 			{
// 			default:
// 			case 3: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_XPOS_FOR_YZAXIS_G59]; break;	// ���� D-Type
// 			case 4: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_XPOS_FOR_YZAXIS_G58]; break;	// ���� R-Type 
// 			}
			switch( coord_no )
			{
			default:
			case 59: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_XPOS_FOR_YZAXIS_G59]; break;	// ���� D-Type
			case 58: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_XPOS_FOR_YZAXIS_G58]; break;	// ���� D-Type
			}
			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) 
			{
				fXPos = fBasePos + fTempOffset;
			}
			else 
			{
				fXPos = fBasePos - fTempOffset;
			}

			sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f", fXPos, fYPos );
		}
		step = 2110;
		break;

		SEND_CMD_MDA( step, 2110, 2120, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 2120, 2130 )

		// Z�� �ٿ� 
	case 2130:
		{
			double	fZPos = 0.0;
			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) {
				fZPos = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_ZPOS_FOR_YAXIS];
			} else {
				fZPos = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_ZPOS_FOR_YAXIS_REVERSE];
			}
	 		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", fZPos );
		}
		step = 2140;
		break;

		SEND_CMD_MDA( step, 2140, 2150, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 2150, 2160 )

		// Y�� - �������� ���� 
	case 2160:
		{
			int		measure_count = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MEASURE_COUNT];
			double	f1st_max_distabce	= p->fParam[SAutoTeachMultiOrgParam::PARAM_1ST_MAX_DISTANCE] * -1.0;
			double	f2st_measure_offset	= p->fParam[SAutoTeachMultiOrgParam::PARAM_2ST_MEASURE_OFFSET];
			int		move_spd = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MOVESPEED_FOR_MEAS_POS];

			PAMotion->DO_MEASURE( FALSE, 
				pa::AXIS_Y, 
				-0.01, 0.001,	// ���� ���� ���� 
				move_spd, 
				measure_count, 
				f1st_max_distabce, 
				f2st_measure_offset );
		}
		Sleep( 300 );
		step = 2170;
		break;
	case 2170:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
			step = 2180;
		}
		break;
		// ���� ��� ���� 
	case 2180:
		PAMotion->GET_MEASURE_RESULT();
		fTemp[0] = TO_G54( pa::AXIS_Y, CPAAsyncComm::F_TEMP_MEASURE_RESULT );
		fTemp[0] -= ( p->fParam[SAutoTeachMultiOrgParam::PARAM_TOOL_DIAMETER] / 2.0 );
		strLog.Format( _T("y-axis result #1 : %.5f"), fTemp[0] );
		writeLog_AutoCal( strLog, TRUE );
		step = 2190;
		break;

		SEND_CMD_MDA( step, 2190, 2200, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 2200, 2210 )

	case 2210:
		{
			double fXPos = 0.0;
			double fYPos = 0.0;
			fYPos = pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][1]
				- ( p->fParam[SAutoTeachMultiOrgParam::PARAM_ROUNDBAR_DIAMETER] / 2.0 )
				- ( p->fParam[SAutoTeachMultiOrgParam::PARAM_V_MEASURE_OFFSET_YAXIS] );
			double fBasePos = pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][0];
			double fTempOffset = 0.0;
// 			switch( coord_index )
// 			{
// 			default:
// 			case 3: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_XPOS_FOR_YZAXIS_G59]; break;	// ���� D-Type 
// 			case 4: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_XPOS_FOR_YZAXIS_G58]; break;	// ���� R-Type 
// 			}
			switch( coord_no )
			{
			default:
			case 59: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_XPOS_FOR_YZAXIS_G59]; break;	// ���� D-Type
			case 58: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_XPOS_FOR_YZAXIS_G58]; break;	// ���� D-Type
			}
			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE )
			{
				fXPos = fBasePos + fTempOffset;
			}
			else 
			{
				fXPos = fBasePos - fTempOffset;
			}

			sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f", fXPos, fYPos );
		}
		step = 2220;
		break;

		SEND_CMD_MDA( step, 2220, 2230, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 2230, 2240 )

		// Z�� �ٿ� 
	case 2240:
		{
			double	fZPos = 0.0;
			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) {
				fZPos = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_ZPOS_FOR_YAXIS];
			} else {
				fZPos = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_ZPOS_FOR_YAXIS_REVERSE];
			}
			sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", fZPos );
		}
		step = 2250;
		break;

		SEND_CMD_MDA( step, 2250, 2260, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 2260, 2270 )

		// Y�� + �������� ���� 
	case 2270:
		{
			int		measure_count = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MEASURE_COUNT];
			double	f1st_max_distance	= p->fParam[SAutoTeachMultiOrgParam::PARAM_1ST_MAX_DISTANCE];
			double	f2st_measure_offset	= p->fParam[SAutoTeachMultiOrgParam::PARAM_2ST_MEASURE_OFFSET] * -1.0;
			int		move_spd = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MOVESPEED_FOR_MEAS_POS];

			PAMotion->DO_MEASURE( FALSE, 
				pa::AXIS_Y,
				0.01, -0.001,	// ���� ���� ���� 
				move_spd,
				measure_count,
				f1st_max_distance,
				f2st_measure_offset );
		}
		Sleep( 300 );
		step = 2280;
		break;
	case 2280:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
			step = 2290;
		}
		break;
		// ���� ��� ���� 
	case 2290:
		PAMotion->GET_MEASURE_RESULT();
		fTemp[1] = TO_G54( pa::AXIS_Y, CPAAsyncComm::F_TEMP_MEASURE_RESULT );
		fTemp[1] += ( p->fParam[SAutoTeachMultiOrgParam::PARAM_TOOL_DIAMETER] / 2.0 );
		strLog.Format( _T("y-axis result #2 : %.5f"), fTemp[1] );
		writeLog_AutoCal( strLog, TRUE );
		// ȯ���� ���� ��� 
		fObjectDiameter = fabs( fTemp[0] - fTemp[1] );
		strLog.Format( _T("roundbar's diameter is %.4f"), fObjectDiameter );
		writeLog_AutoCal( strLog, TRUE );
		step = 2300;
		break;

		SEND_CMD_MDA( step, 2300, 2310, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 2310, 2320 )

	case 2320:
		fYOffset = ( fTemp[0] + fTemp[1] ) / 2.0;
		strLog.Format( _T("y-axis result = %.4f"), fYOffset );
		writeLog_AutoCal( strLog, TRUE );
		step = 2400;

		// ������ ���� 
		if( fabs(fTemp[0] - fTemp[1]) < 0.001 ) 
		{
			throw CPException( ERR_PNC, PNC_ERR_MEASURE_RETURN_SAME_DATA, _T("do_measure return same data") );
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// X�� ���� 
		//	- Y�� ���� ��� ��ġ��, X�� ���� +Offset ��ġ, Z�� ���� ��ġ���� ���� �Ѵ� 
		//////////////////////////////////////////////////////////////////////////
	case 2400:
		{
			strLog.Format( _T("x-axis") );
			writeLog_AutoCal( strLog, TRUE );

			double fXPos = 0.0;
			double fYPos = 0.0;

			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) {
				fXPos = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_MEASURE_BASEPOS_XAXIS] + p->fParam[SAutoTeachMultiOrgParam::PARAM_V_MEASURE_OFFSET_XAXIS];
				fYPos = fYOffset - 5.0;
			} else {
				fXPos = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_MEASURE_BASEPOS_XAXIS]*-1.0 - p->fParam[SAutoTeachMultiOrgParam::PARAM_V_MEASURE_OFFSET_XAXIS];
				fYPos = fYOffset + 5.0;
			}

			sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f", fXPos, fYPos );
		}
		step = 2410;
		break;

		SEND_CMD_MDA( step, 2410, 2420, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 2420, 2430 )

	case 2430:
		// X���� 6-10�� �����Ҷ��� Z���� ZAxis_Offset�� ����ġ�� ������ (�ⱸ������...)
		{
			double	fZPos = 0.0;
			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) {
				fZPos = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_ZPOS_FOR_XAXIS];
			} else {
				fZPos = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_ZPOS_FOR_XAXIS_REVERSE];
			}
			sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", fZPos );
		}
		step = 2440;
		break;

		SEND_CMD_MDA( step, 2440, 2450, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 2450, 2460 )

	case 2460:
		{
			double	fApprocah = 0.0;
			double	fBack = 0.0;
			int		measure_count		= (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MEASURE_COUNT];
			double	f1st_max_distance	= p->fParam[SAutoTeachMultiOrgParam::PARAM_1ST_MAX_DISTANCE];
			double	f2nd_measure_offset	= p->fParam[SAutoTeachMultiOrgParam::PARAM_2ST_MEASURE_OFFSET];
			int		move_spd = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MOVESPEED_FOR_MEAS_POS];

			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) {
				// - ���� ���� 
				fApprocah = -0.01;
				fBack = 0.001;
				f1st_max_distance *= -1.0;
			} else {
				// + ���� ���� 
				fApprocah = 0.01;
				fBack = -0.001;
				f2nd_measure_offset *= -1.0;
			}

			PAMotion->DO_MEASURE( FALSE,
				pa::AXIS_X,
				fApprocah,
				fBack,
				move_spd,
				measure_count,
				f1st_max_distance,
				f2nd_measure_offset );
		}
		Sleep(300);
		step = 2470;
		break;
	
	case 2470:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
			step = 2480;
		}
		break;
		
		// ���� ��� ���� 
	case 2480:
		PAMotion->GET_MEASURE_RESULT();

		fXOffset = TO_G54( pa::AXIS_X, CPAAsyncComm::F_TEMP_MEASURE_RESULT );

		if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) {
			fXOffset -= ( p->fParam[SAutoTeachMultiOrgParam::PARAM_TOOL_DIAMETER] / 2.0 );
		} else {
			fXOffset += ( p->fParam[SAutoTeachMultiOrgParam::PARAM_TOOL_DIAMETER] / 2.0 );
		}

		strLog.Format( _T("x-axis result = %.5f"), fXOffset );
		writeLog_AutoCal( strLog, TRUE );
		step = 2490;
		break;

		SEND_CMD_MDA( step, 2490, 2500, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 2500, 2600 )

		//////////////////////////////////////////////////////////////////////////
		// Z�� ���� 
		//	- Y�� ���� ��ġ ��� 
		//////////////////////////////////////////////////////////////////////////
	case 2600:
		{
			strLog.Format( _T("z-axis") );
			writeLog_AutoCal( strLog, TRUE );

			double fXPos = 0.0;
			double fBasePos = pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][0];
			double fTempOffset = 0.0;
// 			switch( coord_index )
// 			{
// 			default:
// 			case 3: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_XPOS_FOR_YZAXIS_G59]; break;
// 			case 4: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_XPOS_FOR_YZAXIS_G58]; break;
// 			}
			switch( coord_no )
			{
			default:
			case 59: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_XPOS_FOR_YZAXIS_G59]; break;	// ���� D-Type
			case 58: fTempOffset = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_XPOS_FOR_YZAXIS_G58]; break;	// ���� D-Type
			}

			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) {
				fXPos = fBasePos + fTempOffset;
			} else {
				fXPos = fBasePos - fTempOffset;
			}

			sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f", fXPos, fYOffset );
		}
		step = 2610;
		break;

		SEND_CMD_MDA( step, 2610, 2620, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 2620, 2640 )

	case 2640:
		{
			double	fZPos = 0.0;
			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) {
				fZPos = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_ZPOS_FOR_ZAXIS];
			} else {
				fZPos = p->fParam[SAutoTeachMultiOrgParam::PARAM_V_ZPOS_FOR_ZAXIS_REVERSE];
			}
			
			sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", fZPos );
		}
		step = 2650;
		break;

		SEND_CMD_MDA( step, 2650, 2660, szCommandBuffer_ ) 
		MOVE_DNE_MDA( step, 2660, 2670 )

		// Z�� ���� 
	case 2670:
		{
			double	fApproach = -0.01;
			double	fBack = 0.001;
			int		measure_count = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MEASURE_COUNT];
			double	f1st_max_distance	= p->fParam[SAutoTeachMultiOrgParam::PARAM_1ST_MAX_DISTANCE] * -1.0;
			double	f2nd_measure_offset	= p->fParam[SAutoTeachMultiOrgParam::PARAM_2ST_MEASURE_OFFSET];
			int		move_spd = (int)p->fParam[SAutoTeachMultiOrgParam::PARAM_MOVESPEED_FOR_MEAS_POS];

			PAMotion->DO_MEASURE( FALSE,
				pa::AXIS_Z, 
				fApproach, 
				fBack,
				move_spd,
				measure_count, 
				f1st_max_distance, 
				f2nd_measure_offset );
		}
		step = 2680;
		break;
	case 2680:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
			step = 2690;
		}
		break;
		// ���� ��� ���� 
	case 2690:
		PAMotion->GET_MEASURE_RESULT();

		fZOffset = TO_G54(pa::AXIS_Z, CPAAsyncComm::F_TEMP_MEASURE_RESULT);

		strLog.Format( _T("z-axis result : %.5f"), fXOffset );
		writeLog_AutoCal( strLog, TRUE );
		step = 2700;
		break;

		SEND_CMD_MDA( step, 2700, 2710, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 2710, 3000 )

		//////////////////////////////////////////////////////////////////////////
		// ���� ����� hMeasure... �� ���� 
		//////////////////////////////////////////////////////////////////////////
	case 3000:
		{
			double fdX = 0.0;
			double fdY = fYOffset - pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][1];
			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == FALSE ) {
				fdX = fXOffset - ( p->fParam[SAutoTeachMultiOrgParam::PARAM_V_MEASURE_BASEPOS_XAXIS] );
			} else {
				fdX = fXOffset - ( p->fParam[SAutoTeachMultiOrgParam::PARAM_V_MEASURE_BASEPOS_XAXIS] * -1.0 );
			}
			double fdZ = (fZOffset - ( fObjectDiameter / 2.0 )) - pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][2];

			strLog.Format( _T("x-offset = %.5f"), fdX ); writeLog_AutoCal( strLog, TRUE );
			strLog.Format( _T("y-offset = %.5f"), fdY ); writeLog_AutoCal( strLog, TRUE );
			strLog.Format( _T("z-offset = %.5f"), fdZ ); writeLog_AutoCal( strLog, TRUE );

			//////////////////////////////////////////////////////////////////////////
			//
			//////////////////////////////////////////////////////////////////////////
			if( pMultiOriginData->hMultiOrigin[coord_index].bReverseXY[objectno] == TRUE ) {
				fdX *= -1.0;
				fdY *= -1.0;
			}

			//////////////////////////////////////////////////////////////////////////
			// 2017.04.27 
			// �� ��ǥ���� ������ Ȯ�� �Ѵ� 
			//////////////////////////////////////////////////////////////////////////
			{
				double	fMin = pMultiOriginData->fOffset_Min_;
				double	fMax = pMultiOriginData->fOffset_Max_;
				BOOL	bError = FALSE;
				CString	strErrMsg;
				CString strTemp;
				strErrMsg.Format( _T("") );
				if( fdX < fMin || fdX > fMax ) {
					bError = TRUE;
					strTemp.Format( _T("X-Axis (%.3f. %.3f~%.3f)\n"), fdX, fMin, fMax );
					strErrMsg += strTemp;
				}
				if( fdY < fMin || fdY > fMax ) {
					bError = TRUE;
					strTemp.Format( _T("Y-Axis (%.3f. %.3f~%.3f)\n"), fdY, fMin, fMax );
					strErrMsg += strTemp;
				}
				if( fdZ < fMin || fdZ > fMax ) {
					bError = TRUE;
					strTemp.Format( _T("Z-Axis (%.3f. %.3f~%.3f)\n"), fdZ, fMin, fMax );
					strErrMsg += strTemp;
				}
				if( bError == TRUE ) {
					strTemp.Format( _T("RB[%d]\n"), objectno+1 ); 
					strErrMsg = strTemp + strErrMsg;
				}

				if( bError == TRUE ) 
				{
					throw CPException( ERR_PNC, PNC_ERR_MULTIORG_RESULT_OUTOFRANGE, (LPCTSTR)strErrMsg );
				}
			}
			//////////////////////////////////////////////////////////////////////////

			pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][3] = fdX;
			pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][4] = fdY;
			pMultiOriginData->hMultiOrigin[coord_index].fOffset[objectno][5] = fdZ;
		}

		// ���� 
		step = 0;
		break;
	}

	return (BOOL)( step == 0 ? TRUE : FALSE );
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
// step : 58000 ~ 59999
void pa::CPThread::doAutoCal_SingleAbutmentCoordinateOffset()
{
	static int		TOOL_NO = 0;
	static double	F_RESULT_XL[100];
	static double	F_RESULT_XR[100];
	static double	F_X_CENTER;
	static double	F_RESULT_Z[100];
	static double	F_RESULT_Y[100];
	static int		MEASURE_COUNT = 0;
	static double	AAXIS_POS = 0.0;
	pa::SAutoCalSingleAbutmentCoordinateOffsetParam* pPARAM = pa::PPAStatus->GetAutoCalSingleAbutmentCoordOffsetParam();
	int& step = nStep_[RUNMODE_RUN];
	int	 ntemp = 0;
	CString strLog;

	ASSERT( pPARAM );

	switch( step )
	{
	case 58000:
		strLog.Format( _T("start. single abntment auto cal. x,y,z-axis") );
		writeLog_AutoCal( strLog, FALSE );

		TOOL_NO = 0;
		F_X_CENTER = 0.0;
		pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 0;
		step = 58010;
		break;

	case 58010:
		for( int i = 0; i<pa::COORD_NUM; i++ ) {
			pa::PAMotion->RCFG( (pa::EN_COORDINATE)i );
			Sleep( 10 );
		}
		step = 58020;
		break;

		//////////////////////////////////////////////////////////////////////////
		// ������ ���� ��´�
	case 58020:
		TOOL_NO = (int)( pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_TOOL_NO] );
		step = ( TOOL_NO == pa::PPAStatus->GetPAStatus()->nCurrentToolNo ) ? 58090 : 58030;
		break;

	case 58030:
		doAutoCal_Prepare( TRUE, TOOL_NO );
		step = 58040;
		break;
	case 58040:
		if( doAutoCal_Prepare( FALSE, TOOL_NO ) == TRUE ) {
			step = 58090;
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// 2017.08.22. �� ���� ���� ���θ� Ȯ���ؼ�, �ȵǾ� ���� ��� M207 ��ũ�θ� ȣ�� �Ѵ� 
	case 58090:
		if( pa::PPAStatus->GetPAStatus()->nToolLengthUpdateFlag == 0 ) {
			step = 58092;
		} else {
			step = 58100;
		}
		break;
		SEND_CMD_MDA( step, 58092, 58094, "M207" )
		MOVE_DNE_MDA( step, 58094, 58100 )

		//////////////////////////////////////////////////////////////////////////
		// XYZAB ���� ��� ��ġ�� �̵��Ѵ� 
	case 58100:
		doAutlCal_MoveReadyPos( TRUE );
		step = 58110;
		break;
	case 58110:
		if( doAutlCal_MoveReadyPos( FALSE ) == TRUE ) {
			step = 58120;
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// ���̺� ���� �޽��� �ڽ��� ����. 
	case 58120:
		step = 58121;
		break;
// 		{
// 			CAutoCalDlg::SHOW_DLG();
// 			int sel = CAutoCalDlg::WAIT_FOR_SELECT();
// 			CAutoCalDlg::HIDE_DLG();
// 			if( sel == IDOK ) {
// 				pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 1;
// 			}
// 			else {
// 				pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 2;
// 			}
// 		}
// 		step = 58130;
// 		break;

	case 58121:
		CAutoCalDlg::SHOW_DLG();
		step = 58122;
		break;
	case 58122:
		{
			int sel = CAutoCalDlg::WAIT_FOR_SELECT2();
			if (sel == -1) break;
			else {
				if (sel == IDOK) {
					pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 1;
				}
				else {
					pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 2;
				}
				CAutoCalDlg::HIDE_DLG();
				step = 58123;
			}
		}
		break;
	case 58123:
		step = 58130;
		break;

		//////////////////////////////////////////////////////////////////////////
		// ���� ���̺� ������ ��� ���� 
	case 58130:
		if( pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable != 0 ) {
			if( pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable == 1 ) {
				step = 58200;	// �۾� ����  
			} else {
				step = 0;		// �۾� ��� 
				changeRunMode( RUNMODE_STOP, TRUE );
			}
		}
		break;

	case 58200:
		step = 58300;
		break;

		//////////////////////////////////////////////////////////////////////////
		// X�� ����. A���� 0-360���� ȸ���ϸ鼭 ������ ����� ���Ѵ� 
		//////////////////////////////////////////////////////////////////////////
	case 58300:
		MEASURE_COUNT = 0;
		AAXIS_POS = 0.0;
		step = 58310;
		break;
	case 58310:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f",
			pPARAM[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_XPOS_FOR_XAXIS_MEAS], 
			pPARAM[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_YPOS_FOR_XAXIS_MEAS] );
		step = 58320;
		break;
		SEND_CMD_MDA( step, 58320, 58330, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 58330, 58340 )
	case 58340:
		{
			double f = pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_ZPOS_FOR_XAXIS_MEAS];
			sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", f );
		}
		step = 58350;
		break;
		SEND_CMD_MDA( step, 58350, 58360, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 58360, 58370 )
	case 58370:
		{
			int		measure_count = (int)(pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_MEASURE_COUNT]);
			double	f1st_max_distance = (pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_1ST_MAX_DISTANCE])*-1.0;
			double	f2st_measure_offset = (pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_2ST_MEASURE_OFFSET]);
			int		move_spd = (pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_MOVESPEED_FOR_MEAS_POS]);

			PAMotion->DO_MEASURE( FALSE,
				pa::AXIS_X,
				-0.01, 0.001, 
				move_spd,
				measure_count,
				f1st_max_distance,
				f2st_measure_offset );
		}
		Sleep( 500 );
		step = 58380;
		break;
	case 58380:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
			step = 58390;
		}
		break;
		// ���� ��� ���� 
	case 58390:
		PAMotion->GET_MEASURE_RESULT();
		F_RESULT_XL[MEASURE_COUNT] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		step = 58400;
		break;
	case 58400:
		MEASURE_COUNT += 1;
		AAXIS_POS += pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_ROTATION_ANGLE];
	//	if( AAXIS_POS > 360.0 ) {
		if( AAXIS_POS > 359.999 ) {
			//////////////////////////////////////////////////////////////////////////
			// ��� ����. ��� ���� 0��° index�� �����Ѵ� 
			double fAvg = 0.0;
			for( int i = 0; i<MEASURE_COUNT; i++ ) {
				fAvg += F_RESULT_XL[i];
			}
			fAvg = fAvg / MEASURE_COUNT;
			F_RESULT_XL[0] = fAvg;	
			//////////////////////////////////////////////////////////////////////////
			step = 58500;
		} else {
			step = 58410;
		}
		break;
	case 58410:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 A%.3f", AAXIS_POS );
		step = 58420;
		break;
		SEND_CMD_MDA( step, 58420, 58430, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 58430, 58440 )
	case 58440:
		step = 58370;
		break;
	
		//////////////////////////////////////////////////////////////////////////
		// X�� ������. A���� 0-360���� ȸ���ϸ鼭 ������ ����� ���Ѵ� 
		//////////////////////////////////////////////////////////////////////////
		// ���� ����. ��� ��ġ�� �̵� 
		SEND_CMD_MDA( step, 58500, 58510, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 58510, 58520 )
		SEND_CMD_MDA( step, 58520, 58530, "G00 G90 G53 A0" )
		MOVE_DNE_MDA( step, 58530, 58540 )

	case 58540:
		MEASURE_COUNT = 0;
		AAXIS_POS = 0;
		step = 58600;
		break;

	case 58600:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f",
			pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_XPOS_FOR_XAXIS_MEAS] * -1.0,
			pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_YPOS_FOR_XAXIS_MEAS] );
		step = 58610;
		break;
		SEND_CMD_MDA( step, 58610, 58620, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 58620, 58630 )
	case 58630:
		{
			double f = pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_ZPOS_FOR_XAXIS_MEAS];
			sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", f );
		}
		step = 58640;
		break;
		SEND_CMD_MDA( step, 58640, 58650, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 58650, 58660 )
	case 58660:
		{
			int		measure_count = (int)(pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_MEASURE_COUNT]);				//1; //5;
			double	f1st_max_distance = (pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_1ST_MAX_DISTANCE]);		//10.0;
			double	f2st_measure_offset = (pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_2ST_MEASURE_OFFSET]) * -1.0;	//-1.0;
			int		move_spd = (pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_MOVESPEED_FOR_MEAS_POS]);

			PAMotion->DO_MEASURE( FALSE,
				pa::AXIS_X,
				0.01, -0.001,
				move_spd,
				measure_count,
				f1st_max_distance,
				f2st_measure_offset );
		}
		Sleep( 500 );
		step = 58662;
		break;
	case 58662:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
			step = 58670;
		}
		break;
		// ���� ��� ���� 
	case 58670:
		PAMotion->GET_MEASURE_RESULT();
		F_RESULT_XR[MEASURE_COUNT] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		step = 58700;
		break;
	case 58700:
		MEASURE_COUNT += 1;
		AAXIS_POS += pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_ROTATION_ANGLE];
	//	if( AAXIS_POS > 360.0 ) {
		if( AAXIS_POS > 359.999 ) {
			//////////////////////////////////////////////////////////////////////////
			// ��� ����. ��� ���� 0��° index�� �����Ѵ� 
			double fAvg = 0.0;
			for( int i = 0; i<MEASURE_COUNT; i++ ) {
				fAvg += F_RESULT_XR[i];
			}
			fAvg = fAvg / MEASURE_COUNT;
			F_RESULT_XR[0] = fAvg;

			F_X_CENTER = (F_RESULT_XL[0] + F_RESULT_XR[0]) / 2.0;
			//////////////////////////////////////////////////////////////////////////
			step = 58800;
		} else {
			step = 58710;
		}
		break;
	case 58710:
		sprintf_s( szCommandBuffer_, 256, "F00 G90 G53 A%.3f", AAXIS_POS );
		step = 58720;
		break;
		SEND_CMD_MDA( step, 58720, 58730, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 58730, 58740 )
	case 58740:
		step = 58660;
		break;

		//////////////////////////////////////////////////////////////////////////
		// Y�� ���� 
		//////////////////////////////////////////////////////////////////////////
//	case 58800:
		SEND_CMD_MDA( step, 58800, 58810, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 58810, 58820 )
		SEND_CMD_MDA( step, 58820, 58830, "G00 G90 G53 A0" )
		MOVE_DNE_MDA( step, 58830, 58840 )

	case 58840:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f",
			F_X_CENTER,
			pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_YPOS_FOR_YAXIS_MEAS_G53] );
		step = 58850;
		break;
		SEND_CMD_MDA( step, 58850, 58860, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 58860, 58870 )
	case 58870:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f", 
			pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_ZPOS_FOR_YAXIS_MEAS] );
		step = 58880;
		break;
		SEND_CMD_MDA( step, 58880, 58890, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 58890, 58900 )
	case 58900:
		{
			int		measure_count = (int)(pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_MEASURE_COUNT]);				//1; //5;
			double	f1st_max_distance = (pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_1ST_MAX_DISTANCE])*-1.0;			//-10.0;
			double	f2st_measure_offset = (pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_2ST_MEASURE_OFFSET]);			//1.0;
			int		move_spd = (pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_MOVESPEED_FOR_MEAS_POS]);

			if( measure_count < 5 ) {
				measure_count = 5;
			}

			PAMotion->DO_MEASURE( FALSE,
				pa::AXIS_Y,
				-0.01, 0.001,
				move_spd,
				measure_count,
				f1st_max_distance,
				f2st_measure_offset );
		}
		Sleep( 500 );
		step = 58902;
		break;
	case 58902:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
			step = 58910;
		}
		break;
	case 58910:
		PAMotion->GET_MEASURE_RESULT();
		F_RESULT_Y[0] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		step = 58920;
		break;

		SEND_CMD_MDA( step, 58920, 58930, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 58930, 58940 )
		SEND_CMD_MDA( step, 58940, 58950, "G00 G90 G53 A0" )
		MOVE_DNE_MDA( step, 58950, 59000 )

		//////////////////////////////////////////////////////////////////////////
		// Z�� ���� 
		//////////////////////////////////////////////////////////////////////////
	case 59000:
		MEASURE_COUNT = 0;
		AAXIS_POS = 0;
		step = 59010;
		break;
	case 59010:
		{
// 			double y = pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_YPOS_FOR_ZAXIS_MEAS];
// 			sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f Y%.3f",
// 				F_X_CENTER,
// 				y );
			sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 X%.3f", F_X_CENTER );
		}
		step = 59012;
		break;
		SEND_CMD_MDA( step, 59012, 59014, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 59014, 59020 )

	case 59020:
		{
 			double y = pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_YPOS_FOR_ZAXIS_MEAS];
			sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Y%.3f", y );
		}
		step = 59022;
		break;
		SEND_CMD_MDA( step, 59022, 59024, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 59024, 59040 )

	case 59040:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f",
			pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_ZPOS_FOR_ZAXIS_MEAS] );
		step = 59050;
		break;
		SEND_CMD_MDA( step, 59050, 59060, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 59060, 59070 )
	case 59070:
		{
			int		measure_count = (int)(pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_MEASURE_COUNT]);				//1; //5;
			double	f1st_max_distance = (pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_1ST_MAX_DISTANCE])*-1.0; //-10.0;
			double	f2st_measure_offset = (pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_2ST_MEASURE_OFFSET]);	//1.0;
			int		move_spd = (pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_MOVESPEED_FOR_MEAS_POS]);

			PAMotion->DO_MEASURE( FALSE,
				pa::AXIS_Z,
				-0.01, 0.001,
				move_spd,
				measure_count,
				f1st_max_distance,
				f2st_measure_offset );
		}
		Sleep( 500 );
		step = 59080;
		break;
	case 59080:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
			step = 59090;
		}
		break;
		// ���� ��� ���� 
	case 59090:
		PAMotion->GET_MEASURE_RESULT();
		F_RESULT_Z[MEASURE_COUNT] = CPAAsyncComm::F_TEMP_MEASURE_RESULT;
		step = 59100;
		break;
	case 59100:
		MEASURE_COUNT += 1;
		AAXIS_POS += pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_ROTATION_ANGLE];
		if( AAXIS_POS > 359.999 ) {
			//////////////////////////////////////////////////////////////////////////
			// ��� ����. ��� ���� 0��° index�� �����Ѵ� 
			double fAvg = 0.0;
			for( int i = 0; i<MEASURE_COUNT; i++ ) {
				fAvg += F_RESULT_Z[i];
			}
			fAvg = fAvg / MEASURE_COUNT;
			F_RESULT_Z[0] = fAvg;
			//////////////////////////////////////////////////////////////////////////
			step = 59200; 
		} else {
			step = 59110;
		}
		break;

	case 59110:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G53 A%.3f", AAXIS_POS );
		step = 59120;
		break;
		SEND_CMD_MDA( step, 59120, 59130, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 59130, 59140 )
	case 59140:
		step = 59070;
		break;

		SEND_CMD_MDA( step, 59200, 59210, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 59210, 59220 )
		SEND_CMD_MDA( step, 59220, 59230, "G00 G90 G53 X0 Y0" )
		MOVE_DNE_MDA( step, 59230, 59240 )
		SEND_CMD_MDA( step, 59240, 59250, "G00 G90 G53 A0" )
		MOVE_DNE_MDA( step, 59250, 59300 )

	case 59300:
		{
			// X�� Coordinate Offset ����
			double fTempX = ( F_RESULT_XL[0] + F_RESULT_XR[0] ) / 2.0;
			double fTempY = ( F_RESULT_Y[0] - (pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_TOOL_DIAMETER]/2.0) ) + 28.0;	// Y�� ������ġ�� 28��ŭ �̵� 

			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G54][pa::AXIS_X] = fTempX;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G55][pa::AXIS_X] = fTempX;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G56][pa::AXIS_X] = fTempX;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G57][pa::AXIS_X] = fTempX;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G58][pa::AXIS_X] = fTempX;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G59][pa::AXIS_X] = fTempX;

			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G54][pa::AXIS_Y] = fTempY;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G55][pa::AXIS_Y] = fTempY;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G56][pa::AXIS_Y] = fTempY;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G57][pa::AXIS_Y] = fTempY;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G58][pa::AXIS_Y] = fTempY;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G59][pa::AXIS_Y] = fTempY;

			PAMotion->WCFG( pa::COORD_G54, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G54] );
// 			PAMotion->WCFG( pa::COORD_G55, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G55] );
// 			PAMotion->WCFG( pa::COORD_G56, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G56] );
// 			PAMotion->WCFG( pa::COORD_G57, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G57] );
// 			PAMotion->WCFG( pa::COORD_G58, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G58] );
// 			PAMotion->WCFG( pa::COORD_G59, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G59] );

			// Z�� Origin Offset ���� 
// 			double ROUND_BAR = ( F_RESULT_XL[1] - F_RESULT_XR[1] ) - pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_TOOL_DIAMETER];
// 			double fTempZ = F_RESULT_Z[0] - (ROUND_BAR / 2.0);	// F_RESULT_Z[0]�� G53 ����. ������ ������ ���� ��ġ 
// 			double fCoordinateG54Z = pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G54][pa::AXIS_Z];
// 			double fTempZOffset	= fTempZ - pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G54][pa::AXIS_Z];
// 			double fNewZOffset	= pa::PConfig->pConfig_->fOptionData[pa::OPTION_ZAXIS_ORIGIN_OFFSET] + fTempZOffset;
// 			pa::PConfig->pConfig_->fOptionData[pa::OPTION_ZAXIS_ORIGIN_OFFSET] = fNewZOffset;
// 			PAMotion->WZOO( fNewZOffset );
		}
		step = 59310;
		break;
		
	case 59310:
		strLog.Format( _T("stop measure. x,y,z-axis") );
		writeLog_AutoCal( strLog, FALSE );
		changeRunMode( RUNMODE_STOP, TRUE );
		step = 0;
		break;
	}
}

// DS200-4WAS ���� A�� ���� ���� 
void pa::CPThread::doAutoCal_SingleAbutmentCoordinateOffset_A()
{
	static int		TOOL_NO = 0;
	static double	F_RESULT[2];
	static double	AXIS_OFFSET;
	static int		MEASURE_COUNT = 0;
	pa::SAutoCalSingleAbutmentCoordinateOffsetParam* pPARAM = pa::PPAStatus->GetAutoCalSingleAbutmentCoordOffsetParam();
	int& step = nStep_[RUNMODE_RUN];
	CString strLog;

	ASSERT( pPARAM );

	switch( step )
	{
	case 60000:
		strLog.Format( _T("start. single abntment auto cal. a-axis") );
		writeLog_AutoCal( strLog, FALSE );

		TOOL_NO = 0;
		F_RESULT[0] = F_RESULT[1] = 0.0;
		AXIS_OFFSET = 0.0;
		MEASURE_COUNT = 0;
		pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 0;
		step = 60010;
		break;

	case 60010:
		for( int i = 0; i<pa::COORD_NUM; i++ ) {
			pa::PAMotion->RCFG( (pa::EN_COORDINATE)i );
			Sleep( 10 );
		}
		step = 60020;
		break;

		//////////////////////////////////////////////////////////////////////////
		// ������ ���� ��´�
	case 60020:
		TOOL_NO = (int)( pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_TOOL_NO] );
		step = ( TOOL_NO == pa::PPAStatus->GetPAStatus()->nCurrentToolNo ) ? 60090 : 60030;
		break;

	case 60030:
		doAutoCal_Prepare( TRUE, TOOL_NO );
		step = 60040;
		break;
	case 60040:
		if( doAutoCal_Prepare( FALSE, TOOL_NO ) == TRUE ) {
		//	step = 60100;
			step = 60090;
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// 2017.08.22. �� ���� ���� ���θ� Ȯ���ؼ�, �ȵǾ� ���� ��� M207 ��ũ�θ� ȣ�� �Ѵ� 
	case 60090:
		if( pa::PPAStatus->GetPAStatus()->nToolLengthUpdateFlag == 0 ) {
			step = 60092;
		} else {
			step = 60100;
		}
		break;
		SEND_CMD_MDA( step, 60092, 60094, "M207" )
		MOVE_DNE_MDA( step, 60094, 60100 )

		//////////////////////////////////////////////////////////////////////////
		// XYZAB ���� ��� ��ġ�� �̵��Ѵ� 
	case 60100:
		doAutlCal_MoveReadyPos( TRUE );
		step = 60110;
		break;
	case 60110:
		if( doAutlCal_MoveReadyPos( FALSE ) == TRUE ) {
			step = 60120;
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// ���̺� ���� �޽��� �ڽ��� ���� 
	case 60120:
		step = 60121;
		break;
// 		{
// 			CAutoCalDlg::SHOW_DLG();
// 			int sel = CAutoCalDlg::WAIT_FOR_SELECT();
// 			CAutoCalDlg::HIDE_DLG();
// 			if( sel == IDOK ) {
// 				pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 1;
// 			}
// 			else {
// 				pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 2;
// 			}
// 		}
// 		step = 60130;
// 		break;

	case 60121:
		CAutoCalDlg::SHOW_DLG();
		step = 60122;
		break;
	case 60122:
		{
			int sel = CAutoCalDlg::WAIT_FOR_SELECT2();
			if (sel == -1) break;
			else {
				if (sel == IDOK) {
					pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 1;
				}
				else {
					pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable = 2;
				}
				CAutoCalDlg::HIDE_DLG();
				step = 60123;
			}
		}
		break;
	case 60123:
		step = 60130;
		break;

		//////////////////////////////////////////////////////////////////////////
		// ���� ���̺� ������ ��� ���� 
	case 60130:
		if( pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable != 0 ) {
			if( pa::PPAStatus->GetThreadState()->nAutoCal_ConnectedCable == 1 ) {
				step = 60200;	// �۾� ����  
			} else {
				step = 0;		// �۾� ��� 
				changeRunMode( RUNMODE_STOP, TRUE );
			}
		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// ���� ����. ��� ��ġ�� �̵� 
		//////////////////////////////////////////////////////////////////////////
		SEND_CMD_MDA( step, 60200, 60210, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 60210, 60220 )
		SEND_CMD_MDA( step, 60220, 60230, "G00 G90 G54 A0" )
		MOVE_DNE_MDA( step, 60230, 60300 )
// 		SEND_CMD_MDA( step, 60240, 60250, "G00 G90 G54 X0 Y0" )
// 		MOVE_DNE_MDA( step, 60250, 60300 )

		// ù��° ���� X- ��ġ (������)
	case 60300:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f", 
			pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_XPOS_FOR_AAXIS_MEAS]*-1.0,
			pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_YPOS_FOR_AAXIS_MEAS] );
		step = 60310;
		break;
		SEND_CMD_MDA( step, 60310, 60320, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 60320, 60330 )
	case 60330:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f",
			pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_ZPOS_FOR_AAXIS_MEAS] );
		step = 60340;
		break;
		SEND_CMD_MDA( step, 60340, 60350, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 60350, 60360 )
	case 60360:
		// ���� 
		{
			int		measure_count = (int)(pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_MEASURE_COUNT]);				//1; //5;
			if( measure_count < 5 ) {
				measure_count = 5;
			}

			PAMotion->DO_MEASURE( FALSE, 
				pa::AXIS_Z, 
				-0.01, 0.001, 
				(int)(pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_MOVESPEED_FOR_MEAS_POS]), 
				measure_count, //(int)(pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_MEASURE_COUNT]), 
				(pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_1ST_MAX_DISTANCE])*-1.0,
				(pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_2ST_MEASURE_OFFSET]) );
			Sleep( 300 );
		}
		step = 60370;
		break;
	case 60370:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
			step = 60380;
		}
		break;
	case 60380:
		// ���� ��� ���� 
		PAMotion->GET_MEASURE_RESULT();
		F_RESULT[0] = TO_G54( pa::AXIS_Z, CPAAsyncComm::F_TEMP_MEASURE_RESULT );
		strLog.Format( _T("result : %.5f"), F_RESULT[0] );
		writeLog_AutoCal( strLog, TRUE );
		if( fabs( F_RESULT[0] ) < 0.001 ) {
			step = 60330;	// �ٽ� ���� (���� ����)
		} else {
			step = 60390;
		}
		break;
		
		// Z-Up
		SEND_CMD_MDA( step, 60390, 60400, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 60400, 60420 )

		// �ι�° ���� X+ (����)
	case 60420:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 X%.3f Y%.3f", 
			pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_XPOS_FOR_AAXIS_MEAS],
			pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_YPOS_FOR_AAXIS_MEAS] );
		step = 60430;
		break;
		SEND_CMD_MDA( step, 60430, 60440, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 60440, 60450 )
	case 60450:
		sprintf_s( szCommandBuffer_, 256, "G00 G90 G54 Z%.3f",
			pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_ZPOS_FOR_AAXIS_MEAS] );
		step = 60460;
		break;
		SEND_CMD_MDA( step, 60460, 60470, szCommandBuffer_ )
		MOVE_DNE_MDA( step, 60470, 60480 )
	case 60480:
		// ���� 
		{
			int		measure_count = (int)(pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_MEASURE_COUNT]);				//1; //5;
			if( measure_count < 5 ) {
				measure_count = 5;
			}

			PAMotion->DO_MEASURE( FALSE, 
				pa::AXIS_Z, 
				-0.01, 0.001, 
				(int)(pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_MOVESPEED_FOR_MEAS_POS]), 
				measure_count, //(int)(pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_MEASURE_COUNT]), 
				(pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_1ST_MAX_DISTANCE])*-1.0,
				(pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_2ST_MEASURE_OFFSET]) );
			Sleep( 300 );
		}
		step = 60490;
		break;
	case 60490:
		if( PAMotion->MotionDone( CPAAsyncComm::CMD_RND_DO_MEASURE, TRUE ) == TRUE ) {
			step = 60500;
		}
		break;
	case 60500:
		// ���� ��� ���� 
		PAMotion->GET_MEASURE_RESULT();
		F_RESULT[1] = TO_G54( pa::AXIS_Z, CPAAsyncComm::F_TEMP_MEASURE_RESULT );
		strLog.Format( _T("result : %.5f"), F_RESULT[1] );
		writeLog_AutoCal( strLog, TRUE );
		if( fabs( F_RESULT[1] ) < 0.001 ) {
			step = 60480;	// �ٽ� ���� (���� ����)
		} else {
			step = 60510;
		}
		break;

		// Z-Up
		SEND_CMD_MDA( step, 60510, 60520, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 60520, 60600 )

		//////////////////////////////////////////////////////////////////////////
		// ���� ��� ���� 
	case 60600:
		{
			double E23 = F_RESULT[1];
			double D23 = F_RESULT[0];
			if( fabs(E23-D23) > 0.0001 ) {	// 2016.11.18
				double E5  = pPARAM->fParam[pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_XPOS_FOR_AAXIS_MEAS];
				double D5  = E5*-1.0; //fAMeasureXPos_*-1.0;
				AXIS_OFFSET= atan((E23-D23) / (E5-D5)) * 180.0 / 3.14159265358979;
			}
			else {
				AXIS_OFFSET= 0.0;
			}

			strLog.Format( _T("offset : %.5f"), AXIS_OFFSET );
			writeLog_AutoCal( strLog, TRUE );

			double ftemp = pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G54][pa::AXIS_A] + AXIS_OFFSET;
			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G54][pa::AXIS_A] = ftemp;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G55][pa::AXIS_A] = ftemp;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G56][pa::AXIS_A] = ftemp;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G57][pa::AXIS_A] = ftemp;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G58][pa::AXIS_A] = ftemp;
// 			pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G59][pa::AXIS_A] = ftemp;

			PAMotion->WCFG( pa::COORD_G54, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G54] );
// 			PAMotion->WCFG( pa::COORD_G55, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G55] );
// 			PAMotion->WCFG( pa::COORD_G56, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G56] );
// 			PAMotion->WCFG( pa::COORD_G57, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G57] );
// 			PAMotion->WCFG( pa::COORD_G58, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G58] );
// 			PAMotion->WCFG( pa::COORD_G59, pa::PConfig->pConfig_->fCoordOffset[pa::COORD_G59] );
		}
		step = 60610;
		break;

	case 60610:
		if( fabs(AXIS_OFFSET) < 0.002 ) {
			writeLog_AutoCal( _T("stop measure"), FALSE );
			step = 60700; // complete
		}
		else {
			MEASURE_COUNT += 1;
			strLog.Format( _T("retry measure : count is %d"), MEASURE_COUNT );
			writeLog_AutoCal( strLog, FALSE );
			if( MEASURE_COUNT >= 10 ) {
				// 10ȸ �̻� �����ص� �������� ������ ���� !
// 				strLog.Format( _T("measure error !!!") );
// 				AfxMessageBox( strLog, MB_OK|MB_ICONERROR );
// 				writeLog_AutoCal( strLog, TRUE );
// 				step = 0;
// 				changeRunMode( RUNMODE_STOP, TRUE );

 				strLog.Format( _T("measure error !!!") );
 				writeLog_AutoCal( strLog, TRUE );

				CString strErrMsg;
				strErrMsg.Format( _T("Auto calibration. measure fail.") );
				throw CPException( ERR_PNC, PNC_ERR_AUTOCAL_MEASURE_FAIL, (LPCTSTR)strErrMsg );
				step = 0;
			}
			else {
				strLog.Format( _T("retry measure : %d"), MEASURE_COUNT );
				writeLog_AutoCal( strLog, TRUE );
				step = 60200;	// retry 
			}

		}
		break;

		//////////////////////////////////////////////////////////////////////////
		// x, y, z ���� ȸ�� �ϰ�, ȸ������ �������...
		SEND_CMD_MDA( step, 60700, 60710, "G00 G90 G53 Z0" )
		MOVE_DNE_MDA( step, 60710, 60720 )

		SEND_CMD_MDA( step, 60720, 60730, "G00 G90 G53 X0 Y0" )
		MOVE_DNE_MDA( step, 60730, 60740 )

		SEND_CMD_MDA( step, 60740, 60750, "G00 G90 G54 A0 B0" )
		MOVE_DNE_MDA( step, 60750, 60800 )

	case 60800:
		strLog.Format( _T("stop measure. x-axis") );
		writeLog_AutoCal( strLog, FALSE );
		step = 0;
		changeRunMode( RUNMODE_STOP, TRUE );
		break;
	}
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

// 62000 ~ 62999
// ���õ� ���� ����, 
// �Էµ� ȸ�� ��ŭ �ݺ� 
void pa::CPThread::doATCTest()
{
	static int TOOL_NO = 0;
	static int DELAY = 0;
	static char* P_CMD[] = { "M140", "M141", "M142", "M143", "M144", "M145", "M146", "M147" };
	int& step = nStep_[RUNMODE_RUN];
	CString strLog;

	switch( step )
	{
	case 62000:
		strLog.Format( _T("start atc test") );
		writeLog_AutoCal( strLog, FALSE );
		TOOL_NO = 0;
		pa::PPAStatus->GetThreadState()->nATCTest_WorkCount = 0;
		// ���� ������ ������, ���� ���´� 
		step = pa::PPAStatus->GetPAStatus()->nCurrentToolNo != 0 ? 62010 : 62100;
		break;
		SEND_CMD_MDA( step, 62010, 62020, "M148" )
		MOVE_DNE_MDA( step, 62020, 62100 )

	case 62100:
		if( pa::PPAStatus->GetThreadState()->nATCTest_MeasureCount <= pa::PPAStatus->GetThreadState()->nATCTest_WorkCount ) {
			step = 62800;
		} else {
			step = 62110;
		}
		break; 

	case 62110:
		if( pa::PPAStatus->GetThreadState()->bATCTest_EnaTool[TOOL_NO] == TRUE ) 
		{
			strLog.Format( _T("ATCTest. Get Tool %d"), TOOL_NO+1 );
			writeLog_AutoCal( strLog, FALSE );
			DELAY = 5;
			step = 62120;
		}
		else 
		{
			step = 62300;
		}
		break;

		SEND_CMD_MDA( step, 62120, 62130, P_CMD[TOOL_NO] )
		MOVE_DNE_MDA( step, 62130, 62140 )

	case 62140:
		if( DELAY-- < 0 ) {
			step = 62200;
		}
		break;

	case 62200:
		// ������ ���� 
		{
// 			int i = TOOL_NO;
// 			int j = pa::PPAStatus->GetThreadState()->nATCTest_WorkCount;
// 			double f = pa::PPAStatus->GetPAStatus()->fCurrentToolLenght + pa::PConfig->pConfig_->fOptionData[OPTION_ZAXIS_ORIGIN_OFFSET];
// 			pa::PPAStatus->GetThreadState()->fATCTest_MeasureResult[i][j] = f; 
// 			strLog.Format( _T("=> %.3f"), f);
// 			writeLog_AutoCal( strLog, TRUE );
		}
		step = 62300;
		break;
	case 62300:
		TOOL_NO += 1;
		if( TOOL_NO >= 8 ) {
			TOOL_NO = 0;
			pa::PPAStatus->GetThreadState()->nATCTest_WorkCount += 1;
		}
		step = 62100;
		break;

		SEND_CMD_MDA( step, 62800, 62810, "M148" )
		MOVE_DNE_MDA( step, 62810, 62900 )

	case 62900:
		strLog.Format( _T("stop atc test") );
		writeLog_AutoCal( strLog, FALSE );
		step = 0;
		changeRunMode( RUNMODE_STOP, TRUE );
	}
}


//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

void pa::CPThread::ERROR_PROC( CPException& e )
{
	//////////////////////////////////////////////////////////////////////////
	// ������ �� ���� ��ȣ ����
	// EMO ���� �÷��� ����ϴ� ������ ���� 
	if( bIsEMOError_ == FALSE )
	{
		int nTemp = PPAStatus->GetThreadState()->nCurrentNCCodeStepNo;
		SET_ERROR_LINENO( PPAStatus->GetThreadState()->nCurrentNCCodeStepNo );
		pa::CPAMotion::STREAM_MODE_ERROR = TRUE;
		Sleep( 500 );
	}
	//////////////////////////////////////////////////////////////////////////

	PPAStatus->GetThreadState()->bCheckStatus = FALSE;

	//////////////////////////////////////////////////////////////////////////
	//
	if( ( e.hErr == ERR_RND_CMD ) &&		// RND Command ���� 
		( e.nErrCode == 10010 || e.nErrCode == 10014 || e.nErrCode == 10018 || e.nErrCode == 10019 ) )				// Tool Broken ���� (Get Tool ������ ���� ���� ������ �׳� �����)
	{
		nToolErrorHandlingCode_ = PConfig->pConfig_->nToolErrorOccure_HandlingCode;
		bIsToolError_ = TRUE;
		bToolDirection_ = FALSE;	// Left 
	}

	else if( ( e.hErr == ERR_RND_CMD ) &&		// RND Command ���� 
		     ( e.nErrCode == 20010 || e.nErrCode == 20014 || e.nErrCode == 20018 || e.nErrCode == 20019 ) )
	{
		nToolErrorHandlingCode_ = PConfig->pConfig_->nToolErrorOccure_HandlingCode;
		bIsToolError_ = TRUE;
		bToolDirection_ = TRUE;	// Right 
	}
	
	//////////////////////////////////////////////////////////////////////////
	// Tool ������ ���, ���� ó�� �ؾ� �� 
	//////////////////////////////////////////////////////////////////////////

	if( (e.hErr == ERR_RND_CMD) && (bIsToolError_ == TRUE) )
	{
		if (!bToolDirection_)
		{
			int nToolNo = PPAStatus->GetPAStatus()->nCurrentToolNo;
			PTool->SetToolErrCode( nToolNo, e.nErrCode );
			PTool->SaveToolUsingTime( nToolNo );
		}

		else
		{
			int nToolNo2 = PPAStatus->GetPAStatus()->nCurrentTool2No;
			PTool->SetToolErrCode( nToolNo2, e.nErrCode );
			PTool->SaveToolUsingTime( nToolNo2 );
		}

		if( nErrorLineNo_ != 0 ) {
			int nccode_stepno = PPAStatus->GetThreadState()->SEARCH_LAST_USED_TOOL_LINENO( nErrorLineNo_ );
			PNCFile->SetWorkLine( nccode_stepno );
			PPAStatus->SetNCFileMachiningLine( nccode_stepno, TRUE );
		}

		errorProc( e );
	}
	else
	{
		// �ֱ� ���� �ڵ� ���� 
		PAMotion->SetLastErrorInfo( e.hErr, e.nErrCode );
		//////////////////////////////////////////////////////////////////////////
		// 2017.08.23 ������ �߻��� ���ι�ȣ ���� 
		//	Timeout ������ ���, ���ι�ȣ�� �������� �ʴ´� 
		if( !(e.hErr == ERR_TIMEOUT && 
			 (e.nErrCode == CPAAsyncComm::CMD_RND_STATUS ||
			  e.nErrCode == CPAAsyncComm::CMD_RND_STATE ) ) )
		{
			if( nErrorLineNo_ != 0 ) // 2018.08.23. ���� ������ 0�� ���, �������� �ʴ´� 
			{
				PPAStatus->SetNCFileMachiningLine( nErrorLineNo_, TRUE );
			}
		}
		//////////////////////////////////////////////////////////////////////////
		errorProc( e );
	}

	PPAStatus->GetThreadState()->bCheckStatus = TRUE;
}

//////////////////////////////////////////////////////////////////////////

// pa ������� ���¸� �α׷� ����� 
void pa::CPThread::logging_pa_status()
{
	EnterCriticalSection( &cs_ );

	CString strLog;
	pa::SPAStatus* p = pa::PPAStatus->GetPAStatus();

	strLog.Format( _T("[PA Controller Status]") ); writeLog_AutoCal( strLog, FALSE );

	strLog.Format( _T("md_code : %d"), p->nMDCode ); writeLog_AutoCal( strLog, TRUE );
	strLog.Format( _T("gpl_error_code : %d"), p->nGPLErrorCode ); writeLog_AutoCal( strLog, TRUE );
	strLog.Format( _T("run_status : %d"), p->nRunStatus );

	strLog.Format( _T("position : %.3f %.3f %.3f %.3f %.3f"), p->fPosition[0], p->fPosition[1], p->fPosition[2], p->fPosition[3], p->fPosition[4] ); writeLog_AutoCal( strLog, TRUE );
	p->get_input_str( strLog ); writeLog_AutoCal( strLog, TRUE );
	p->get_output_str( strLog ); writeLog_AutoCal( strLog, TRUE );

	strLog.Format( _T("servo_power : %d"), p->nServoPower ); writeLog_AutoCal( strLog, TRUE );
	strLog.Format( _T("servo_home_state : %d"), p->nServoHomeState ); writeLog_AutoCal( strLog, TRUE );
	strLog.Format( _T("servo_error_state : %d"), p->nServoErrorState ); writeLog_AutoCal( strLog, TRUE );

	strLog.Format( _T("z_ready_state : %d"), p->nZReadyState ); writeLog_AutoCal( strLog, TRUE );
	
	strLog.Format( _T("current_tool_no : %d"), p->nCurrentToolNo ); writeLog_AutoCal( strLog, TRUE );
	strLog.Format( _T("current_coordinate_no : %d"), p->nCurrentCoordinateNo ); writeLog_AutoCal( strLog, TRUE );
	strLog.Format( _T("current_tool_length : %.3f"), p->fCurrentToolLenght ); writeLog_AutoCal( strLog, TRUE );

	strLog.Format( _T("io_board_connect : %d"), p->nIO_Board_Status ); writeLog_AutoCal( strLog, TRUE );
	strLog.Format( _T("spindle_board_connect : %d"), p->nSpindle_Board_Status ); writeLog_AutoCal( strLog, TRUE );

	strLog.Format( _T("spindle_run : %d"), p->nSpindleRun ); writeLog_AutoCal( strLog, TRUE ); 
	strLog.Format( _T("spindle_speed : %d"), p->nSpindleSpeed ); writeLog_AutoCal( strLog, TRUE );

	strLog.Format( _T("motor_override : %d"), p->nMotorOverride ); writeLog_AutoCal( strLog, TRUE );
	strLog.Format( _T("motor_feedrate : %d"), p->nMotorFeedrate ); writeLog_AutoCal( strLog, TRUE );
	strLog.Format( _T("motor_feedrate_with_override : %d"), p->nMotorFeedrateWithOverride ); writeLog_AutoCal( strLog, TRUE );

	strLog.Format( _T("rnd_error_code : %d"), p->nRndErrorCode ); writeLog_AutoCal( strLog, TRUE ); 

	// status code, line number�� ������� �ʴ´�  
// 	strLog.Format( _T("stream_status_code : %d"), p->nStreamStatusCode ); writeLog_AutoCal( strLog, FALSE );
// 	strLog.Format( _T("stream_line_number : %d"), p->nStreamLineNumber ); writeLog_AutoCal( strLog, FALSE );
	strLog.Format( _T("stream_buffer_count : %d"), p->nStreamBufferCount );											// ���۸��� ������ ���� 
	writeLog_AutoCal( strLog, TRUE );		
	strLog.Format( _T("current_nccode_step_no : %d - %d"), pa::PPAStatus->GetThreadState()->nCurrentNCCodeStepNo, nErrorLineNo_ );		// ���� �������� ������ ��ȣ 
	writeLog_AutoCal( strLog, TRUE );

	// ���� ���� ���ε� 
	//	- ���� �޴� �κп��� �α׸� ����� 
	//	- ������ �� �޴� ������ �־, �ϴ� ��ŵ �Ѵ�
// 	PAMotion->RND_MSC();

	logging_tool_status();

	LeaveCriticalSection( &cs_ );
}

void pa::CPThread::logging_tool_status()
{
	CString strLog;

	strLog.Format( _T("[Tool Status]") ); writeLog_AutoCal( strLog, FALSE );

	for( int i = 1; i<MAX_TOOL_NUM; i++ ) {
		CTimeSpan tmsCur(pa::PTool->GetToolData(i)->dwUsingTime);
		CTimeSpan tmsMax(pa::PTool->GetToolData(i)->dwMaximumTime);
		int h, m, s;
		h = tmsCur.GetTotalHours();
		m = tmsCur.GetMinutes();
		s = tmsCur.GetSeconds();
		strLog.Format( _T("tool[%d] -> Err(%d) Rate(%.1f) Using(%d:%02d:%02d)"), 
			i, 
			pa::PTool->GetToolData(i)->dwErrCode,
			pa::PTool->GetToolData(i)->fUsingRate,
			h, m, s );
		writeLog_AutoCal( strLog, TRUE );
	}
}


// ---------------------------------------- Get ITEM ----------------------------------------

BOOL pa::CPThread::GetItemFromAutoLoaderSlot( BOOL bResetStep, int itemNumber )
{
// 	static int step = 0;
// 	static int returnStep = 0;
// 	static BOOL hasRescan = FALSE;
// 	static int slotIndex = -1;
// 
// 	step = bResetStep ? 1 : step;
// 
// 	switch( step )
// 	{
// 	case 1:
// 		hasRescan = FALSE;
// 		step = 50;
// 		break;
// 
// 	// Do `Work Space` cleaning before proceeding.
// 	case 50:
// 		if ( PPAStatus->GetPAStatus()->nCurrentToolNo != 0 ) {
// 			PAMotion->toolReturn_148();
// 			step = 51;
// 		} else {
// 			step = 60;
// 		}
// 		break;
// 	MOVE_DNE_Mxxx( step, 51, 60, CPAAsyncComm::CMD_RND_M148 )
// 	case 60:
// 		if ( !PPAStatus->GetThreadState()->bIsDemoMode_ && !PPAStatus->GetPAStatus()->bInput[pa::IN20016_AutoLoader_PNC_Sensing_Item] ) {
// 			PAMotion->workSpaceClean_787( 0 );
// 			step = 61;
// 		} else {
// 			step = 100;
// 		}
// 		break;
// 	MOVE_DNE_Mxxx( step, 61, 100, CPAAsyncComm::CMD_M787 )
// 	
// 	case 100:
// 		slotIndex  = PAutoLoader->GetSlotIndexFromItemNumber( itemNumber );
// 
// 		if ( slotIndex == -1 ) {
// 			step = 7770;
// 		} else {
// 			step = 200;
// 		}
// 		break;
// 
// 	case 200: 
// 		PAMotion->AL_MoveBlockSensingPosition_M753( FALSE, slotIndex );
// 		step = 201;
// 		break;
// 	MOVE_DNE_Mxxx( step, 201, 202, CPAAsyncComm::CMD_M753 )
// 
// 	case 202:
// 		if ( PAutoLoader->IsItemSensing() ) {
// 			if ( PAutoLoader->IsThereSlotData() ) {
// 				PAMotion->AL_MoveDiskBarcodeReadingPosition_M754( FALSE, slotIndex );
// 				step = 203;	
// 			} else {
// 				step = 300;
// 			}
// 		} else {
// 			step = 7770;
// 		}
// 		break;
// 	MOVE_DNE_Mxxx( step, 203, 204, CPAAsyncComm::CMD_M754 )
// 
// 	case 204:
// 		if ( PAutoLoader->VerifyWorkingPiece(slotIndex) ) {
// 			step = 300;
// 		} else {
// 			step = 7770;
// 		}
// 		break;
// 
// 	case 300:
// 		PAutoLoader->SetBlockState( slotIndex, BLOCK_STATE_RUNNING );
// 		PAMotion->getItemFromCassette_751( FALSE, slotIndex );
// 		PAutoLoader->SetAutoLoaderHandItemNumber( itemNumber );
// 		step = 301;
// 		break;
// 	MOVE_DNE_Mxxx( step, 301, 400, CPAAsyncComm::CMD_M751 )
// 
// 	case 400:
// 		GetItemFromAutoLoaderHand( TRUE );
// 		step = 401;
// 		break;
// 	case 401:
// 		if ( GetItemFromAutoLoaderHand( FALSE ) ) {
// 			step = 99999;
// 		}
// 		break;
// 
// 	case 7770: {
// 		EN_AUTOLOADER_FAILURE_OPTION failureOption = PAutoLoader->GetRetryOption();
// 
// 		// If the working piece is not valid, retry.
// 		switch(failureOption) {
// 			case AUTOLOADER_UP_ONE:
// 				// TODO: maybe enable?
// 				// throw CPException( ERR_PNC, PNC_ERR_AL_NO_VALID_ITEM_REQUESTED, _T("There is no valid item requested.") );
// 				PPAStatus->SetNCFileState( NCFILE_STATE_ERROR, TRUE );
// 				step = 0;
// 				break;
// 			case AUTOLOADER_RESCAN:
// 				step = 9990;
// 				returnStep = 100;
// 				break;
// 			default :
// 				// TODO: maybe enable?
// 				// throw CPException( ERR_PNC, PNC_ERR_AL_NO_VALID_ITEM_REQUESTED, _T("There is no valid item requested.") );
// 				PPAStatus->SetNCFileState( NCFILE_STATE_ERROR, TRUE );
// 				step = 0;
// 				break;
// 		}
// 		break;
// 	}
// 
// 	case 9990:
// 		if ( hasRescan ) {
// 			// TODO: maybe enable?
// 			// throw CPException( ERR_PNC, PNC_ERR_AL_NO_VALID_ITEM_REQUESTED, _T("There is no valid item requested.") );
// 			PPAStatus->SetNCFileState( NCFILE_STATE_ERROR, TRUE );
// 			step = 0;
// 			break;
// 		}
// 		doAutoloaderRescan( TRUE );
// 		step = 9991;
// 		break;
// 	case 9991:
// 		if ( doAutoloaderRescan( FALSE ) ) {
// 			hasRescan = TRUE;
// 			step = returnStep;
// 			returnStep = 0;
// 		}
// 		break;
// 
// 	case 99999:
// 		step = 0;
// 		break;
// 	}
// 
// 	return (BOOL)( step == 0 );
	return 0;
}

BOOL pa::CPThread::GetItemFromAutoLoaderHand( BOOL bResetStep )
{
	static int step = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100:
		MoveItemFromAutoLoaderHandToItemPasser( TRUE );
		step = 101;
		break;
	case 101:
		if ( MoveItemFromAutoLoaderHandToItemPasser( FALSE ) ) {
			GetItemFromItemPasser( TRUE );
			step = 102;
		}
		break;
	case 102:
		if ( GetItemFromItemPasser( FALSE ) ) {
			step = 99999;
		}
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::GetItemFromItemPasser( BOOL bResetStep )
{
	static int step = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100:
		PAMotion->workSpaceUngrip_913();
		step = 101;
		break;
	MOVE_DNE_Mxxx( step, 101, 102, CPAAsyncComm::CMD_M913 )

	case 102:
		PAMotion->itemPasserMoveToWorkPosition_784();
		step = 103;
		break;
	MOVE_DNE_Mxxx( step, 103, 104, CPAAsyncComm::CMD_M784 )

	case 104:
		PAutoLoader->SetWorkSpaceItemNumber( PAutoLoader->GetItemPasserItemNumber() );
		PAutoLoader->SetWorkIndex( PAutoLoader->GetSlotIndexFromItemNumber( PAutoLoader->GetWorkSpaceItemNumber() ) );
		PAMotion->itemPasserDown_780();
		step = 105;
		break;
	MOVE_DNE_Mxxx( step, 105, 106, CPAAsyncComm::CMD_M780 )
	
	case 106:
		PAMotion->itemPasserUngrip_782();
		step = 107;
		break;
	MOVE_DNE_Mxxx( step, 107, 108, CPAAsyncComm::CMD_M782 )
	
	case 108:
		PAMotion->itemPasserUp_779();
		step = 109;
		break;
	MOVE_DNE_Mxxx( step, 109, 110, CPAAsyncComm::CMD_M779 )

	case 110:
		PAutoLoader->SetItemPasserItemNumber( -1 );
		PAMotion->workSpaceDoubleGrip_914();
		step = 111;
		break;
	MOVE_DNE_Mxxx( step, 111, 99999, CPAAsyncComm::CMD_M914 )

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::GetItem( BOOL bResetStep, int itemNumber )
{
	static int step = 0;
	static int returnStep = 0;
	static int isBlockUnloading = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100:
		// Item Passer and Work Space are holding onto a same item.
		if ( IsItemPasserWorkSpaceTogether() ) {
			if ( PAutoLoader->GetWorkSpaceItemPasserJointItemNumber() == itemNumber ) {
				SeparateItemPasserToWorkSpace( TRUE );
				step = 110;
			} else {
				SeparateWorkSpaceToItemPasser( TRUE );
				step = 120;
			}
		} else {
			step = 190;
		}
		break;
	case 110:
		if ( SeparateItemPasserToWorkSpace( FALSE ) ) {
			step = 190;
		}
		break;
	case 120:
		if ( SeparateWorkSpaceToItemPasser( FALSE ) ) {
			step = 190;
		}
		break;
	case 190:
		if ( PAMotion->IsItemInWorkSpace() ) {
			if ( itemNumber == PAutoLoader->GetWorkSpaceItemNumber() ) {
				step = 191;
			} else {
				step = 9990;
				returnStep = 400;
			}
		} else {
			step = 200;
		}
		break;
	case 191:
		PAMotion->workSpaceGrip_912();
		step = 192;
		break;
	MOVE_DNE_Mxxx( step, 192, 8880, CPAAsyncComm::CMD_M912 )


	case 200: {
		pa::CPThread::IS_ALH_IP_TOGETHER isTogether = IsAutoLoaderHandItemPasserTogether();
		if ( isTogether == NOT_TOGETHER ) {
			step = 290;
		} else {
			isBlockUnloading = isTogether == TOGETHER_UNLOADING;
			if ( PAutoLoader->GetItemPasserAutoLoaderHandJointItemNumber() == itemNumber ) {
				SeparateAutoLoaderHandToItemPasser( TRUE, isBlockUnloading );
				step = 210;
			} else {
				SeparateItemPasserToAutoLoaderHand( TRUE, isBlockUnloading );
				step = 220;
			}
		}
		break;
	}
	case 210:
		if ( SeparateAutoLoaderHandToItemPasser( FALSE, isBlockUnloading ) ) {
			step = 290;
		}
		break;
	case 220:
		if ( SeparateItemPasserToAutoLoaderHand( FALSE, isBlockUnloading ) ) {
			step = 290;
		}
		break;
	case 290:
		if ( PAMotion->IsItemInItemPasser() ) {
			if ( itemNumber == PAutoLoader->GetItemPasserItemNumber() ) {
				GetItemFromItemPasser( TRUE );
				step = 291;
			} else {
				step = 9990;
				returnStep = 400;
			}
		} else {
			step = 300;
		}
		break;
	case 291:
		if ( GetItemFromItemPasser( FALSE ) ) {
			step = 8880;
		}
		break;


	case 300:
		if ( PAMotion->IsItemInAutoLoaderHand() ) {
			if ( itemNumber == PAutoLoader->GetAutoLoaderHandItemNumber() ) {
				GetItemFromAutoLoaderHand( TRUE );
				step = 301;
			} else {
				step = 9990;
				returnStep = 400;
			}
		} else {
			step = 400;
		}
		break;
	case 301:
		if ( GetItemFromAutoLoaderHand( FALSE ) ) {
			step = 99999;
		}
		break;


	case 400:
		GetItemFromAutoLoaderSlot( TRUE, itemNumber );
		step = 401;
		break;
	case 401:
		if ( GetItemFromAutoLoaderSlot( FALSE, itemNumber ) ) {
			step = 99999;
		}
		break;


	case 9990:
		ReturnItem( TRUE );
		step = 9991;
		break;
	case 9991:
		if ( ReturnItem( FALSE ) ) {
			step = returnStep;
			returnStep = 0;
		}
		break;


	// Clean up AutoLoader Hand and Item Passer after item is located in the Work Space.
	case 8880:
		ReturnItemExceptWorkSpace( TRUE );
		step = 8881;
		break;
	case 8881:
		if ( ReturnItemExceptWorkSpace( FALSE ) ) {
			step = 99999;
		}
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}


// ---------------------------------------- RETURN ITEM ----------------------------------------

BOOL pa::CPThread::ReturnItemFromAutoLoaderHand( BOOL bResetStep )
{
// 	static int step = 0;
// 	static int slotIndex = -1;
// 
// 	step = bResetStep ? 100 : step;
// 
// 	switch( step )
// 	{
// 	case 100: {
// 		int itemNumber = PAutoLoader->GetAutoLoaderHandItemNumber();
// 		slotIndex = PAutoLoader->GetSlotIndexFromItemNumber( itemNumber );
// 
// 		if ( slotIndex == -1 ) {
// 			step = 9990;
// 		} else {
// 			// Need to check if AL hand is in the right position.
// 			step = PPAStatus->GetPAStatus()->bInput[pa::IN20030_AutoLoader_ROT_ARM_ToPNC]  ? 200 : 300;
// 		}
// 		break;
// 	}
// 
// 	case 200:
// 		PAMotion->itemPasserUngrip_782();
// 		step = 201;
// 		break;
// 	MOVE_DNE_Mxxx( step, 201, 202, CPAAsyncComm::CMD_M782 )
// 
// 	case 202:
// 		PAMotion->autoLoaderHandToCasettePosition_786( 1 );
// 		step = 203;
// 		break;
// 	MOVE_DNE_Mxxx( step, 203, 300, CPAAsyncComm::CMD_M786 )
// 
// 	case 300:
// 		PAMotion->AL_MoveBlockSensingPosition_M753( FALSE, slotIndex );
// 		step = 301;
// 		break;
// 	MOVE_DNE_Mxxx( step, 301, 302, CPAAsyncComm::CMD_M753 )
// 
// 	case 302:
// 		if ( PAutoLoader->IsItemSensing() ) {
// 			PAutoLoader->RecordSlotExistance( slotIndex );
// 			step = (PAutoLoader->IsThereSlotData() == TRUE) ? 1000 : 9990;
// 		} else {
// 			PAMotion->putItemToCassette_752( slotIndex );
// 			step = 2001;
// 		}
// 		break;
// 
// 	case 1000:
// 		PAMotion->AL_MoveDiskBarcodeReadingPosition_M754( FALSE, slotIndex );
// 		step = 1001;
// 		break;
// 	MOVE_DNE_Mxxx( step, 1001, 1002, CPAAsyncComm::CMD_M754 )
// 
// 	case 1002:
// 		PAutoLoader->RecordSlotData( slotIndex );
// 		PAutoLoader->RemoveDuplicateBlockStates( slotIndex );
// 		step = 9990;
// 		break;
// 
// 	MOVE_DNE_Mxxx( step, 2001, 2002, CPAAsyncComm::CMD_M752 )
// 	case 2002:
// 		if ( PAutoLoader->IsThereSlotData() == TRUE ) {
// 			PAutoLoader->SetBlockState( slotIndex, BLOCK_STATE_BEFORE );
// 		} else {
// 			PAutoLoader->SetBlockState( slotIndex, BLOCK_STATE_COMPLETE );
// 		}
// 		PAutoLoader->SetAutoLoaderHandItemNumber( -1 );
// 		step = 99999;
// 		break;
// 
// 	case 9990:
// 		PlaceItemOnAnEmptySlotFromAutoLoaderHand( TRUE );
// 		step = 9991;
// 		break;
// 	case 9991:
// 		if ( PlaceItemOnAnEmptySlotFromAutoLoaderHand( FALSE ) ) {
// 			step = 99999;
// 		}
// 		break;
// 
// 	case 99999:
// 		step = 0;
// 		break;
// 	}

//	return (BOOL)( step == 0 );
	return 0;
}

BOOL pa::CPThread::ReturnItemFromItemPasser( BOOL bResetStep )
{
	static int step = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100:
		MoveItemFromItemPasserToAutoLoaderHand( TRUE );
		step = 101;
		break;
	case 101:
		if ( MoveItemFromItemPasserToAutoLoaderHand( FALSE ) ) {
			ReturnItemFromAutoLoaderHand( TRUE );
			step = 102;
		}
		break;
	case 102:
		if ( ReturnItemFromAutoLoaderHand( FALSE ) ) {
			step = 99999;
		}
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::ReturnItemFromWorkSpace( BOOL bResetStep )
{
	static int step = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100:
		MoveItemFromWorkSpaceToItemPasser( TRUE );
		step = 101;
		break;
	case 101:
		if ( MoveItemFromWorkSpaceToItemPasser( FALSE ) ) {
			ReturnItemFromItemPasser( TRUE );
			step = 102;
		}
		break;
	case 102:
		if ( ReturnItemFromItemPasser( FALSE) ) {
			step = 99999;
		}
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::ReturnItem( BOOL bResetStep )
{
	static int step = 0;
	static int slotIndex = -1;
	static int isBlockUnloading = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100: {
		pa::CPThread::IS_ALH_IP_TOGETHER isTogether = IsAutoLoaderHandItemPasserTogether();
		if ( isTogether == NOT_TOGETHER ) {
			step = 102;
		} else {

			isBlockUnloading = isTogether == TOGETHER_UNLOADING;
			SeparateItemPasserToAutoLoaderHand( TRUE, isBlockUnloading );
			step = 101;
		}
	}
	case 101:
		if ( SeparateItemPasserToAutoLoaderHand( FALSE, isBlockUnloading ) ) {
			step = 102;
		}
		break;
	case 102:
		if ( PAMotion->IsItemInAutoLoaderHand() ) {
			ReturnItemFromAutoLoaderHand( TRUE );
			step = 103;
		} else {
			step = 200;
		}
		break;
	case 103:
		if ( ReturnItemFromAutoLoaderHand( FALSE ) ) {
			step = 200;
		}
		break;

	case 200:
		if ( IsItemPasserWorkSpaceTogether() ) {
			// Item Passer and Work Space are holding onto a same item.
			SeparateWorkSpaceToItemPasser( TRUE );
			step = 201;
		} else {
			step = 202;
		}
		break;
	case 201:
		if ( SeparateWorkSpaceToItemPasser( FALSE ) ) {
			step = 202;
		}
		break;
	case 202:
		if ( PAMotion->IsItemInItemPasser() ) {
			ReturnItemFromItemPasser( TRUE );
			step = 203;
		} else {
			step = 300;
		}
		break;
	case 203:
		if ( ReturnItemFromItemPasser( FALSE ) ) {
			step = 300;
		}
		break;

	case 300:
		if ( PAMotion->IsItemInWorkSpace() ) {
			MoveReadyPosWrapper( TRUE );
			step = 301;
		} else {
			step = 99999;
		}
		break;
	case 301:
		if ( MoveReadyPosWrapper( FALSE ) ) {
			ReturnItemFromWorkSpace( TRUE );
			step = 302;
		}
		break;
	case 302:
		if ( ReturnItemFromWorkSpace( FALSE ) ) {
			step = 99999;
		}
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::ReturnItemExceptWorkSpace( BOOL bResetStep )
{
	static int step = 0;
	static int slotIndex = -1;
	static int isBlockUnloading = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100: {
		pa::CPThread::IS_ALH_IP_TOGETHER isTogether = IsAutoLoaderHandItemPasserTogether();
		if ( isTogether == NOT_TOGETHER ) {
			step = 102;
		} else {

			isBlockUnloading = isTogether == TOGETHER_UNLOADING;
			SeparateItemPasserToAutoLoaderHand( TRUE, isBlockUnloading );
			step = 101;
		}
		break;
	}
	case 101:
		if ( SeparateItemPasserToAutoLoaderHand( FALSE, isBlockUnloading ) ) {
			step = 102;
		}
		break;
	case 102:
		if ( PAMotion->IsItemInAutoLoaderHand() ) {
			ReturnItemFromAutoLoaderHand( TRUE );
			step = 103;
		} else {
			step = 200;
		}
		break;
	case 103:
		if ( ReturnItemFromAutoLoaderHand( FALSE ) ) {
			step = 200;
		}
		break;

	case 200:
		if ( PAMotion->IsItemInItemPasser() ) {
			ReturnItemFromItemPasser( TRUE );
			step = 201;
		} else {
			step = 99999;
		}
		break;
	case 201:
		if ( ReturnItemFromItemPasser( FALSE ) ) {
			step = 99999;
		}
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::PlaceItemOnAnEmptySlotFromAutoLoaderHand( BOOL bResetStep )
{
	static int step = 0;
	static int returnStep = 0;
	static BOOL hasRescan = FALSE;
	static int emptySlotIndex = -1;

	step = bResetStep ? 1 : step;

	switch( step )
	{
	case 1:
		hasRescan = FALSE;
		step = 100;
		break;
	
	case 100:
		emptySlotIndex = PAutoLoader->GetEmptySlotIndex();
		if ( emptySlotIndex == -1 ) {
			step = 9990;
			returnStep = 100;
		} else {
			step = 200;
		}
		break;

	case 200: 
		PAMotion->AL_MoveBlockSensingPosition_M753( FALSE, emptySlotIndex );
		step = 201;
		break;
	MOVE_DNE_Mxxx( step, 201, 202, CPAAsyncComm::CMD_M753 )

	case 202:
		if ( PAutoLoader->IsItemSensing() ) {
			step = 9990;
			returnStep = 100;
		} else {
			PAMotion->putItemToCassette_752( emptySlotIndex );
			step = 203;
		}
		break;
	MOVE_DNE_Mxxx( step, 203, 204, CPAAsyncComm::CMD_M752 )

	case 204:
		PAutoLoader->SetAutoLoaderHandItemNumber( -1 );
		
		if ( PAutoLoader->IsThereSlotData() == TRUE ) {
			PAutoLoader->SetBlockState( emptySlotIndex, BLOCK_STATE_BEFORE );
			step = 205;
		} else {
			PAutoLoader->SetBlockState( emptySlotIndex, BLOCK_STATE_COMPLETE );
			step = 99999;
		}
		break;

	case 205:
		if ( hasRescan ) {
			doAutoloaderBarcodeScan( TRUE );
			step = 206;
		} else {
			PAMotion->AL_MoveDiskBarcodeReadingPosition_M754( FALSE, emptySlotIndex );
			step = 301;
		}
		break;
	case 206:
		if ( doAutoloaderBarcodeScan( FALSE ) ) {
			hasRescanForRefill_ = TRUE;
			step = 99999;
		}
		break;

	MOVE_DNE_Mxxx( step, 301, 302, CPAAsyncComm::CMD_M754 )
	case 302:
		PAutoLoader->RecordSlotData( emptySlotIndex );
		PAutoLoader->RemoveDuplicateBlockStates( emptySlotIndex );
		step = 99999;
		break;

	case 9990:
		if ( hasRescan ) {
			PPAStatus->SetNCFileState( NCFILE_STATE_ERROR, TRUE );
			throw CPException( ERR_PNC, PNC_ERR_AL_NO_EMPTY_SLOT, _T("There is no empty AutoLoader slot.") );
			step = 0;
			break;
		}
		doAutoloaderExistanceScan( TRUE );
		step = 9991;
		break;
	case 9991:
		if ( doAutoloaderExistanceScan( FALSE ) ) {
			hasRescan = TRUE;
			step = returnStep;
			returnStep = 0;
		}
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}


// ---------------------------------------- Move ITEM ----------------------------------------

BOOL pa::CPThread::MoveItemFromItemPasserToAutoLoaderHand( BOOL bResetStep )
{
	static int step = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100:
		PAMotion->moveItemPasserToExchangePosition_783( 1 );
		step = 101;
		break;
	MOVE_DNE_Mxxx( step, 101, 102, CPAAsyncComm::CMD_M783 )
	
	case 102:
		PAMotion->autoLoaderHandUngrip_778();
		step = 103;
		break;
	MOVE_DNE_Mxxx( step, 103, 104, CPAAsyncComm::CMD_M778 )

	case 104:
		PAMotion->autoLoaderHandToExchangePosition_785( 1 );
		PAutoLoader->SetAutoLoaderHandItemNumber( PAutoLoader->GetItemPasserItemNumber() );
		step = 105;
		break;
	MOVE_DNE_Mxxx( step, 105, 106, CPAAsyncComm::CMD_M785 )

	case 106:
		PAMotion->itemPasserUngrip_782();
		step = 107;
		break;
	MOVE_DNE_Mxxx( step, 107, 108, CPAAsyncComm::CMD_M782 )

	case 108:
		PAMotion->autoLoaderHandGrip_777();
		step = 109;
		break;
	MOVE_DNE_Mxxx( step, 109, 110, CPAAsyncComm::CMD_M777 )

	case 110:
		PAMotion->autoLoaderHandToCasettePosition_786( 1 );
		step = 111;
		break;
	MOVE_DNE_Mxxx( step, 111, 112, CPAAsyncComm::CMD_M786 )

	case 112:
		PAutoLoader->SetItemPasserItemNumber( -1 );
		step = 99999;
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::MoveItemFromWorkSpaceToItemPasser( BOOL bResetStep )
{
	static int step = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100:
		PAMotion->workSpaceUngrip_913();
		step = 101;
		break;
	MOVE_DNE_Mxxx( step, 101, 102, CPAAsyncComm::CMD_M913 )

	case 102:
		PAMotion->itemPasserUngrip_782();
		step = 103;
		break;
	MOVE_DNE_Mxxx( step, 103, 104, CPAAsyncComm::CMD_M782 )

	case 104:
		PAMotion->itemPasserMoveToWorkPosition_784();
		step = 105;
		break;
	MOVE_DNE_Mxxx( step, 105, 106, CPAAsyncComm::CMD_M784 )

	case 106:
		PAMotion->itemPasserDown_780();
		PAutoLoader->SetItemPasserItemNumber( PAutoLoader->GetWorkSpaceItemNumber() );
		step = 107;
		break;
	MOVE_DNE_Mxxx( step, 107, 108, CPAAsyncComm::CMD_M780 )
	
	case 108:
		PAMotion->itemPasserGrip_781();
		step = 109;
		break;
	MOVE_DNE_Mxxx( step, 109, 110, CPAAsyncComm::CMD_M781 )
	
	case 110:
		PAMotion->itemPasserUp_779();
		step = 111;
		break;
	MOVE_DNE_Mxxx( step, 111, 112, CPAAsyncComm::CMD_M779 )

	case 112:
		PAutoLoader->SetWorkSpaceItemNumber( -1 );
		PAutoLoader->SetWorkIndex( -1 );
		PAMotion->workSpaceGrip_912();
		step = 113;
		break;
	MOVE_DNE_Mxxx( step, 113, 99999, CPAAsyncComm::CMD_M912 )
	
	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::MoveItemFromAutoLoaderHandToItemPasser( BOOL bResetStep )
{
	static int step = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100:
		PAMotion->itemPasserUngrip_782();
		step = 101;
		break;
	MOVE_DNE_Mxxx( step, 101, 102, CPAAsyncComm::CMD_M782 )

	case 102:
		PAMotion->moveItemPasserToExchangePosition_783( 0 );
		step = 103;
		break;
	MOVE_DNE_Mxxx( step, 103, 104, CPAAsyncComm::CMD_M783 )
	
	case 104:
		PAMotion->autoLoaderHandToExchangePosition_785( 0 );
		PAutoLoader->SetItemPasserItemNumber( PAutoLoader->GetAutoLoaderHandItemNumber() );
		step = 105;
		break;
	MOVE_DNE_Mxxx( step, 105, 106, CPAAsyncComm::CMD_M785 )

	case 106:
		PAMotion->itemPasserGrip_781();
		step = 107;
		break;
	MOVE_DNE_Mxxx( step, 107, 108, CPAAsyncComm::CMD_M781 )

	case 108:
		PAMotion->autoLoaderHandUngrip_778();
		step = 109;
		break;
	MOVE_DNE_Mxxx( step, 109, 110, CPAAsyncComm::CMD_M778 )

	case 110:
		PAMotion->autoLoaderHandToCasettePosition_786( 0 );
		PAutoLoader->SetAutoLoaderHandItemNumber( -1 );
		step = 111;
		break;
	MOVE_DNE_Mxxx( step, 111, 99999, CPAAsyncComm::CMD_M786 )

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::SeparateWorkSpaceToItemPasser( BOOL bResetStep )
{
	static int step = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100:
		PAMotion->workSpaceUngrip_913();
		step = 101;
		break;
	MOVE_DNE_Mxxx( step, 101, 102, CPAAsyncComm::CMD_M913 )

	case 102:
		PAMotion->itemPasserGrip_781();
		step = 103;
		break;
	MOVE_DNE_Mxxx( step, 103, 104, CPAAsyncComm::CMD_M781 )

	case 104:
		PAMotion->itemPasserUp_779();
		PAutoLoader->SetWorkSpaceItemNumber( -1 );
		PAutoLoader->SetWorkIndex( -1 );
		step = 105;
		break;
	MOVE_DNE_Mxxx( step, 105, 106, CPAAsyncComm::CMD_M779 )
	
	case 106:
		PAMotion->workSpaceGrip_912();
		step = 107;
		break;
	MOVE_DNE_Mxxx( step, 107, 108, CPAAsyncComm::CMD_M912 )

	case 108:	// TODO: This step may be unnecessary.
		PAMotion->MoveReadyPos();
		step = 99999;
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::SeparateItemPasserToWorkSpace( BOOL bResetStep )
{
	static int step = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100:
		PAMotion->itemPasserUngrip_782();
		step = 101;
		break;
	MOVE_DNE_Mxxx( step, 101, 102, CPAAsyncComm::CMD_M782 )
	
	case 102:
		PAMotion->itemPasserUp_779();
		PAutoLoader->SetItemPasserItemNumber( -1 );
		step = 103;
		break;
	MOVE_DNE_Mxxx( step, 103, 104, CPAAsyncComm::CMD_M779 )

	case 104:
		PAMotion->workSpaceDoubleGrip_914();
		step = 105;
		break;
	MOVE_DNE_Mxxx( step, 105, 106, CPAAsyncComm::CMD_M914 )

	case 106:	// TODO: This step may be unnecessary.
		PAMotion->MoveReadyPos();
		step = 99999;
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::SeparateItemPasserToAutoLoaderHand( BOOL bResetStep, int isUnLoading )
{
	static int step = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100:
		PAMotion->itemPasserUngrip_782();
		step = 101;
		break;
	MOVE_DNE_Mxxx( step, 101, 102, CPAAsyncComm::CMD_M782 )

	case 102:
		PAutoLoader->SetAutoLoaderHandItemNumber( PAutoLoader->GetItemPasserAutoLoaderHandJointItemNumber() );
		PAMotion->autoLoaderHandToCasettePosition_786( isUnLoading );
		PAutoLoader->SetItemPasserItemNumber( -1 );
		step = 103;
		break;
	MOVE_DNE_Mxxx( step, 103, 99999, CPAAsyncComm::CMD_M786 )

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::SeparateAutoLoaderHandToItemPasser( BOOL bResetStep, int isUnLoading )
{
	static int step = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100:
		PAutoLoader->SetItemPasserItemNumber( PAutoLoader->GetItemPasserAutoLoaderHandJointItemNumber() );
		PAMotion->itemPasserGrip_781();
		step = 101;
		break;
	MOVE_DNE_Mxxx( step, 101, 102, CPAAsyncComm::CMD_M781 )

	case 102:
		PAMotion->autoLoaderHandToCasettePosition_786( isUnLoading );
		PAutoLoader->SetAutoLoaderHandItemNumber( -1 );
		step = 103;
		break;
	MOVE_DNE_Mxxx( step, 103, 99999, CPAAsyncComm::CMD_M786 )

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPThread::MoveReadyPosWrapper( BOOL bResetStep )
{
	static int step = 0;

	step = bResetStep ? 100 : step;

	switch( step )
	{
	case 100:
		PAMotion->workSpaceGrip_912();
		step = 101;
		break;
	MOVE_DNE_Mxxx( step, 101, 102, CPAAsyncComm::CMD_M912 )

	case 102:
		PAMotion->MoveReadyPos();
		step = 99999;
		break;

	case 99999:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

pa::CPThread::IS_ALH_IP_TOGETHER pa::CPThread::IsAutoLoaderHandItemPasserTogether()
{
// 	if ( PPAStatus->GetPAStatus()->bInput[pa::IN20030_AutoLoader_ROT_ARM_ToPNC]
// 	   && PPAStatus->GetPAStatus()->bInput[pa::IN20025_AutoLoader_EXT_ARM]
// 	   && PAMotion->IsItemInItemPasser() ) {
		// AutoLoader Hand and Item Passer are holding onto a same item
// 		double	xpos = pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X];
// 		double	ypos = pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y];
// 		double	fxLoading = fabs( xpos - PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_BLOCK_LOADER][pa::AXIS_X] );
// 		double	fyLoading = fabs( ypos - PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_BLOCK_LOADER][pa::AXIS_Y] );
// 		double	fxUnloading = fabs( xpos - PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_BLOCK_UNLOADER][pa::AXIS_X] );
// 		double	fyUnloading = fabs( ypos - PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_BLOCK_UNLOADER][pa::AXIS_Y] );
// 		double offset = 1.0;
// 
// 		int isBlockLoading = fxLoading < offset && fyLoading < offset;
// 		int isBlockUnloading = fxUnloading < offset && fyUnloading < offset;
// 
// 		if ( isBlockLoading ) return TOGETHER_LOADING;
// 		if ( isBlockUnloading ) return TOGETHER_UNLOADING;
//	}

	return NOT_TOGETHER;
}

BOOL pa::CPThread::IsItemPasserWorkSpaceTogether()
{
	// Item Passer and Work Space are holding onto a same item.
	return PAMotion->IsItemInItemPasser()
		&& PAMotion->IsItemInWorkSpace();
//		&& PPAStatus->GetPAStatus()->bInput[pa::IN20021_AutoLoader_PNC_Gripper_Down];
}
