#include "StdAfx.h"
#include "EPncMDllApp.h"

//////////////////////////////////////////////////////////////////////////
//
EPNCMDLL_API CEPncMDllApp theApp;

CEPncMDllApp::CEPncMDllApp(void)
{
	pMainDlg = NULL;
}

CEPncMDllApp::~CEPncMDllApp(void)
{
}

// App ��ü�� �ʱ�ȭ �Ѵ� 
int CEPncMDllApp::Initialize()
{
	//////////////////////////////////////////////////////////////////////////
	// �ڵ尡 ������, ���̾�α׸� ���� �� ����
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	//////////////////////////////////////////////////////////////////////////

//	P_VERSION = _T("DS-20170901-5m_DLL-test-release");
	P_VERSION = _T("CM-20201012-DLL-003-test");	

	//////////////////////////////////////////////////////////////////////////
	// ������ �ʱ�ȭ �Ѵ� 
	CString strErrMsg(_T(""));
	hcsock::STARTUP_SOCKET_COMM(strErrMsg);

	//////////////////////////////////////////////////////////////////////////
	// �� ������ �д´�
	pa::MODEL_INFO.Load();

	//////////////////////////////////////////////////////////////////////////
	// Main Dialog�� ���� �Ѵ� 
	pMainDlg = new CEPncMDlg();
	ASSERT(pMainDlg);
	BOOL b = pMainDlg->Create(106/*IDD_DIALOG_EPNCM*/, NULL);
// 	pMainDlg->ShowWindow(SW_SHOW);

	if (pMainDlg->GetInitSuccess() != 0)
	{
		pMainDlg->ShowWindow(SW_HIDE);
	}

	return pMainDlg->GetInitSuccess();
}

// App ��ü�� ���� �Ѵ�
void CEPncMDllApp::Destory()
{
	if (pMainDlg != NULL)
	{
		pMainDlg->DestroyWindow();
		delete pMainDlg;
		pMainDlg = NULL;
	}

	hcsock::CLEANUP_SOCKET_COMM();
}
