#pragma once

//////////////////////////////////////////////////////////////////////////
// IpcQueue�� �ܹ��� Queue �̱� ������,
//	- IpcServer������ Listen�� �� �� �ְ�,
//	- IpcClient������ Send�� �� �� �ִ� 
//////////////////////////////////////////////////////////////////////////

namespace pa 
{
//////////////////////////////////////////////////////////////////////////

class CPIpcServer : public CGeneralThread
{
private:
	hcipc::CIpcQueue	*pIpcQueue_;
	void subCommandProc( SIpcCommCommand& cmd );

	void uploadCoordinateOffset();
	void uploadTeachingPoint();
	void uploadOption();
	void uploadFlowSensorData();
	void uploadAutoLoaderTeachingPoint();

	void downloadCoordinateOffset();
	void downloadTeachingPoint();
	void downloadOption();
	void downloadFlowSensorData();
	void downloadAutoLoaderTeachingPoint();

	void writeLog_IPC( LPCTSTR logMsg );

public:
	BOOL Initialize( DWORD dwCycleTime, CString& strErrMsg );
	void Destroy();

	// Virtual Method
public:
	virtual void Execute();


public:
	CPIpcServer(void);
	virtual ~CPIpcServer(void);
};

//////////////////////////////////////////////////////////////////////////
}