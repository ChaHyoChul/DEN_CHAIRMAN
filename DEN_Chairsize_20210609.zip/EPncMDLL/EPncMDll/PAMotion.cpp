#include "StdAfx.h"
#include "PAMotion.h"
// #include "EPncM.h"
#include "EPncMDLL.h"

//////////////////////////////////////////////////////////////////////////
//
BOOL pa::CPAMotion::NOT_CHECK_STATUS = FALSE;
BOOL pa::CPAMotion::STREAM_MODE_ERROR= FALSE;

//////////////////////////////////////////////////////////////////////////



pa::CPAMotion::CPAMotion(void)
{
	InitializeCriticalSection( &hCS_ );

	hSockStream_	= INVALID_SOCKET;
	dwStreamTimeout_= 2000; //3000;
}

pa::CPAMotion::~CPAMotion(void)
{
	DeleteCriticalSection( &hCS_ );
}

// 1:RND_HALT
void pa::CPAMotion::HALT()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_HALT );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_HALT );
}

// 0:RND_RST
void pa::CPAMotion::RST()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_RST );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_RST, 30*1000 );
}

// 0:RND_INIT
void pa::CPAMotion::INIT()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_INIT );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_INIT );
}

// 0:RND_MODE
void pa::CPAMotion::MODE( CPAAsyncComm::EN_PA_RUNMODE hRunMode )
{
	char*	P_PA_RUNMODE[] = { "OFF", "AUTO", "STEP", "MDA" };

	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_MODE, P_PA_RUNMODE[hRunMode] );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_MODE );
}

// 0:RND_STREAM
void pa::CPAMotion::STREAM()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_STREAM );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_STREAM );
}

void pa::CPAMotion::PAUSE_MCODE_THREAD()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_MCODE_THREAD_PAUSE );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_MCODE_THREAD_PAUSE );
}

void pa::CPAMotion::RESUME_MCODE_THREAD()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_MCODE_THREAD_RESUME );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_MCODE_THREAD_RESUME );
}

// 1:RND_STOP
void pa::CPAMotion::STOP( int is_stream /*=0*/ )
{
	try {
// 		EnterCriticalSection( &hCS_ );
		if( is_stream == 0 ) 
		{
			PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RND_STOP );
			PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RND_STOP, 30000 ); //0 );
		}
		else 
		{
			PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RND_STOP, "1" );
			PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RND_STOP, 30000 ); //0 );
		}
// 		LeaveCriticalSection( &hCS_ );
	}
	catch( CPException& e ) {
// 		LeaveCriticalSection( &hCS_ );
		throw e;
	}
}

// 1:RND_PAUSE
void pa::CPAMotion::PAUSE()
{
	try {
// 		EnterCriticalSection( &hCS_ );
		PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RND_PAUSE );
		PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RND_PAUSE, 120*1000 );
// 		LeaveCriticalSection( &hCS_ );
		TRACE( _T("void pa::CPAMotion::PAUSE()\n") );
	}
	catch( CPException& e ) {
// 		LeaveCriticalSection( &hCS_ );
		throw e;
	}
}

// 0:RND_CONTINUE
void pa::CPAMotion::CONTINUE()
{
	try {
// 		EnterCriticalSection( &hCS_ );
		PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_CONTINUE );
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_CONTINUE );
// 		LeaveCriticalSection( &hCS_ );
		TRACE( _T("void pa::CPAMotion::CONTINUE()\n") );
	}
	catch( CPException& e ) {
// 		LeaveCriticalSection( &hCS_ );
		throw e;
	}
}

// 1:RND_STATUS
void pa::CPAMotion::STATUS()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RND_STATUS );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RND_STATUS, 5000 ); // 0 );	// 2017.05.20. 0���� ���� ���, ������ ������ ���� ��� �Ѵ� 
																			// - 5�ʷ� ���������� RND_STATUS[8]���� timeout ������ �߻��ؼ� 10�ʷ� ������ ���� 
																			// - 10�ʷ� ���������� RND_STATUS[8]���� timeout ������ �߻��ؼ� 30�ʷ� ������ ���� 
																			// - 30�ʷ� ���������� RND_STATUS[8]���� timeout ������ �߻��ؼ� 0�ʷ� ������ ���� 
																			// - log �߰� �� �ٽ� 10�ʷ� ���� 
}

// 0:RND_MDA
pa::CPAAsyncComm::EN_COMMAND pa::CPAMotion::MDA( BOOL blocking, char* pCommand )
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_MDA, pCommand );
	if( blocking ) 
	{
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_MDA );
	}
	return CPAAsyncComm::CMD_RND_MDA;

	// MDA ���� ���� ������ �Ʒ� ������� ��� 
// 	ATTACH( 0 );	// attach 0
// 	ATTACH( 1 );	// attach 
// 	MODE( CPAAsyncComm::PA_RUNMODE_MDA );
// 	COMMAND( TRUE, pCommand );
// 	MODE( CPAAsyncComm::PA_RUNMODE_AUTO );
// 	ATTACH( 0 );
// 	return CPAAsyncComm::CMD_RND_MDA;
}

// 0:RND_ATTACH
void pa::CPAMotion::ATTACH( int mode )
{
	char param[32];
	if( mode == 0 ) {
		sprintf_s( param, 32, "0" );
	} else {
		sprintf_s( param, 32, "", mode );
	}

	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_ATTACH, param );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_ATTACH );
}

// 0:RND_COMMAND => ��� ����
pa::CPAAsyncComm::EN_COMMAND pa::CPAMotion::COMMAND( BOOL blocking, char* pcommand )
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_COMMAND, pcommand );
	if( blocking )
	{
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_COMMAND, 0 );
	}
	return CPAAsyncComm::CMD_RND_COMMAND;
}

// 0:RND_HOME
pa::CPAAsyncComm::EN_COMMAND pa::CPAMotion::HOME( BOOL blocking )
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_HOME );
	if( blocking ) 
	{
		// 2016.09.21. 
		//	4WA ��� INC ���͸� ���� ����� Timeout �� �ʿ�. 
		//	�������� INFINITE�� ������, �׷� �� ���� �ð��� ũ�� �Է� (3��)
		// PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_HOME, 180*1000 );
		//	�������� INFINITE�� ������, �׷� �� ���� �ð��� ũ�� �Է� (5��)
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_HOME, 300*1000 );
	}
	return CPAAsyncComm::CMD_RND_HOME;
}

// 0:RND_ORG
pa::CPAAsyncComm::EN_COMMAND pa::CPAMotion::ORG( BOOL blocking )
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_ORG );
	if( blocking )
	{
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_ORG );
	}
	return CPAAsyncComm::CMD_RND_ORG;
}

// 0:JOG 
//	> jog_mode : step / cont 
void pa::CPAMotion::JOG( EN_AXIS hAxis, BOOL bDir, BOOL bStep, double fStepDist )
{
	char param[64];

	if( !bStep ) {
		// Continuous
		sprintf_s( param, 64, "%d,%d", (int)(hAxis+1), (bDir ? 1 : -1) );
		PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_JOG, param );
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_JOG );
	}
	else {
		// Step 
		double fPos[pa::AXIS_NUM+1] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };	// AutoLoader �� �߰�. C�� 
		fPos[hAxis] = fStepDist * ( bDir ? 1.0 : -1.0 );
		switch( pa::MODEL_INFO.GetNumAxis() )
		{
		case 3:
			sprintf_s( param, 64, "%.3f,%.3f,%.3f", fPos[0], fPos[1], fPos[2] );
			break;
		case 4:
			sprintf_s( param, 64, "%.3f,%.3f,%.3f,%.3f", fPos[0], fPos[1], fPos[2], fPos[3] );
			break;
		case 5:
			if( PAutoLoader && PAutoLoader->IsUsingAutoLoader() ) {
				sprintf_s( param, 64, "%.3f,%.3f,%.3f,%.3f,%.3f,%.3f", fPos[0], fPos[1], fPos[2], fPos[3], fPos[4], fPos[5] );
			}
			else {
				sprintf_s( param, 64, "%.3f,%.3f,%.3f,%.3f,%.3f", fPos[0], fPos[1], fPos[2], fPos[3], fPos[4] );
			}
			break;
		default:
			return ;
		}
		PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_MMI, param );
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_MMI );
	}
}

void pa::CPAMotion::JSTOP()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_JSTOP );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_JSTOP );
}

// 0:Read Jog Speed 
void pa::CPAMotion::RJSS()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RJSS );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RJSS );
}

// 0:Set Jog Speed
void pa::CPAMotion::WJSS( int jog_speed )
{
	char param[64];

	sprintf_s( param, 64, "%d", jog_speed );
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_WJSS, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_WJSS );
	//////////////////////////////////////////////////////////////////////////
	// ������ ���� 
// 	CPAAsyncComm::N_TEMP_JOG_SPEED = jog_speed;
	pa::PPAStatus->GetThreadState()->nJogSpeed_ = jog_speed;
	//////////////////////////////////////////////////////////////////////////
}

// 0:Get Coordinate Offset 
void pa::CPAMotion::RCFG( EN_COORDINATE hCoordNo )
{
	char param[64];

	sprintf_s( param, 64, "%d", 53+hCoordNo );
	CPAAsyncComm::H_TEMP_COORDINATE_NO = hCoordNo; 
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RCFG, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RCFG );
}

// 0:Set Coordinate Offset 
void pa::CPAMotion::WCFG( int coordno, double val[] )
{
	char param[128];

	sprintf_s( param, 128, "1,%d,%.3f,%.3f,%.3f,0.0,0.0,0.0,%.3f,%.3f", 53+coordno, val[0], val[1], val[2], val[3], val[4] );
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_WCFG, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_WCFG );
	//////////////////////////////////////////////////////////////////////////
	// ������ ���� 
	for( int i = 0; i<pa::MODEL_INFO.GetNumAxis(); i++ ) {
		PConfig->pConfig_->fCoordOffset[coordno][i] = val[i];
	}
	//////////////////////////////////////////////////////////////////////////
}

// 0:Get Teaching Point 
void pa::CPAMotion::RTCP( EN_TEACHING_POINT hTeachingPoint )
{
	char param[32];
	int  tp_no = N_TEACHING_POINT_NO[(int)hTeachingPoint];

	//////////////////////////////////////////////////////////////////////////
	// 2016.09.06.
	//	ready position�� ���ε� ���� �ʴ´� (B���� <0�� ���, A���� -180 ���� �ٲ�� ���� ����) 
	/*
	enum EN_TEACHING_POINT 
	{
	TEACHING_POINT_TOOL1 = 0,		// point no. 1
	TEACHING_POINT_TOOL2,			// point no. 2
	TEACHING_POINT_TOOL3,			// point no. 3
	TEACHING_POINT_TOOL4,			// point no. 4
	TEACHING_POINT_TOOL5,			// point no. 5
	TEACHING_POINT_TOOL6,			// point no. 6
	TEACHING_POINT_TOOL7,			// point no. 7
	TEACHING_POINT_TOOL8,			// point no. 8
	TEACHING_POINT_READYPOS,		// point no. 9
	TEACHING_POINT_BLOCK_LOADER,	// point no. 10	=> autoloader �۾� ����. �߰�  
	TEACHING_POINT_BLOCK_UNLOADER,	// point no. 11	=> autoloader �۾� ����. �߰�  
	TEACHING_POINT_BLOCK_WORK,		// point no. 12
	TEACHING_POINT_SENSING_UP,		// point no. 19
	TEACHING_POINT_SENSING_DN,		// point no. 20
	TEACHING_POINT_NUM
	};
	*/
	//////////////////////////////////////////////////////////////////////////
	// 2016.09.06.
	//	ready position�� ���ε� ���� �ʴ´� (B���� <0�� ���, A���� -180 ���� �ٲ�� ���� ����) 
	// 2017.05.16 
	//	block-loader, block-work ��ġ�� ���ε� ���� �ʴ´� 
	if( tp_no == 9 ) //|| tp_no == 10 || tp_no == 11 ) 
	{
		return ;
	}

	//////////////////////////////////////////////////////////////////////////

	sprintf_s( param, 32, "%d", tp_no );

	CPAAsyncComm::H_TEMP_TEACHING_POINT_NO = hTeachingPoint;
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RTCP, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RTCP );
}

// 0:Set Teaching Point 
void pa::CPAMotion::WTCP( int index, int tp_no, double val[] )
{
	char param[256];

	//////////////////////////////////////////////////////////////////////////
	// 2016.09.08. A,B���� 0�� �����ϵ��� ���� 
// 	switch( PConfig->pConfig_->nNumAxis )
// 	{
// 	case 3:
// 	default:
// 		sprintf_s( param, 256, "%d,%.3f,%.3f,%.3f", tp_no, val[0], val[1], val[2] );
// 		break;
// 	case 4:
// 		sprintf_s( param, 256, "%d,%.3f,%.3f,%.3f,%.3f", tp_no, val[0], val[1], val[2], val[3] );
// 		break;
// 	case 5:
// 		sprintf_s( param, 256, "%d,%.3f,%.3f,%.3f,%.3f,%.3f", tp_no, val[0], val[1], val[2], val[3], val[4] );
// 		break;
// 	}
	sprintf_s( param, 256, "%d,%.3f,%.3f,%.3f,%.3f,%.3f", tp_no, val[0], val[1], val[2], val[3], val[4] );

	//////////////////////////////////////////////////////////////////////////
	// 2016.09.06.
	//	ready position�� �ٿ�ε� ���� �ʴ´� (B���� <0�� ���, A���� -180 ���� �ٲ�� ���� ����) 
	// 2017.05.16 
	//	block-loader, block-work ��ġ�� �ٿ�ε� ���� �ʴ´� 	
	if( tp_no != 9 ) //&& tp_no !=10 && tp_no != 11 )
	{
		PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_WTCP, param );
		PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_WTCP );
	}
	else
	{
		// ���Ͽ� �����Ѵ� 
		TCHAR*		pFilePath =  INI_TEACHING_POINT_PATH;
		CString		strAxisName[] = { _T("_X"), _T("_Y"), _T("_Z"), _T("_A"), _T("_B") }; 
		CCEIniFile	hIniFile;
		CString		strValueName;

		if( hIniFile.Open( pFilePath ) ) {
			for( int j = 0; j<pa::AXIS_NUM; j++ ) {
				strValueName = pa::STR_TEACHING_POINT[pa::TEACHING_POINT_READYPOS] + strAxisName[j];
				hIniFile.SetValue( _T("TeachingPoint"), strValueName, (double)(pa::PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_READYPOS][j]) );
			}		
			hIniFile.Close();
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// ������ ���� 
	for( int i = 0; i<pa::MODEL_INFO.GetNumAxis(); i++ ) {
		PConfig->pConfig_->fTeachingPoint[index][i] = val[i];
	}
	//////////////////////////////////////////////////////////////////////////
}

// 0:Get Z-Offset 
void pa::CPAMotion::RZOO()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RZOO );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RZOO );
}

void pa::CPAMotion::RTOO(int nDirection)
{
	char param[64];

	sprintf_s( param, 64, "%d", nDirection);
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RTOO, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RTOO );
}

void pa::CPAMotion::RTDATA(char* szDataname)
{
	char param[64];

	sprintf_s( param, 64, "%s", szDataname );
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RTDATA, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RTDATA );
}

// 0:Set Z-Offset 
void pa::CPAMotion::WZOO( double z_offset )
{
	char param[64];

	sprintf_s( param, 64, "%.3f", z_offset );
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_WZOO, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_WZOO );
	//////////////////////////////////////////////////////////////////////////
	// ������ ���� 
	PConfig->pConfig_->fOptionData[OPTION_Z1AXIS_ORIGIN_OFFSET] = z_offset;
	//////////////////////////////////////////////////////////////////////////
}

void pa::CPAMotion::WTOO( int nDirection, double z_offset )
{
	char param[64];

	sprintf_s( param, 64, "%d,%.3f", nDirection, z_offset );
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_WTOO, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_WTOO );

	if (nDirection == 1)
	{
		PConfig->pConfig_->fOptionData[OPTION_Z1AXIS_ORIGIN_OFFSET] = z_offset;
	}

	else if (nDirection == 2)
	{
		PConfig->pConfig_->fOptionData[OPTION_Z2AXIS_ORIGIN_OFFSET] = z_offset;
	}
}

void pa::CPAMotion::WTDATA( char* szDataname, double dwData )
{
	char param[64];

	sprintf_s( param, 64, "%s,%.3f", szDataname, dwData );
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_WTDATA, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_WTDATA );

	if (strcmp(szDataname, "spindleoffset") == 0)
	{
		PConfig->pConfig_->fOptionData[OPTION_SPINDLE_OFFSET] = dwData;

	}
}

// 0:Get Tool Sensing High Speed 
void pa::CPAMotion::RTHS()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RTHS );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RTHS );
}

// 0:Set Tool Sensing High Speed 
void pa::CPAMotion::WTHS( int high_speed )
{
	char param[64];

	sprintf_s( param, 64, "%d", high_speed );
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_WTHS, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_WTHS );
	//////////////////////////////////////////////////////////////////////////
	// ������ ���� 
	PConfig->pConfig_->fOptionData[OPTION_TOOL_SENSING_HIGHSPEED] = high_speed;
	//////////////////////////////////////////////////////////////////////////
}

// 0:Get Tool Sensing Low Speed
void pa::CPAMotion::RTLS()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RTLS );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RTLS );
}

// 0:Set Tool Sensing Low Speed 
void pa::CPAMotion::WTLS( int low_speed )
{
	char param[64];

	sprintf_s( param, 64, "%d", low_speed );
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_WTLS, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_WTLS );
	//////////////////////////////////////////////////////////////////////////
	// ������ ���� 
	PConfig->pConfig_->fOptionData[OPTION_TOOL_SENSING_LOWSPEED] = low_speed;
	//////////////////////////////////////////////////////////////////////////
}

// 0:Output Signal 
void pa::CPAMotion::IOT( int bit, int signal )
{
	char param[64];

	bit = pa::SPAStatus::OUTPUT_BIT_NO[bit];

	sprintf_s( param, 64, "%d,%d", bit, signal );
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_IOT, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_IOT, 3000 );
}

// 1:RND_STATE 
void pa::CPAMotion::RND_STATE()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RND_STATE );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RND_STATE, 5000 ); // 0 );		// 2017.05.20. 0���� ���� ���, ������ ������ ���� ��� �Ѵ�  0 );
																			// - 5�ʷ� ���������� RND_STATUS[8]���� timeout ������ �߻��ؼ� 10�ʷ� ������ ���� 
																			// - 10�ʷ� ���������� RND_STATUS[8]���� timeout ������ �߻��ؼ� 30�ʷ� ������ ���� 
																			// - 30�ʷ� ���������� RND_STATUS[8]���� timeout ������ �߻��ؼ� 0�ʷ� ������ ���� 
																			// - log ���� �� 10�ʷ� ���� 
}

// 1:RND_AES
void pa::CPAMotion::RND_AES()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RND_AES );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RND_AES );
}

// 1:RND_ASS
void pa::CPAMotion::RND_ASS()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RND_ASS );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RND_ASS );
}

// 0:RND_MMA
pa::CPAAsyncComm::EN_COMMAND pa::CPAMotion::RND_MMA( BOOL blocking, double position[] )
{
	char param[128];

	sprintf_s( param, 128, "%.3f,%.3f,%.3f,%.3f,%.3f", position[0], position[1], position[2], position[3], position[4] );
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_MMA, param );
	if( blocking )
	{
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_MMA );
	}

	return CPAAsyncComm::CMD_RND_MMA;
}

// 0:RND_MMI
pa::CPAAsyncComm::EN_COMMAND pa::CPAMotion::RND_MMI( BOOL blocking, double position[] )
{
	char param[128];

	sprintf_s( param, 128, "%.3f,%.3f,%.3f,%.3f,%.3f", position[0], position[1], position[2], position[3], position[4] );
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_MMI, param );
	if( blocking )
	{
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_MMI );
	}

	return CPAAsyncComm::CMD_RND_MMI;
}

// 0:DO_MEASURE
pa::CPAAsyncComm::EN_COMMAND pa::CPAMotion::DO_MEASURE( 
	BOOL blocking, pa::EN_AXIS hAxis, 
	double in_pitch, double out_pitch, int speed_for_measure_pos, int measure_count, 
	double f1st_max_distance, double f2st_measure_offset )
{
	char	param[256];
	int		no_axis = (int)hAxis + 1;

	sprintf_s( param, 256, "%d,%.3f,%.3f,%d,%d,%.3f,%.3f", no_axis, in_pitch, out_pitch, speed_for_measure_pos, measure_count, f1st_max_distance, f2st_measure_offset );
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_DO_MEASURE, param );
	if( blocking )
	{
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_DO_MEASURE );
	}

	CString strDbg;
	strDbg.Format( _T("%d SEND : DO_MEASURE\n"), GetTickCount() );
	TRACE( strDbg );

	CString strLog;
	strLog.Format( _T("do_measure : %d,%.3f,%.3f,%d,%d,%.3f,%.3f"), 
		no_axis, in_pitch, out_pitch, speed_for_measure_pos, measure_count, f1st_max_distance, f2st_measure_offset );
	PThread->writeLog_AutoCal( strLog, TRUE );

	return CPAAsyncComm::CMD_RND_DO_MEASURE;
}

pa::CPAAsyncComm::EN_COMMAND pa::CPAMotion::SCAL(
	BOOL blocking, pa::EN_AXIS hAxis,
	int spindle_no, double in_pitch, double out_pitch, int speed_for_measure_pos, int measure_count,
	double f1st_max_distance, double f2st_measure_offset)
{
	char	param[256];
	int		no_axis = (int)hAxis + 1;

	sprintf_s( param, 256, "%d,%d,%.3f,%.3f,%d,%d,%.3f,%.3f", spindle_no, no_axis, in_pitch, out_pitch, speed_for_measure_pos, measure_count, f1st_max_distance, f2st_measure_offset );
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_SCAL, param );
	if( blocking )
	{
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_SCAL );
	}

	CString strDbg;
	strDbg.Format( _T("%d SEND : SCAL\n"), GetTickCount() );
	TRACE( strDbg );

	CString strLog;
	strLog.Format( _T("SCAL : %d,%d,%.3f,%.3f,%d,%d,%.3f,%.3f"), 
		spindle_no, no_axis, in_pitch, out_pitch, speed_for_measure_pos, measure_count, f1st_max_distance, f2st_measure_offset );
	PThread->writeLog_AutoCal( strLog, TRUE );

	return CPAAsyncComm::CMD_RND_SCAL;
}

// 0:GET_MEASURE_RESULT
//	> ��� �����ʹ� Receive �Լ����� �����Ѵ� 
//	> SThreadState::fTempMeasureResult  
void pa::CPAMotion::GET_MEASURE_RESULT()
{
	CPAAsyncComm::F_TEMP_MEASURE_RESULT = 0.0;	// �ʱ�ȭ 

	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RND_GET_MEASURE_RESULT );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RND_GET_MEASURE_RESULT );

	CString strLog;
	strLog.Format( _T("measure result : %.5f"), CPAAsyncComm::F_TEMP_MEASURE_RESULT );
	PThread->writeLog_AutoCal( strLog, TRUE );
}

// Get Tool Sensing Margin
void pa::CPAMotion::RTMG()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RTMG );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RTMG );
}

// Set Tool Sensing Margin
void pa::CPAMotion::WTMG( double fval )
{
	char param[64];

	sprintf_s( param, 64, "%.3f", fval );
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_WTMG, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_WTMG );
	//////////////////////////////////////////////////////////////////////////
	// ������ ���� 
	PConfig->pConfig_->fOptionData[OPTION_TOOL_SENSING_MARGIN] = fval;
	//////////////////////////////////////////////////////////////////////////
}

// Get S/W Limit+ 
void pa::CPAMotion::RMAXL()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RMAXL );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RMAXL );
}

// Set S/W Limit+
// void pa::CPAMotion::WMAXL( double fval[] )
// {
// 	int		nNumAxis = PConfig->pConfig_->nNumAxis;
// 	char	param[256];
// 
// 	switch( nNumAxis )
// 	{
// 	default:
// 	case 3:
// 		sprintf_s( param, 256, "%.3f,%.3f,%.3f", fval[0], fval[1], fval[2] );
// 		break;
// 	case 4:
// 		sprintf_s( param, 256, "%.3f,%.3f,%.3f,%.3f", fval[0], fval[1], fval[2], fval[3] );
// 		break;
// 	case 5:
// 		sprintf_s( param, 256, "%.3f,%.3f,%.3f,%.3f,%.3f", fval[0], fval[1], fval[2], fval[3], fval[4] );
// 		break;
// 	}
// 
// 	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_WMAXL, param );
// 	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_WMAXL, 0 );
// 
// 	//////////////////////////////////////////////////////////////////////////
// 	// ������ ���� 
// 	for( int i = 0; i<nNumAxis; i++ ) {
// 		PPAStatus->GetThreadState()->fSoftLimit_[i][0] = fval[i];
// 	}
// 	//////////////////////////////////////////////////////////////////////////
// }

// Set Soft-Limit 
void pa::CPAMotion::WMAXL( int axis, double fmax, double fmin )
{
	char param[256];

	sprintf_s( param, 256, "%d,%.3f,%.3f", axis, fmax, fmin );

	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_WMAXL, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_WMAXL, 10000 ); // 0 );
}

// Get S/W Limit-
void pa::CPAMotion::RMINL()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RMINL );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RMINL );
}

// Set S/W Limit-
// void pa::CPAMotion::WMINL( double fval[] )
// {
// 	int		nNumAxis = PConfig->pConfig_->nNumAxis;
// 	char	param[256];
// 
// 	switch( nNumAxis )
// 	{
// 	default:
// 	case 3:
// 		sprintf_s( param, 256, "%.3f,%.3f,%.3f", fval[0], fval[1], fval[2] );
// 		break;
// 	case 4:
// 		sprintf_s( param, 256, "%.3f,%.3f,%.3f,%.3f", fval[0], fval[1], fval[2], fval[3] );
// 		break;
// 	case 5:
// 		sprintf_s( param, 256, "%.3f,%.3f,%.3f,%.3f,%.3f", fval[0], fval[1], fval[2], fval[3], fval[4] );
// 		break;
// 	}
// 
// 	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_WMINL, param );
// 	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_WMINL, 0 );
// 
// 	//////////////////////////////////////////////////////////////////////////
// 	// ������ ���� 
// 	for( int i = 0; i<nNumAxis; i++ ) {
// 		PPAStatus->GetThreadState()->fSoftLimit_[i][1] = fval[i];
// 	}
// 	//////////////////////////////////////////////////////////////////////////}
// }

void pa::CPAMotion::RENABLE()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RENABLE );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RENABLE, 30000 ); //0 );
}

void pa::CPAMotion::RDISABLE()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RDISABLE );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RDISABLE, 30000 ); //0 );
}

void pa::CPAMotion::S_INIT()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_S_INIT );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_S_INIT );
}

//
void pa::CPAMotion::M140()
{

}

void pa::CPAMotion::M141()
{

}

void pa::CPAMotion::M142()
{

}

void pa::CPAMotion::M143()
{

}

void pa::CPAMotion::M144()
{

}

void pa::CPAMotion::M145()
{

}

void pa::CPAMotion::M146()
{

}

void pa::CPAMotion::M147()
{

}

void pa::CPAMotion::toolReturn_148()
{
	SendMotionCommand( CPAAsyncComm::CMD_RND_M148, FALSE );
}

// Spindle Stop
void pa::CPAMotion::M05()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_M05 );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_M05 );
}

// ������/������ Stop
void pa::CPAMotion::M29()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_M29 );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_M29 );
}

//
void pa::CPAMotion::RND_SUHO()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_SUHO );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_SUHO );
}

//
void pa::CPAMotion::RND_SABHO()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_SABHO );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_SABHO );
}

// 
void pa::CPAMotion::VER()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_VER );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_VER );
}

//
void pa::CPAMotion::RND_STIN( int tool_no, double tool_length, int tool_length_update_flag )
{
	char	param[64];

	sprintf_s( param, 64, "%d,%.5f,%d", tool_no, tool_length, tool_length_update_flag );

	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RND_STIN, param );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RND_STIN );
}

//
void pa::CPAMotion::WDSSZ( double disk_thiness )
{
	char	param[32];

	sprintf_s( param, 32, "%.3f", disk_thiness );

	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_WDSSZ, param );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_WDSSZ );
}

//
void pa::CPAMotion::SORZ( BOOL blocking )
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_SORZ );

	if( blocking )
	{
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_SORZ, 30000 );	// 30�� 
	}
}

//////////////////////////////////////////////////////////////////////////
// ������ �Ϸ�� TRUE
BOOL pa::CPAMotion::MotionDone( CPAAsyncComm::EN_COMMAND hCommand, BOOL isMotorStop )
{
	BOOL bRet = TRUE;

	bRet = PPAAsyncComm[0]->IsComplete(hCommand);		// !B_IS_RUNNING_COMPLETE[hCommand]; SEND : TRUE, RECV : FALSE

	// 2018.03.14 
	// MotionDone Ȯ�ο��� Motor ���� Ȯ�� ����� ���� �Ѵ�. 
	//	- xyzab �� �� autoloader ���� �и� �ؾ� �ϱ� ������, ���� ���� �� ���� 
	//	- ���� �ʿ��ϴٸ�, isMotorStop �÷��׸� ���� �����ؼ� ����ؾ� �Ѵ� 
	/*
	if( isMotorStop == TRUE ) {
		bRet &= IsMotorStop();
	}
	if( isMotorStop == TRUE ) {
		bRet &= IsMotorStopAutoloader();
	}
	*/

	return bRet;
}

// ���� Stop �� ��, TRUE
BOOL pa::CPAMotion::IsMotorStop()
{
	/*
	for( int i = 0; i<pa::AXIS_NUM; i++ ) {
		if( fabs(pa::PPAStatus->GetPAStatus()->fVelocity[i]) > 0.2 ) {	// > 0.05 
			return FALSE;	// ������ FALSE
		}
	}
	if( PAutoLoader->IsUsingAutoLoader() ) {
		if( fabs(pa::PPAStatus->GetPAStatus()->fAutoLoaderVelocity > 0.2 ) ) {
			return FALSE;
		}	
	}
	return TRUE;
	*/

	BOOL bRet = (pa::PPAStatus->GetPAStatus()->nMotorMovingFlag == 0) ? TRUE : FALSE;

	return bRet;
}

BOOL pa::CPAMotion::IsMotorStopAutoloader()
{
	BOOL bRet = (pa::PPAStatus->GetPAStatus()->nMotorMovingFlagAutoloader == 0) ? TRUE : FALSE;

	return bRet;
}

//////////////////////////////////////////////////////////////////////////

// ��� ���� 
// void pa::CPAMotion::EMO( EN_PNC_ERR hErrCode )
// {
// 	if( PPAStatus->GetThreadState()->hRunMode == pa::RUNMODE_RUN ) 
// 	{
// 		int nCurrNCFileIndex = PNCFileMgr->GetCurrentWorkNCFileIndex();
// 		int nTempLineNo = 0;
// 		if( nCurrNCFileIndex != -1 ) {
// 			// ���� ���ι�ȣ ���� 
// 			nTempLineNo = PPAStatus->GetThreadState()->nCurrentNCCodeStepNo;
// //			PPAStatus->SetNCFileMachiningLine( PPAStatus->GetThreadState()->nCurrentNCCodeStepNo, FALSE );			
// //			PPAStatus->SetNCFileState( NCFILE_STATE_ERROR, TRUE );
// 			pa::PThread->SET_ERROR_LINENO( nTempLineNo );
// 		}
// 		//////////////////////////////////////////////////////////////////////////
// 		// �Ʒ� Halt�� ����, ������ ��-ü�������� ��������,
// 		// �Ϲ� ���� �ڵ忡���� ������ �ʴ´� 
// // 		HALT();
// // 		Sleep(10);
// 		STOP();
// 		Sleep(10);
// 		StopStreamMode();
// 	}
// 	HALT();
// 	Sleep(10);
// 	HALT();
// 	Sleep(10);
// 
// 	RDISABLE();	// Servo-Off 
// 
// 	throw CPException( pa::ERR_PNC, hErrCode, _T("") );
// }

void pa::CPAMotion::EMO( EN_PNC_ERR hErrCode )
{
	CString strDbg;
// 	DWORD dwTime = 0; //GetTickCount();

	//////////////////////////////////////////////////////////////////////////
	// RST ������ �������̸� ���� �Ѵ� 
	if( CPAAsyncComm::B_IS_RUNNING_COMPLETE[CPAAsyncComm::CMD_RND_RST] == TRUE ) 
	{
		return ;
	}
	//////////////////////////////////////////////////////////////////////////

	if( PPAStatus->GetThreadState()->hRunMode == pa::RUNMODE_RUN ) 
	{
		int nCurrNCFileIndex = PNCFileMgr->GetCurrentWorkNCFileIndex();
		int nTempLineNo = 0;
		if( nCurrNCFileIndex != -1 ) {
			// ���� ���ι�ȣ ���� 
			nTempLineNo = PPAStatus->GetThreadState()->nCurrentNCCodeStepNo;
			//			PPAStatus->SetNCFileMachiningLine( PPAStatus->GetThreadState()->nCurrentNCCodeStepNo, FALSE );			
			//			PPAStatus->SetNCFileState( NCFILE_STATE_ERROR, TRUE );
			pa::PThread->SET_ERROR_LINENO( nTempLineNo );
		}
		//////////////////////////////////////////////////////////////////////////
		// �Ʒ� Halt�� ����, ������ ��-ü�������� ��������,
		// �Ϲ� ���� �ڵ忡���� ������ �ʴ´� 
		// 		HALT();
		// 		Sleep(10);

		//////////////////////////////////////////////////////////////////////////
		// 2017.08.23 ���ϰ�, Flag�� ����Ѵ� 
		/*
		StopStreamMode();	// ���� �� ��...
		*/
		pa::PThread->bIsEMOError_ = TRUE;
		//////////////////////////////////////////////////////////////////////////

		STOP( 1 );
		Sleep( 50 );

		STOP( 1 );
		Sleep( 50 );
	}
	else
	{
// 		dwTime = GetTickCount();
		STOP();
		Sleep( 50 );
// 		dwTime = GetTickCount() - dwTime;
// 		strDbg.Format( _T("pa::CPAMotion::EMO() STOP: %d\n"), dwTime );
// 		TRACE( strDbg );
		
// 		dwTime = GetTickCount();
		STOP();
		Sleep( 50 );
// 		dwTime = GetTickCount() - dwTime;
// 		strDbg.Format( _T("pa::CPAMotion::EMO() STOP: %d\n"), dwTime );
// 		TRACE( strDbg );
	}

// 	STOP( 1 );
// 	Sleep( 50 );
// 	STOP( 1 );
// 	Sleep( 50 );

	//////////////////////////////////////////////////////////////////////////
	// Servo-Off 
// 	dwTime = GetTickCount();
	RDISABLE();	
// 	dwTime = GetTickCount() - dwTime;
// 	strDbg.Format( _T("pa::CPAMotion::EMO() RDISABLE: %d\n"), dwTime );
// 	TRACE( strDbg );
	//////////////////////////////////////////////////////////////////////////

	throw CPException( pa::ERR_PNC, hErrCode, _T("") );
}

// ����� ���� ���� 
void pa::CPAMotion::ErrorReset()
{
	if (pa::PPAStatus->GetThreadState()->nIsConnectedPAController == 0)
	{
		return;
	}

	CString strLog;

	ASSERT( PPAAsyncComm[0] );
	ASSERT( PPAAsyncComm[1] );

	int nRetryCount = 0;

// 	while( PPAAsyncComm[0]->GetConnectState() == pa::CONNECT_STATUS_NOT )
// 	{
// 		DWORD dwErrNo = PPAAsyncComm[0]->Connect( theApp.szIpAddr, theApp.nPortNo1 );
// 		if( dwErrNo != 0 ) {
// 			if( ++nRetryCount >= 3 )
// 			{
// 				// ���� ����. ���� OFF 
// 				AfxMessageBox( _T("connect fail. power off !!!"), MB_OK|MB_ICONERROR );
// 				return ;
// 			}
// 			else 
// 			{
// 				Sleep( 1000 );
// 				continue;
// 			}
// 		}
// 		else 
// 		{
// 			// ���� ���� 
// 			break;
// 		}
// 	}
// 	nRetryCount = 0;
// 	while( PPAAsyncComm[1]->GetConnectState() == pa::CONNECT_STATUS_NOT )
// 	{
// 		DWORD dwErrNo = PPAAsyncComm[1]->Connect( theApp.szIpAddr, theApp.nPortNo2 );
// 		if( dwErrNo != 0 ) {
// 			if( ++nRetryCount >= 3 )
// 			{
// 				// ���� ����. ���� OFF 
// 				AfxMessageBox( _T("connect fail. power off !!!"), MB_OK|MB_ICONERROR );
// 				return ;
// 			}
// 			else 
// 			{
// 				Sleep( 1000 );
// 				continue;
// 			}
// 		}
// 		else 
// 		{
// 			// ���� ���� 
// 			break;
// 		}
// 	}

// 	CWaitDlg::SHOW_DLG();

	DWORD dwTime = GetTickCount();

	if( PPAAsyncComm[0]->GetConnectState() == pa::CONNECT_STATUS_NOT )
	{
		PPAAsyncComm[0]->Connect( theApp.szIpAddr, theApp.nPortNo1 );
		Sleep( 5000 );
		while( TRUE )
		{
			hcsock::ISocket::EN_CONNECT_STATE conn_status = PPAAsyncComm[0]->GetConnectState();

			//////////////////////////////////////////////////////////////////////////
			// Timeout Checking : 60�� �ȿ� ������� ������, ���� ó�� �Ѵ� 
			if( (GetTickCount() - dwTime) > 30*1000 )
			{
				AfxMessageBox( _T("connect fail(1). power off !!!"), MB_OK|MB_ICONERROR );
				return ;
			}
			//////////////////////////////////////////////////////////////////////////

			// ���� �ɶ����� ���
			if( conn_status == hcsock::ISocket::CONNECTED ) 
			{
				break;
			}
			else if( conn_status == hcsock::ISocket::PENDING_CONNECT ) 
			{
				;	
			}
			else if( conn_status == hcsock::ISocket::NOT_CONNECT ) 
			{
				// �ٽ� ���� �õ� 
				PPAAsyncComm[0]->Connect( theApp.szIpAddr, theApp.nPortNo1 );
				// 5�� ��� 
				Sleep( 5000 );	
			}
		}
	}

	dwTime = GetTickCount();
	if( PPAAsyncComm[1]->GetConnectState() == pa::CONNECT_STATUS_NOT )
	{
		PPAAsyncComm[1]->Connect( theApp.szIpAddr, theApp.nPortNo2 );
		Sleep( 5000 );
		while( TRUE )
		{
			hcsock::ISocket::EN_CONNECT_STATE conn_status = PPAAsyncComm[1]->GetConnectState();

			//////////////////////////////////////////////////////////////////////////
			// Timeout Checking : 60�� �ȿ� ������� ������, ���� ó�� �Ѵ� 
			if( (GetTickCount() - dwTime) > 30*1000 )
			{
				AfxMessageBox( _T("connect fail(2). power off !!!"), MB_OK|MB_ICONERROR );
				return ;
			}
			//////////////////////////////////////////////////////////////////////////

			// ���� �ɶ����� ���
			if( conn_status == hcsock::ISocket::CONNECTED ) 
			{
				break;
			}
			else if( conn_status == hcsock::ISocket::PENDING_CONNECT ) 
			{
				;	
			}
			else if( conn_status == hcsock::ISocket::NOT_CONNECT ) 
			{
				// �ٽ� ���� �õ� 
				PPAAsyncComm[1]->Connect( theApp.szIpAddr, theApp.nPortNo2 );
				// 5�� ��� 
				Sleep( 5000 );	
			}
		}
	}

	if( pa::IS_SUCCESS_FIRST_CONNECT == FALSE )
	{
		//////////////////////////////////////////////////////////////////////////
		// ó�� ������ �ȵǾ����Ƿ�, �ʱ�ȭ�� �Ѵ� 
		pa::IS_SUCCESS_FIRST_CONNECT = TRUE;
		
		PThread->change_external_button_led( pa::RUNMODE_ERROR ); 
	}
	//////////////////////////////////////////////////////////////////////////

	if( PPAStatus->GetPAStatus()->nSpindle_Board_Status != 1 ) {
		S_INIT();
	}

	if( pa::CPAMotion::STREAM_MODE_ERROR == TRUE )
	{
		pa::CPAMotion::STREAM_MODE_ERROR = FALSE;
		RST();
		Sleep(100);
		STOP(1);
	}

	RST();
	Sleep(100);
	STOP();

	//////////////////////////////////////////////////////////////////////////
	// Collet�� ���� �ְ�, COLLET-OPEN LOW LIMIT �� ���
	// Collet�� �ݴ´� 
	// 2018.03.01 ���׷��̵� �۾��� �ʿ� �������� ���� �� 
// 	int curr_main_air2 = PPAStatus->GetPAStatus()->bInput[pa::IN10006_MainAirCheck2];
// 	int curr_collet_state = PPAStatus->GetPAStatus()->bOutput[pa::OUT20040_ToolClamp];
// 	if( curr_main_air2 == 0 && curr_collet_state != 0 )
// 	{
// 		pa::PAMotion->ToolClamp( pa::CPAMotion::CLAMP );
// 	}
	//////////////////////////////////////////////////////////////////////////

	PPAAsyncComm[0]->Reset();
	PPAAsyncComm[1]->Reset();

	PThread->changeRunMode( RUNMODE_STOP, TRUE );
}

// Tool Clamp/Unclamp
void pa::CPAMotion::ToolClamp( BOOL bDirection, EN_STATE hState )
{
	int	nSignal = 0;

	switch( hState )
	{
	case CLAMP:		nSignal = 0; break;
	case UNCLAMP:	nSignal = 1; break;
	default:
		ASSERT( FALSE );
		return ;
	}
	
	if ( bDirection == 0)		// Left Tool
	{
		if (nSignal == 0)
		{
			MDA( TRUE, "M911" );
		}
		else
		{
			MDA( TRUE, "M910");
		}
	}
	else		// Right Tool
	{
		if (nSignal == 0)
		{
			MDA( TRUE, "M921" );
		}
		else
		{
			MDA( TRUE, "M920");
		}
	}
}

// Block Clamp/Unclamp
void pa::CPAMotion::BlockClamp( EN_STATE hState )
{
	// 	int nSignal_On = 0;
	// 	int nSignal_Off = 0;
	// 
	// 	switch( hState )
	// 	{
	// 	case CLAMP:		nSignal_On = pa::OUT117_BLOCK_CLAMP;   nSignal_Off = pa::OUT118_BLOCK_UNCLAMP; break;
	// 	case UNCLAMP:	nSignal_On = pa::OUT118_BLOCK_UNCLAMP; nSignal_Off = pa::OUT117_BLOCK_CLAMP;   break;
	// 	default: 
	// 		ASSERT( FALSE );
	// 		return ;
	// 	}
	// 
	// 	IOT( nSignal_Off, 0 );
	// 	IOT( nSignal_On, 1 );

	// 2017.06.21 
	// bychul2 
// 	int signal = 0;
// 
// 	switch( hState )
// 	{
// 	case CLAMP:
// 	default:		signal = 0; break;
// 	case UNCLAMP:	signal = 1; break;
// 	}
// 
// 	IOT( pa::OUT20053_AB_Gripper_Ungrip, signal );

	switch( hState )
	{
	case CLAMP: default:
	//	MDA( TRUE, "M912" );
		PPAAsyncComm[0]->SendCommand( (CPAAsyncComm::EN_COMMAND)CPAAsyncComm::CMD_M912 );
		PPAAsyncComm[0]->Wait((CPAAsyncComm::EN_COMMAND)CPAAsyncComm::CMD_M912);
		break;
	case UNCLAMP:
	//	MDA( TRUE, "M913" );
		PPAAsyncComm[0]->SendCommand( (CPAAsyncComm::EN_COMMAND)CPAAsyncComm::CMD_M913 );
		PPAAsyncComm[0]->Wait((CPAAsyncComm::EN_COMMAND)CPAAsyncComm::CMD_M913);
		break;
	}
}

// Door Open/Close
void pa::CPAMotion::ATCDoor( EN_STATE hState )
{
	int nSignal = 0;

	switch( hState )
	{
	case OPEN:	nSignal = 1; break;
	case CLOSE:	nSignal = 0; break;
	default: 
		ASSERT( FALSE );
		return ;
	}

#ifdef _PA_G2400_
	IOT( pa::OUT120_ATC_DOOR_OPEN, nSignal );
#endif 
#ifdef _PA_G1600_
	if( pa::MODEL_INFO.IsUsingATCDoor() )
	{
		if( nSignal == 0 ) {
			MDA( TRUE, "M702" );	// Close
		} else {
			MDA( TRUE, "M701" );	// Open
		}
	}
#endif 
}

// 2016.12.19
//	5Z, 4W(A/S)������ ������ �� �ֵ��� 
//	M28/M29 ��ũ�� ������� ���� �Ѵ� 
void pa::CPAMotion::ClearRoom( BOOL bOn )
{
// #ifdef _PA_G2400_
// 	;
// #endif
// #ifdef _PA_G1600_
// 	if( bOn ) {
// 		IOT( pa::OUT20041_RoomCleaning, 1 );
// 		Sleep(500);
// 		IOT( pa::OUT20047_VacuumPumpOnSignal, 1 );
// 	}
// 	else {
// 		IOT( pa::OUT20047_VacuumPumpOnSignal, 0 );
// 		Sleep(500);
// 		IOT( pa::OUT20041_RoomCleaning, 0 );
// 	}
// #endif 
#ifdef _PA_G2400_
	;
#endif 
#ifdef _PA_G1600_
	if( bOn )
	{
		if( pa::MODEL_INFO.IsUsingCleanRoomSol() ) {
			// DS200-5Z�� ���,
//			IOT( pa::OUT20041_RoomCleaning, 1 );
		}
		Sleep( 500 );
		// M28
		MDA( TRUE, "MM28"); //	"M28" ); => 2018.07.06. �Ŵ���� M28������ �������� MM28�� ����Ѵ� 
	}
	else 
	{
		// M29 
		MDA( TRUE, "M29" );
		Sleep( 500 );
		if( pa::MODEL_INFO.IsUsingCleanRoomSol() ) {
			// DS200-5Z�� ���,
//			IOT( pa::OUT20041_RoomCleaning, 0 );
		}
	}
#endif 
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

void pa::CPAMotion::SendCommand( char* command, char* response, int len, DWORD dwTimeout  )
{
	char*	pcmd = NULL;
	char*	pdata= NULL;
	int		command_index = 0;

	for( int i = 0; i<CPAAsyncComm::CMD_NUM; i++ )
	{
		pcmd = strstr( command, CPAAsyncComm::STR_COMMAND[i] );
		if( pcmd ) {
			command_index = i;
			break;
		}
	}
 	if( pcmd == NULL ) {
		sprintf_s( response, len, "command is not exist !" );
		return ;
	}
	else
	{
		pdata = strstr( command, " " );
		if( pdata ) {
			pdata += 1;	// skip white space 
		}
	}

	if( pdata ) {
		PPAAsyncComm[0]->SendCommand( (CPAAsyncComm::EN_COMMAND)command_index, pdata );
	} else {
		PPAAsyncComm[0]->SendCommand( (CPAAsyncComm::EN_COMMAND)command_index );
	}
	PPAAsyncComm[0]->Wait( (CPAAsyncComm::EN_COMMAND)command_index, dwTimeout );
	
	// ���� ������ ���� 
	if( response )
	{
		sprintf_s( response, len, "%s", PPAAsyncComm[0]->GetResponse() );
	}
}

void pa::CPAMotion::SendMDACommand( char* mda_command )
{
	MDA( FALSE, mda_command );
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

void pa::CPAMotion::UploadSoftLimit()
{
	RMAXL();
	RMINL();
}

void pa::CPAMotion::DownloadSoftLimit()
{
// 	double ftemp[20];
// 
// 	NOT_CHECK_STATUS = TRUE;
// 
// 	Sleep( 3000 );
// 
// 	try 
// 	{
// 		RDISABLE();
// 	}
// 	catch( CPException& e )
// 	{
// 	}
// 
// 	for( int i = 0; i<PConfig->pConfig_->nNumAxis; i++ ) {
// 		ftemp[i] = PPAStatus->GetThreadState()->fSoftLimit_[i][0];
// 	}
// 	WMAXL( ftemp );
// 
// 	for( int i = 0; i<PConfig->pConfig_->nNumAxis; i++ ) {
// 		ftemp[i] = PPAStatus->GetThreadState()->fSoftLimit_[i][1];
// 	}
// 	WMINL( ftemp );
// 
// 	RENABLE();
// 
// 	Sleep( 5000 );
// 
// 	NOT_CHECK_STATUS = FALSE;

	double	ftemp[20][2];
	int		nNumAxis = pa::MODEL_INFO.GetNumAxis();

	NOT_CHECK_STATUS = TRUE;

	Sleep( 3000 );

	try {
		RDISABLE();
	}
	catch( CPException& e ) {

	}

	for( int i = 0; i<nNumAxis; i++ ) 
	{
		int		axis = i+1;
		double	fTempMax = PPAStatus->GetThreadState()->fSoftLimit_[i][0];
		double	fTempMin = PPAStatus->GetThreadState()->fSoftLimit_[i][1];
		WMAXL( axis, fTempMax, fTempMin );
		Sleep( 100 );
	}

	Sleep( 1000 );

	RENABLE();

	Sleep( 3000 );

	NOT_CHECK_STATUS = FALSE;
}

//////////////////////////////////////////////////////////////////////////
// Z up
// AB ���� 
// XY �̵� 
// AB �̵� 
void pa::CPAMotion::MoveReadyPos()
{
	char szCommand[256];
	double fAPos;
	double fBPos;
	BOOL bMoveAB  = pa::MODEL_INFO.IsUsingABMoveWhenReadyPosMove() == 0 ? FALSE : TRUE;	// 4WAS�� FALSE

	//////////////////////////////////////////////////////////////////////////
	// ZUp 
	sprintf_s( szCommand, 256, "G00 G90 G53 X%.3f Y%.3f Z%.3f A%.3f B%.3f",
		PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X],
		PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y],
		0.0,
		PPAStatus->GetPAStatus()->fPosition[pa::AXIS_A],
		0.0 );

	MDA( FALSE, szCommand );
	PPAAsyncComm[0]->Wait( pa::CPAAsyncComm::CMD_RND_MDA, 10000 ); //0 );
	Sleep( 100 );

	//////////////////////////////////////////////////////////////////////////
	// XY �̵� 
	sprintf_s( szCommand, 256, "G00 G90 G53 X%.3f Y%.3f Z%.3f A%.3f B%.3f",
		PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_READYPOS][pa::AXIS_X],
		PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_READYPOS][pa::AXIS_Y],
		0.0,
		PConfig->pConfig_->fTeachingPoint[pa::TEACHING_POINT_READYPOS][pa::AXIS_A],
		0.0);

	MDA( FALSE, szCommand );
	PPAAsyncComm[0]->Wait( pa::CPAAsyncComm::CMD_RND_MDA, 10000 ); //0 );
	Sleep( 100 );
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

// stream ��带 �����ϰ�, stream�� scoket �� �����Ѵ�.  
void pa::CPAMotion::StartStreamMode()
{
	int errcode = 0;

	TRACE( _T("pa::CPAMotion::StartStreamMode()\n") );

	STOP();
	Sleep( 100 );
	MODE( CPAAsyncComm::PA_RUNMODE_AUTO );
	Sleep( 100 );
	STREAM();

#ifdef _USE_PA_
 
 	try {
 		// 1. socket ���� 
 		hSockStream_ = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );
 
 		if( hSockStream_ == INVALID_SOCKET ) {
 			errcode = GetLastError();
 			throw errcode;
 		}
 
 		// 2. ���� 
 		SOCKADDR_IN server_addr;
 		server_addr.sin_family		= AF_INET;
 //		server_addr.sin_port		= htons(20000);
		server_addr.sin_port		= htons( theApp.nPortNoForStream );
		server_addr.sin_addr.s_addr = inet_addr( theApp.szIpAddr );
 
 		int conn = connect( hSockStream_, (SOCKADDR*)&server_addr, sizeof(server_addr) );
 		if( conn != 0 ) {
 			errcode = GetLastError();
 			throw errcode;
 		}
 
 		// 3. ������ �񵿱� �������� ����� 
 		unsigned long ul = 1;
 		if( ioctlsocket( hSockStream_, FIONBIO, (unsigned long *)&ul ) == SOCKET_ERROR ) {
 			errcode = GetLastError();
 			throw errcode;
 		}
 	}
 	catch( int& )
 	{
 		if( hSockStream_ != INVALID_SOCKET ) 
 		{
 			closesocket( hSockStream_ );
 			hSockStream_ = INVALID_SOCKET;
 		}

		throw CPException( pa::ERR_PNC, pa::PNC_ERR_STREAM_SOCKET_CONNECT_FAIL, _T("") );
 	}
 
#endif
 
 	PPAStatus->GetPAStatus()->nStreamStatusCode = 0;
 	PPAStatus->GetPAStatus()->nStreamLineNumber = 0;
 	PPAStatus->GetPAStatus()->nStreamBufferCount= 0;
}

// stream ��带 ���� �Ѵ� 
void pa::CPAMotion::StopStreamMode()
{
	if( hSockStream_ != INVALID_SOCKET ) {
		closesocket( hSockStream_ );
		hSockStream_ = INVALID_SOCKET;
	}

	PPAStatus->GetThreadState()->nStartingNCCodeStepNo = 0;
	PPAStatus->GetThreadState()->nNumberOfPreparingStep= 0;

	TRACE( _T("pa::CPAMotion::StopStreamMode()\n") );
}

BOOL pa::CPAMotion::IsStopStreamMode()
{
	BOOL bRet = ( hSockStream_ == INVALID_SOCKET ) ? TRUE : FALSE;

	return bRet;
}

// stream ���� gcode�� ���� �Ѵ�. b�� false�� ���, ?�� �����Ѵ�		
int  pa::CPAMotion::SendStreamCommand( char* pCommand, BOOL bPrepareCmd )
{
 	int status_code = 0;
 	int line_number = 0;
	int buffer_count = 0;
 
	status_code = 0;
	line_number = 0;
	buffer_count = 0;

	// 2017.08.14. ������ EMO �ɷ��� ��, ���ߴ� �������� ���� �� ��
	try {
// 		EnterCriticalSection( &hCS_ );
		// command ���� 
		stream_send_and_receive( pCommand, &status_code, &line_number, &buffer_count );
// 		LeaveCriticalSection( &hCS_ );
	}
	catch( CPException& e ) {
// 		LeaveCriticalSection( &hCS_ );
		throw e;
	}

	// ���� ���� 
	PPAStatus->GetPAStatus()->nStreamStatusCode = status_code;
	PPAStatus->GetPAStatus()->nStreamLineNumber = line_number;
	PPAStatus->GetPAStatus()->nStreamBufferCount= buffer_count;
		 
	if( bPrepareCmd ) {
		PPAStatus->GetThreadState()->nNumberOfPreparingStep += 1;
	}
		 
	// ���� ó�� 
	if( status_code != 0 ) {
		// status 
		throw CPException( ERR_PA_STREAM, status_code, _T("") );
	} 

	return buffer_count;
}

// void pa::CPAMotion::stream_send_and_receive( char* pCommand, int* state_code, int* line_no, int* buffer_count )
// {
//  	static char szReveive[128];
//  	static int  receive_index;
//  	DWORD	dwTime;
//  	int ret = 0;
// 
// 	if( hSockStream_ == INVALID_SOCKET ) {
// 		for( int i = 0; i<20; i++ ) {
// 			PThread->checkState();
// 			PThread->checkLimitSensor();
// 			Sleep(10);
// 		}
//  		throw CPException( ERR_PNC, PNC_ERR_STREAM_SOCKET_DISCONNECT, _T("") );
//  	}
//  
//  	memset( (void*)szReveive, 0, sizeof(char)*128 );
//  	receive_index = 0;
//  
//  	ret = send( hSockStream_, pCommand, strlen(pCommand), 0 );
//  
//  	dwTime = GetTickCount();
//  
//  	// \r\n ���� �д°�, ����� �Ľ��ؼ� ���� �Ѵ� 
//  	while( TRUE )
//  	{
// 		if( PPAStatus->GetPAStatus()->nRunStatus == 0 ) { *state_code=0; *line_no=0; *buffer_count=0; return; }
// 
//  		ret = recv( hSockStream_, (char*)(szReveive + receive_index), 128, 0 );
//  
//  		if( ret <= 0 ) 
//  		{	
//  			DWORD dwErrCode = WSAGetLastError();
//  			if( dwErrCode == 0 || dwErrCode == WSAEWOULDBLOCK )
//  			{
//  				if( GetTickCount() - dwTime > dwStreamTimeout_ ) 
//  				{
// 					TRACE( _T("*****") );
// 
// 					//////////////////////////////////////////////////////////////////////////
// 					// 2016.05.31 
// 					//	- stream timeout�� ���, ����� ���¸� �о� ���� 
// 					try 
// 					{
// 					//	for( int i = 0; i<20; i++ ) {
// 						for( int i = 0; i<3; i++ ) 
// 						{
// 							// ���� �� check state
// 							PThread->checkState();
// 							// ���� ���� check 
// 							PThread->checkLimitSensor();
// 							//
// 							Sleep(10);
// 							//
// 							CString strTemp;
// 							strTemp.Format( _T("*** %d\n"), i );
// 							TRACE( strTemp );
// 						}
// 					}
// 					catch( CPException& e ) 
// 					{
// 						throw e;
// 					}
// 					//////////////////////////////////////////////////////////////////////////
// 
// 					CString strCmd;
// 					strCmd = hcutil::ASCII_TO_CSTRING( pCommand );
//  					// receive timeout error 
//  					throw CPException( ERR_PNC, PNC_ERR_STREAM_SOCKET_TIMEOUT, _T("") ); //(LPCTSTR)strCmd );
//  				}
//  				else 
//  				{
// 					TRACE( _T("retry !!!\n") );
//  					// �ٽ� �д´� 
//  					Sleep( 1 );
//  					continue;
//  				}
//  			}
//  			else 
//  			{
// 				for( int i = 0; i<20; i++ ) 
// 				{
// 					PThread->checkState();
// 					PThread->checkLimitSensor();
// 					Sleep(10);
// 				}
//  				// ��� ���� 
//  				// socket �ݰ�, exception 
//  				closesocket( hSockStream_ );
// 				hSockStream_ = INVALID_SOCKET;
// 
//  				throw CPException( ERR_PNC, PNC_ERR_STREAM_SOCKET_DISCONNECT, _T("") );
//  			}
//  		}
//  
//  		receive_index += ret;
//  
//  		// ���� �Ϸ� Ȯ�� 
//  		if( szReveive[receive_index-2] == '\r' && szReveive[receive_index-1] == '\n' ) 
//  		{
//  			break;
//  		}
// 	}
// 
// 	CString strDbg;
// 	if( pCommand[0]=='?' )
// 	{
// 		strDbg.Format( _T("? send-receive time %d\n"), GetTickCount() - dwTime );
// 	}
// 	else 
// 	{
// 		strDbg.Format( _T("C send-receive time %d\n"), GetTickCount() - dwTime );
// 	}
// 	TRACE( strDbg );
// 
//  
//  	// ���� �ڵ忡�� "\n\r"  ���� �ϰ�, �������� ' '�� �߰� �Ѵ�  
//  	szReveive[receive_index-2] = ' ';
//  	szReveive[receive_index-1] = 0;
//  	receive_index -= 1;
//  
//  	// ���� �ڵ� �м� : "status_code line_number buffer_count"
//  	int  ret_value[3] = { 0, 0, 0};
//  	int  ret_index = 0;
//  	char sztemp[62]; 
//  	int  temp_index = 0;
//  	for( int i = 0; i<receive_index; i++ )
//  	{
//  		if( szReveive[i] != ' ' ) 
//  		{
//  			sztemp[temp_index++] = szReveive[i];
//  		}
//  		else 
//  		{
//  			sztemp[temp_index++] = 0;
//  			ret_value[ret_index] = atoi( sztemp );
//  			temp_index = 0;
//  			ret_index += 1;
//  		}
//  	}
//  
//  	*state_code		= ret_value[0];
//  	*line_no		= ret_value[1];
//  	*buffer_count	= ret_value[2];
// }

void pa::CPAMotion::stream_send_and_receive( char* pCommand, int* state_code, int* line_no, int* buffer_count )
{
	static char szReveive[128];
	static int  receive_index;
	DWORD	dwTime;
	int ret = 0;
	int retry_count = 0;

	CString strTrace;
	strTrace.Format(_T("stream_send_and_receive : %s\n"), pCommand);
	TRACE(strTrace);

HC_RETRY:

	if( hSockStream_ == INVALID_SOCKET ) {
		for( int i = 0; i<20; i++ ) {
			PThread->checkState();
			PThread->checkLimitSensor();
			Sleep(10);
		}
		throw CPException( ERR_PNC, PNC_ERR_STREAM_SOCKET_DISCONNECT, _T("1. [Invalid-socket]") );
	}

	memset( (void*)szReveive, 0, sizeof(char)*128 );
	receive_index = 0;

	ret = send( hSockStream_, pCommand, strlen(pCommand), 0 );

	dwTime = GetTickCount();

	// \r\n ���� �д°�, ����� �Ľ��ؼ� ���� �Ѵ� 
	while( TRUE )
	{
		if( PPAStatus->GetPAStatus()->nRunStatus == 0 ) { *state_code=0; *line_no=0; *buffer_count=0; return; }

		ret = recv( hSockStream_, (char*)(szReveive + receive_index), 128, 0 );

		if( ret <= 0 ) 
		{	
			DWORD dwErrCode = WSAGetLastError();
			if( dwErrCode == 0 || dwErrCode == WSAEWOULDBLOCK )
			{
				if( GetTickCount() - dwTime > dwStreamTimeout_ ) 
				{
					TRACE( _T("*****") );

					//////////////////////////////////////////////////////////////////////////
					// 2016.05.31 
					//	- stream timeout�� ���, ����� ���¸� �о� ���� 
					try 
					{
						//	for( int i = 0; i<20; i++ ) {
						for( int i = 0; i<10; i++ ) 
						{
							// ���� �� check state
							PThread->checkState();
							// ���� ���� check 
							PThread->checkLimitSensor();
							//
							Sleep(10);
							//
							CString strTemp;
							strTemp.Format( _T("*** %d\n"), i );
							TRACE( strTemp );
						}
					}
					catch( CPException& e ) 
					{
						throw e;
					}
					//////////////////////////////////////////////////////////////////////////

					CString strCmd;
					strCmd = hcutil::ASCII_TO_CSTRING( pCommand );
					// receive timeout error 
					//  				throw CPException( ERR_PNC, PNC_ERR_STREAM_SOCKET_TIMEOUT, _T("") ); //(LPCTSTR)strCmd );

					//////////////////////////////////////////////////////////////////////////
					// 2016.10.12. StreamSocketTimeout ����� �׽�Ʈ �ڵ� 
					if( pCommand[0] == '?' ) 
					{
						retry_count += 1;

						if( retry_count >= 10 )
						{
							CString strErrCode;
							strErrCode.Format( _T("2: SEC[%d]"), dwErrCode );
							throw CPException( ERR_PNC, PNC_ERR_STREAM_SOCKET_TIMEOUT, strErrCode ); //(LPCTSTR)strCmd );
						}

						CString logMsg;
						logMsg.Format( _T(">>>>> STREAM_SOCKET_TIMEOUT and RETRY") );
						P_LOG->WriteLog_EXT( _T(">>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<") );		
						P_LOG->WriteLog_EXT( logMsg );
						goto HC_RETRY;
					}
					else 
					{
						try {
							for (int i = 0; i<10; i++) {
								PThread->checkState();
								PThread->checkLimitSensor();
							}
						}
						catch (CPException& e) {
							throw e;
						}
						
						CString strErrCode;
						strErrCode.Format( _T("3: SEC[%d]"), dwErrCode );
						throw CPException( ERR_PNC, PNC_ERR_STREAM_SOCKET_TIMEOUT, strErrCode ); //(LPCTSTR)strCmd );
					}
					//////////////////////////////////////////////////////////////////////////

				}
				else 
				{
// 					TRACE( _T("retry !!!\n") );
					// �ٽ� �д´� 
					Sleep( 0 );	// 2017.03.14	// 2017.03.15	// �̰� ������ ȭ�� �������� ������ 
					continue;
				}
			}
			else 
			{
				try {
					for( int i = 0; i<10; i++ ) {
						PThread->checkState();
						PThread->checkLimitSensor();
						Sleep(10);
					}
				}
				catch (CPException& e) {
					throw e;
				}

				// ��� ���� 
				// socket �ݰ�, exception 
				closesocket( hSockStream_ );
				hSockStream_ = INVALID_SOCKET;

				CString strErrCode;
				strErrCode.Format( _T("4: SEC[%d]"), dwErrCode );
				throw CPException( ERR_PNC, PNC_ERR_STREAM_SOCKET_DISCONNECT, strErrCode );
			}
		}

		receive_index += ret;

		// ���� �Ϸ� Ȯ�� 
		if( szReveive[receive_index-2] == '\r' && szReveive[receive_index-1] == '\n' ) 
		{
			break;
		}
	}

// 	CString strDbg;
// 	if( pCommand[0]=='?' )
// 	{
// 		strDbg.Format( _T("? send-receive time %d\n"), GetTickCount() - dwTime );
// 	}
// 	else 
// 	{
// 		strDbg.Format( _T("C send-receive time %d\n"), GetTickCount() - dwTime );
// 	}
// 	TRACE( strDbg );


	// ���� �ڵ忡�� "\n\r"  ���� �ϰ�, �������� ' '�� �߰� �Ѵ�  
	szReveive[receive_index-2] = ' ';
	szReveive[receive_index-1] = 0;
	receive_index -= 1;

	// ���� �ڵ� �м� : "status_code line_number buffer_count"
	int  ret_value[3] = { 0, 0, 0};
// 	int  ret_index = 0;
// 	char sztemp[62]; 
// 	int  temp_index = 0;
// 	for( int i = 0; i<receive_index; i++ )
// 	{
// 		if( szReveive[i] != ' ' ) 
// 		{
// 			sztemp[temp_index++] = szReveive[i];
// 		}
// 		else 
// 		{
// 			sztemp[temp_index++] = 0;
// 			if( ret_index == 2 ) {	// 2017.03.14
// 				ret_value[ret_index] = atoi( sztemp );
// 			}						// 2017.03.14
// 			temp_index = 0;
// 			ret_index += 1;
// 		}
// 	}

	// 2017.03.15
	char* p = strchr( szReveive, ' ' );	// start line_number 
	if( p ) {
		p = strchr( p+1, ' ' );				// start buffer_count 
		if( p ) {
			ret_value[2] = atoi( p+1 );
		}
	} 
	
	*state_code		= 0;	// ret_value[0];	// 2017.03.14
	*line_no		= 0;	// ret_value[1];	// 2017.03.14
	*buffer_count	= ret_value[2];
}

//////////////////////////////////////////////////////////////////////////
// 2017.01.11 �߰� 
void pa::CPAMotion::RTPPO()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RTPPO );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RTPPO );
}

void pa::CPAMotion::WTPPO( double offset )
{
	char param[64];

	sprintf_s( param, 64, "%.3f", offset );
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_WTPPO, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_WTPPO );
	//////////////////////////////////////////////////////////////////////////
	// ������ ���� 
	PConfig->pConfig_->fOptionData[OPTION_TOOL_POCKET_PUT_OFFSET] = offset;
	//////////////////////////////////////////////////////////////////////////
}

//////////////////////////////////////////////////////////////////////////
// 2017.01.12 �߰� 
void pa::CPAMotion::RADR()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RADR );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RADR );
}

void pa::CPAMotion::WADR( char* pNewAddress )
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_WADR, pNewAddress );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_WADR, 10*1000 );
}

void pa::CPAMotion::RRIOADR()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RRIOADR );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RRIOADR );
}

void pa::CPAMotion::WRIOADR( char* pNewAddress )
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_WRIOADR, pNewAddress );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_WRIOADR, 10*1000 );
}

void pa::CPAMotion::ChangeIPAddress( char cBoard )
{
	try 
	{
		PPAStatus->GetThreadState()->bCheckStatus = FALSE;

		CString strLog;
		strLog.Format( _T("start change ip address - %s"), cBoard==0 ? _T("PA") : _T("IO") );
		PThread->writeLog_AutoCal( strLog, FALSE );

		if( cBoard == 0 ) 
		{
			// PA ����� 
			CString strPAAddr = hcutil::ASCII_TO_CSTRING( pa::PPAStatus->GetThreadState()->szNEW_PA_IP_ADDR );
			strLog.Format( _T("pa controller %s -> %s"),
				pa::PPAStatus->GetThreadState()->szPA_IP_ARRD,
				strPAAddr );
			PThread->writeLog_AutoCal( strLog, TRUE );
			WADR( pa::PPAStatus->GetThreadState()->szNEW_PA_IP_ADDR );
			Sleep(100);

			// PAConfig.ini ���� ���� 
			//	KeyName = PA
			//	ValueName = IpAddr 
			CString strConfigFilePath;
			strConfigFilePath.Format( INI_PA_CONFIG_PATH ); //_T("\\SD Card\\EPnc\\Config\\PAConfig.ini") );

			CCEIniFile hIniFile;
			hIniFile.Open( strConfigFilePath );
			hIniFile.SetValue( _T("PA"), _T("IpAddr"), strPAAddr );
			hIniFile.Close();
		}
		else if( cBoard == 1 )
		{
			// Cantops I/O ���� 
			CString strIOAddr = hcutil::ASCII_TO_CSTRING( pa::PPAStatus->GetThreadState()->szNEW_CANTOPS_IP_ADDR );
			strLog.Format( _T("io controller %s -> %s"),
				pa::PPAStatus->GetThreadState()->szCANTOPS_IP_ADDR, 
				strIOAddr );
			PThread->writeLog_AutoCal( strLog, TRUE );
			WRIOADR( pa::PPAStatus->GetThreadState()->szNEW_CANTOPS_IP_ADDR );
			Sleep(100);
		}

		strLog.Format( _T("end change ip address") );
		PThread->writeLog_AutoCal( strLog, FALSE );

		PPAStatus->GetThreadState()->bCheckStatus = TRUE;
	}
	catch (CPException& e)
	{
		PPAStatus->GetThreadState()->bCheckStatus = TRUE;
		throw e;
	}
}

void pa::CPAMotion::UploadIPAddress()
{
	CString strTemp[2];
	//int count = hcsock::GET_IP_ADDRESS( strTemp, 2 );
	memset((void*)(pa::PPAStatus->GetThreadState()->szIpAddress), 0, sizeof(TCHAR)*64);
	_stprintf_s( pa::PPAStatus->GetThreadState()->szIpAddress, 63, _T("%s / %s\n\n"), strTemp[0], strTemp[1] );
	TRACE( pa::PPAStatus->GetThreadState()->szIpAddress );
}

//////////////////////////////////////////////////////////////////////////
// 2017.06.13. Autoloader 

// Index ��° ������ ���� ��ġ�� �̵�
void pa::CPAMotion::AL_MoveBlockSensingPosition_M753( BOOL blocking, int nIndex )
{
	SendMotionCommand( CPAAsyncComm::CMD_M753, blocking, nIndex + 1 );
}

void pa::CPAMotion::AL_MoveDiskBarcodeReadingPosition_M754( BOOL blocking, int nIndex )
{
	SendMotionCommand( CPAAsyncComm::CMD_M754, blocking, nIndex + 1 );
}

BOOL pa::CPAMotion::AL_IsBlockSensing()
{
	//BOOL bRet = PPAStatus->GetPAStatus()->bInput[IN20031_AutoLoader_Sensing_Block2];
	//return bRet;
	return FALSE;
}

BOOL pa::CPAMotion::IsItemInWorkSpace()
{
	//BOOL bRet = PPAStatus->GetPAStatus()->bInput[IN20017_DetectedBlock];
	//return bRet;
	return FALSE;
}

BOOL pa::CPAMotion::IsItemInItemPasser()
{
	//BOOL bRet = PPAStatus->GetPAStatus()->bInput[IN20016_AutoLoader_PNC_Sensing_Item];
	//return bRet;
	return FALSE;
}

BOOL pa::CPAMotion::IsItemInAutoLoaderHand()
{
// 	BOOL bRet = PPAStatus->GetPAStatus()->bInput[IN20028_AutoLoader_Sensing_Block];
// 	return bRet;
	return FALSE;
}

void pa::CPAMotion::AL_MoveBlockFromCassetteToPNC_M757( BOOL blocking, int nIndex )
{
	SendMotionCommand( CPAAsyncComm::CMD_M757, blocking, nIndex + 1 );
}

void pa::CPAMotion::AL_MoveBlockFromPNCToCassette_M758( BOOL blocking, int nIndex )
{
	SendMotionCommand( CPAAsyncComm::CMD_M758, blocking, nIndex + 1 );

}

BOOL pa::CPAMotion::AL_Init_Loader_ARM( BOOL bResetStep )
{
	static DWORD	dwTIME;
	static int		step;

	step = ( bResetStep == TRUE ) ? 1 : step;

	switch( step )
	{
	case 0: break;
	case 1:
		//	MDA( FALSE, "M773" );
		PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_M773 );		
		Sleep( 500 );
		step = 10;
		break;
	case 10:
		//	if( MotionDone( pa::CPAAsyncComm::CMD_RND_MDA, TRUE ) == TRUE ) {
		//		step = 20;
		//	}
		if( PPAAsyncComm[0]->IsComplete( CPAAsyncComm::CMD_M773 ) ) {
			step = 20;
		}
		break;
		// AutoLoader ���� ī��Ʈ ��������..
	case 20:
		//	MDA( FALSE, "M775" );
		PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_M775 );
		Sleep( 500 );
		step = 30;
		break;
	case 30:
		//	if( MotionDone( pa::CPAAsyncComm::CMD_RND_MDA, TRUE ) == TRUE ) {
		if( PPAAsyncComm[0]->IsComplete( CPAAsyncComm::CMD_M775 ) ) {
			step = 40;
		}
		break;
	case 40:
		step = 0;
		break;
	}

	return (BOOL)( step == 0 );
}

BOOL pa::CPAMotion::AL_Init_PNC_ARM( BOOL bResetStep )
{
	static DWORD	dwTIME;
	static int		step;

	step = ( bResetStep == TRUE ) ? 1 : step;

	switch( step )
	{
	case 0: break;
	case 1:
		//	MDA( FALSE, "M779" );
		PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_M779 );
		Sleep( 500 );
		step = 10;
		break;
	case 10:
		//	if( MotionDone( pa::CPAAsyncComm::CMD_RND_MDA, TRUE ) == TRUE ) {
		if( PPAAsyncComm[0]->IsComplete( CPAAsyncComm::CMD_M779 ) ) {
			step = 0;
		}
		break;
	}

	return (BOOL)( step == 0 );
}

void pa::CPAMotion::AL_GripperGrip_M777( BOOL blocking )
{
	SendMotionCommand( CPAAsyncComm::CMD_M777, blocking );
}

void pa::CPAMotion::AL_GripperUngrip_M778( BOOL blocking )
{
	SendMotionCommand( CPAAsyncComm::CMD_M778, blocking );
}

// AutoLoader TeachingPoint �����͸� �д´� 
void pa::CPAMotion::RALP()
{
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_RALP );
	PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_RALP );
}

// AutoLoader TeachingPoint �����͸� ����Ѵ� 
void pa::CPAMotion::WALP()
{
	char param[256];

	sprintf_s( param, 256, "%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f",
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[0],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[1],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[2],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[3],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[4],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[5],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[6],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[7],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[8],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[9],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[10],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[11],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[12],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[13],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[14],
		PAutoLoader->GetAutoLoaderConfig()->fTeachingPoint_[15]);

	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_WALP, param );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_WALP );
}

//////////////////////////////////////////////////////////////////////////

void pa::CPAMotion::getItemFromCassette_751( BOOL blocking, int slotIndex )
{
	SendMotionCommand( CPAAsyncComm::CMD_M751, blocking, slotIndex + 1 );
}

void pa::CPAMotion::AL_M761( BOOL blocking, int param )
{
	SendMotionCommand( CPAAsyncComm::CMD_M761, blocking, param );
}

void pa::CPAMotion::AL_M762( BOOL blocking, int param )
{
	SendMotionCommand( CPAAsyncComm::CMD_M762, blocking, param );
}

void pa::CPAMotion::putItemToCassette_752( int slotIndex )
{
	SendMotionCommand( CPAAsyncComm::CMD_M752, FALSE, slotIndex + 1 );
}

void pa::CPAMotion::moveItemPasserToExchangePosition_783( int isUnload )
{
	SendMotionCommand( CPAAsyncComm::CMD_M783, FALSE, isUnload );
}

void pa::CPAMotion::autoLoaderHandGrip_777( )
{
	SendMotionCommand( CPAAsyncComm::CMD_M777, FALSE );
}

void pa::CPAMotion::autoLoaderHandUngrip_778( )
{
	SendMotionCommand( CPAAsyncComm::CMD_M778, FALSE );
}

void pa::CPAMotion::itemPasserUp_779( )
{
	SendMotionCommand( CPAAsyncComm::CMD_M779, FALSE );
}

void pa::CPAMotion::itemPasserDown_780( )
{
	SendMotionCommand( CPAAsyncComm::CMD_M780, FALSE );
}

void pa::CPAMotion::itemPasserGrip_781( )
{
	SendMotionCommand( CPAAsyncComm::CMD_M781, FALSE );
}

void pa::CPAMotion::itemPasserUngrip_782( )
{
	SendMotionCommand( CPAAsyncComm::CMD_M782, FALSE );
}

void pa::CPAMotion::itemPasserMoveToWorkPosition_784( )
{
	SendMotionCommand( CPAAsyncComm::CMD_M784, FALSE );
}

void pa::CPAMotion::autoLoaderHandToExchangePosition_785( int isUnload )
{
	SendMotionCommand( CPAAsyncComm::CMD_M785, FALSE, isUnload );
}

void pa::CPAMotion::autoLoaderHandToCasettePosition_786( int isUnload )
{
	SendMotionCommand( CPAAsyncComm::CMD_M786, FALSE, isUnload );
}

// `isPostMill` �� ���� `1` �� ��, ���� �� Ŭ���� �۾� ����.
void pa::CPAMotion::workSpaceClean_787( int isPostMill )
{
	SendMotionCommand( CPAAsyncComm::CMD_M787, FALSE, isPostMill );
}

void pa::CPAMotion::workSpaceGrip_912()
{
	SendMotionCommand( CPAAsyncComm::CMD_M912, FALSE );
}

void pa::CPAMotion::workSpaceUngrip_913()
{
	SendMotionCommand( CPAAsyncComm::CMD_M913, FALSE );
}

void pa::CPAMotion::workSpaceDoubleGrip_914()
{
	SendMotionCommand( CPAAsyncComm::CMD_M914, FALSE );
}

//////////////////////////////////////////////////////////////////////////
// Helpers
//////////////////////////////////////////////////////////////////////////

void pa::CPAMotion::SendMotionCommand( pa::CPAAsyncComm::EN_COMMAND cmd, BOOL blocking )
{
	PPAAsyncComm[0]->SendCommand( cmd );

	if( blocking ) 
	{
		PPAAsyncComm[0]->Wait( cmd, 0 );
	}
}

void pa::CPAMotion::SendMotionCommand( pa::CPAAsyncComm::EN_COMMAND cmd, BOOL blocking, int param )
{
	char szParam[64];

	sprintf_s( szParam, 64, "%d", param );

	PPAAsyncComm[0]->SendCommand( cmd, szParam );

	if( blocking ) 
	{
		PPAAsyncComm[0]->Wait( cmd, 0 );
	}
}

//////////////////////////////////////////////////////////////////////////
// Select M28/M29 
//////////////////////////////////////////////////////////////////////////
void pa::CPAMotion::GWVF( BOOL blocking )
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_GWVF );

	if( blocking ) 
	{
		PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_GWVF );
	}
}

void pa::CPAMotion::SWVF( BOOL blocking, int nSelectM28 )
{
	char szParam[64];

	sprintf_s( szParam, 64, "%d", nSelectM28 );

	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_SWVF, szParam );

	if( blocking )
	{
		PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_SWVF );
	}
}

//////////////////////////////////////////////////////////////////////////
// Barcode
//////////////////////////////////////////////////////////////////////////

int pa::CPAMotion::ReadBarcode()
{
	int barcode = -1;
	return barcode;
}

void pa::CPAMotion::RND_MSC()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RND_MSC );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RND_MSC, 3000 );
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
void pa::CPAMotion::ResetOrigin( pa::EN_AXIS hAxis, BOOL blocking )
{
	char szParam[32];

	PPAStatus->GetThreadState()->bCompleteResetOrigin_ = FALSE;

	sprintf_s( szParam, 32, "%d", (int)(hAxis)+1 );
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_FZS, szParam );

	if( blocking )
	{
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_FZS, 300*1000 );	// 5��  
	}
}

//////////////////////////////////////////////////////////////////////////
// 2018.02.27 SALF ���� �߰� 
//////////////////////////////////////////////////////////////////////////
void pa::CPAMotion::RND_SALF( BOOL blocking, int using_air, int interval, int sensor_type )
{
	char szParam[64];

	sprintf_s( szParam, 64, "%d,%d,%d", using_air, interval, sensor_type );
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_SALF, szParam );

	if( blocking )
	{
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_SALF, 3000 );
	}
}

void pa::CPAMotion::RND_CDT()
{
//	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RND_CDT );
//	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RND_CDT, 5000 ); // 0 );		// 2017.05.20. 0���� ���� ���, ������ ������ ���� ��� �Ѵ�  0 );
	// - 5�ʷ� ���������� RND_STATUS[8]���� timeout ������ �߻��ؼ� 10�ʷ� ������ ���� 
	// - 10�ʷ� ���������� RND_STATUS[8]���� timeout ������ �߻��ؼ� 30�ʷ� ������ ���� 
	// - 30�ʷ� ���������� RND_STATUS[8]���� timeout ������ �߻��ؼ� 0�ʷ� ������ ���� 
	// - log ���� �� 10�ʷ� ���� 
}

void pa::CPAMotion::RND_CDTEX()
{
	PPAAsyncComm[1]->SendCommand( CPAAsyncComm::CMD_RND_CDTEX );
	PPAAsyncComm[1]->Wait( CPAAsyncComm::CMD_RND_CDTEX, 5000 ); // 0 );		// 2017.05.20. 0���� ���� ���, ������ ������ ���� ��� �Ѵ�  0 );
	// - 5�ʷ� ���������� RND_STATUS[8]���� timeout ������ �߻��ؼ� 10�ʷ� ������ ���� 
	// - 10�ʷ� ���������� RND_STATUS[8]���� timeout ������ �߻��ؼ� 30�ʷ� ������ ���� 
	// - 30�ʷ� ���������� RND_STATUS[8]���� timeout ������ �߻��ؼ� 0�ʷ� ������ ���� 
	// - log ���� �� 10�ʷ� ���� 
}

void pa::CPAMotion::RND_SFSF( BOOL blocking, int using_waterflow_senor, int startTimeout, int sensingTimeout )
{
	char szParam[64];

	sprintf_s( szParam, 64, "%d,%d,%d", using_waterflow_senor, startTimeout, sensingTimeout );
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_SFSF, szParam );

	if( blocking )
	{
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_SFSF, 3000 );
	}
}

void pa::CPAMotion::RND_WPAR( BOOL blocking, int purge_air_hold_time )
{
	char szParam[64];

	sprintf_s( szParam, 64, "%d", purge_air_hold_time );
	PPAAsyncComm[0]->SendCommand( CPAAsyncComm::CMD_WPAR, szParam );

	if( blocking )
	{
		PPAAsyncComm[0]->Wait( CPAAsyncComm::CMD_WPAR, 3000 );
	}
}