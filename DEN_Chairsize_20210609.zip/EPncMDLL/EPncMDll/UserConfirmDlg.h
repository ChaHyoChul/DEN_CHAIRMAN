#pragma once

// CUserConfirmDlg ��ȭ �����Դϴ�.

class CUserConfirmDlg : public CDialog
{
	DECLARE_DYNAMIC(CUserConfirmDlg)

	CFont	hFntMsg_;
	CFont	hFntBtn_;

	CBrush	brhBackground_;
	CBrush	brhOkBtn_;

	BOOL bToolDirection_;

public:
	CUserConfirmDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CUserConfirmDlg();

	void display_toolerror_info(BOOL bToolDirection);

// ��ȭ ���� �������Դϴ�.
	enum { IDD = 105 }; //IDD_DIALOG_USER_CONFIRM };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedButtonOk();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);

	//////////////////////////////////////////////////////////////////////////

	static HANDLE			hWAIT_EVENT;
	static CUserConfirmDlg	*P_USER_CONFIRM_DLG;

	static void INITIALIZE_DLG(); 
	static void DELETE_DLG(); 
	static void SHOW_DLG(BOOL bToolDirection);
	static void HIDE_DLG();
	static BOOL IS_SHOW_DLG();
	static int  WAIT_FOR_SELECT();
	static void REMOTE_SET_RESPONSE( int nSelect );
	int nSelect_;
};
