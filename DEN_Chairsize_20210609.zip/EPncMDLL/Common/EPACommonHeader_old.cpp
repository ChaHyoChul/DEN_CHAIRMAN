//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "EPACommonHeader.h"

namespace pa 
{
//////////////////////////////////////////////////////////////////////////

EN_USER_MODE	USER_MODE = USER_MODE_USR;
CString	STR_USER_MODE[USER_MODE_NUM] =
{
	_T("User"),
	_T("Manager"),
	_T("RND")
};

CString	STR_USER_MODE_PW[USER_MODE_NUM] =
{
	_T(""),
	_T("1234"),
	_T("100321")
};

void SET_CURRENT_USERMODE(EN_USER_MODE user_mode)
{
	pa::PPAStatus->GetThreadState()->hUserMode = user_mode;
}

EN_USER_MODE GET_CURRENT_USERMODE()
{
	return pa::PPAStatus->GetThreadState()->hUserMode;
}

//////////////////////////////////////////////////////////////////////////

CString STR_PA_RUN_STATUS[] = 
{
	_T("Idle"),
	_T("Run"),
	_T("Unknown"),
	_T("Error"),
	_T("Pause")
};

CString STR_COORDINATE[COORD_NUM] = 
{
	_T("G53"),
	_T("G54"),
	_T("G55"),
	_T("G56"),
	_T("G57"),
	_T("G58"),
	_T("G59")
};

CString STR_TEACHING_POINT[TEACHING_POINT_NUM] =
{
	_T("Tool No.1"),
	_T("Tool No.2"),
	_T("Tool No.3"),
	_T("Tool No.4"),
	_T("Tool No.5"),
	_T("Tool No.6"),
	_T("Tool No.7"),
	_T("Tool No.8"),
	_T("Ready Position"),
	_T("Block Loading"),
	_T("Block Unloading"),	// 2017.06.28 �߰�
	_T("Block Working"),
	_T("Tool Sensing Up"),
	_T("Tool Sensing Down")
};

int N_TEACHING_POINT_NO[TEACHING_POINT_NUM] =
{
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	10, 
	11,
	12, 
	19,
	20
};

CString STR_OPTION[OPTION_NUM] =
{
	_T("ZAxis Origin Offset"),
	_T("Tool Sensing High Speed"),
	_T("Tool Sensing Low Speed"),
	_T("Tool Sensing Margin"),
	// 2017.01.11
	_T("Tool Pocket Put Offset")
};

CString STR_NC_FILESTATE[MAX_NCFILE_NUM] = 
{
	_T("Before"),
	_T("Run"),
	_T("Complete"),
	_T("Stop"),
	_T("Error")
};

COLORREF CLR_NC_FILESTATE[NCFILE_STATE_NUM] =
{
	RGB( 200, 120,  80 ),	// Before
	RGB( 120, 200, 120 ),	// Run
	RGB( 120, 120, 200 ),	// Complete
	RGB( 200, 120, 200 ),	// Stop
	RGB( 255, 100, 100 )	// Error
};

CString STR_RUNMODE[RUNMODE_NUM] = 
{
	_T("Stop"),
	_T("ToStop"),
	_T("ToRun"),
	_T("Run"),
	_T("Init."),
	_T("Error"),
	_T("Pause")
};

//////////////////////////////////////////////////////////////////////////

CString STR_AUTOLOADER_TEACHING_POINT_NAME[AUTOLOADER_TP_NUM] =
{
	_T("First_Block_Position"),
	_T("Block_Exchinging_Position"),	//_T("Rotation_Position"),
	_T("Block_Pitch"),
	_T("GetPut_Down_Strock"),	
	_T("GetPut_Up_Strock"),
	_T("GetPut_Sensing_Offset"),
	_T("GetPut_BarcodeSensing_Offset"),
	_T("Gripper_Put_Offset"),
	_T("GetPut_Fast_Speed"),
	_T("GetPut_Slow_Speed"),
	_T("Slot_Jump_Number"),
	_T("Slot_Jump_Dist"),
	_T("Gripper_Get_Offset"),
	_T("Block_Load_Unload_A_Pos"),
	_T("Block_Load_Ubload_B_Pos"),
	_T("Number_Of_Block")
};

CString STR_BLOCK_STATE[BLOCK_STATE_NUM] = {
	_T("Empty"),
	_T("Ready"),
	_T("Running"),
	_T("Complete"),
	_T("Error"),
	_T("Lost")
};

//////////////////////////////////////////////////////////////////////////
// input bit ��ȣ ���� 
#ifdef _PA_G2400_
// input bit ��ȣ ���� 
int SPAStatus::INPUT_BIT_NO[IN_NUM] = 
{
	101, 102, 103, 104, 105, 106, 107, 108, 109, 110,
	111, 112, 113, 114, 115, 116, 117, 118, 119, 120,
	121, 122, 123, 124, 125, 126, 127, 128, 129, 130,
	131, 132
};

// output bit ��ȣ ���� 
int SPAStatus::OUTPUT_BIT_NO[OUT_NUM] = 
{
	101, 102, 103, 104, 105, 106, 107, 108, 109, 110,
	111, 112, 113, 114, 115, 116, 117, 118, 119, 120,
	121, 122, 123, 124, 125, 126, 127, 128, 129, 130,
	131, 132
};
#endif 

#ifdef _PA_G1600_
// input bit ��ȣ ���� 

int SPAStatus::INPUT_BIT_NO[IN_NUM] = 
{
	10001, 10002, 10003, 10004, 10005, 10006, 10007, 10008,
	20001, 20002, 20003, 20004, 20005,
	20006, 20007, 20008, 20009, 20010,
	20011, 20012, 20013, 20014, 20015, 
	20016, 20017, 20018, 20019, 20020,
	20021, 20022, 20023, 20024, 20025, 
	20026, 20027, 20028, 20029, 20030,
	20031, 20032
};

// output bit ��ȣ ���� 
int SPAStatus::OUTPUT_BIT_NO[OUT_NUM] = 
{
	13, 14, 15, 16, 17, 18, 19, 20,
	20033, 20034, 20035, 20036, 20037,
	20038, 20039, 20040, 20041, 20042,
	20043, 20044, 20045, 20046, 20047, 
	20048, 20049, 20050, 20051, 20052,  
	20053, 20054, 20055, 20056, 20057,  
	20058, 20059, 20060, 20061, 20062,  
	20063, 20064
};
#endif
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////

// TCHAR*	P_NCFILE_PATH		= _T("\\SD Card\\ncfiles");			// ���α׷����� ����ϴ� NC ���� ��� ( \\SD Card\\ncfiles )
// 
// TCHAR*	P_LOG_FILE_PATH		= _T("\\SD Card\\Log");				// 

// TODO: figure this out
TCHAR* P_USB_NCFILE_PATH = NCFILE_PATH;				// USB �޸��� NC ���� ��� ( \\�ϵ� ��ũ )

void GET_NCFILE_FULL_PATH( CString& strNCFileName )
{
	strNCFileName = CString( NCFILE_PATH ) + CString( _T("\\") ) + strNCFileName;
}

//////////////////////////////////////////////////////////////////////////
// FileMgr ȭ�� �÷� ����
// COLORREF CLR_FILEMGR_MAIN		= RGB( 96, 96, 216 );
// COLORREF CLR_FILEMGR_REGISTER	= RGB( 96, 96, 216 ); //RGB( 198, 255, 255 );
// COLORREF CLR_FILEMGR_COPY		= RGB( 96, 96, 216 );
COLORREF CLR_FILEMGR_MAIN		= RGB( 96, 96, 216 );
COLORREF CLR_FILEMGR_REGISTER	= RGB( 198, 255, 255 ); //RGB( 198, 255, 255 );
COLORREF CLR_FILEMGR_COPY		= RGB( 250, 224, 212 );

//////////////////////////////////////////////////////////////////////////
// Setup ȭ�� �÷� ���� 
COLORREF CLR_SETUP_MAIN			= RGB( 220, 220, 220 );
COLORREF CLR_SETUP_TEACHING		= RGB( 198, 255, 255 );
COLORREF CLR_SETUP_TOOL			= RGB( 209, 255, 202 );
COLORREF CLR_SETUP_AUTOLOADER	= RGB( 250, 224, 212 );
COLORREF CLR_SETUP_OPTION		= RGB( 255, 198, 255 );
COLORREF CLR_BUTTON_EMO_RESET	= RGB( 255, 64, 64 );
COLORREF CLR_BUTTON_BACK		= RGB( 128, 128, 220 );
COLORREF CLR_SETUP_IO			= RGB( 198, 255, 255 );
COLORREF CLR_SETUP_LOG			= RGB( 250, 244, 192 );
COLORREF CLR_SETUP_BKGND		= RGB( 190, 190, 190 );

//////////////////////////////////////////////////////////////////////////
// Multi-Origin Data
//////////////////////////////////////////////////////////////////////////

BOOL SMultiOriginData::Load( TCHAR* pFilePath, CString& strErrMsg, BOOL bCheckError )
{
	CCEIniFile	hIniFile;
	CString		strKeyName, strValueName;

	//////////////////////////////////////////////////////////////////////////
	// ������ ���� ���, ��� 0���� �ʱ�ȭ �Ѵ� 
	CString strFilePath;
	strFilePath.Format( _T("%s"), pFilePath );
	if( hcutil::IsExistFile( strFilePath ) == FALSE )
	{
		memset((void*)this, 0, sizeof(SMultiOriginData) );
		return TRUE;
	}
	//////////////////////////////////////////////////////////////////////////

	strErrMsg.Format( _T("") );

	hIniFile.Open( pFilePath );

	strKeyName.Format( _T("multi_origin_gcode") );

	hIniFile.GetValue( strKeyName, _T("num"), (int*)&nNumGCode );

	// ������ ���ϱ� ����, ���� �����͸� ���� �д´� 
	hIniFile.GetValue( _T("Offset"), _T("Min"), (double*)&fOffset_Min_ );
	hIniFile.GetValue( _T("Offset"), _T("Max"), (double*)&fOffset_Max_ );

	for( int i = 0; i<nNumGCode; i++ )
	{
		int gcode_no = 0;
		int num_sub_coord = 0;

		strValueName.Format( _T("gcode_%d"), i+1 );
		hIniFile.GetValue( strKeyName, strValueName, (int*)&gcode_no );
		strValueName.Format( _T("gcode_%d_num_sub_coord"), i+1 );
		hIniFile.GetValue( strKeyName, strValueName, (int*)&num_sub_coord );

		load_gcode_offset( &hIniFile, i, gcode_no, num_sub_coord );

		if( bCheckError == TRUE )
		{
			for( int j = 0; j<hMultiOrigin[i].nNumSubCoord; j++ )
			{
				CString strTemp;

				for( int k = 3; k<6; k++ )
				{
					double fVal = hMultiOrigin[i].fOffset[j][k];
					if( fVal >= fOffset_Min_ && fVal <= fOffset_Max_ ) 
					{
						;
					}
					else
					{
						strTemp.Format( _T("coordinate(%d), offset_index(%d), offset_axis(%d), value(%.3f)\r\n"), i, j, k, fVal ); strErrMsg += strTemp;
						strTemp.Format( _T("new value is out of range [%.3f ~ %.3f]\r\n"), fOffset_Min_, fOffset_Max_ ); strErrMsg += strTemp;

						hIniFile.Close();
						return FALSE;
					}
				}			
			}
		}
	}

	hIniFile.Close();

	return TRUE;
}

// start_no:1, stop_no=10
void SMultiOriginData::load_gcode_offset( CCEIniFile* pIniFile, int index, int gcode_no, int num_sub_coord )
{
	CString strKeyName;
	double	fTemp;
	int		nTemp;

	hMultiOrigin[index].nGcode	= gcode_no;
	hMultiOrigin[index].nNumSubCoord = num_sub_coord;

	for( int i = 0; i<hMultiOrigin[index].nNumSubCoord; i++ )
	{
		strKeyName.Format( _T("G%d.%d"), gcode_no, i+1 );

		pIniFile->GetValue( strKeyName, _T("x_dist"), (double*)&fTemp ); 
		hMultiOrigin[index].fOffset[i][0] = fTemp;
		pIniFile->GetValue( strKeyName, _T("y_dist"), (double*)&fTemp ); 
		hMultiOrigin[index].fOffset[i][1] = fTemp;
		pIniFile->GetValue( strKeyName, _T("z_dist"), (double*)&fTemp ); 
		hMultiOrigin[index].fOffset[i][2] = fTemp;
		pIniFile->GetValue( strKeyName, _T("x_offset"), (double*)&fTemp ); 
		hMultiOrigin[index].fOffset[i][3] = fTemp;
		pIniFile->GetValue( strKeyName, _T("y_offset"), (double*)&fTemp ); 
		hMultiOrigin[index].fOffset[i][4] = fTemp;
		pIniFile->GetValue( strKeyName, _T("z_offset"), (double*)&fTemp ); 
		hMultiOrigin[index].fOffset[i][5] = fTemp;

		pIniFile->GetValue( strKeyName, _T("reverse_xyoffset"), (int*)&nTemp );
		hMultiOrigin[index].bReverseXY[i] = ( nTemp == 0 ) ? FALSE : TRUE;
	}
}

void SMultiOriginData::Save( TCHAR* pFilePath )
{
	CCEIniFile	hIniFile;
	CString		strKeyName, strValueName;

	hIniFile.Open( pFilePath );

	strKeyName.Format( _T("multi_origin_gcode") );

	hIniFile.SetValue( strKeyName, _T("num"), nNumGCode );

	for( int i = 0; i<nNumGCode; i++ )
	{
		int	gcode_no = hMultiOrigin[i].nGcode;
		int num_sub_coord = hMultiOrigin[i].nNumSubCoord;

		save_gcode_offset( &hIniFile, i, gcode_no, num_sub_coord );
	}

	hIniFile.Close();
}

// G57.1-G57.10���� ���� 
void SMultiOriginData::save_gcode_offset( CCEIniFile* pIniFile, int index, int gcode_no, int num_sub_coord )
{
	CString strKeyName;

	for( int i = 0; i<num_sub_coord; i++ )
	{
		strKeyName.Format( _T("G%d.%d"), gcode_no, i+1 );

		pIniFile->SetValue( strKeyName, _T("x_dist"), (double)(hMultiOrigin[index].fOffset[i][0]) );
		pIniFile->SetValue( strKeyName, _T("y_dist"), (double)(hMultiOrigin[index].fOffset[i][1]) );
		pIniFile->SetValue( strKeyName, _T("z_dist"), (double)(hMultiOrigin[index].fOffset[i][2]) );
		pIniFile->SetValue( strKeyName, _T("x_offset"), (double)(hMultiOrigin[index].fOffset[i][3]) );
		pIniFile->SetValue( strKeyName, _T("y_offset"), (double)(hMultiOrigin[index].fOffset[i][4]) );
		pIniFile->SetValue( strKeyName, _T("z_offset"), (double)(hMultiOrigin[index].fOffset[i][5]) );

		pIniFile->SetValue( strKeyName, _T("reverse_xyoffset"), (int)(hMultiOrigin[index].bReverseXY[i] == FALSE ? 0 : 1) );
	}
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
// 2016.11.18 ���� 
/*
CString SAutoCalCoordinateOffsetParam::STR_PARAM_NAME[PARAM_NUM] =
{
	CString( _T("DummyPosX") ),
	CString( _T("DummyPosY") ),
	CString( _T("MeasurePosX") ),
	CString( _T("MeasurePosY") ),
	CString( _T("MeasurePosA") ),
	CString( _T("MeasurePosB") ),
	CString( _T("MeasurePosZ_AB0") ),
	CString( _T("MeasurePosZ_An") ),
	CString( _T("MeasurePosZ_Bn") ),
	CString( _T("Tool_Number") ),
	CString( _T("Tool_Diameter") ),
	CString( _T("Measure_Count") ),
	CString( _T("Disc_Thickness") ),
	CString( _T("Z_Axis_1st_MaxDistance") ),
	CString( _T("Z_Axis_2nd_MeasureOffset") ),
	CString( _T("XY_MeasureOffset") ),
	CString( _T("MoveSpeed_For_MeasurePosition") ),
	CString( _T("MoveSpeed_For_MeasureForword") ),
	CString( _T("MoveSpeed_For_MeasureBackword") )
};
*/

// enum EN_PARAM
// {
// 	PARAM_DUMMY_POS_X = 0,			// P6041
// 	PARAM_DUMMY_POS_Y,				// P6042
// 	// 		PARAM_MEASURE_POS_X,			// P6043: A,X�� ������ X�� ��ġ 
// 	// 		PARAM_MEASURE_POS_Y,			// P6044: B,Y�� ������ Y�� ��ġ 
// 	// 		PARAM_MEASURE_POS_A,			// P6045: X�� ������ A�� ��ġ
// 	// 		PARAM_MEASURE_POS_B,			// P6046: Y�� ������ B�� ��ġ 
// 
// 	// 2016.11.18 ���� (�߰�)
// 	PARAM_XPOS_FOR_AAXIS_MEAS,		// P6043: A�� ������ ���� X�� ��ġ
// 	PARAM_YPOS_FOR_BAXIS_MEAS,		// P6044: B�� ������ ���� Y�� ��ġ 
// 	PARAM_XPOS_FOR_XAXIS_MEAS,		// P6056: X�� ������ ���� X�� ��ġ
// 	PARAM_YPOS_FOR_YAXIS_MEAS,		// P6057: Y�� ������ ���� Y�� ��ġ 
// 
// 	PARAM_APOS_FOR_XAXIS_MEAS,		// P6045: X�� ������ ���� A�� ��ġ 
// 	PARAM_BPOS_FOR_YAXIS_MEAS,		// P6046: Y�� ������ ���� B�� ��ġ 
// 
// 	PARAM_MEASURE_POS_Z_AB0,		// P6047
// 	PARAM_MEASURE_POS_Z_An,			// P6048
// 	PARAM_MEASURE_POS_Z_Bn,			// P6049
// 
// 	PARAM_TOOL_NO,					// P6050
// 	PARAM_TOOL_DIAMETER,			// P6058 
// 	PARAM_MEASURE_COUNT,			// P6051
// 	PARAM_DISK_THICK,				// P6052
// 	PARAM_ZAXIS_1ST_MAX_DISTANCE,	// P6053: ù��° ������ �ִ� ���� �Ÿ� 
// 	PARAM_ZAXIS_2ST_MEASURE_OFFSET,	// P6054: �ι�° ������ ���� �ɼ� �Ÿ� 
// 	PARAM_XY_MEASURE_OFFSET,		// P6055: ���� ��ġ �ɼ� (x, y)
// 	PARAM_MOVESPEED_FOR_MEAS_POS,	// P597 : ���� ��ġ�� �̵� �ӵ� 
// 	PARAM_MOVESPEED_MEAS_FORWORD,	// P602 : ���� �̵� �ӵ� (����)
// 	PARAM_MOVESPEED_MEAS_BACKWORD,	// P603 : ���� �̵� �ӵ� (����)
// 	PARAM_NUM
// };
CString SAutoCalCoordinateOffsetParam::STR_PARAM_NAME[PARAM_NUM] =
{
	CString( _T("DummyPosX") ),
	CString( _T("DummyPosY") ),
// 	CString( _T("MeasurePosX") ),
// 	CString( _T("MeasurePosY") ),
// 	CString( _T("MeasurePosA") ),
// 	CString( _T("MeasurePosB") ),
	CString( _T("XPosForAAxisMeasure") ),
	CString( _T("YPosForBAxisMeasure") ),
	CString( _T("XPosForXAxisMeasure") ),
	CString( _T("YPosForYAxisMeasure") ),

	CString( _T("APosForXAxisMeasure") ),
	CString( _T("BPosForYAxisMeasure") ),

	CString( _T("MeasurePosZ_AB0") ),
	CString( _T("MeasurePosZ_An") ),
	CString( _T("MeasurePosZ_Bn") ),
	CString( _T("Tool_Number") ),
	CString( _T("Tool_Diameter") ),
	CString( _T("Measure_Count") ),
	CString( _T("Disc_Thickness") ),
	CString( _T("Z_Axis_1st_MaxDistance") ),
	CString( _T("Z_Axis_2nd_MeasureOffset") ),
	CString( _T("XY_MeasureOffset") ),
	CString( _T("MoveSpeed_For_MeasurePosition") ),
	CString( _T("MoveSpeed_For_MeasureForword") ),
	CString( _T("MoveSpeed_For_MeasureBackword") )
};

BOOL SAutoCalCoordinateOffsetParam::Load( TCHAR* pFilePath, CString& strErrMsg )
{
	CCEIniFile	hIniFile;
	CString		strKeyName;

	if( !hcutil::IsExistDir( CString(pFilePath) ) ) {
		strErrMsg.Format( _T("file not found !") );
		return FALSE;
	}

	hIniFile.Open( pFilePath );

	strKeyName.Format( _T("AutoCal") );

	for( int i = 0; i<(int)PARAM_NUM; i++ ) 
	{
		hIniFile.GetValue( strKeyName, STR_PARAM_NAME[i], (double*)&fParam[i] );
	}

	hIniFile.Close();

	return TRUE;
}

BOOL SAutoCalCoordinateOffsetParam::Save( TCHAR* pFilePath, CString& strErrMsg )
{
	CCEIniFile	hIniFile;
	CString		strKeyName;

	hIniFile.Open( pFilePath );

	strKeyName.Format( _T("AutoCal") );

	for( int i = 0; i<(int)PARAM_NUM; i++ ) 
	{
		hIniFile.SetValue( strKeyName, STR_PARAM_NAME[i], (double)fParam[i] );
	}

	hIniFile.Close();

	return TRUE;
}

//////////////////////////////////////////////////////////////////////////
//
// PARAM_X_LEFT_MEASURE_POSX = 0,
// PARAM_X_LEFT_MEASURE_POSY,
// PARAM_X_LEFT_MEASURE_POSZ,
// PARAM_X_RIGHT_MEASURE_POSX,
// PARAM_X_RIGHT_MEASURE_POSY,
// PARAM_X_RIGHT_MEASURE_POSZ,
// PARAM_Y_MEASURE_POSY,
// PARAM_Y_MEASURE_POSZ,
// PARAM_Z_MEASURE_POSY,
// PARAM_Z_MEASURE_POSZ,
// 
// PARAM_TOOL_NO,
// PARAM_TOOL_DIAMETER,
// PARAM_MEASURE_COUNT,
// PARAM_1ST_MAX_DISTANCE,
// PARAM_2ST_MEASURE_OFFSET,
// PARAM_MOVESPEED_FOR_MEAS_POS,
// PARAM_MOVESPEED_MEAS_FORWARD,
// PARAM_MOVESPEED_MEAS_BACKWARD,

// CString SAutoCalSingleAbutmentCoordinateOffsetParam::STR_PARAM_NAME[PARAM_NUM] = 
// {
// 	CString( _T("X_Left_Measure_PosX") ),
// 	CString( _T("X_Left_Measure_PosY") ),
// 	CString( _T("X_Left_Measure_PosZ") ),
// 	CString( _T("X_Right_Measure_PosX") ),
// 	CString( _T("X_Right_Measure_PosY") ),
// 	CString( _T("X_Right_Measure_PosZ") ),
// 	CString( _T("Y_Measure_PosY") ),
// 	CString( _T("Y_Measure_PosZ") ),
// 	CString( _T("Z_Measure_PosY") ),
// 	CString( _T("Z_Measure_PosZ") ),
// 	CString( _T("Tool_No") ),
// 	CString( _T("Tool_Diameter") ),
// 	CString( _T("Measure_Count") ),
// 	CString( _T("Rotation_Angle") ),
// 	CString( _T("1st_MaxDistance") ),
// 	CString( _T("2nd_MeasureOffset") ),
// 	CString( _T("MoveSpeed_For_MeasurePosition") ),
// 	CString( _T("MoveSpeed_For_MeasureForward") ),
// 	CString( _T("MoveSpeed_For_MeasureBackward") )
// };

/*
enum EN_PARAM
{
PARAM_X_MEASURE_POSX = 0,		// X�� �������� X��ġ
PARAM_X_MEASURE_POSY,			// X�� �������� Y��ġ
PARAM_X_MEASURE_POSZ,			// X�� �������� Z��ġ 

PARAM_Y_MEASURE_POSY_G53,		// Y�� �������� Y��ġ 
PARAM_Y_MEASURE_POSZ,			// Y�� �������� Z��ġ 

PARAM_Z_MEASURE_POSY,			// Z�� �������� Y��ġ 
PARAM_Z_MEASURE_POSZ,			// Z�� �������� Z��ġ 

PARAM_A_MEASURE_POSX,			// A�� �������� X��ġ 
PARAM_A_MEASURE_POSY,			// A�� �������� Y��ġ 
PARAM_A_MEASURE_POSZ,			// A�� �������� Z��ġ 

PARAM_TOOL_NO,					// ����� �� ��ȣ 
PARAM_TOOL_DIAMETER,			// ����� ���� �β�
PARAM_MEASURE_COUNT,			// �� ����Ʈ ���� ī��Ʈ 
PARAM_ROTATION_ANGLE,			// ���� ���� 10
PARAM_1ST_MAX_DISTANCE,			// 
PARAM_2ST_MEASURE_OFFSET,		//
PARAM_MOVESPEED_FOR_MEAS_POS,	//
PARAM_MOVESPEED_MEAS_FORWARD,	//
PARAM_MOVESPEED_MEAS_BACKWARD,	//
PARAM_NUM
};
*/

CString SAutoCalSingleAbutmentCoordinateOffsetParam::STR_PARAM_NAME[PARAM_NUM] =
{
	CString( _T("XPosForXAxisMeasure") ),
	CString( _T("YPosForXAxisMeasure") ),
	CString( _T("ZPosForXAxisMeasure") ),

	CString( _T("YPosForYAxisMeasure_G53") ),
	CString( _T("ZPosForYAxisMeasure") ),

	CString( _T("YPosForZAxisMeasure") ),
	CString( _T("ZPosForZAxisMeasure") ),

	CString( _T("XPosForAAxisMeasure") ),
	CString( _T("YPosForAAxisMeasure") ),
	CString( _T("ZPosForAAxisMeasure") ),

 	CString( _T("Tool_No") ),
 	CString( _T("Tool_Diameter") ),
 	CString( _T("Measure_Count") ),
 	CString( _T("Rotation_Angle") ),
 	CString( _T("1st_MaxDistance") ),
 	CString( _T("2nd_MeasureOffset") ),
 	CString( _T("MoveSpeed_For_MeasurePosition") ),
 	CString( _T("MoveSpeed_For_MeasureForward") ),
 	CString( _T("MoveSpeed_For_MeasureBackward") )
};

BOOL SAutoCalSingleAbutmentCoordinateOffsetParam::Load( TCHAR* pFilePath, CString& strErrMsg )
{
	CCEIniFile	hIniFile;
	CString		strKeyName;
	CString		strFilePath;

	strFilePath.Format( _T("%s"), pFilePath );

	if( !hcutil::IsExistFile( strFilePath ) ) {
		strErrMsg.Format( _T("file not found !") );
		return FALSE;
	}

	hIniFile.Open( pFilePath );

	strKeyName.Format( _T("SingleAbutment_AutoCal") );

	for( int i = 0; i<(int)PARAM_NUM; i++ ) 
	{
		hIniFile.GetValue( strKeyName, STR_PARAM_NAME[i], (double*)&fParam[i] );
	}

	hIniFile.Close();

	return TRUE;
}

BOOL SAutoCalSingleAbutmentCoordinateOffsetParam::Save( TCHAR* pFilePath, CString& strErrMsg )
{
	CCEIniFile	hIniFile;
	CString		strKeyName;

	hIniFile.Open( pFilePath );

	strKeyName.Format( _T("SingleAbutment_AutoCal") );

	for( int i = 0; i<(int)PARAM_NUM; i++ ) 
	{
		hIniFile.SetValue( strKeyName, STR_PARAM_NAME[i], (double)fParam[i] );
	}

	hIniFile.Close();

	return TRUE;
}

//////////////////////////////////////////////////////////////////////////
// PARAM_MEASURE_P1_XPOS = 0,		// P6081 : P1. X�� ��ġ
// PARAM_MEASURE_P1_YPOS,			// P6082 : P1. Y�� ��ġ
// PARAM_MEASURE_P1_ZPOS,			// P     : P1. Z�� ��ġ
// PARAM_MEASURE_P2_XPOS,			// P6083 : P2. X�� ��ġ
// PARAM_MEASURE_P2_YPOS,			// P6084 : P2. Y�� ��ġ 
// PARAM_MEASURE_P2_ZPOS,			// P     : P2. Z�� ��ġ
// PARAM_MEASURE_P3_XPOS,			// P6085 : P3. X�� ��ġ
// PARAM_MEASURE_P3_YPOS,			// P6086 : P3. Y�� ��ġ 
// PARAM_MEASURE_P3_ZPOS,			// P     : P3. Z�� ��ġ
// PARAM_TOOL_NO,					// P6088 : ������ ����� �� ��ȣ 
// PARAM_MEASURE_COUNT,				// P6089 : ���� ȸ�� 
// PARAM_1ST_POCKET_X_DIST,			// P6090 : 1�� Pocket X�� ��ġ
// PARAM_1ST_POCKET_Y_DIST,			// P6091 : 1�� Pocket Y�� ��ġ
// PARAM_POCKET_X_DIST,				// P6092 : Pocket�� X�� �Ÿ� 
// PARAM_POCKET_Y_DIST,				// P6093 : Pocket�� Y�� �Ÿ� 
// PARAM_SENSOR_X_DIST,				// P6094 : Probe sensor ���� x�� �Ÿ� 
// PARAM_SENSOR_Y_DIST,				// P6095 : Probe sensor ���� y�� �Ÿ� 
// PARAM_1ST_MAX_DISTANCE,			// P6096 : ù��° ������, �ִ� ���� �Ÿ� 
// PARAM_2ST_MEASURE_OFFSET,		// P6097 : �ι��� ������, �ִ� ���� �Ÿ� 
// PARAM_MOVESPEED_FOR_MEAS_POS,	// P597 : ���� ��ġ�� �̵� �ӵ� 
// PARAM_MOVESPEED_MEAS_FORWORD,	// P602 : ���� �̵� �ӵ� (����)
// PARAM_MOVESPEED_MEAS_BACKWORD,	// P603 : ���� �̵� �ӵ� (����)

CString SAutoTeachToolPocketParam::STR_PARAM_NAME[PARAM_NUM] = 
{
	CString( _T("MeausrePosX1") ),
	CString( _T("MeausrePosY1") ),
	CString( _T("MeausrePosZ1") ),
	CString( _T("MeausrePosX2") ),
	CString( _T("MeausrePosY2") ),
	CString( _T("MeausrePosZ2") ),
	CString( _T("MeausrePosX3") ),
	CString( _T("MeausrePosY3") ),
	CString( _T("MeausrePosZ3") ),
	CString( _T("Tool_No") ),
	CString( _T("Tool_Diameter") ),
	CString( _T("Measure_Count") ),
	CString( _T("1stPocketPosX") ),
	CString( _T("1stPocketPosY") ),
	CString( _T("PocketXDist") ),
	CString( _T("PocketYDist") ),
	CString( _T("SensorXDist") ),
	CString( _T("SensorYDist") ),
	CString( _T("1st_MaxDistance") ),
	CString( _T("2nd_MeasureOffset") ),
	CString( _T("MoveSpeed_For_MeasurePosition") ),
	CString( _T("MoveSpeed_For_MeasureForword") ),
	CString( _T("MoveSpeed_For_MeasureBackword") )
};

BOOL SAutoTeachToolPocketParam::Load( TCHAR* pFilePath, CString& strErrMsg )
{
	CCEIniFile	hIniFile;
	CString		strKeyName;
	CString		strFilePath;

	strFilePath.Format( _T("%s"), pFilePath );

	if( !hcutil::IsExistFile( strFilePath ) ) {
		strErrMsg.Format( _T("file not found !") );
		return FALSE;
	}

	hIniFile.Open( pFilePath );

	strKeyName.Format( _T("AT_ToolPocket") );

	for( int i = 0; i<(int)PARAM_NUM; i++ ) 
	{
		hIniFile.GetValue( strKeyName, STR_PARAM_NAME[i], (double*)&fParam[i] );
	}

	hIniFile.Close();

	return TRUE;
}

BOOL SAutoTeachToolPocketParam::Save( TCHAR* pFilePath, CString& strErrMsg )
{
	CCEIniFile	hIniFile;
	CString		strKeyName;

	hIniFile.Open( pFilePath );

	strKeyName.Format( _T("AT_ToolPocket") );

	for( int i = 0; i<(int)PARAM_NUM; i++ ) 
	{
		hIniFile.SetValue( strKeyName, STR_PARAM_NAME[i], (double)fParam[i] );
	}

	hIniFile.Close();

	return TRUE;
}

//////////////////////////////////////////////////////////////////////////

BOOL SCoordinateOffsetDataRange::Load( TCHAR* pFilePath, CString& strErrMsg )
{
	TCHAR*	P_AXIS_NAME[pa::AXIS_NUM] = {_T("X_AXIS"), _T("Y_AXIS"), _T("Z_AXIS"), _T("A_AXIS"), _T("B_AXIS") };
	CCEIniFile	hIniFile;
	CString strKeyname;

	hIniFile.Open( pFilePath );

	// �� �ະ�� default, min, max���� �о� �����Ѵ� 
	for( int i = 0; i<pa::AXIS_NUM; i++ )
	{
		strKeyname.Format( _T("%s"), P_AXIS_NAME[i] );

		hIniFile.GetValue( strKeyname, _T("default"), (double*)&fDefault[i] );
		hIniFile.GetValue( strKeyname, _T("min"), (double*)&fMin[i] );
		hIniFile.GetValue( strKeyname, _T("max"), (double*)&fMax[i] );
	}

	hIniFile.Close();

	return TRUE;
}

//////////////////////////////////////////////////////////////////////////

BOOL SMeasureParamEtc::Load( TCHAR* pFilePath, CString& strErrMsg )
{
	CCEIniFile	hIniFile;
	CString strKeyname, strValuename;

	hIniFile.Open( pFilePath );

	// [Tool]
	strKeyname.Format( _T("Tool") );
	for( int i = 0; i<8; i++ )
	{
		strValuename.Format( _T("No%d"), i );
		hIniFile.GetValue( strKeyname, strValuename, (int*)&nUsingTool[i] );
	}
	hIniFile.GetValue( strKeyname, _T("DefaultDiameter"), (double*)&fDefaultToolDiameter );
	hIniFile.GetValue( strKeyname, _T("MinDiameter"), (double*)&fMinToolDiameter );
	hIniFile.GetValue( strKeyname, _T("MaxDiameter"), (double*)&fMaxToolDiameter );

	// [Disk]
	strKeyname.Format( _T("Disk") );
	hIniFile.GetValue( strKeyname, _T("DefaultThickness"), (double*)&fDefaultDiskThickness );
	hIniFile.GetValue( strKeyname, _T("MinThickness"), (double*)&fMinDiskThickness );
	hIniFile.GetValue( strKeyname, _T("MaxThickmess"), (double*)&fMaxDiskThickness );

	hIniFile.Close();

	return TRUE;
}

BOOL SMeasureParamEtc::CheckToolNo( int nToolNo, CString& strErrMsg )
{
	BOOL bRet = TRUE; 

	if( nToolNo >=1 && nToolNo <= 8 ) 
	{
		if( pa::PPAStatus->GetMeasureParamEtc()->nUsingTool[nToolNo-1] == 0 ) 
		{
			// ����� �� ���� �� ��ȣ 
			bRet = FALSE;
			strErrMsg.Format( _T("Tool number input error") );
		}
	}
	else 
	{
		bRet = FALSE;
		strErrMsg.Format( _T("Tool number input error") );
	}

	return bRet;
}

BOOL SMeasureParamEtc::CheckToolDiameter( double fTD, CString& strErrMsg )
{
	BOOL bRet = TRUE;
	double fMin = fMinToolDiameter;
	double fMax = fMaxToolDiameter;
	
	if( fTD < fMin || fTD > fMax ) 
	{
		// �� �β� �Է� ���� 
		bRet = FALSE;
		strErrMsg.Format( _T("Tool diameter input error (%.3f ~ %.3f)"), fMin, fMax );
	}

	return bRet;
}

BOOL SMeasureParamEtc::CheckDiskThickness( double fThick, CString& strErrMsg )
{
	BOOL bRet = TRUE;
	double fMin = fMinDiskThickness;
	double fMax = fMaxDiskThickness;

	if( fThick < fMin || fThick > fMax ) 
	{
		// �� �β� �Է� ���� 
		bRet = FALSE;
		strErrMsg.Format( _T("Disk thickness input error (%.3f ~ %.3f)"), fMin, fMax );
	}

	return bRet;
}

//////////////////////////////////////////////////////////////////////////
// enum EN_PARAM
// {
// 	PARAM_MEASURE_OFFSET_XAXIS = 0,		// P6061: X�� ���� ���� ��ġ �ɼ� 
// 	PARAM_MEASURE_OFFSET_YAXIS,			// P6062: Y�� ���� ���� ��ġ �ɼ� 
// 	PARAM_ZPOS_FOR_XAXIS,				// P6063: X�� ������, Z�� ��ġ
// 	PARAM_ZPOS_FOR_YAXIS,				// P6064: Y�� ������, Z�� ��ġ
// 	PARAM_ZPOS_FOR_ZAXIS,				// P6065: Z�� ������, Z�� ��ġ 
// 	PARAM_YPOS_FOR_XZAXIS,				// P6066: XZ�� ������, Y�� ��ġ 
// 	PARAM_TOOL_NO,						// P6067: �� ��ȣ 
// 	PARAM_TOOL_DIAMETER,				// P6068: �� ���� 
// 	PARAM_ROUNDBAR_DIAMETER,			// P6069: ȯ�� ���� 
// 	PARAM_MEASURE_COUNT,				// P6070: ���� ȸ�� 
// 	PARAM_ZAXIS_1ST_MAX_DISTANCE,		// P6071: ù��° ������, �ִ� ���� �Ÿ� 
// 	PARAM_ZAXIS_2ST_MEASURE_OFFSET,		// P6072: �ι�° ������, ���� �ɼ� �Ÿ� 
// 	PARAM_MOVESPEED_FOR_MEAS_POS,		// P597
// 	PARAM_MOVESPEED_MEAS_FORWORD,		// P602
// 	PARAM_MOVESPEED_MEAS_BACKWORD,		// P603 
// 	PARAM_NUM
// }

CString SAutoTeachMultiOrgParam::STR_PARAM_NAME[PARAM_NUM] = 
{
	CString( _T("H_MeasureOffset_X_Axis [Offset]") ),		// Offset (ȯ�� ������ ������ �Ÿ�) 
	CString( _T("H_MeasureBase_Y_Axis [G54]") ),			// Y�� ���� ���� ��ġ
	CString( _T("H_MeasureOffset_Y_Axis [Offset]") ),		// Offset (���� ���� ������ �Ÿ�)
	CString( _T("H_ZPos_For_XAxis [G54]") ),				// G54
	CString( _T("H_ZPos_For_YAxis [G54]") ),				// G54
	CString( _T("H_ZPos_For_ZAxis [G54]") ),				// G54
	CString( _T("H_YPos_For_XZAxis_G57 [Offset]") ),		// Y�� ���� ������ġ���� ������ �Ÿ� 
	CString( _T("H_YPos_For_XZAxis_G56 [Offset]") ),		// Y�� ���� ������ġ���� ������ �Ÿ� 
	CString( _T("H_YPos_For_XZAxis_G55 [Offset]") ),		// Y�� ���� ������ġ���� ������ �Ÿ�. Single abutment ��� �߰� 

	CString( _T("V_MeasureOffset_Y_Axis [Offset]") ),		// Offset (ȯ�� ������ ������ �Ÿ�) 
	CString( _T("V_MeasureBase_X_Axis [G54]") ),			// X�� ���� ���� ��ġ
	CString( _T("V_MeasureOffset_X_Axis [Offset]") ),		// Offset (���� ���� ������ �Ÿ�)
	CString( _T("V_ZPos_For_XAxis [G54]") ),				// G54
	CString( _T("V_ZPos_For_YAxis [G54]") ),				// G54
	CString( _T("V_ZPos_For_ZAxis [G54]") ),				// G54
	CString( _T("V_ZPos_For_XAxis_Reserve [G54]") ),		// G54
	CString( _T("V_ZPos_For_YAxis_Reserve [G54]") ),		// G54
	CString( _T("V_ZPos_For_ZAxis_Reserve [G54]") ),		// G54
	CString( _T("V_XPos_For_YZAxis_G59 [Offset]") ),		// Y�� ���� ������ġ���� ������ �Ÿ� 
	CString( _T("V_XPos_For_YZAxis_G58 [Offset]") ),		// Y�� ���� ������ġ���� ������ �Ÿ� 

	CString( _T("Tool_No") ),
	CString( _T("Tool_Diameter") ),
	CString( _T("RoundBar_Diameter") ),
	CString( _T("Measure_Count") ),
	CString( _T("1st_MaxDistance") ),
	CString( _T("2nd_MeasureOffset") ),
	CString( _T("MoveSpeed_For_MeasurePosition") ),
	CString( _T("MoveSpeed_For_MeasureForword") ),
	CString( _T("MoveSpeed_For_MeasureBackword") )
};

BOOL SAutoTeachMultiOrgParam::Load( TCHAR* pFilePath, CString& strErrMsg )
{
	CCEIniFile	hIniFile;
	CString		strKeyName;
	CString		strFilePath;

	strFilePath.Format( _T("%s"), pFilePath );

	if( !hcutil::IsExistFile( strFilePath ) ) {
		strErrMsg.Format( _T("file not found !") );
		return FALSE;
	}

	hIniFile.Open( pFilePath );

	strKeyName.Format( _T("AT_MultiOrg") );

	for( int i = 0; i<(int)PARAM_NUM; i++ ) 
	{
		hIniFile.GetValue( strKeyName, STR_PARAM_NAME[i], (double*)&fParam[i] );
		double fval = fParam[i];
		fval = fval;
	}

	hIniFile.Close();

	return TRUE;
} 

BOOL SAutoTeachMultiOrgParam::Save( TCHAR* pFilePath, CString& strErrMsg )
{
	CCEIniFile	hIniFile;
	CString		strKeyName;

	hIniFile.Open( pFilePath );

	strKeyName.Format( _T("AT_MultiOrg") );

	for( int i = 0; i<(int)PARAM_NUM; i++ ) 
	{
		hIniFile.SetValue( strKeyName, STR_PARAM_NAME[i], (double)fParam[i] );
	}

	hIniFile.Close();

	return TRUE;
}

//////////////////////////////////////////////////////////////////////////

/*
CString SAutoTeachMultiOrgParam::STR_PARAM_H_TYPE_NAME[PARAM_H_TYPE_NUM] = 
{
	CString( _T("MeasureOffset_X_Axis [Offset]") ),		// Offset (ȯ�� ������ ������ �Ÿ�) 
	CString( _T("MeasureBase_Y_Axis [G54]") ),			// Y�� ���� ���� ��ġ
	CString( _T("MeasureOffset_Y_Axis [Offset]") ),		// Offset (���� ���� ������ �Ÿ�)
	CString( _T("ZPos_For_XAxis [G54]") ),				// G54
	CString( _T("ZPos_For_YAxis [G54]") ),				// G54
	CString( _T("ZPos_For_ZAxis [G54]") ),				// G54
	CString( _T("YPos_For_XZAxis_G57 [Offset]") ),		// Y�� ���� ������ġ���� ������ �Ÿ� 
	CString( _T("YPos_For_XZAxis_G56 [Offset]") ),		// Y�� ���� ������ġ���� ������ �Ÿ� 
	CString( _T("YPos_For_XZAxis_G55 [Offset]") ),		// Y�� ���� ������ġ���� ������ �Ÿ�. Single abutment ��� �߰� 

	CString( _T("Tool_No") ),
	CString( _T("Tool_Diameter") ),
	CString( _T("RoundBar_Diameter") ),
	CString( _T("Measure_Count") ),
	CString( _T("1st_MaxDistance") ),
	CString( _T("2nd_MeasureOffset") ),
	CString( _T("MoveSpeed_For_MeasurePosition") ),
	CString( _T("MoveSpeed_For_MeasureForword") ),
	CString( _T("MoveSpeed_For_MeasureBackword") )
};

CString SAutoTeachMultiOrgParam::STR_PARAM_V_TYPE_NAME[PARAM_V_TYPE_NUM] = 
{
	CString( _T("MeasureOffset_Y_Axis [Offset]") ),		// Offset (ȯ�� ������ ������ �Ÿ�) 
	CString( _T("MeasureBase_X_Axis [G54]") ),			// X�� ���� ���� ��ġ
	CString( _T("MeasureOffset_X_Axis [Offset]") ),		// Offset (���� ���� ������ �Ÿ�)
	CString( _T("ZPos_For_XAxis [G54]") ),				// G54
	CString( _T("ZPos_For_YAxis [G54]") ),				// G54
	CString( _T("ZPos_For_ZAxis [G54]") ),				// G54
	CString( _T("XPos_For_YZAxis_G59 [Offset]") ),		// Y�� ���� ������ġ���� ������ �Ÿ� 
	CString( _T("XPos_For_YZAxis_G58 [Offset]") ),		// Y�� ���� ������ġ���� ������ �Ÿ� 

	CString( _T("Tool_No") ),
	CString( _T("Tool_Diameter") ),
	CString( _T("RoundBar_Diameter") ),
	CString( _T("Measure_Count") ),
	CString( _T("1st_MaxDistance") ),
	CString( _T("2nd_MeasureOffset") ),
	CString( _T("MoveSpeed_For_MeasurePosition") ),
	CString( _T("MoveSpeed_For_MeasureForword") ),
	CString( _T("MoveSpeed_For_MeasureBackword") )
};

BOOL SAutoTeachMultiOrgParam::Load( TCHAR* pFilePath, CString& strErrMsg )
{
	CCEIniFile	hIniFile;
	CString		strKeyName;
	CString		strFilePath;

	strFilePath.Format( _T("%s"), pFilePath );

	if( !hcutil::IsExistFile( strFilePath ) ) {
		strErrMsg.Format( _T("file not found !") );
		return FALSE;
	}

	hIniFile.Open( pFilePath );

	strKeyName.Format( _T("MultiOrg_H_Type") );
	for( int i = 0; i<(int)PARAM_H_TYPE_NUM; i++ )
	{
		hIniFile.GetValue( strKeyName, STR_PARAM_H_TYPE_NAME[i], (double*)&fParamHType[i] );
		double fval = fParamHType[i];
		fval = fval;
	}

	strKeyName.Format( _T("MultiOrg_V_Type") );
	for( int i = 0; i<(int)PARAM_V_TYPE_NUM; i++ )
	{
		hIniFile.GetValue( strKeyName, STR_PARAM_V_TYPE_NAME[i], (double*)&fParamVType[i] );
		double fval = fParamVType[i];
		fval = fval;
	}

	hIniFile.Close();

	return TRUE;
}

BOOL SAutoTeachMultiOrgParam::Save( TCHAR* pFilePath, CString& strErrMsg )
{
	CCEIniFile	hIniFile;
	CString		strKeyName;

	hIniFile.Open( pFilePath );

	strKeyName.Format( _T("MultiOrg_H_Type") );
	for( int i = 0; i<(int)PARAM_H_TYPE_NUM; i++ ) 
	{
		hIniFile.SetValue( strKeyName, STR_PARAM_H_TYPE_NAME[i], (double)fParamHType[i] );
	}

	strKeyName.Format( _T("MultiOrg_V_Type") );
	for( int i = 0; i<(int)PARAM_V_TYPE_NUM; i++ ) 
	{
		hIniFile.SetValue( strKeyName, STR_PARAM_V_TYPE_NAME[i], (double)fParamVType[i] );
	}

	hIniFile.Close();

	return TRUE;
}
*/
//////////////////////////////////////////////////////////////////////////

//
void DELETE_OLD_FILE( int nKeepingDays, TCHAR* extension, TCHAR* path )
{
	HANDLE			hr;
	WIN32_FIND_DATA	hWFD;
	TCHAR			szPath[512];

	memset((void*)szPath, 0, sizeof(TCHAR)*512);
	//	_stprintf( szPath, _T("%s\\*.log"), LOG_PATH );
	_stprintf( szPath, _T("%s\\*.%s"), path, extension );

	hr = FindFirstFile( szPath, &hWFD );

	while( hr != INVALID_HANDLE_VALUE ) 
	{
		{
			CTime tmBase;
			CTime tmFile;

			tmBase = CTime::GetCurrentTime() - CTimeSpan( nKeepingDays, 0, 0, 0 );
			tmFile = CTime( hWFD.ftLastWriteTime );

			if( tmBase > tmFile ) 
			{
				TCHAR szTemp[512];
				memset((void*)szTemp, 0, sizeof(TCHAR)*512);
				_stprintf( szTemp, _T("%s\\%s"), LOG_PATH, hWFD.cFileName );

				::DeleteFile( szTemp );
			}
		}

		if( FindNextFile( hr, &hWFD ) == FALSE )
		{
			break;
		}
	}

	FindClose( hr );
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

void SPowerOnTestConfig::Load( TCHAR* pFileName )
{
	CCEIniFile	hIniFile;
	CString		strKeyName;

	if( pFileName != NULL && hcutil::IsExistFile( pFileName ) == TRUE ) {
		IsLoaded = 1;
	} else {
		IsLoaded = 0;
		return;
	}

	hIniFile.Open( pFileName );

	strKeyName.Format( _T("Tool") );
	
	hIniFile.GetValue( strKeyName, _T("tp_x_min"), (double*)&toolpocket_x_min );
	hIniFile.GetValue( strKeyName, _T("tp_x_max"), (double*)&toolpocket_x_max );
	hIniFile.GetValue( strKeyName, _T("tp_y_min"), (double*)&toolpocket_y_min );
	hIniFile.GetValue( strKeyName, _T("tp_y_max"), (double*)&toolpocket_y_max );

	hIniFile.Close();
}

//////////////////////////////////////////////////////////////////////////

SModelInfo2 MODEL_INFO;

SModelInfo2::SModelInfo2()
{
	memset((void*)this, 0, sizeof(SModelInfo2));
}

SModelInfo2::~SModelInfo2()
{

}

// �������� ���Ͽ��� �о� �ʱ�ȭ �Ѵ� 
void SModelInfo2::Load()
{
	CString		strFilePath(INI_MODEL_INFO_PATH);
	CCEIniFile	hIniFile;
	CString		strKeyName;
	int			num = 0;
	int			model_no = 0;
	int			ntemp;

	hIniFile.Open( strFilePath );

	hIniFile.GetValue( _T("Common"), _T("Num"), (int*)&num );
	hIniFile.GetValue( _T("Common"), _T("ModelNo"), (int*)&model_no );

	//////////////////////////////////////////////////////////////////////////

	strKeyName.Format( _T("Model%d"), model_no );

	hModelID = (EN_MODEL)model_no;

	hIniFile.GetValue( strKeyName, _T("NumAxis"), (int*)&nNumAxis );
	hIniFile.GetValue( strKeyName, _T("MachineName"), (LPTSTR)szMachineName, 64 );
	hIniFile.GetValue( strKeyName, _T("ModelName"), (LPTSTR)szModelName, 64 );
	hIniFile.GetValue( strKeyName, _T("DisplayModelName"), (LPTSTR)szDisplayModelName, 64 );

	hIniFile.GetValue( strKeyName, _T("bk_image_name"), (LPTSTR)szBkgndImageFileName, 64 );
	hIniFile.GetValue( strKeyName, _T("mn_font_sx"), (int*)&nModelNameFontSX );
	hIniFile.GetValue( strKeyName, _T("mn_font_sy"), (int*)&nModelNameFontSY );
	hIniFile.GetValue( strKeyName, _T("mn_offset_x"), (int*)&nModelNameOffsetX );
	hIniFile.GetValue( strKeyName, _T("mn_offset_y"), (int*)&nModelNameOffsetY );
	hIniFile.GetValue( strKeyName, _T("using_atc_door"), (int*)&nUsingATCDoor );
	hIniFile.GetValue( strKeyName, _T("autoloader_type"), (int*)&ntemp ); hAutoLoaderType = (EN_AL_TYPE)ntemp;
	hIniFile.GetValue( strKeyName, _T("using_multi_origin"), (int*)&nUsingMultiOrigin );
	hIniFile.GetValue( strKeyName, _T("input_filename"), (LPTSTR)szInputFileName, 128 );
	hIniFile.GetValue( strKeyName, _T("output_filename"), (LPTSTR)szOutputFileName, 128 );
	hIniFile.GetValue( strKeyName, _T("m28_type"), (int*)&ntemp ); hM28Type = (EN_M28_TYPE)ntemp;
	hIniFile.GetValue( strKeyName, _T("pa_ctrl_type"), (int*)&ntemp ); hPaCtrlType = (EN_PA_CTRL_TYPE)ntemp;
	hIniFile.GetValue( strKeyName, _T("air_pressure_sensor_type"), (int*)&ntemp ); hAirPressureSensorType = (EN_AIR_PRESSURE_SENEOR_TYPE)ntemp;
	//////////////////////////////////////////////////////////////////////////

	hIniFile.Close();
}

//////////////////////////////////////////////////////////////////////////

}

