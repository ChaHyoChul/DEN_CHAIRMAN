// SetupDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "SetupDlg.h"
#include "SetupMenuDlg.h"
#include "SetupTeachingDlg.h"
#include "SetupToolDlg.h"
#include "SetupAutoLoaderDlg.h"
#include "SetupOptionDlg.h"
#include "SetupIODlg.h"
#include "SetupTerminalDlg.h"
#include "SetupLogDlg.h"
#include "SetupSystemDlg.h"
#include "SetupMultiOriginDlg.h"

//////////////////////////////////////////////////////////////////////////
// CSetupDlg ��ȭ �����Դϴ�.
//////////////////////////////////////////////////////////////////////////

CSetupDlg*	PSETUP_DLG;

//////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNAMIC(CSetupDlg, CDialog)

CSetupDlg::CSetupDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetupDlg::IDD, pParent)
{

}

CSetupDlg::~CSetupDlg()
{
}

void CSetupDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CSetupDlg, CDialog)
	ON_WM_DESTROY()
	ON_WM_CTLCOLOR()
	ON_MESSAGE(WM_SETUP, &CSetupDlg::OnSetup)
	ON_MESSAGE(WM_NOTIFY_WINDOW_MOVE,&CSetupDlg::OnWindowMove )
	ON_WM_SHOWWINDOW()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CSetupDlg �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CSetupDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CSetupDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CRect	rcWnd;

	//MoveWindow(0,0, 1025,621);
	MoveWindow(100,100, 1025,621);
	
	GetWindowRect( &rcWnd );
	GetClientRect( &rcWnd );

	hDlgMap_.Initialize( this );
	hDlgMap_.AddDialog( _T("Menu"), RUNTIME_CLASS(CSetupMenuDlg), IDD_DIALOG_SETUP_MENU, rcWnd );
	hDlgMap_.AddDialog( _T("Teaching"), RUNTIME_CLASS(CSetupTeachingDlg), IDD_DIALOG_SETUP_TEACHING, rcWnd );
	hDlgMap_.AddDialog( _T("Tool"), RUNTIME_CLASS(CSetupToolDlg), IDD_DIALOG_SETUP_TOOL, rcWnd );
	hDlgMap_.AddDialog( _T("AutoLoader"), RUNTIME_CLASS(CSetupAutoLoaderDlg), IDD_DIALOG_SETUP_AUTOLOADER, rcWnd );
	hDlgMap_.AddDialog( _T("Option"), RUNTIME_CLASS(CSetupOptionDlg), IDD_DIALOG_SETUP_OPTION, rcWnd );
	hDlgMap_.AddDialog( _T("IO"), RUNTIME_CLASS(CSetupIODlg), IDD_DIALOG_SETUP_IO, rcWnd );
	hDlgMap_.AddDialog( _T("Term"), RUNTIME_CLASS(CSetupTerminalDlg), IDD_DIALOG_SETUP_TERMINAL, rcWnd );
	hDlgMap_.AddDialog( _T("Log"), RUNTIME_CLASS(CSetupLogDlg), IDD_DIALOG_SETUP_LOG, rcWnd );
	hDlgMap_.AddDialog( _T("System"), RUNTIME_CLASS(CSetupSystemDlg), IDD_DIALOG_SETUP_SYSTEM, rcWnd );
	hDlgMap_.AddDialog( _T("MultiOrg"), RUNTIME_CLASS(CSetupMultiOriginDlg), IDD_DIALOG_SETUP_MULTIORG, rcWnd );
	
	((CSetupMenuDlg*)hDlgMap_.GetDialog(_T("Menu")))->SetParentWnd( this );
	((CSetupTeachingDlg*)hDlgMap_.GetDialog(_T("Teaching")))->SetParentWnd( this );
	((CSetupToolDlg*)hDlgMap_.GetDialog(_T("Tool")))->SetParentWnd( this );
	((CSetupAutoLoaderDlg*)hDlgMap_.GetDialog(_T("AutoLoader")))->SetParentWnd( this );
	((CSetupOptionDlg*)hDlgMap_.GetDialog(_T("Option")))->SetParentWnd( this );
	((CSetupIODlg*)hDlgMap_.GetDialog(_T("IO")))->SetParentWnd( this );
	((CSetupTerminalDlg*)hDlgMap_.GetDialog(_T("Term")))->SetParentWnd( this );
	((CSetupLogDlg*)hDlgMap_.GetDialog(_T("Log")))->SetParentWnd( this );
	((CSetupSystemDlg*)hDlgMap_.GetDialog(_T("System")))->SetParentWnd( this );
	((CSetupMultiOriginDlg*)hDlgMap_.GetDialog(_T("MultiOrg")))->SetParentWnd( this );

	hDlgMap_.HideAll();

	hDlgMap_.Show( _T("Menu") );

	brhBackground_.CreateSolidBrush( RGB(100, 100, 100) );

	CenterWindow();
	CRect rcTemp;
	GetWindowRect( &rcTemp );
	MoveWindow(rcTemp.left, rcTemp.top + 73, 1024,621);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CSetupDlg::OnDestroy()
{
	brhBackground_.DeleteObject();

	hDlgMap_.Destroy();

	CDialog::OnDestroy();
}

HBRUSH CSetupDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  ���⼭ DC�� Ư���� �����մϴ�.

	// TODO:  �⺻���� �������� ������ �ٸ� �귯�ø� ��ȯ�մϴ�.
	// CTLCONTROL_EDIT�� CTLSCTRLLBAR�� ���� 1�� ���ǵǾ� �ִ�
	switch( nCtlColor )
	{
	case CTLCOLOR_BTN:			//   Button control 
	case CTLCOLOR_EDIT:			//   Edit control (CTLCOLOR_SCROLLBAR)
	case CTLCOLOR_LISTBOX:		//   List-box control 
	case CTLCOLOR_MSGBOX:		//   Message box 
	case CTLCOLOR_STATIC:		//   Static control 
		break;

	case 4://CTLCOLOR_DLG:		//   Dialog box (���ǵ��� �ʾ�, ���ڸ� �״�� ���)
		hbr = brhBackground_;
		break;
	}

	return hbr;
}

LRESULT CSetupDlg::OnSetup(WPARAM wparam, LPARAM lparam)
{
	switch( (int)wparam )
	{
	case SETUP_EXIT:
		ShowWindow( SW_HIDE );
		break;
	case SETUP_BACK:
		hDlgMap_.HideAll();
		hDlgMap_.Show( _T("Menu") );
		break;
	case SETUP_TEACHING:
		hDlgMap_.HideAll();
		hDlgMap_.Show( _T("Teaching") );
		break;
	case SETUP_TOOL:
		hDlgMap_.HideAll();
		hDlgMap_.Show( _T("Tool") );
		break;
	case SETUP_AUTOLOADER:
		hDlgMap_.HideAll();
		hDlgMap_.Show( _T("AutoLoader") );
		break;
	case SETUP_OPTION:
		hDlgMap_.HideAll();
		hDlgMap_.Show( _T("Option") );
		break;
	case SETUP_IO:
		hDlgMap_.HideAll();
		hDlgMap_.Show( _T("IO") );
		break;
	case SETUP_TERM:
		hDlgMap_.HideAll();
		hDlgMap_.Show( _T("Term") );
		break;
	case SETUP_LOG:
		hDlgMap_.HideAll();
		hDlgMap_.Show( _T("Log") );
		break;
	case SETUP_SYSTEM:
		hDlgMap_.HideAll();
		hDlgMap_.Show( _T("System") );
		break;
	case SETUP_MULTIORG:
		hDlgMap_.HideAll();
		hDlgMap_.Show( _T("MultiOrg") );
		break;
	}

	return 0;
}

// 2020.03.25 Setup Windows �������� ���� �÷��׸� �����ϰ�,
// 
void CSetupDlg::OnShowWindow(BOOL bShow, UINT nStatus)
{
	pa::PPAStatus->GetThreadState()->bShowSetupDialog_ = bShow;

	CDialog::OnShowWindow(bShow, nStatus);
}

void CSetupDlg::ShowMain()
{
	hDlgMap_.HideAll();
	hDlgMap_.Show( _T("Menu") );
	((CSetupToolDlg*)hDlgMap_.GetDialog(_T("Tool")))->SetDirectAccess( FALSE );
}

void CSetupDlg::ShowToolSetup()
{
	hDlgMap_.HideAll();
	hDlgMap_.Show( _T("Tool") );
	((CSetupToolDlg*)hDlgMap_.GetDialog(_T("Tool")))->SetDirectAccess( TRUE );
}

//����â�� ��ġ������ �޾� ������Ʈ
LRESULT CSetupDlg::OnWindowMove(WPARAM wparam, LPARAM lparam)
{
	LPPOINT ChangedPos=(LPPOINT)lparam;
	MoveWindow(ChangedPos->x-1,ChangedPos->y+148, 1024,621);
	((CSetupMultiOriginDlg*)hDlgMap_.GetDialog(_T("MultiOrg")))->PostMessage(WM_NOTIFY_WINDOW_MOVE, (WPARAM)0, (LPARAM)lparam );

	return 0;
}
