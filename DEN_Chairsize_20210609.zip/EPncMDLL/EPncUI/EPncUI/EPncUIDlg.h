// EPncUIDlg.h : ��� ����
//

#pragma once
#include "AutoLoaderRefillDlg.h"
#include "NCFileListBoxEx.h"

//////////////////////////////////////////////////////////////////////////
#define WM_USB_MEMORY		(WM_USER+160)		// wparam : 0(not connect), 1(connect)
//////////////////////////////////////////////////////////////////////////

// CEPncUIDlg ��ȭ ����
class CEPncUIDlg : public CDialog
{
public:
	enum EN_OPER_BUTTON
	{
		OPER_BTN_EMG_RESET = 0,
		OPER_BTN_HOME,
		OPER_BTN_TOOL_CALMP_UNCLAMP,
		OPER_BTN_BLOCK_GRIP_UNGRIP,
		OPER_BTN_SETUP,
		OPER_BTN_OPEN,
		OPER_BTN_RUN,
		OPER_BTN_PAUSE_STOP,
		OPER_BTN_NCFILE_MGR,
		OPER_BTN_NCFILE_UP,
		OPER_BTN_NCFILE_DN,
		OPER_BTN_MANUAL,		// ReadyPos ��ư���� ��� (pause-stop ��ư ��ġ)
		OPER_BTN_NUM
	};

private:
	HANDLE	hEvent_;

	TCHAR*				pResourcePath_;
	hcutil::CCanvasCE*	pCanvasCE_;
	int					nBackgroundLayerIndex_;

//	CImgButtonEx*			pOperButtons_[OPER_BTN_NUM];
	CImgButtonEx2*			pOperButtonsEx_[OPER_BTN_NUM];
	CNCFileListBoxEx*		pNCFileListBoxEx_;
	CAutoLoaderStateWnd*	pAutoLoaderStateWnd_;
	CNCStatusBarWnd*		pNCStateBarWnd_;
	
	BOOL	bConnectedUsbMemory_;

private:
	void draw_model_info();

	void initialize_OperButtons();
	void destroy_OperButtons();

	BOOL preinitialize_pmac_object( CString& strErrMsg );

	BOOL initialize_pmac_object( CString& strErrMsg );
	void destroy_pmac_object();

	BOOL initialize_NCFileListBox( CString& strErrMsg );
	void destroy_NCFileListBox();

	BOOL initialize_AutoLoaderStateWnd( CString& strErrMsg );
	void destroy_AutoLoaderStateWnd();

	BOOL initialize_NCStateBarWnd( CString& strErrMgs );
	void destroy_NCStateBarWnd();

	BOOL initialize_ErrorDlg();
	void destroy_ErrorDlg();

	BOOL initialize_SetupDlg();
	void destroy_SetupDlg();

	void updateButtonState();						// ȭ���� ��ư ���¸� ���� �Ѵ�

	void updateNCFileListBox();						// ncfile ����Ʈ�� ���¸� �����Ѵ� 

	void updateOperationM28Disp();					// 
	void updateRemoteModeDisp();					// remote mode ǥ�� ��� 
	void updateDemoModeDisp();						// demo mode ǥ�� ��� 
	void updateUsbMemConnectDisp();					// usb memory ǥ�� ���
	void updateConnStatePmac();

	void doButtonEmoReset();
	void doButtonHome();
// 	void doButtonOperModeChange();
	void doButtonToolClampUnclamp();
	void doButtonBlockGripUngrip();
	void doButtonSetup();
	void doButtonOpen();
	void doButtonRun();
	void doButtonPauseStop();
	void doButtonNCFileMgr();
	void doButtonNCFileUp();
	void doButtonNCFuleDn();
	void doButtonMoveResdyPosition();

	void writeLog( LPCTSTR log_msg );

// �����Դϴ�.
public:
	CEPncUIDlg(CWnd* pParent = NULL);	// ǥ�� �������Դϴ�.

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_EPNCUI_DIALOG };


	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �����Դϴ�.

// �����Դϴ�.
protected:
	HICON m_hIcon;

	// ������ �޽��� �� �Լ�
	virtual BOOL OnInitDialog();
#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
	afx_msg void OnSize(UINT /*nType*/, int /*cx*/, int /*cy*/);
#endif
	DECLARE_MESSAGE_MAP()
	virtual void PreInitDialog();
public:
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg LRESULT OnImgButtonExClicked(WPARAM wparam, LPARAM lparam); // WM_IMGBUTTONEX_CLICKED
	afx_msg LRESULT OnAutoLoaderRefill(WPARAM wparam, LPARAM lparam);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg LRESULT OnUsbMemory(WPARAM wparam, LPARAM lparam);
};
