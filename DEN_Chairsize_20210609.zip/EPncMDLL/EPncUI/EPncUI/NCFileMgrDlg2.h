#pragma once

#include "FileListBox.h"

// CNCFileMgrDlg2 ��ȭ �����Դϴ�.

class CNCFileMgrDlg2 : public CDialog
{
	DECLARE_DYNAMIC(CNCFileMgrDlg2)

	CFont	fntMenuButton_;
	CBrush	brhBkgnd_;
	CBrush	brhCopyBtn_;
	CBrush	brhQuitBth_;

	CFileListBox* pFileListBoxForUSB_;

	void initialize_FileListBox();
	void destroy_FileListBox();

public:
	CNCFileMgrDlg2(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CNCFileMgrDlg2();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_NCFILE_MGR2 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedButtonReflash();
	afx_msg void OnBnClickedButtonAllSelect();
	afx_msg void OnBnClickedButtonUnselect();
	afx_msg void OnBnClickedButtonCopyToPc();
	afx_msg void OnBnClickedButtonQuit();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg LRESULT OnWindowMove(WPARAM wparam, LPARAM lparam);
};

extern CNCFileMgrDlg2*	P_NCFILE_MGR_DLG2;

