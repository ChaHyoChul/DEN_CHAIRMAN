#include "StdAfx.h"
#include "PSWConfig.h"

pa::CPSWConfig::CPSWConfig(void)
{
	pShMemConfigData_	= NULL;
	pConfigData_		= NULL;

// 	pShMemAutoLoaderConfigData_	= NULL;
// 	pAutoLoaderConfigData_		= NULL;
}

pa::CPSWConfig::~CPSWConfig(void)
{
	Destroy();
}

BOOL pa::CPSWConfig::Initialzie( CString& strErrMsg )
{
	pShMemConfigData_ = new hcipc::CSharedMem();
	if( pShMemConfigData_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::CPConfig::pShMemConfigData_ object" ) );
		return FALSE;
	} 
	pConfigData_ = (SConfigData*)pShMemConfigData_->Create( NULL, CONFIG_OBJECT_NAME, sizeof(SConfigData), FALSE, 0 );
	if( pConfigData_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pmac::CPConfig::pConfigData_ object") );
		return FALSE;
	}

// 	pShMemAutoLoaderConfigData_ = new hcipc::CSharedMem();
// 	if( pShMemAutoLoaderConfigData_ == NULL ) {
// 		strErrMsg.Format( _T("memory alloc error for pmac::CPConfig::pShMemAutoLoaderConfigData_ object" ) );
// 		return FALSE;
// 	}
// 	pAutoLoaderConfigData_ = (SAutoLoaderConfig *)pShMemAutoLoaderConfigData_->Create( NULL, ALCONFIG_ONJECT_NAME, sizeof(SAutoLoaderConfig), FALSE, 0 );
// 	if( pAutoLoaderConfigData_ == NULL ) {
// 		strErrMsg.Format( _T("create shared memory error for pmac::CPConfig::pAutoLoaderConfigData_ object") );
// 		return FALSE;
// 	}

	return TRUE;
}

void pa::CPSWConfig::Destroy()
{
	if( pShMemConfigData_ ) {
		pShMemConfigData_->Destroy();
		delete pShMemConfigData_;
		pShMemConfigData_ = NULL;
		pConfigData_ = NULL;
	}

// 	if( pShMemAutoLoaderConfigData_ ) {
// 		pShMemAutoLoaderConfigData_->Destroy();
// 		delete pShMemAutoLoaderConfigData_;
// 		pShMemAutoLoaderConfigData_ = NULL;
// 		pAutoLoaderConfigData_ = NULL;
// 	}
}

