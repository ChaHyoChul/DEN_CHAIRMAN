#pragma once
#include "afxwin.h"
#include "SensorStateWnd.h"
#include "TitleBarWnd.h"

// CSetupAutoLoaderManualOperDlg ��ȭ �����Դϴ�.

class CSetupAutoLoaderManualOperDlg : public CDialogListPage
{
	DECLARE_DYNCREATE(CSetupAutoLoaderManualOperDlg)

	int		nRecentRun_ManualButton_;
	int		nPREV_BARCODE_;

	CTitleBarWnd*	pTitleBar_ALRManual_;
	CTitleBarWnd*	pTitleBar_XYRManual_;	
	CTitleBarWnd*	pTitleBar_WSManual_;	

	CFont	fntOperButton_;
	CFont	fntCombo_;
	
	CBrush	brhBkgnd_;
	CBrush	brhRecentRun_;

	CRect	CUIrectSALM; 

	enum {
		SS_ALR_DOOR_OPEN, SS_ALR_DOOR_CLOSE, SS_ALR_GRIPPER_GRIP, SS_ALR_GRIPPER_UNGRIP,
// 		SS_ALR_HAND_FORWARD, SS_ALR_HAND_BACKWARD, 
		SS_ALR_HAND_BACKWARD, SS_ALR_HAND_FORWARD, 
		SS_ALR_ROTATE_CASSETTE, SS_ALR_ROTATE_XYSTAGE,
		SS_XYS_GRIPPER_GRIP, SS_XYS_GRIPPER_UNGRIP, SS_XYS_GRIPPER_UP, SS_XYS_GRIPPER_DOWN,
		SS_ALR_GRIP_EXIST_BLOCK,
		SS_NUM
	};

	enum MANUAL_STEP {
		MANUAL_STEP_01,
		MANUAL_STEP_02,
		MANUAL_STEP_03,
		MANUAL_STEP_04,
		MANUAL_STEP_05,
		MANUAL_STEP_06,
		MANUAL_STEP_07,
		MANUAL_STEP_08,
		MANUAL_STEP_09,
		MANUAL_STEP_10
	};

	// Current state, which is an error.
	enum MANUAL_STEP_ERR {
		// AutoLoader Hand
		AL_HAND_FACE_CASSETTE,
		AL_HAND_FACE_WORKSPACE,
		AL_HAND_FORWARD,
		AL_HAND_BACKWARD,
		AL_HAND_SENSING_ITEM,
		AL_HAND_NOT_SENSING_ITEM,

		// XY Gripper
		XY_GRIPPER_SENSING_ITEM,
		XY_GRIPPER_NOT_SENSING_ITEM,
		XY_GRIPPER_UP,
		XY_GRIPPER_DOWN,
		XY_GRIPPER_GRIP,
		XY_GRIPPER_UNGRIP,
		XY_GRIPPER_NOT_IN_EXCHANGE_POSITION,

		// Work Space
		WS_SENSING_ITEM,
		WS_NOT_SENSING_ITEM,
	};

	int nSS_ID[SS_NUM];
	CSensorStateWnd	*pSensorStateWnd_[SS_NUM];

	void updateManualButton();
	void update_ButtonState();
	void update_SensorState();
	void update_BarcodeState();

	void writeLog( LPCTSTR log_msg );

	BOOL checkIfValidState(MANUAL_STEP manualStep);
	CString getManualErrorMessage(MANUAL_STEP_ERR manualStepErr);


public:
	CSetupAutoLoaderManualOperDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupAutoLoaderManualOperDlg();

	virtual void StartPageWork();
	virtual void StopPageWork();
	virtual void UpdatePage();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_AUTOLOADER_MANUAL_OPER };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	CComboBox cboSelBlockNo_;
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);

	CButton btnALR_DoorOpen_;
	CButton btnALR_DoorClose_;
	CButton btnALR_GripperGrip_;
	CButton btnALR_Gripper_Ungrip_;
	CButton btnALR_HandForward_;
	CButton btnALR_HandBackward_;
	CButton btnALR_RotateCassette_;
	CButton btnALR_RotateXYStage_;
	CButton btnALR_GetBlockFromCassette_;
	CButton btnALR_LoadingBlockToXYStage_;
	CButton btnALR_PutBlockToCassette_;
	CButton btnALR_UnloadingBlockToCassette_;
	CButton btnXYS_GripperGrip_;
	CButton btnXYS_GripperUngrip_;
	CButton btnXYS_GripperUp_;
	CButton btnXYS_GripperDown_;
	CButton btnXYS_AutoLoaderPos_;
	CButton btnXYS_MachiningPos_;
	CButton btnWS_BlockCamp_;
	CButton btnWS_BlockUnclamp_;
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedButtonAlrDoorOpen();
	afx_msg void OnBnClickedButtonAlrDoorClose();
	afx_msg void OnBnClickedButtonAlrHandForward();
	afx_msg void OnBnClickedButtonAlrGripperGrip();
	afx_msg void OnBnClickedButtonAlrGripperUngrip();
	afx_msg void OnBnClickedButtonAlrHandBackward();
	afx_msg void OnBnClickedButtonAlrRotateCassette();
	afx_msg void OnBnClickedButtonAlrRotateXystate();
	afx_msg void OnBnClickedButtonAlrGetBlockFromCassette();
	afx_msg void OnBnClickedButtonAlrPutBlockToCassette();
	afx_msg void OnBnClickedButtonAlrLoadingBlockXytage();
	afx_msg void OnBnClickedButtonAlrUnloadingBlockToCassette();
	afx_msg void OnBnClickedButtonXysGripperGrip();
	afx_msg void OnBnClickedButtonXysGripperUngrip();
	afx_msg void OnBnClickedButtonXysGripperUp();
	afx_msg void OnBnClickedButtonXysGripperDown();
	afx_msg void OnBnClickedButtonXysAutoloaderPos();
	afx_msg void OnBnClickedButtonXysMachiningPos();
	afx_msg void OnBnClickedButtonAlrReturnArmToCassette();
	afx_msg void OnBnClickedButtonAlrExtendArmToStage();
	CButton btnALR_ReturnArmToCassette_;
	CButton btnALR_ExtendArmToXYStage_;
//	afx_msg void OnBnClickedButton1();
//	afx_msg void OnBnClickedButton5();
	afx_msg void OnBnClickedButtonStep01();
	afx_msg void OnBnClickedButtonStep02();
	afx_msg void OnBnClickedButtonStep03();
	afx_msg void OnBnClickedButtonStep04();
	afx_msg void OnBnClickedButtonStep05();
	afx_msg void OnBnClickedButtonStep06();
	afx_msg void OnBnClickedButtonStep07();
	afx_msg void OnBnClickedButtonStep08();
	afx_msg void OnBnClickedButtonStep09();
	afx_msg void OnBnClickedButtonStep10();
	afx_msg void OnBnClickedButtonXysMoveExchangingPos();
	afx_msg void OnBnClickedButtonXysMoveMachiningPos();
	afx_msg void OnBnClickedButtonMoveBlockSensingPos();
	afx_msg void OnBnClickedButtonMoveBarcodeReadPos();
	afx_msg void OnBnClickedButtonAlBarcode();
	afx_msg void OnBnClickedButtonBlockClamp();
	afx_msg void OnBnClickedButtonBlockUnclamp();
	CEdit editBarcode_;
};
