// ResetOriginDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "ResetOriginDlg.h"
#include "MsgDlg.h"
#include "MsgDlgThread.h"

// CResetOriginDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CResetOriginDlg, CDialog)

CResetOriginDlg::CResetOriginDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CResetOriginDlg::IDD, pParent)
{

}

CResetOriginDlg::~CResetOriginDlg()
{
}

void CResetOriginDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_SEL_AXIS, cboSelectAxis_);
	DDX_Control(pDX, IDC_BUTTON_ORIGIN, btnOrigin_);
	DDX_Control(pDX, IDC_BUTTON2, btnClose_);
}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CResetOriginDlg, CDialog)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON2, &CResetOriginDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON_ORIGIN, &CResetOriginDlg::OnBnClickedButtonOrigin)
	ON_WM_TIMER()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CResetOriginDlg �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CResetOriginDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CResetOriginDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// font �ʱ�ȭ 
	fntLabel_.CreateFont( 
		18, 0, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	fntCombo_.CreateFont( 
		20, 0, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );
	
	fntButton_.CreateFont( 
		20, 0, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	// ctrl �ʱ�ȭ 
	((CStatic*)GetDlgItem(IDC_STATIC_AREA))->SetFont( &fntLabel_, TRUE );
	cboSelectAxis_.SetFont( &fntCombo_, TRUE );
	btnOrigin_.SetFont( &fntButton_, TRUE );
	btnClose_.SetFont( &fntButton_, TRUE );

	cboSelectAxis_.SetCurSel(0);	
	cboSelectAxis_.EnableWindow( TRUE );
	btnClose_.EnableWindow( TRUE );
	btnOrigin_.SetWindowText( _T("Origin") );

	//////////////////////////////////////////////////////////////////////////
	// Center Window 
	CRect rcWnd;
	GetWindowRect( &rcWnd );
	int xpos = 1024/2 - rcWnd.Width()/2;
	int ypos = 768/2 - rcWnd.Height()/2;
	SetWindowPos( &wndTopMost, xpos, ypos, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW );
	//////////////////////////////////////////////////////////////////////////

	// ���� ������Ʈ Ÿ�̸� ���� 
	SetTimer( 1, 1000, NULL );

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CResetOriginDlg::OnDestroy()
{
	KillTimer( 1 );

	fntLabel_.DeleteObject();
	fntCombo_.DeleteObject();
	fntButton_.DeleteObject();

	CDialog::OnDestroy();
}

void CResetOriginDlg::OnBnClickedButton2()
{
	CDialog::OnOK();
}

/** 
 * ���� ���õ� ���� ���� ���͸� �����Ѵ� 
 */
void CResetOriginDlg::OnBnClickedButtonOrigin()
{
	if( pa::PPAStatus->GetThreadState()->bCompleteResetOrigin_ == FALSE ) 
	{
		// ����  
		PPNC_IPC_CLIENT->Stop();
	}
	else 
	{
		int sel = cboSelectAxis_.GetCurSel();

		//////////////////////////////////////////////////////////////////////////
		// softlimit ������ Ȯ���ؼ� -500 ~ 500 �����̸�, softlimit�� �ɸ������� ���� �Ѵ� 
		double	fSoftLimitP = pa::PPAStatus->GetThreadState()->fSoftLimit_[sel][0];
		double	fSoftLimitM = pa::PPAStatus->GetThreadState()->fSoftLimit_[sel][1];
		BOOL	is_set_softlimit = FALSE;
		CString strMsg;

		if( sel != 2 ) {
			// x, y, a, b���� ���... 
			if( fSoftLimitM > -500.0 ) {
				is_set_softlimit = TRUE;
				strMsg.Format( _T("softlimit(-) data is set.\r\nplease disable softlimit and try again.") );
			}
		}
		else {
			// z���� ���...
			if( fSoftLimitP < 500.0 ) {
				is_set_softlimit = TRUE;
				strMsg.Format( _T("softlimit(+) data is set.\r\nplease disable softlimit and try again.") );
			}
		}
		if( is_set_softlimit == TRUE ) {
			// SoftLimit�� �����Ǿ� �ִ� ������ �����ϰ�, �˸� �޽����� ���� 
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_WARM, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
			return ;
		}

		//////////////////////////////////////////////////////////////////////////
		// PPAStatus->GetThreadState()->bCompleteResetOrigin_ = FALSE;	
		// ���� 
		PPNC_IPC_CLIENT->ResetOrigin(sel);
		Sleep(500);
	}
}

void CResetOriginDlg::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 1 )
	{
		KillTimer( 1 );

		update_state();

		if( IsWindowVisible() == TRUE )
		{
			SetTimer( 1, 500, NULL );
		}
	}

	CDialog::OnTimer(nIDEvent);
}

// ���� ���¿� ����, ��Ʈ���� ���¸� ���� �Ѵ� 
void CResetOriginDlg::update_state()
{
	static int PREV_MODE = -1;
	int curr_mode = (pa::PPAStatus->GetThreadState()->bCompleteResetOrigin_ == FALSE) ? 0 : 1;

	if( PREV_MODE != curr_mode )
	{
		PREV_MODE = curr_mode;

		if( curr_mode == 0 )
		{
			// ���� �� 
			cboSelectAxis_.EnableWindow( FALSE );
			btnClose_.EnableWindow( FALSE );
			btnOrigin_.SetWindowText( _T("Stop") );
		}
		else 
		{
			// ���� 
			cboSelectAxis_.EnableWindow( TRUE );
			btnClose_.EnableWindow( TRUE );
			btnOrigin_.SetWindowText( _T("Origin") );
		}
	}
}

