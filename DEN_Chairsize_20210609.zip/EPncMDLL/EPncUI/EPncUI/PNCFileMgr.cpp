#include "StdAfx.h"
#include "PNCFileMgr.h"

//////////////////////////////////////////////////////////////////////////

pa::CPNCFileMgr::CPNCFileMgr(void)
{
	pShMem_				= NULL;
	pMutex_				= NULL;
	pnNumNCFile_		= NULL;
	pnCurNCFileIndex_	= NULL;
	pNCFileBasePoint_	= NULL;
	vtrpObservers_.clear();
	vtrpSDObservers_.clear();
}

pa::CPNCFileMgr::~CPNCFileMgr(void)
{
	Destroy();
}

void pa::CPNCFileMgr::set_flag_for_upload_registered_ncfile()
{
	if( pa::PPAStatus->GetThreadState()->bSendRegistered_NCFileList_ == FALSE ) {
		pa::PPAStatus->GetThreadState()->bSendRegistered_NCFileList_ = TRUE;
	}
}

// File Mapping Shared Memory�� �ʱ�ȭ �Ѵ� 
BOOL pa::CPNCFileMgr::Initialize( CString& strErrMsg )
{
	pShMem_ = new hcipc::CSharedMem();
	pMutex_	= new hcipc::CMutex();

	if( pShMem_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pa::CPNCFileMgr::pShMem_") );
		return FALSE;
	}
	if( pMutex_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pa::CPNCFileMgr::pMutext_") );
		return FALSE;
	}

	//////////////////////////////////////////////////////////////////////////
	// create shared memory 
	//////////////////////////////////////////////////////////////////////////
	int size = ( sizeof(pa::SNCFileInfo) * MAX_NCFILE_NUM ) + ( sizeof(int) * 3 );

	int *pTemp = (int*)pShMem_->Create( IPC_FILEPATH, NCFILE_MANAGER_OBJECT_NAME, size, FALSE, 0 );
	if( pTemp ) {
		pnNumNCFile_		= (int*)(pTemp + 0);
		pnCurNCFileIndex_	= (int*)(pTemp + 1);
 		pnReverse_			= (int*)(pTemp + 2);
		pNCFileBasePoint_	= (pa::SNCFileInfo*)(pTemp + 3);
	} else {
		// ERROR
		strErrMsg.Format( _T("create shared memory for pa::CPNCFileMgr::pShMem_") );
		return FALSE;
	}

	//////////////////////////////////////////////////////////////////////////
	// create mutex
	//////////////////////////////////////////////////////////////////////////
	if( !pMutex_->Create( NCFILE_MANAGER_OBJECT_NAME ) ) {
		// ERROR
		strErrMsg.Format( _T("create mutex for pa::CPNCFileMgr::pMutex_") );
		return FALSE;
	}

	// �ʱ�ȭ �� NC�� ���߾� ������ currNCFileIdnex_�� -1�� �ʱ�ȭ �Ѵ� 
	// -> ���α׷� ����� -1�� �ʱ�ȭ �Ѵ� 
	// ���� �����ϰ� ���� �ʱ� ������...
	// ������ �۾��� ���� ������ RunInfo�� ����Ѵ� 
	// RunInfo���� ���������� ������ �۾� ����(���� index, line ��ȣ)�� ����ȴ� 
	// SetCurrentWorkIndex( -1 );

	// ��ϵ� �����Ͱ� ���� ���, Current Work Index�� -1�� �����Ѵ� 
	if( *pnNumNCFile_ == 0 ) {
		SetCurrentWorkIndex( -1, FALSE );
	}

	return TRUE;
}

void pa::CPNCFileMgr::Destroy()
{
	vtrpObservers_.clear();
	vtrpSDObservers_.clear();

	if( pShMem_ ) {
		pShMem_->Destroy();
		delete pShMem_;
		pShMem_ = NULL;
	}
	if( pMutex_ ) {
		pMutex_->Destroy();
		delete pMutex_;
		pMutex_ = NULL;
	}
}

void pa::CPNCFileMgr::RegisterObserver( INCFileMgrObserver* pObserver )
{
	std::vector<INCFileMgrObserver*>::iterator itr = vtrpObservers_.begin();
	
	for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
		if( (*itr) == pObserver ) {
			return;
		}
	}

	vtrpObservers_.push_back( pObserver );
}

void pa::CPNCFileMgr::RegisterSDObserver( INCFileMgrForSDObserver *pSDObserver )
{
	std::vector<INCFileMgrForSDObserver*>::iterator itr;

	for( itr = vtrpSDObservers_.begin(); itr != vtrpSDObservers_.end(); itr++ ) {
		if( (*itr) == pSDObserver ) {
			return ;
		}
	}

	vtrpSDObservers_.push_back( pSDObserver );
}


// ��ϵ� NC ������ ������ ���� �Ѵ� 
int pa::CPNCFileMgr::GetNumNCFile()
{
	int n = 0;

	pMutex_->Lock( INFINITE );
	if( pnNumNCFile_ != NULL ) {
		n = *pnNumNCFile_;
	}
	pMutex_->Unlock();

	return n;
}

// ��ϵ� NC ���� �� ���õ� ������ �����Ѵ� 
int pa::CPNCFileMgr::GetNumSelectedNcFile()
{
	int n = 0;

	if( pnNumNCFile_ != NULL )
	{
		pMutex_->Lock( INFINITE );

		for( int i = 0; i < *pnNumNCFile_; i++ ) 
		{
			SNCFileInfo* p = pNCFileBasePoint_ + i;
			if( p->is_select != 0 )
			{
				n++;
			}
		}

		pMutex_->Unlock();
	}

	return n;
}

// ���� �۾����� NC ������ Index�� ���� �Ѵ� 
int pa::CPNCFileMgr::GetCurrentWorkNCFileIndex()
{
	int n = -1;

	pMutex_->Lock( INFINITE );
	if( pnCurNCFileIndex_ != NULL ) {
		n = *pnCurNCFileIndex_;
	}
	pMutex_->Unlock();

	return n;
}

// ���� �۾����� NC ������ Index�� �����Ѵ� 
void pa::CPNCFileMgr::SetCurrentWorkIndex( int nIndex, BOOL bNotify )
{
	ASSERT( pMutex_ );

	if( nIndex < -1 || nIndex >= *pnNumNCFile_ ) {
		return ;
	}

	pMutex_->Lock( INFINITE );

	if( pnCurNCFileIndex_ != NULL ) {
		*pnCurNCFileIndex_ = nIndex;
	}

	pShMem_->Flush( (void*)(pnCurNCFileIndex_), sizeof(int) );

	//////////////////////////////////////////////////////////////////////////
	// notify observer 
	std::vector<INCFileMgrObserver*>::iterator itr;
	for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
		(*itr)->NCFMObsvr_SetCurrentWorkIndex( nIndex );
	}
	//////////////////////////////////////////////////////////////////////////

	pMutex_->Unlock();
}

// ���� �۾� NC ������ Index�� �����Ѵ�. ���� -1�̰ų� ���� �۾��� ���� ��� -1 ���� 
int pa::CPNCFileMgr::GetNextWorkNCFileIndex()
{
	int nRet = -1;
	int nStart;

	pMutex_->Lock( INFINITE );

	if( *pnCurNCFileIndex_ == -1 ) {
		nStart = 0;
	} else {
		nStart = *pnCurNCFileIndex_;
	}

	for( int i = nStart; i < *pnNumNCFile_; i++ ) {
		SNCFileInfo* p = pNCFileBasePoint_ + i;
		if( p->is_select != 0 && p->finish == 0 ) {
			nRet = i;
			break;
		}
	}

	pMutex_->Unlock();

	return nRet;
}

// �۾��� �Ϸ���� ����, ù��° ���õ� NC ������ Index�� �����Ѵ� 
// 
int pa::CPNCFileMgr::FindFirstCheckingNCFileIndex(bool ignoreFinishedFiles)
{
	int ret = -1;

	pMutex_->Lock( INFINITE );

	for( int i = 0; i<*pnNumNCFile_; i++ )
	{
		SNCFileInfo* p = pNCFileBasePoint_ + i;
		if( p->is_select != 0 && (!ignoreFinishedFiles || p->finish == 0) ) {
			ret = i;
			break;
		}
	}

	pMutex_->Unlock();

	return ret;
}

DWORD pa::CPNCFileMgr::EstimateLoadingTime(int index) 
{
	if( GetNCFileInfo(index)->file_size < 40000000 ) {
		return 60000; // 60 seconds
	} 
	else {
		return 100000; // 100 seconds
	}
}


// ���� NC File�� ���� �ڵ带 �����Ѵ� 
// void pa::CPNCFileMgr::SetNCFileLineNo( int nLineNo, BOOL bSave )
// {
// 	*pnNCFileLineNo_ = nLineNo;
// 
// 	if( bSave ) {
// 		pShMem_->Flush( (void*)pnNCFileLineNo_, sizeof(int) );
// 	}
// }

// ���� �۾����� NC ���� ������ ���� �Ѵ� 
// pa::SNCFileInfo* pa::CPNCFileMgr::GetCurrentNCFileInfo()
// {
// 	pa::SNCFileInfo* p = NULL;
// 
// 	if( *pnCurNCFileIndex_ < 0 || *pnCurNCFileIndex_ >= *pnNumNCFile_ ) {
// 		return NULL;
// 	}
// 
// 	pMutex_->Lock( INFINITE );
// 
// 	if( pNCFileBasePoint_ != NULL ) {
// 		p = ( pNCFileBasePoint_ + ( *pnCurNCFileIndex_ - 1 ) );
// 	}
// 
// 	pMutex_->Unlock();
// 
// 	return p;
// }

// Index ��° NC ���� ������ ���� �Ѵ� 
pa::SNCFileInfo* pa::CPNCFileMgr::GetNCFileInfo( int nIndex )
{
	pa::SNCFileInfo* p = NULL;

	if( nIndex < 0 || nIndex >= *pnNumNCFile_ ) {
		return NULL;
	}

	pMutex_->Lock( INFINITE );

	if( pNCFileBasePoint_ != NULL ) {
		p = ( pNCFileBasePoint_ + nIndex );
	}

	pMutex_->Unlock();

	return p;
}

pa::SNCFileInfo* pa::CPNCFileMgr::GetNCFileInfo( TCHAR* pID )
{
	pa::SNCFileInfo* p = NULL;

	if( pID == NULL ) {
		return NULL;
	}

	pMutex_->Lock( INFINITE );

	for( int i = 0; i<*pnNumNCFile_; i++ ) {
		p = GetNCFileInfo( i );
		if( p ) {
			if( _tcscmp( p->id, pID ) == 0 ) {
				break;
			}
		} else {
			break;
		}
	}

	pMutex_->Unlock();

	return p;
}

//////////////////////////////////////////////////////////////////////////
// ���� �۾����� NC ���� ������ �����Ѵ� 
//////////////////////////////////////////////////////////////////////////

// NCFile ������ �Ѳ����� Update �Ѵ� 	
void pa::CPNCFileMgr::UpdateNCFileInfo( int nIndex, SNCFileInfo* pNCFileInfo )
{
	ASSERT( pMutex_ );

	if( nIndex < 0 || nIndex >= *pnNumNCFile_ ) {
		return ;
	}

	pMutex_->Lock( INFINITE );

	pa::SNCFileInfo* p = GetNCFileInfo( nIndex );

	if( p ) 
	{
		memcpy( (void*)p, (const void*)pNCFileInfo, sizeof(SNCFileInfo) );
		pShMem_->Flush( (void*)p, sizeof(SNCFileInfo) );

		//////////////////////////////////////////////////////////////////////////
		// notify observer 
		std::vector<INCFileMgrObserver*>::iterator itr;
		for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
			(*itr)->NCFMObsvr_UpdateNCFileInfo( nIndex );
		}
	}

	pMutex_->Unlock();
}

int  pa::CPNCFileMgr::GetNCFileSelect( int nIndex )
{
	int ret = 0;

	ASSERT( pMutex_ );

	pMutex_->Lock( INFINITE );

	pa::SNCFileInfo *p = GetNCFileInfo( nIndex );

	if( p )
	{
		ret = (int)p->is_select;
	}

	pMutex_->Unlock();

	return ret;
}

void pa::CPNCFileMgr::SetNCFileSelect( int nIndex, int is_select, BOOL bNotify )
{
	ASSERT( pMutex_ );

	pMutex_->Lock( INFINITE );

	pa::SNCFileInfo *p = GetNCFileInfo( nIndex );

	if( p )
	{
		p->is_select = is_select;

		if( bNotify )
		{
			//////////////////////////////////////////////////////////////////////////
			// notify observer 
			std::vector<INCFileMgrObserver*>::iterator itr;
			for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
				(*itr)->NCFMObsvr_UpdateNCFileInfo( nIndex );
			}
			//////////////////////////////////////////////////////////////////////////
		}
	}

	pMutex_->Unlock();

	if( bNotify ) {
		set_flag_for_upload_registered_ncfile();
	}
}

int  pa::CPNCFileMgr::GetNCFileSelectUpDown( int nIndex )
{
	int ret = 0;

	ASSERT( pMutex_ );

	pMutex_->Lock( INFINITE );

	pa::SNCFileInfo *p = GetNCFileInfo( nIndex );

	if( p )
	{
		ret = (int)(p->is_select_updown);
	}

	pMutex_->Unlock();

	return ret;
}

void pa::CPNCFileMgr::SetNCFileSelectUpDown( int nIndex, int is_select_updown, BOOL bNotify )
{
	ASSERT( pMutex_ );

	pMutex_->Lock( INFINITE );

	pa::SNCFileInfo *p = GetNCFileInfo( nIndex );

	if( p )
	{
		p->is_select_updown = is_select_updown;

		if( bNotify ) 
		{
			//////////////////////////////////////////////////////////////////////////
			// notify observer 
			std::vector<INCFileMgrObserver*>::iterator itr;
			for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
				(*itr)->NCFMObsvr_UpdateNCFileInfo( nIndex );
			}
			//////////////////////////////////////////////////////////////////////////
		}
	}

	pMutex_->Unlock();

	if( bNotify ) {
		set_flag_for_upload_registered_ncfile();
	}
}

void pa::CPNCFileMgr::SetNCFileFinish( int nIndex, int finish_code, BOOL bNotify )
{
	ASSERT( pMutex_ );

	pMutex_->Lock( INFINITE );

	pa::SNCFileInfo *p = GetNCFileInfo( nIndex );

	if( p )
	{
		p->finish = finish_code;

		if( bNotify )
		{
			//////////////////////////////////////////////////////////////////////////
			// notify observer 
			std::vector<INCFileMgrObserver*>::iterator itr;
			for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
				(*itr)->NCFMObsvr_UpdateNCFileInfo( nIndex );
			}
			//////////////////////////////////////////////////////////////////////////
		}
	}

	pMutex_->Unlock();

	if( bNotify ) {
		set_flag_for_upload_registered_ncfile();
	}
}

void pa::CPNCFileMgr::SetNCFileState( int nIndex, int state, BOOL bNotify )
{
	ASSERT( pMutex_ );

	pMutex_->Lock( INFINITE );

	pa::SNCFileInfo *p = GetNCFileInfo( nIndex );

	if( p )
	{
		p->state = state;
		if( state == NCFILE_STATE_BEFORE )
		{
			p->machining_lines = 0;
			memset( (void*)(p->start_time), 0, sizeof(TCHAR)*16 );
			memset( (void*)(p->work_time), 0, sizeof(TCHAR)*16 );
		}

		if( bNotify )
		{
			//////////////////////////////////////////////////////////////////////////
			// notify observer 
			std::vector<INCFileMgrObserver*>::iterator itr;
			for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
				(*itr)->NCFMObsvr_UpdateNCFileInfo( nIndex );
			}
			//////////////////////////////////////////////////////////////////////////
		}
	}

	pMutex_->Unlock();

	if( bNotify ) {
		set_flag_for_upload_registered_ncfile();
	}
}

// void pa::CPNCFileMgr::SetNCFileFinish( int nIndex, BOOL b )
// {
// 	ASSERT( pMutex_ );
// 
// 	if( nIndex < 0 || nIndex >= *pnNumNCFile_ ) {
// 		return ;
// 	}
// 
// 	pMutex_->Lock( INFINITE );
// 
// 	pa::SNCFileInfo *p = GetNCFileInfo( nIndex );
// 
// 	if( p ) 
// 	{
// 		p->finish = ( b == FALSE ) ? 0 : 1;
// 		pShMem_->Flush( (void*)p, sizeof(SNCFileInfo) );
// 
// 		//////////////////////////////////////////////////////////////////////////
// 		// notify observer 
// 		std::vector<INCFileMgrObserver*>::iterator itr;
// 		for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
// 			(*itr)->NCFMObsvr_UpdateNCFileInfo( nIndex );
// 		}
// 		//////////////////////////////////////////////////////////////////////////
// 	}
// 
// 	pMutex_->Unlock();
// }

// void pa::CPNCFileMgr::SetNCFileState( int nIndex, pa::EN_NC_FILESTATE hState )
// {
// 	ASSERT( pMutex_ );
// 
// 	pMutex_->Lock( INFINITE );
// 
// 	pa::SNCFileInfo *p = GetNCFileInfo( nIndex );
// 
// 	if( p ) 
// 	{
// 		p->state = hState;
// 		pShMem_->Flush( (void*)p, sizeof(SNCFileInfo) );
// 
// 		//////////////////////////////////////////////////////////////////////////
// 		// notify observer 
// 		std::vector<INCFileMgrObserver*>::iterator itr;
// 		for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
// 			(*itr)->NCFMObsvr_UpdateNCFileInfo( nIndex );
// 		}
// 		//////////////////////////////////////////////////////////////////////////
// 	}
// 
// 	pMutex_->Unlock();
// }

// void pa::CPNCFileMgr::SetNCFileStartTime( int nIndex )
// {
// 	ASSERT( pMutex_ );
// 
// 	pMutex_->Lock( INFINITE );
// 
// 	pa::SNCFileInfo *p = GetNCFileInfo( nIndex );
// 
// 	if( p ) 
// 	{
// 		CTime tm = CTime::GetCurrentTime();
// 		CString strTm = tm.Format( _T("%H:%M:%S") );
// 		_stprintf_s( p->start_time, 9, _T("%s"), (LPCTSTR)strTm ); //(LPCTSTR)tm.Format( _T("%H:%M:%S") ) );
// 		pShMem_->Flush( (void*)p, sizeof(SNCFileInfo) );
// 
// 		//////////////////////////////////////////////////////////////////////////
// 		// notify observer 
// 		std::vector<INCFileMgrObserver*>::iterator itr;
// 		for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
// 			(*itr)->NCFMObsvr_UpdateNCFileInfo( nIndex );
// 		}
// 		//////////////////////////////////////////////////////////////////////////
// 	}
// 
// 	pMutex_->Unlock();
// }

// void pa::CPNCFileMgr::SetNCFileWorkTime( int nIndex, DWORD dwSec ) 
// {
// 	ASSERT( pMutex_ );
// 
// 	pMutex_->Lock( INFINITE );
// 
// 	pa::SNCFileInfo *p = GetNCFileInfo( nIndex );
// 
// 	if( p ) 
// 	{
// 		CTimeSpan tms(dwSec);
// 		_stprintf_s( p->work_time, 9, _T("%s"), tms.Format( _T("%H:%M:%S") ) );
// 		pShMem_->Flush( (void*)p, sizeof(SNCFileInfo) );
// 
// 		//////////////////////////////////////////////////////////////////////////
// 		// notify observer 
// 		std::vector<INCFileMgrObserver*>::iterator itr;
// 		for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
// 			(*itr)->NCFMObsvr_UpdateNCFileInfo( nIndex );
// 		}
// 		//////////////////////////////////////////////////////////////////////////
// 	}
// 
// 	pMutex_->Unlock();
// }

// ������ �� ���� �� 
// void pa::CPNCFileMgr::SetNCFileTotalLine( int nIndex, int nTotalLine )
// {
// 	ASSERT( pMutex_ );
// 
// 	pMutex_->Lock( INFINITE );
// 
// 	pa::SNCFileInfo *p = GetNCFileInfo( nIndex );
// 
// 	if( p ) 
// 	{
// 		p->total_lines = nTotalLine;
// 		pShMem_->Flush( (void*)p, sizeof(SNCFileInfo) );
// 
// 		//////////////////////////////////////////////////////////////////////////
// 		// notify observer 
// 		std::vector<INCFileMgrObserver*>::iterator itr;
// 		for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
// 			(*itr)->NCFMObsvr_UpdateNCFileInfo( nIndex );
// 		}
// 		//////////////////////////////////////////////////////////////////////////
// 	}
// 
// 	pMutex_->Unlock();
// }

// ���� ���� ��ȣ 
// void pa::CPNCFileMgr::SetNCFileMachiningLine( int nIndex, int nMachiningLine )
// {
// 	ASSERT( pMutex_ );
// 
// 	pMutex_->Lock( INFINITE );
// 
// 	pa::SNCFileInfo *p = GetNCFileInfo( nIndex );
// 
// 	if( p ) 
// 	{
// 		p->machining_lines = nMachiningLine;
// 		pShMem_->Flush( (void*)p, sizeof(SNCFileInfo) );
// 
// 		//////////////////////////////////////////////////////////////////////////
// 		// notify observer 
// 		std::vector<INCFileMgrObserver*>::iterator itr;
// 		for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
// 			(*itr)->NCFMObsvr_UpdateNCFileInfo( nIndex );
// 		}
// 		//////////////////////////////////////////////////////////////////////////
// 	}
// 
// 	pMutex_->Unlock();
// }

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

// index ��° �۾� ������ �Ѵܰ� ���� �̵�
// ���� �۾����� �ε����� ���� �Ѵ� 
void pa::CPNCFileMgr::MoveUpWorkNCFileInfo( int nIndex, BOOL bNotify, BOOL bSort/*=FALSE*/)
{
	if( nIndex <= 0 ) {
		return ;
	}

	pMutex_->Lock( INFINITE );

	int				len = sizeof(SNCFileInfo);
	SNCFileInfo		hTemp;
	SNCFileInfo*	pA = pNCFileBasePoint_ + nIndex;
	SNCFileInfo*	pB = pNCFileBasePoint_ + nIndex - 1;

	// 2017.06.19 
	if( bSort )
	{
		// <0 if A less then B 
		// >0 if A greater then B
		int comp = _tcscmp( pA->file_name, pB->file_name );
		if( comp > 0 )
		{
			pMutex_->Unlock();
			return ;
		}
	}

	memcpy((void*)&hTemp, (const void*)pA, len);
	memcpy((void*)pA, (const void*)pB, len);
	memcpy((void*)pB, (const void*)&hTemp, len);

	if( nIndex == *pnCurNCFileIndex_ ) {
		(*pnCurNCFileIndex_)--;
	}
	else if( nIndex == *pnCurNCFileIndex_+1 ) {
		(*pnCurNCFileIndex_)++;
	}

	pShMem_->Flush( (void*)pA, len );
	pShMem_->Flush( (void*)pB, len );
	pShMem_->Flush( (void*)pnCurNCFileIndex_, sizeof(int) );

	//////////////////////////////////////////////////////////////////////////
	// notify observer 
	if( bNotify ) {
		std::vector<INCFileMgrObserver*>::iterator itr;
		for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
			(*itr)->NCFMObsvr_MoveUpNCFile( nIndex );
		}
	}
	//////////////////////////////////////////////////////////////////////////

	pMutex_->Unlock();

	if( bNotify ) {
		set_flag_for_upload_registered_ncfile();
	}
}

// index ��° �۾� ������ �Ѵܰ� �Ʒ��� �̵� 
// ���� �۾����� �ε��� ��ȣ�� ���� �Ѵ�
void pa::CPNCFileMgr::MoveDownWorkNCFileInfo( int nIndex, BOOL bNotify, BOOL bSort/*=FALSE*/ )
{
	if( nIndex >= (*pnNumNCFile_ - 1) ) {
		return ;
	}

	pMutex_->Lock( INFINITE );

	int				len = sizeof(SNCFileInfo);
	SNCFileInfo		hTemp;
	SNCFileInfo*	pA = pNCFileBasePoint_ + nIndex;
	SNCFileInfo*	pB = pNCFileBasePoint_ + nIndex + 1;

	// 2017.06.19 
	if( bSort )
	{
		// <0 if A less then B 
		// >0 if A greater then B
		int comp = _tcscmp( pA->file_name, pB->file_name );
		if( comp < 0 )
		{
			pMutex_->Unlock();
			return ;
		}
	}

	memcpy((void*)&hTemp, (const void*)pA, len);
	memcpy((void*)pA, (const void*)pB, len);
	memcpy((void*)pB, (const void*)&hTemp, len);
	
	if( nIndex ==  *pnCurNCFileIndex_ ) {
		(*pnCurNCFileIndex_)++;
	}
	else if( nIndex == *pnCurNCFileIndex_-1 ) {
		(*pnCurNCFileIndex_)--;
	}

	pShMem_->Flush( (void*)pA, len );
	pShMem_->Flush( (void*)pB, len );
	pShMem_->Flush( (void*)pnCurNCFileIndex_, sizeof(int) );

	//////////////////////////////////////////////////////////////////////////
	// notify observer 
	if( bNotify ) {
		std::vector<INCFileMgrObserver*>::iterator itr;
		for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
			(*itr)->NCFMObsvr_MoveDownNCFile( nIndex );
		}
	}
	//////////////////////////////////////////////////////////////////////////

	pMutex_->Unlock();

	if( bNotify ) {
		set_flag_for_upload_registered_ncfile();
	}
}

// ���õ� NC ������ ��� �Ѵܰ� ���� �̵� 
void pa::CPNCFileMgr::MoveUpSelectedNcFile()
{
// 	for( int i = 0; i<*pnNumNCFile_; i++ )
// 	{
// 		pa::SNCFileInfo *pInfo = GetNCFileInfo( i );
// 		if( pInfo && pInfo->is_select_updown != 0 )
// 		{
// 			if( i == 0 ) {
// 				break;
// 			}
// 
// 			MoveUpWorkNCFileInfo( i );
// 		}
// 	}
}

// ���õ� NC ������ ��� �Ѵܰ� �Ʒ��� �̵� 
void pa::CPNCFileMgr::MoveDownSelectedNcFile()
{
// 	for( int i = *pnNumNCFile_-1; i>=0; i-- ) 
// 	{
// 		pa::SNCFileInfo *pInfo = GetNCFileInfo( i );
// 		if( pInfo && pInfo->is_select_updown != 0 )
// 		{
// 			if( i == *pnNumNCFile_-1 ) {
// 				break;
// 			}
// 
// 			MoveDownWorkNCFileInfo( i );
// 		}
// 	}
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

void pa::CPNCFileMgr::UpdateNcFileListForSD()
{
	pMutex_->Lock(INFINITE);

	//////////////////////////////////////////////////////////////////////////
	// notify observer 
	std::vector<INCFileMgrForSDObserver*>::iterator itr;
	for( itr = vtrpSDObservers_.begin(); itr != vtrpSDObservers_.end(); itr++ ) {
		(*itr)->NCFMObsvrForSD_UpdateNCFileList();
	}
	//////////////////////////////////////////////////////////////////////////

	pMutex_->Unlock();
}

void pa::CPNCFileMgr::UpdateNcFileList()
{
	pMutex_->Lock(INFINITE);

	//////////////////////////////////////////////////////////////////////////
	// notify observer 
	std::vector<INCFileMgrObserver*>::iterator itr;
	for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
		(*itr)->NCFMObsvr_UpdateNCFileList();
	}
	//////////////////////////////////////////////////////////////////////////

	pMutex_->Unlock();
}

// �������� �۾� �����͸� �߰� �Ѵ� (pID�� NULL�̸� �ý��� �ð��� ����ؼ� �ڵ� �Է�)
BOOL pa::CPNCFileMgr::AddWorkNCFileInfo( TCHAR* pID, TCHAR* pNCFilePath, DWORD dwFileSize, BOOL bSorting/*=FALSE*/ )
{
	SNCFileInfo	hNCFileInfo;

	if( *pnNumNCFile_+1 >= MAX_NCFILE_NUM ) {
		return FALSE;
	}

	pMutex_->Lock( INFINITE );

	//////////////////////////////////////////////////////////////////////////
	// ���� �̸��� ������ ������ �߰����� �ʴ´� 
	for( int i = 0; i<*pnNumNCFile_; i++ ) {
		SNCFileInfo* p = pNCFileBasePoint_ + i;
		if( p && ( _tcscmp( p->file_name, pNCFilePath ) == 0 ) ) 
		{
			// ���� �̸��� ������ ���� 
			pMutex_->Unlock();
			return TRUE;
		}
	}
	//////////////////////////////////////////////////////////////////////////

	memset((void*)&hNCFileInfo, 0, sizeof(SNCFileInfo));

	if( pID ) {
		memcpy((void*)(hNCFileInfo.id), (const void*)pID, sizeof(TCHAR)*_tcslen(pID));
	} else {
		CTime tm = CTime::GetCurrentTime();
		CString strID = tm.Format( _T("%y%m%d%H%M%S") );
		memcpy((void*)(hNCFileInfo.id), (const void*)(LPCTSTR)strID, sizeof(TCHAR)*strID.GetLength());
	}

	memcpy((void*)(hNCFileInfo.file_name), (const void*)pNCFilePath, sizeof(TCHAR)*_tcslen(pNCFilePath));

	hNCFileInfo.file_size = dwFileSize;

	if( bSorting == FALSE )
	{
		//////////////////////////////////////////////////////////////////////////
		// �������� �߰� 
		memcpy((void*)(pNCFileBasePoint_ + *pnNumNCFile_), (const void*)&hNCFileInfo, sizeof(SNCFileInfo));
		pShMem_->Flush( (void*)(pNCFileBasePoint_ + *pnNumNCFile_), sizeof(SNCFileInfo));

		(*pnNumNCFile_)++;
		pShMem_->Flush( (void*)pnNumNCFile_, sizeof(int));

		//////////////////////////////////////////////////////////////////////////
		// notify observer 
		std::vector<INCFileMgrObserver*>::iterator itr;
		for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
			(*itr)->NCFMObsvr_AddNewNCFile();
		}
		//////////////////////////////////////////////////////////////////////////
	}
	else 
	{
		//////////////////////////////////////////////////////////////////////////
		// NC ���� �̸��� ����ؼ� ����. ����Ʈ�� �Ʒ� ���� ã�� �ö󰣴� 
		// �߰��� ��ġ�� ã�µ�... ã�� ��ġ�� �Ʒ� �߰� �ϵ��� �Ѵ� 
		int nNumFiles = *pnNumNCFile_;
		int index = 0;
		BOOL bFind = FALSE;
		
		for( int i = nNumFiles-1; i>=0; i-- )
		{
			SNCFileInfo* pTemp = (SNCFileInfo*)(pNCFileBasePoint_ + i);

			int comp = _tcscmp( hNCFileInfo.file_name, pTemp->file_name );

			if( comp > 0 )
			{
				index = i+1;
				bFind = TRUE;
				break;
			}
		}
		if( bFind == FALSE ) {
			index = 0;
		}

		// index ��° hNCFileInfo�� �߰� �Ѵ� 
		int movingNum = nNumFiles - index;			// �̵��� ����
		
		if( movingNum > 0 )
		{
			// movingNum ������ NC������ �Ʒ��� �̵� �Ѵ� 
			for( int i = nNumFiles-1; i>=index; i-- )
			{
				// MoveDown
				memcpy((void*)(pNCFileBasePoint_+i+1), (const void*)(pNCFileBasePoint_+i), sizeof(SNCFileInfo));
			}
		}

		// ���� �߰��Ǵ� NC ���� ���� ���� 
		memcpy((void*)(pNCFileBasePoint_ + index), (const void*)&hNCFileInfo, sizeof(SNCFileInfo));
		//////////////////////////////////////////////////////////////////////////

		(*pnNumNCFile_)++;

		if( (*pnCurNCFileIndex_) >= index )
		{
			(*pnCurNCFileIndex_) += 1;
		}

		pShMem_->Flush();

		//////////////////////////////////////////////////////////////////////////
		// notify observer 
		std::vector<INCFileMgrObserver*>::iterator itr;
		for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
			(*itr)->NCFMObsvr_UpdateNCFileList();
		}
		//////////////////////////////////////////////////////////////////////////
	}

	pMutex_->Unlock();

	return TRUE;
}

// Index ��° �۾� �����͸� �߰� �Ѵ� (pID�� NULL�̸� �ý��� �ð��� ����ؼ� �ڵ� �Է�)
// ���� �۾����� ���ؽ� ��ȣ�� �����Ѵ� 
BOOL pa::CPNCFileMgr::InsertWorkNCFileInfo( int nIndex, TCHAR* pID, TCHAR* pNCFilePath )
{
	SNCFileInfo	hNCFileInfo;

	if( *pnNumNCFile_+1 >= MAX_NCFILE_NUM ) {
		return FALSE;
	}

	pMutex_->Lock( INFINITE );

	if( nIndex < 0 ) { nIndex = 0; }
	if( nIndex >= *pnNumNCFile_ ) { nIndex = *pnNumNCFile_; }

	memset((void*)&hNCFileInfo, 0, sizeof(SNCFileInfo));

	if( pID ) {
		memcpy((void*)(hNCFileInfo.id), (const void*)pID, sizeof(TCHAR)*_tcslen(pID));
	} else {
		CTime tm = CTime::GetCurrentTime();
		CString strID = tm.Format( _T("%y%m%d%H%M%S") );
		memcpy((void*)(hNCFileInfo.id), (const void*)(LPCTSTR)strID, sizeof(TCHAR)*strID.GetLength());
	}

	memcpy((void*)(hNCFileInfo.file_name), (const void*)pNCFilePath, sizeof(TCHAR)*_tcslen(pNCFilePath));

	//////////////////////////////////////////////////////////////////////////
	// nIndex ��° �����͸� �߰� �Ѵ� 
	//////////////////////////////////////////////////////////////////////////

	// nIndex ��° �����͸� �ڷ� �̵� 
	for( int i = *pnNumNCFile_-1; i>=nIndex; i-- ) {
		// i��° �����͸� i+1 ��°�� �̵��Ѵ� 
		memcpy((void*)(pNCFileBasePoint_+i+1), (const void*)(pNCFileBasePoint_+i), sizeof(SNCFileInfo));
	}

	// nIndex ��° �����͸� ���� 
	memcpy((void*)(pNCFileBasePoint_ + nIndex), (const void*)&hNCFileInfo, sizeof(SNCFileInfo));

	(*pnNumNCFile_)++;

	int len = sizeof(int) + sizeof(int) + ( sizeof(SNCFileInfo) * MAX_NCFILE_NUM );
	pShMem_->Flush( (void*)pnNumNCFile_, len ); 

	//////////////////////////////////////////////////////////////////////////
	// notify observer 
	std::vector<INCFileMgrObserver*>::iterator itr;
	for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
		(*itr)->NCFMObsvr_InsertNewNCFile( nIndex );
	}
	//////////////////////////////////////////////////////////////////////////

	pMutex_->Unlock();

	return TRUE;
}

// index ��° �۾� ���� ���� (���� �������� �۾� ������ ������ �� ����)
// ���� �۾����� �ε��� ��ȣ�� �����Ѵ� 
BOOL pa::CPNCFileMgr::RemoveWorkNCFileInfo( int nIndex )
{
	BOOL bReset = FALSE;

	if( nIndex == *pnCurNCFileIndex_ ) {
		// ���� �ִ� ������ ��ŵ �Ѵ� 
		return FALSE;
	}

	pMutex_->Lock( INFINITE );

	int len = sizeof(SNCFileInfo) * ( *pnNumNCFile_ - nIndex - 1 );

	memcpy( (void*)(pNCFileBasePoint_+nIndex), (const void*)(pNCFileBasePoint_+nIndex+1), len );

	(*pnNumNCFile_)--;	// NC ���� ���� -1
	if( *pnNumNCFile_ <= 0 || nIndex < *pnCurNCFileIndex_ || bReset ) {
		*pnCurNCFileIndex_ = -1;
	}

	pShMem_->Flush( (void*)(pNCFileBasePoint_ + nIndex), len );
	pShMem_->Flush( (void*)(pnCurNCFileIndex_), sizeof(int) );

	//////////////////////////////////////////////////////////////////////////
	// notify observer 
	std::vector<INCFileMgrObserver*>::iterator itr;
	for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ ) {
		(*itr)->NCFMObsvr_RemoveNCFile( nIndex );
	}
	//////////////////////////////////////////////////////////////////////////

	pMutex_->Unlock();

	return TRUE;
}

// filename�� index�� ã�Ƽ�, 
BOOL pa::CPNCFileMgr::RemoveWorkNCFileInfo( CString strFileName )
{
	int		index = 0;
	BOOL	bFind =FALSE;
	BOOL	bRet = TRUE;

	for( index = 0; index < *pnNumNCFile_; index++ ) 
	{
		SNCFileInfo* p = pNCFileBasePoint_ + index;
		CString strTemp;
		strTemp.Format( _T("%s"), p->file_name );
		if( strFileName == strTemp ) {
			bFind = TRUE;
			break;
		}
	}

	if( bFind ) {
		bRet = RemoveWorkNCFileInfo( index );
	}

	return bRet;
}

// ������ ��ϵǾ� ������ TRUE 
BOOL pa::CPNCFileMgr::IsRegisterNCFile( CString strFileName )
{
	int		index = 0;
	BOOL	bFind = FALSE;

	for( index = 0; index < *pnNumNCFile_; index++ ) 
	{
		SNCFileInfo	*p = pNCFileBasePoint_ + index;
		if( p ) 
		{
			CString strTemp;
			strTemp.Format( _T("%s"), p->file_name );
			if( strTemp == strFileName ) 
			{
				bFind = TRUE;
				break;
			}
		}
	}

	return bFind;
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

// ��ϵ� ��� NC ������ select ���¸� ���� �Ѵ� 
void pa::CPNCFileMgr::SetAllNCFileSelectAndFinish( int is_select, int finish_code, int state )
{
	for( int i = 0; i < *pnNumNCFile_; i++ ) 
	{
		SetNCFileSelect( i, is_select, FALSE );
		SetNCFileFinish( i, finish_code, FALSE );
		SetNCFileState( i, state, TRUE );
	}
}

// ��� NC ������ select �Ѵ�
void pa::CPNCFileMgr::SelectAllNCFiles( bool bNotify )
{
	for( int i = 0; i < *pnNumNCFile_; i++ ) 
	{
		SetNCFileSelect( i, 1, bNotify );
	}
}

// ��� NC ������ deselect �Ѵ�
void pa::CPNCFileMgr::DeselectAllNCFiles( bool bNotify )
{
	for( int i = 0; i < *pnNumNCFile_; i++ ) 
	{
		SetNCFileSelect( i, 0, bNotify );
	}
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

BOOL pa::CPNCFileMgr::IsExistNCFile( CString& strNCFileName )
{
	BOOL bRet = FALSE;
	CString strTemp;

	for( int i = 0; i < *pnNumNCFile_; i++ )
	{
		SNCFileInfo* p = pNCFileBasePoint_ + i;
		strTemp.Format( _T("%s"), p->file_name );
		if( strTemp == strNCFileName ) {
			bRet = TRUE;
			break;
		}
	}

	return bRet;
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////
// NC ���� ����Ʈ�� ���� �Ѵ� 
//	- ���� �۾� �ε����� ��ġ�� ������Ʈ �Ѵ� 
void pa::CPNCFileMgr::SortNCFileList( BOOL bNotify )
{
	pMutex_->Lock( INFINITE );

	int num_ncfile = *pnNumNCFile_;
	int curr_index = *pnCurNCFileIndex_;
	int len = sizeof(SNCFileInfo);

	//////////////////////////////////////////////////////////////////////////
	// ���� ���õ� NC ���� ������ �����Ѵ� 
	SNCFileInfo hSelectNCFileInfo;
	if( curr_index != -1 )
	{
		memcpy((void*)&hSelectNCFileInfo, (const void *)(pNCFileBasePoint_+curr_index), len); 
	}
	//////////////////////////////////////////////////////////////////////////

	for( int i = 0; i<num_ncfile-1; i++ )
	{
		for( int j = 0; j<num_ncfile-1-i; j++ )
		{
			// i��°�� j��° �����͸� �� �ؼ�,
			SNCFileInfo* pA = pNCFileBasePoint_ + j;
			SNCFileInfo* pB = pNCFileBasePoint_ + j+1;
			
			// string1 less than string2
			int comp = _tcscmp( pA->file_name, pB->file_name );

			if( comp > 0 )
			{
				// A��°�� ũ��, �����͸� ��ȯ�Ѵ� 
				SNCFileInfo hTemp;

				memcpy((void*)&hTemp, (const void*)pA, len);
				memcpy((void*)pA, (const void*)pB, len);
				memcpy((void*)pB, (const void*)&hTemp, len );
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// ���� ���õ� NC ������ ��ġ�� ã�Ƽ�, ���� �����Ѵ� 
	if( curr_index != -1 )
	{
		curr_index = -1;
		for( int i = 0; i<num_ncfile; i++ )
		{
			SNCFileInfo* pTemp;
			pTemp = pNCFileBasePoint_ + i;
			if( _tcscmp( hSelectNCFileInfo.id, pTemp->id) == 0 )
			{
				curr_index = i;
				break;
			}
		}
		*pnCurNCFileIndex_ = curr_index;
	}
	//////////////////////////////////////////////////////////////////////////

	if( bNotify )
	{
		std::vector<INCFileMgrObserver*>::iterator itr;
		for( itr = vtrpObservers_.begin(); itr != vtrpObservers_.end(); itr++ )
		{
			(*itr)->NCFMObsvr_UpdateNCFileList();
		}
	}

	pShMem_->Flush();

	pMutex_->Unlock();

	if( bNotify ) {
		set_flag_for_upload_registered_ncfile();
	}
}

