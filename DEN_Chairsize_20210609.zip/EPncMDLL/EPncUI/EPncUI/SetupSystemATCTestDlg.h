#pragma once
#include "afxwin.h"


// CSetupSystemATCTestDlg ��ȭ �����Դϴ�.

class CSetupSystemATCTestDlg : public CDialog
{
	DECLARE_DYNAMIC(CSetupSystemATCTestDlg)

	int PREV_WORKING_COUNT;
	CFont fntStatic_;
	int nIsPressStopButton_;

	void get_num( UINT nButtonID );
	void updateButtonState();
	void updateWorkingCount();
	void updateResult();

public:
	CSetupSystemATCTestDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupSystemATCTestDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_SYSTEM_ATCTEST };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedButtonClose();
	BOOL	bEnaTooln_[8];
	CString strEditTooln_[8];
	CString strEditToolnME_[8];
	CComboBox cboTooln_[8];
//	afx_msg void OnBnClickedButtonMeasureStart();
	afx_msg void OnBnClickedButtonMeasureCount();
//	afx_msg void OnBnClickedButtonMeasureStop();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedButtonMeasureStart();
	CStatic stcWorkCount_;
};
