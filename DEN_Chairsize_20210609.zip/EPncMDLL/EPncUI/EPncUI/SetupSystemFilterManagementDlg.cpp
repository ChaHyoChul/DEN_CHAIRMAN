// SetupSystemFilterManagementDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "SetupSystemFilterManagementDlg.h"
#include "MsgDlg.h"
#include "MsgDlgThread.h"

// CSetupSystemFilterManagementDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CSetupSystemFilterManagementDlg, CDialog)

CSetupSystemFilterManagementDlg::CSetupSystemFilterManagementDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetupSystemFilterManagementDlg::IDD, pParent)
{

}

CSetupSystemFilterManagementDlg::~CSetupSystemFilterManagementDlg()
{
}

void CSetupSystemFilterManagementDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_BUTTON_HOUR, btnHour_);
	DDX_Control(pDX, IDC_BUTTON_MIN, btnMin_);
	DDX_Control(pDX, IDC_BUTTON_SEC, btnSec_);
}


BEGIN_MESSAGE_MAP(CSetupSystemFilterManagementDlg, CDialog)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, &CSetupSystemFilterManagementDlg::OnBnClickedButtonClose)
	ON_BN_CLICKED(IDC_BUTTON_HOUR, &CSetupSystemFilterManagementDlg::OnBnClickedButtonHour)
	ON_BN_CLICKED(IDC_BUTTON_MIN, &CSetupSystemFilterManagementDlg::OnBnClickedButtonMin)
	ON_BN_CLICKED(IDC_BUTTON_SEC, &CSetupSystemFilterManagementDlg::OnBnClickedButtonSec)
	ON_BN_CLICKED(IDC_BUTTON_RESET, &CSetupSystemFilterManagementDlg::OnBnClickedButtonReset)
	ON_BN_CLICKED(IDC_BUTTON_SET, &CSetupSystemFilterManagementDlg::OnBnClickedButtonSet)
END_MESSAGE_MAP()

// CSetupSystemFilterManagementDlg �޽��� ó�����Դϴ�.

BOOL CSetupSystemFilterManagementDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CSetupSystemFilterManagementDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	//////////////////////////////////////////////////////////////////////////

	fntEdit_.CreateFont(
		20, 0, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	btnHour_.SetFont( &fntEdit_, FALSE );
	btnMin_.SetFont( &fntEdit_, FALSE );
	btnSec_.SetFont( &fntEdit_, FALSE );
	((CStatic*)GetDlgItem(IDC_STATIC_TIME))->SetFont( &fntEdit_, FALSE );

	//////////////////////////////////////////////////////////////////////////

	fntButton_.CreateFont(
		17, 0,
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	((CStatic*)GetDlgItem(IDC_STATIC_CURRENT_TIME))->SetFont( &fntButton_, FALSE );
	((CStatic*)GetDlgItem(IDC_STATIC_TOTAL_TIME))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_SET))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_RESET))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_CLOSE))->SetFont( &fntButton_, FALSE );

	//////////////////////////////////////////////////////////////////////////
	// Center Window 
	CenterWindow();
	//////////////////////////////////////////////////////////////////////////

	displayFilterInfo();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CSetupSystemFilterManagementDlg::OnDestroy()
{
	fntEdit_.DeleteObject();
	fntButton_.DeleteObject();

	CDialog::OnDestroy();
}

void CSetupSystemFilterManagementDlg::OnBnClickedButtonClose()
{
	CDialog::OnOK();
}

void CSetupSystemFilterManagementDlg::displayFilterInfo()
{
	// ���� ���ð� ǥ��
	DWORD dwTemp = pa::PPAStatus->GetThreadState()->dwTOTAL_FILTER_TIME;
	CTimeSpan	tms(dwTemp);
	CString		strTime, strHour, strMin, strSec;
	int nHour, nMin, nSec;

	strHour.Format( _T("%d"), tms.GetTotalHours() );
	strMin.Format( _T("%d"), tms.GetMinutes() );
	strSec.Format( _T("%d"), tms.GetSeconds() );

	strTime.Format( _T("%s : %s : %s"), strHour, strMin, strSec );
	GetDlgItem(IDC_STATIC_TIME)->SetWindowText( strTime );

	// �ִ� ���ð� ǥ��
	dwTemp = pa::PSWConfig->GetConfigData()->nFilterTimeout_sec;
	nHour = dwTemp / 3600;
	nMin = ( dwTemp - nHour * 3600 ) / 60;
	nSec = ( dwTemp - nHour * 3600 - nMin * 60 );

	strHour.Format( _T("%d"), nHour );
	strMin.Format( _T("%d"), nMin );
	strSec.Format( _T("%d"), nSec );

	btnHour_.SetWindowText( strHour );
	btnMin_.SetWindowText( strMin );
	btnSec_.SetWindowText( strSec );
}

#include "NumericInputDlg.h"

void CSetupSystemFilterManagementDlg::OnBnClickedButtonHour()
{
	CNumericInputDlg dlg;
	CString strTemp;
	btnHour_.GetWindowText( strTemp );
	int prev_num = _ttoi(strTemp);

	dlg.SetIsFloatType( FALSE );
	dlg.SetPrevNumber( prev_num );
	dlg.SetProperty( 0 );

	if( dlg.DoModal() == IDOK ) {
		strTemp = dlg.GetNumber();
		if (strTemp.IsEmpty()) {
			strTemp.Format(_T("0"));
		}
		int nMin = _ttoi( strTemp );
		if( nMin >= 0 ) {
			btnHour_.SetWindowText( strTemp );
		}
	}

}

void CSetupSystemFilterManagementDlg::OnBnClickedButtonMin()
{
	CNumericInputDlg dlg;
	CString strTemp;
	btnMin_.GetWindowText( strTemp );
	int prev_num = _ttoi(strTemp);

	dlg.SetIsFloatType( FALSE );
	dlg.SetPrevNumber( prev_num );
	dlg.SetProperty( 0 );

	if( dlg.DoModal() == IDOK ) {
		strTemp = dlg.GetNumber();
		if (strTemp.IsEmpty()) {
			strTemp.Format(_T("0"));
		}
		int nMin = _ttoi( strTemp );
		if( nMin >= 0 && nMin <= 59 ) {
			btnMin_.SetWindowText( strTemp );
		}
	}

}

void CSetupSystemFilterManagementDlg::OnBnClickedButtonSec()
{
	CNumericInputDlg dlg;
	CString strTemp;
	btnSec_.GetWindowText( strTemp );
	int prev_num = _ttoi(strTemp);

	dlg.SetIsFloatType( FALSE );
	dlg.SetPrevNumber( prev_num );
	dlg.SetProperty( 0 );

	if( dlg.DoModal() == IDOK ) {
		strTemp = dlg.GetNumber();
		if (strTemp.IsEmpty()) {
			strTemp.Format(_T("0"));
		}
		int nMin = _ttoi( strTemp );
		if( nMin >= 0 && nMin <= 59 ) {
			btnSec_.SetWindowText( strTemp );
		}
	}

}

// �ð��� �ʱ�ȭ �Ѵ� 
void CSetupSystemFilterManagementDlg::OnBnClickedButtonReset()
{
	CString strMsg;

	strMsg.Format( _T("Do you want to reset total time ?") );

	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
	CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();

	if( hRet == CMsgDlg::RET_OK ) 
	{
		pa::PPAStatus->GetThreadState()->dwTOTAL_FILTER_TIME = 0;

		PPNC_IPC_CLIENT->SaveFilterTotalTime();
	}

	displayFilterInfo();
}

// �ð��� �����Ѵ� 
void CSetupSystemFilterManagementDlg::OnBnClickedButtonSet()
{
	CString strMsg, strErrMsg;
	CString strHour, strMin, strSec;
	int		nHour, nMin, nSec;
	CCEIniFile	hIniFile;

	strMsg.Format( _T("Do you want to change total time ?") );

	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
	CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();

	if( hRet == CMsgDlg::RET_OK ) 
	{
		btnHour_.GetWindowText( strHour );
		btnMin_.GetWindowText( strMin );
		btnSec_.GetWindowText( strSec );

		nHour	= _ttoi( strHour );
		nMin	= _ttoi( strMin );
		nSec	= _ttoi( strSec );

		DWORD dwTotal = (nHour*60*60) + (nMin*60) + nSec;
		pa::PSWConfig->GetConfigData()->nFilterTimeout_sec = dwTotal;

		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );
		if( save_to_file_sw_config( strErrMsg ) ) 
		{
			CMsgDlgThread::GetInstance()->Hide();
		} 
		else {
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strErrMsg );
			CMsgDlgThread::GetInstance()->Wait();
		}
	}

	displayFilterInfo();
}

BOOL CSetupSystemFilterManagementDlg::save_to_file_sw_config(CString& strErrMsg)
{
	CString		strKeyName, strValueName;
	CCEIniFile	hIniFile;

	if( !hIniFile.Open( INI_SW_CONFIG_PATH ) ) {
		strErrMsg.Format( _T("ERROR : config file open fail (CSetupSystemFilterManagementDlg::save_to_file_sw_config())") );
		return FALSE;
	}

	strKeyName.Format( _T("Timeout") );
	strValueName.Format( _T("FilterTimeout") );
	hIniFile.SetValue( strKeyName, strValueName, pa::PSWConfig->GetConfigData()->nFilterTimeout_sec );

	return TRUE;
}