#pragma once
#include "afxwin.h"
#include "NotifyButton.h"
#include "PositionMiniWnd.h"
#include "TitleBarWnd.h"

// CSetupAutoLoaderDlg ��ȭ �����Դϴ�.

class CSetupAutoLoaderDlg : public CDialogListPage
{
	DECLARE_DYNCREATE(CSetupAutoLoaderDlg)

	CWnd* pParentWnd_;

	TCHAR*				pResourcePath_;
	hcutil::CCanvasCE*	pCanvasCE_;
	
	CDialogMap*	pDlgMap_;

	CTitleBarWnd*	pPositionTitleWnd_;

	CBrush	brhBkgnd_;
	CBrush	brhEmoResetButton_;
	CBrush	brhBackButton_;

	CFont	fntMenuButton_;
	CFont	fntOperButton_;
	CFont	fntJogSpd_;

	CRect	PCUIrectSAL; 

	int		PREV_MENU_BUTTON_ENABLE_;
	double	fJogStep_[10];	// 0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0
	int		nJogStep_;
	int		nJogMode_;		// 0:Step, 1:Continue

	BOOL bkeyboard_jog_btn_down_;

	BOOL isJogging;

// 	int		nJogSpeedRate_;	// �ʱ� 100% ���� �� up/down ��ư�� ��������, �� ���� �������� �����Ѵ� 
// 							// ȭ�鿡 ���ö� ���� 100% �ʱ�ȭ �Ѵ� 

	CPositionMiniWnd*	pPositionMiniWnd_;

	void update_PositionMiniWnd();
	
	void updateState_MenuButton();

	void updateState_JobButton();

	void updateJogStepVal( int nJogStep );

	void writeLog( LPCTSTR log_msg );

	void startJog( int axis, BOOL dir );

	void startJog( pa::EN_AXIS axis, BOOL dir, int nstep );

	void stopJog( int axis, BOOL dir );

	void setMotorOverride( int nNewOvr );

	void setJogSpeedRate( int nNewSpdRate );

	void upload_to_pc();

	void JOG_START_STOP( int button_id, int axis_no, BOOL dir, MSG *pMsg );

	BOOL load_from_file_autoloader_teaching_point( CString& strErrMsg );
	BOOL save_to_file_autoloader_teaching_point( CString& strErrMsg );

public:
	CSetupAutoLoaderDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupAutoLoaderDlg();

	void SetParentWnd( CWnd* pParent ) { pParentWnd_ = pParent; }

	virtual void StartPageWork();
	virtual void StopPageWork();
	virtual void UpdatePage();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_AUTOLOADER };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	CButton btnDownLoadToController_;
	CButton btnSave_;
	CButton btnClose_;
	int nSelMode_;
	afx_msg void OnBnClickedRadioTeachingPoint2();
	afx_msg void OnBnClickedRadioManualOperation();
	afx_msg void OnBnClickedButtonClose();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedButtonDownloadToCtrl();
//	afx_msg void OnBnClickedButtonUpoadToPc();
	afx_msg void OnBnClickedButtonSav();
	afx_msg void OnBnClickedCheckJogMode();
	CButton chkJogMode_;
	CButton btnJogStepVal_;
	afx_msg void OnBnClickedButtonStepVal();
// 	CNotifyButton btnJogUp_;
// 	CNotifyButton btnJogDown_;
// 	afx_msg LRESULT OnNotifyButton(WPARAM wparam, LPARAM lparam);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	CButton btnEmoReset_;
	afx_msg void OnBnClickedButtonEmoReset3();
//	afx_msg void OnBnClickedButtonJogUp();
	afx_msg void OnBnClickedButtonJogSpeedUp();
	afx_msg void OnBnClickedButtonJogSpeedDown();
	afx_msg LRESULT OnHcchaKeyMeg(WPARAM wparam, LPARAM lparam);
	afx_msg void OnBnClickedButtonJogModeStep();
	afx_msg void OnBnClickedButtonJogModeContinue();
	CButton btnJogModeStep_;
	CButton btnJogModeContinue_;
protected:
	virtual void PreInitDialog();
public:
	afx_msg void OnPaint();
//	afx_msg void OnBnClickedButtonUpoadToPc();
	CButton btnLoad_;
	afx_msg void OnBnClickedButtonLoadFromFile();
};
