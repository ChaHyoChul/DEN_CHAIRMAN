// SetupMenuDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "SetupMenuDlg.h"

//////////////////////////////////////////////////////////////////////////
// CSetupMenuDlg ��ȭ �����Դϴ�.
//////////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNCREATE(CSetupMenuDlg, CDialogListPage)

CSetupMenuDlg::CSetupMenuDlg(CWnd* pParent /*=NULL*/)
	: CDialogListPage(CSetupMenuDlg::IDD, pParent)
{
	pWndParent_ = NULL;
	pResourcePath_ = RESOURCE_2_PATH;
}

CSetupMenuDlg::~CSetupMenuDlg()
{
}

void CSetupMenuDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogListPage::DoDataExchange(pDX);
}

void CSetupMenuDlg::StartPageWork()
{
	BOOL bEnableButton = FALSE;
	
#ifdef _PA_G2400_
	if( pa::PAutoLoader && pa::PAutoLoader->IsUsingAutoLoader() ) {
		bEnableButton = TRUE;
	}
#endif 
#ifdef _PA_G1600_
// 	switch( pa::PSWConfig->GetConfigData()->nModelID )
// 	{
// 	case 0:	// DS200-5Z
// 	case 1:	// DS200-4W
// 	case 2:	// DS200-4WA
// 	case 3:	// DS200-4WAS
// 		bEnableButton = FALSE;
// 		break;
// 	case 4:	// DS200-5P
// 		bEnableButton = TRUE;
// 		break;
// 	}
#endif 

// 	((CButton*)GetDlgItem(IDC_BUTTON_AUTOLOADER))->EnableWindow( bEnableButton );

	((CButton*)GetDlgItem(IDC_CHECK_NO_NDDE_PASSWORD))->SetCheck( theApp.bNoNeedEnterPassword_ );

	//////////////////////////////////////////////////////////////////////////
	//
//	if( pa::USER_MODE < pa::USER_MODE_RND )
	if( pa::GET_CURRENT_USERMODE() < pa::USER_MODE_RND )
	{
		((CButton*)GetDlgItem(IDC_BUTTON_TERM))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_CHECK_NO_NDDE_PASSWORD))->ShowWindow( FALSE );
		((CButton*)GetDlgItem(IDC_CHECK_NO_NDDE_PASSWORD))->SetCheck( FALSE );
	}
	else 
	{
		((CButton*)GetDlgItem(IDC_BUTTON_TERM))->EnableWindow( TRUE );
		((CButton*)GetDlgItem(IDC_CHECK_NO_NDDE_PASSWORD))->ShowWindow( TRUE );
	}
	//////////////////////////////////////////////////////////////////////////
	SetTimer( 1, 200, NULL );
}

void CSetupMenuDlg::StopPageWork()
{
	KillTimer( 1 );

	BOOL bEnableButton = FALSE;

	if( pa::PAutoLoader && pa::PAutoLoader->IsUsingAutoLoader() ) {
		bEnableButton = TRUE;
	}

	((CButton*)GetDlgItem(IDC_BUTTON_AUTOLOADER))->EnableWindow( bEnableButton );

	((CButton *)GetDlgItem(IDC_CHECK_NO_NDDE_PASSWORD))->SetCheck( theApp.bNoNeedEnterPassword_ );

	//////////////////////////////////////////////////////////////////////////
	// 
	if( pa::GET_CURRENT_USERMODE() < pa::USER_MODE_RND )
	{
		((CButton*)GetDlgItem(IDC_BUTTON_TERM))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_CHECK_NO_NDDE_PASSWORD))->ShowWindow( FALSE );
		((CButton*)GetDlgItem(IDC_CHECK_NO_NDDE_PASSWORD))->SetCheck( FALSE );
	}
	else 
	{
		((CButton*)GetDlgItem(IDC_BUTTON_TERM))->EnableWindow( TRUE );
		((CButton*)GetDlgItem(IDC_CHECK_NO_NDDE_PASSWORD))->ShowWindow( TRUE );
	}

}

void CSetupMenuDlg::UpdatePage()
{

}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CSetupMenuDlg, CDialogListPage)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_TEACHING, &CSetupMenuDlg::OnBnClickedButtonTeaching)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, &CSetupMenuDlg::OnBnClickedButtonClose)
	ON_BN_CLICKED(IDC_BUTTON_TOOL, &CSetupMenuDlg::OnBnClickedButtonTool)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_AUTOLOADER, &CSetupMenuDlg::OnBnClickedButtonAutoloader)
	ON_BN_CLICKED(IDC_BUTTON_OPTION, &CSetupMenuDlg::OnBnClickedButtonOption)
	ON_BN_CLICKED(IDC_CHECK_NO_NDDE_PASSWORD, &CSetupMenuDlg::OnBnClickedCheckNoNddePassword)
	ON_BN_CLICKED(IDC_BUTTON_IO, &CSetupMenuDlg::OnBnClickedButtonIo)
	ON_BN_CLICKED(IDC_BUTTON_TERM, &CSetupMenuDlg::OnBnClickedButtonTerm)
	ON_BN_CLICKED(IDC_BUTTON_LOG, &CSetupMenuDlg::OnBnClickedButtonLog)
	ON_WM_SHOWWINDOW()
	ON_BN_CLICKED(IDC_BUTTON_SYSTEM, &CSetupMenuDlg::OnBnClickedButtonSystem)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BUTTON_MULTIORG, &CSetupMenuDlg::OnBnClickedButtonMultiorg)
	ON_BN_CLICKED(IDC_BUTTON_SERVICE, &CSetupMenuDlg::OnBnClickedButtonService)
	ON_WM_TIMER()
	ON_WM_DRAWITEM()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CSetupMenuDlg �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CSetupMenuDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialogListPage::PreTranslateMessage(pMsg);
}

void CSetupMenuDlg::PreInitDialog()
{
	CString strImageFilePath;
	CDC*	pDC = GetDC();
	CRect	rcWnd;

	//////////////////////////////////////////////////////////////////////////
	strImageFilePath.Format( _T("%s\\Background_setup.bmp"), pResourcePath_ );

	MoveWindow(0,0, 1023,619);
	GetClientRect( &rcWnd );

	pCanvasCE_ = new hcutil::CCanvasCE();
	ASSERT(pCanvasCE_ );
	pCanvasCE_->Create( this, pDC->GetSafeHdc(), rcWnd.Width(), rcWnd.Height(), RGB(1, 1, 0) );
	pCanvasCE_->GetCanvasCELayerMgr()->Add( FALSE, RGB(0, 0, 0) );
	pCanvasCE_->GetCanvasCELayerMgr()->Add( TRUE, RGB(255, 0, 255) );

	pCanvasCE_->GetCanvasCELayerMgr()->Get( 0 )->FillSolidRect( rcWnd, pa::CLR_SETUP_MAIN );
	pCanvasCE_->GetCanvasCELayerMgr()->Get( 1 )->LoadImageFormFile( strImageFilePath, CPoint(0, 0), CPoint(rcWnd.Width(), rcWnd.Height()) );
	//////////////////////////////////////////////////////////////////////////

	ReleaseDC( pDC );
	pDC = NULL;

	CDialogListPage::PreInitDialog();
}

BOOL CSetupMenuDlg::OnInitDialog()
{
	CDialogListPage::OnInitDialog();

	//////////////////////////////////////////////////////////////////////////
	// ������ �ʱ�ȭ 
	brhSetupMain_.CreateSolidBrush( pa::CLR_SETUP_MAIN );
	brhTeachingButton_.CreateSolidBrush( pa::CLR_SETUP_TEACHING );
	brhToolButton_.CreateSolidBrush( pa::CLR_SETUP_TOOL );
	brhAutoLoaderButton_.CreateSolidBrush( pa::CLR_SETUP_AUTOLOADER );
	brhOptionButton_.CreateSolidBrush( pa::CLR_SETUP_OPTION );
	brhBackButton_.CreateSolidBrush( pa::CLR_BUTTON_BACK );
	brhIOButton_.CreateSolidBrush( pa::CLR_SETUP_IO );
	brhLogButton_.CreateSolidBrush( pa::CLR_SETUP_LOG );

	//////////////////////////////////////////////////////////////////////////
	// 2016.12.16 
	//	- �𵨿� ���� ��ư�� ���¸� �����Ѵ� 
	// 2020.03.26
	//	- Chairman�� �׻� Disable 
	int nShowAutoLoaderButton = (pa::MODEL_INFO.GetAutoLoaderType() == pa::SModelInfo2::AL_TYPE_NONE) ? SW_HIDE : SW_SHOW;
	int nShowMultiOriginButton= (pa::MODEL_INFO.IsUsingMultiOrigin() == 0 ) ? SW_HIDE : SW_SHOW;
	nShowAutoLoaderButton = SW_HIDE;
	nShowMultiOriginButton= SW_HIDE;
	((CButton*)GetDlgItem(IDC_BUTTON_AUTOLOADER))->ShowWindow( nShowAutoLoaderButton );
	((CButton*)GetDlgItem(IDC_BUTTON_MULTIORG))->ShowWindow( nShowMultiOriginButton );
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	// ��ư ��Ʈ �ʱ�ȭ 
	fntButton_.CreateFont( 
		26, 0, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") );	//_T("Courier New") );

	reposbutton ((CButton*)GetDlgItem(IDC_BUTTON_TEACHING));
	reposbutton ((CButton*)GetDlgItem(IDC_BUTTON_TOOL));
	reposbutton ((CButton*)GetDlgItem(IDC_BUTTON_AUTOLOADER));
	reposbutton ((CButton*)GetDlgItem(IDC_BUTTON_OPTION));
	reposbutton ((CButton*)GetDlgItem(IDC_BUTTON_CLOSE));
	reposbutton ((CButton*)GetDlgItem(IDC_BUTTON_IO));
	reposbutton ((CButton*)GetDlgItem(IDC_BUTTON_TERM));
	reposbutton ((CButton*)GetDlgItem(IDC_BUTTON_LOG));
	reposbutton ((CButton*)GetDlgItem(IDC_BUTTON_SYSTEM));
	reposbutton ((CButton*)GetDlgItem(IDC_BUTTON_MULTIORG));
	reposbutton ((CButton*)GetDlgItem(IDC_BUTTON_SERVICE));

	((CButton*)GetDlgItem(IDC_BUTTON_TEACHING))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_TOOL))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_AUTOLOADER))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_OPTION))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_CLOSE))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_IO))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_TERM))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_LOG))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_SYSTEM))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_MULTIORG))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_SERVICE))->SetFont( &fntButton_, FALSE );

	//////////////////////////////////////////////////////////////////////////
	//
	fntCheckBox_.CreateFont( 
		16, 0, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") );

	reposbutton ((CButton*)GetDlgItem(IDC_CHECK_NO_NDDE_PASSWORD));
	((CButton*)GetDlgItem(IDC_CHECK_NO_NDDE_PASSWORD))->SetFont( &fntCheckBox_, FALSE );

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

//�޴� ��ư ��ġ ����
void CSetupMenuDlg::reposbutton(CButton* Cbuttn)
{
	CRect Cbuttonpos;
	Cbuttn->GetWindowRect( &Cbuttonpos );
	ScreenToClient( &Cbuttonpos );


	int top=Cbuttonpos.top;
	int bottom=Cbuttonpos.bottom;
	int left=Cbuttonpos.left;
	int right=Cbuttonpos.right;
	double newheight=619.0/671;
	double newwidth=1023.0/878;

	int newtop=(int)(top*newheight+0.5);
	int newbottom=(int)(bottom*newheight+0.5);

	int newleft=(int)(left*newwidth+0.5);
	int newright=(int)(right*newwidth+0.5);

	Cbuttn->MoveWindow(newleft,newtop, newright-newleft,newbottom-newtop);
	Cbuttn->GetWindowRect( &Cbuttonpos );
	ScreenToClient( &Cbuttonpos );
}

void CSetupMenuDlg::OnDestroy()
{
	brhSetupMain_.DeleteObject();
	brhTeachingButton_.DeleteObject();
	brhAutoLoaderButton_.DeleteObject();
	brhOptionButton_.DeleteObject();
	brhBackButton_.DeleteObject();
	brhIOButton_.DeleteObject();
	brhLogButton_.DeleteObject();

	fntButton_.DeleteObject();
	fntCheckBox_.DeleteObject();

	if( pCanvasCE_ ) {
		delete pCanvasCE_;
		pCanvasCE_ = NULL;
	}

	CDialogListPage::OnDestroy();
}

void CSetupMenuDlg::OnBnClickedButtonTeaching()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("teaching button click") );
	//////////////////////////////////////////////////////////////////////////
	ASSERT( pWndParent_ );
	pWndParent_->PostMessage( WM_SETUP, (WPARAM)SETUP_TEACHING, (LPARAM)0 );
}

void CSetupMenuDlg::OnBnClickedButtonTool()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("tool button click") );
	//////////////////////////////////////////////////////////////////////////
	ASSERT( pWndParent_ );
	pWndParent_->PostMessage( WM_SETUP, (WPARAM)SETUP_TOOL, (LPARAM)0 );
}

void CSetupMenuDlg::OnBnClickedButtonAutoloader()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("autoloader button click") );
	//////////////////////////////////////////////////////////////////////////
	ASSERT( pWndParent_ );
	pWndParent_->PostMessage( WM_SETUP, (WPARAM)SETUP_AUTOLOADER, (LPARAM)0 );
}

void CSetupMenuDlg::OnBnClickedButtonOption()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("option button click") );
	//////////////////////////////////////////////////////////////////////////
	ASSERT( pWndParent_ );
	pWndParent_->PostMessage( WM_SETUP, (WPARAM)SETUP_OPTION, (LPARAM)0 );
}

void CSetupMenuDlg::OnBnClickedButtonMultiorg()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("option button click") );
	//////////////////////////////////////////////////////////////////////////
	ASSERT( pWndParent_ );
	pWndParent_->PostMessage( WM_SETUP, (WPARAM)SETUP_MULTIORG, (LPARAM)0 );
}

void CSetupMenuDlg::OnBnClickedButtonTerm()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("term. button click") );
	//////////////////////////////////////////////////////////////////////////
	ASSERT( pWndParent_ );
	pWndParent_->PostMessage( WM_SETUP, (WPARAM)SETUP_TERM, (LPARAM)0 );
}

void CSetupMenuDlg::OnBnClickedButtonClose()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("back button click") );
	//////////////////////////////////////////////////////////////////////////
	ASSERT( pWndParent_ );
	pWndParent_->PostMessage( WM_SETUP, (WPARAM)SETUP_EXIT, (LPARAM)0 );
}

void CSetupMenuDlg::OnBnClickedButtonIo()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("i/o button click") );
	//////////////////////////////////////////////////////////////////////////
	ASSERT( pWndParent_ );
	pWndParent_->PostMessage( WM_SETUP, (WPARAM)SETUP_IO, (LPARAM)0 );
}

void CSetupMenuDlg::OnBnClickedButtonLog()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("log button click") );
	//////////////////////////////////////////////////////////////////////////
	ASSERT( pWndParent_ );
	pWndParent_->PostMessage( WM_SETUP, (WPARAM)SETUP_LOG, (LPARAM)0 );
}

#include "PasswordDlg.h"
void CSetupMenuDlg::OnBnClickedButtonSystem()
{
// 	PPNC_IPC_CLIENT->UploadSoftLimit();
// 	Sleep(100);
// 
// 	while( pmac::PState->GetThreadState()->bIpcCmdComplete_ == FALSE ) {
// 		Sleep(100);
// 	}
// 
// 	double f;
// 	CString str;
// 
// 	for( int i = 0; i<5; i++ ) {
// 		for( int j = 0; j<2; j++ ) {
// 			f = pmac::PState->GetThreadState()->fSoftLimit_[i][j];
// 			str.Format( _T("%d %d -> %.3f\n"), i, j, f );
// 			TRACE( str );
// 		}
// 	}

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("system button click") );
	//////////////////////////////////////////////////////////////////////////
	BOOL b = TRUE;

	if( b ) {
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog( _T("password ok. change setup mode") );
		//////////////////////////////////////////////////////////////////////////
		ASSERT( pWndParent_ );
		pWndParent_->PostMessage( WM_SETUP, (WPARAM)SETUP_SYSTEM, (LPARAM)0 );
	} else {
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog( _T("password fail.") );
		//////////////////////////////////////////////////////////////////////////
	}
	//////////////////////////////////////////////////////////////////////////
}

HBRUSH CSetupMenuDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogListPage::OnCtlColor(pDC, pWnd, nCtlColor);

	if( nCtlColor == 4 ) { //CTLCOLOR_DLG ) {
		hbr = (HBRUSH)brhSetupMain_;
	}

	else if( nCtlColor == CTLCOLOR_BTN ) {
		int nBtnID = pWnd->GetDlgCtrlID();
		switch( nBtnID )
		{
		case IDC_BUTTON_TEACHING:
			hbr = (HBRUSH)brhTeachingButton_;
			break;
		case IDC_BUTTON_TOOL:
			hbr = (HBRUSH)brhToolButton_;
			break;
		case IDC_BUTTON_AUTOLOADER:
			hbr = (HBRUSH)brhAutoLoaderButton_;
			break;
		case IDC_BUTTON_OPTION:
			hbr = (HBRUSH)brhOptionButton_;
			break;
		case IDC_BUTTON_CLOSE:
			hbr = (HBRUSH)brhBackButton_;
			break;
		case IDC_BUTTON_IO:
			hbr = (HBRUSH)brhIOButton_;
			break;
		case IDC_BUTTON_LOG:
			hbr = (HBRUSH)brhLogButton_;
			break;
		case IDC_CHECK_NO_NDDE_PASSWORD:
			hbr = (HBRUSH)brhSetupMain_;
			break;
		case IDC_BUTTON_MULTI_ORIGIN:
			hbr = (HBRUSH)brhSetupMain_;
			break;
		default:
			hbr = (HBRUSH)brhSetupMain_;
			break;
		}
	}
	else {
		pDC->SetBkMode( TRANSPARENT );
		hbr = (HBRUSH)brhSetupMain_;
	}

	return hbr;
}

void CSetupMenuDlg::OnBnClickedCheckNoNddePassword()
{
	theApp.bNoNeedEnterPassword_ = ((CButton *)GetDlgItem(IDC_CHECK_NO_NDDE_PASSWORD))->GetCheck();
	pa::PPAStatus->GetThreadState()->bNoNeedPassword = theApp.bNoNeedEnterPassword_;
	//////////////////////////////////////////////////////////////////////////
	// log
	CString strLog;
	strLog.Format( _T("no need password click (%s)"), theApp.bNoNeedEnterPassword_==TRUE ? "True" : "False" );
	writeLog( strLog );
	//////////////////////////////////////////////////////////////////////////
}

void CSetupMenuDlg::writeLog( LPCTSTR log_msg )
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	WriteLog( CLog::TYPE_OPER, 2, log_msg );
	//////////////////////////////////////////////////////////////////////////
}

void CSetupMenuDlg::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CDialogListPage::OnShowWindow(bShow, nStatus);

}


void CSetupMenuDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	if( pCanvasCE_ ) {
		pCanvasCE_->Draw( dc.m_hDC, dc.m_ps.rcPaint );
	}
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

// Service Dialog�� ����, ���� �õ� 
#include "MaxxLinkServiceDlg.h"
void CSetupMenuDlg::OnBnClickedButtonService()
{
	CMaxxLinkServiceDlg dlg;
	dlg.DoModal();
}

//////////////////////////////////////////////////////////////////////////
// 1. Connect �Ǿ� ������, Service��ư�� disable ��Ų�� 
void CSetupMenuDlg::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 1 )
	{
		KillTimer( 1 );

		update_service_button_state();

		if( IsWindowVisible() )
		{
			SetTimer( 1, 200, NULL );
		}
	}

	CDialogListPage::OnTimer(nIDEvent);
}

void CSetupMenuDlg::update_service_button_state()
{
	static int PREV_STATE = -1;
	int curr_state = pa::PPAStatus->GetThreadState()->bIsClientConnected_ ? 1 : 0;

	if( PREV_STATE != curr_state )
	{
		PREV_STATE = curr_state;

		((CButton*)GetDlgItem(IDC_BUTTON_SERVICE))->EnableWindow( (curr_state==1 ? 0 : 1) );
	}
}

void CSetupMenuDlg::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	UINT state;
	CDC dc;
	RECT rctBtn;
	TCHAR buffer[MAX_PATH];           //To store the Caption of the button.
	ZeroMemory(buffer,MAX_PATH );     //Intializing the buffer to zero

	dc.Attach(lpDrawItemStruct->hDC);  // Get the Button DC to CDC
	rctBtn = lpDrawItemStruct->rcItem;     //Store the Button rect to our local rect.
	dc.Draw3dRect(&rctBtn,RGB(191, 191, 191),RGB(191, 191, 191));
	rctBtn.left++;
	rctBtn.top++;
	rctBtn.right--;
	rctBtn.bottom--;

	switch (nIDCtl)
	{
	case IDC_BUTTON_TEACHING:
		dc.FillSolidRect(&rctBtn, pa::CLR_SETUP_TEACHING);   //Setting the Text Background color
		dc.SetBkColor(pa::CLR_SETUP_TEACHING);   //Setting the Text Background color
		break;

	case IDC_BUTTON_TOOL:
		dc.FillSolidRect(&rctBtn, pa::CLR_SETUP_TOOL);   //Setting the Text Background color
		dc.SetBkColor(pa::CLR_SETUP_TOOL);   //Setting the Text Background color
		break;

	case IDC_BUTTON_AUTOLOADER:
		dc.FillSolidRect(&rctBtn, pa::CLR_SETUP_AUTOLOADER);   //Setting the Text Background color
		dc.SetBkColor(pa::CLR_SETUP_AUTOLOADER);   //Setting the Text Background color
		break;

	case IDC_BUTTON_OPTION:
		dc.FillSolidRect(&rctBtn, pa::CLR_SETUP_OPTION);   //Setting the Text Background color
		dc.SetBkColor(pa::CLR_SETUP_OPTION);   //Setting the Text Background color
		break;

	case IDC_BUTTON_CLOSE:
		dc.FillSolidRect(&rctBtn, pa::CLR_BUTTON_BACK);   //Setting the Text Background color
		dc.SetBkColor(pa::CLR_BUTTON_BACK);   //Setting the Text Background color
		break;

	case IDC_BUTTON_IO:
		dc.FillSolidRect(&rctBtn, pa::CLR_SETUP_IO);   //Setting the Text Background color
		dc.SetBkColor(pa::CLR_SETUP_IO);   //Setting the Text Background color
		break;

	case IDC_BUTTON_LOG:
		dc.FillSolidRect(&rctBtn, pa::CLR_SETUP_LOG);   //Setting the Text Background color
		dc.SetBkColor(pa::CLR_SETUP_LOG);   //Setting the Text Background color
		break;

	case IDC_BUTTON_TERM:
	case IDC_BUTTON_MULTIORG:
	case IDC_BUTTON_SYSTEM:
	case IDC_BUTTON_SERVICE:
		dc.FillSolidRect(&rctBtn, pa::CLR_SETUP_MAIN);   //Setting the Text Background color
		dc.SetBkColor(pa::CLR_SETUP_MAIN);   //Setting the Text Background color
		break;
	}

	dc.SetTextColor(RGB(0, 0, 0));     //Setting the Text Color

	state = lpDrawItemStruct->itemState;
	if (state & ODS_SELECTED)
	{
		switch (nIDCtl)
		{
		case IDC_BUTTON_TEACHING:
			dc.FillSolidRect(&rctBtn, RGB( 178, 235, 235 ));   //Setting the Text Background color
			dc.SetBkColor(RGB( 178, 235, 235 ));   //Setting the Text Background color
			break;

		case IDC_BUTTON_TOOL:
			dc.FillSolidRect(&rctBtn, RGB( 189, 235, 182 ));   //Setting the Text Background color
			dc.SetBkColor(RGB( 189, 235, 182 ));   //Setting the Text Background color
			break;

		case IDC_BUTTON_AUTOLOADER:
			dc.FillSolidRect(&rctBtn, RGB( 230, 204, 192 ));   //Setting the Text Background color
			dc.SetBkColor(RGB( 230, 204, 192 ));   //Setting the Text Background color
			break;

		case IDC_BUTTON_OPTION:
			dc.FillSolidRect(&rctBtn, RGB( 235, 178, 235 ));   //Setting the Text Background color
			dc.SetBkColor(RGB( 235, 178, 235 ));   //Setting the Text Background color
			break;

		case IDC_BUTTON_CLOSE:
			dc.FillSolidRect(&rctBtn, RGB( 108, 108, 200 ));   //Setting the Text Background color
			dc.SetBkColor(RGB( 108, 108, 200 ));   //Setting the Text Background color
			break;

		case IDC_BUTTON_IO:
			dc.FillSolidRect(&rctBtn, RGB( 178, 235, 235 ));   //Setting the Text Background color
			dc.SetBkColor(RGB( 178, 235, 235 ));   //Setting the Text Background color
			break;

		case IDC_BUTTON_LOG:
			dc.FillSolidRect(&rctBtn, RGB( 230, 224, 172 ));   //Setting the Text Background color
			dc.SetBkColor(RGB( 230, 224, 172 ));   //Setting the Text Background color
			break;

		case IDC_BUTTON_TERM:
		case IDC_BUTTON_MULTIORG:
		case IDC_BUTTON_SYSTEM:
		case IDC_BUTTON_SERVICE:
			dc.FillSolidRect(&rctBtn, RGB( 200, 200, 200 ));   //Setting the Text Background color
			dc.SetBkColor(RGB( 200, 200, 200 ));   //Setting the Text Background color
			break;
		}
	}

	if (state & ODS_DISABLED)
	{
		dc.FillSolidRect(&rctBtn, pa::CLR_SETUP_MAIN);   //Setting the Text Background color
		dc.SetBkColor(pa::CLR_SETUP_MAIN);   //Setting the Text Background color
		dc.SetTextColor(RGB(131, 131, 131));     //Setting the Text Color
	}

	::GetWindowText(lpDrawItemStruct->hwndItem,buffer,MAX_PATH); //Get the Caption of Button Window 
	dc.DrawText(buffer,&rctBtn,DT_CENTER|DT_VCENTER|DT_SINGLELINE);//Redraw the  Caption of Button Window 
	dc.Detach();  // Detach the Button DC
}
