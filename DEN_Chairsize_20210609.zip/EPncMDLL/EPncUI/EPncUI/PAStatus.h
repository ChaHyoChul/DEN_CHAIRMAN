#pragma once

/** 
 * Pmac ������� �����޸𸮸� �о� �����Ѵ� 
 * Memory Map File�� �����Ѵ� 
 */ 

namespace pa 
{
//////////////////////////////////////////////////////////////////////////

class CPAStatus
{
private:
	hcipc::CSharedMem	*pShMem_;						// 
	SPAStatus			*pPAStatus_;					// ���� �޸𸮸� ���� �Ѵ� 
	BOOL				bUpdateFlag_;					// Reset �� �ѹ��̶� Update ������ TRUE

	hcipc::CSharedMem	*pShMemForThreadState_;			// 
	SThreadState		*pThreadState_;					//

	hcipc::CSharedMem	*pShMemForMultiOrigin_;			// Multi Origin �ɼ� ������
	SMultiOriginData	*pMultiOriginData_;				// 

	hcipc::CSharedMem	*pShMemForAutoCalCoordinateOffsetParam_;
	SAutoCalCoordinateOffsetParam	*pAutoCalCoordinateOffsetParam_;

	hcipc::CSharedMem			*pShMemForAutoTeachToolPocketParam_;
	SAutoTeachToolPocketParam	*pAutoTeachToolPocketParam_;

	hcipc::CSharedMem			*pShMemForAutoTeachMultiOrgParam_;
	SAutoTeachMultiOrgParam		*pAutoTeachMultiOrgParam_;

	hcipc::CSharedMem	*pShMemForAutoCalSingleAbutmentCoordinateOffsetParam_;		// Single Abutment ���� �Ķ��Ÿ 
	SAutoCalSingleAbutmentCoordinateOffsetParam	*pAutoCalSingleAbutmentCoordinateOffsetParam_;

	hcipc::CSharedMem			*pShMemForCoordinateOffsetDataRange_;		// coordinate offset�� ������ �� ����
	SCoordinateOffsetDataRange	*pCoordinateOffsetDataRange_;				//

	hcipc::CSharedMem			*pShMemForMeasureParamEtc_;					//
	SMeasureParamEtc			*pMeasureParamEtc_;							//

public:
	BOOL Initialize( CString& strErrMsg );
	void Destroy();

	//////////////////////////////////////////////////////////////////////////
	//
	void ResetUpdateFlag() { bUpdateFlag_ = FALSE; }
	BOOL GetUpdateFlag() { return bUpdateFlag_; }

	//////////////////////////////////////////////////////////////////////////
	//
// 	void SetNCFileInfo( int nNCFileIndex );									// ThreadState�� NCFileInfo�� index ��° NCFile�� ������ �����Ѵ�. File Open ���·� �����  
// 	void ResetNCFileInfo();													// ThreadState�� NCFileInfo�� ������ �����, File Close ���·� ����� 
// 
// 	void SetNCFileState( pa::EN_NC_FILESTATE state, BOOL bSaveMem );		// ���� ���� NC File�� ���ؼ� �۾�.
// 	void SetNCFileFinish( TCHAR finish, BOOL bSaveMem );					// ���� ������ ���� ���, ����
// 	void SetNCFileTotalLine( int nTotalLine, BOOL bSaveMem );				// 
// 	void SetNCFileMachiningLine( int nMachiningLine, BOOL bSaveMem );		//
// 	void SetNCFileStartTime( BOOL bSaveMem );								// 
// 	void SetNCFileWorkTime( DWORD sec, BOOL bSaveMem );						// 
// 
// 	pa::EN_NC_FILESTATE GetNCFileState();

	//////////////////////////////////////////////////////////////////////////
	//
	SPAStatus* GetPAStatus() { return pPAStatus_; }

	SThreadState* GetThreadState() { return pThreadState_; }				// 

	SMultiOriginData* GetMultiOriginData() { return pMultiOriginData_; }	//

	SAutoCalCoordinateOffsetParam* GetAutoCalCoordinateOffsetParam() { return pAutoCalCoordinateOffsetParam_; }

	SAutoCalSingleAbutmentCoordinateOffsetParam* GetAutoCalSingleAbutmentCoordOffsetParam() { return pAutoCalSingleAbutmentCoordinateOffsetParam_; }

	SAutoTeachMultiOrgParam* GetAutoTeachMultiOrgParam() { return pAutoTeachMultiOrgParam_; }

	SAutoTeachToolPocketParam* GetAutoTeachToolPocketParam() { return pAutoTeachToolPocketParam_; }

	SCoordinateOffsetDataRange* GetCoordinateOffsetDataRange() { return pCoordinateOffsetDataRange_; }

	SMeasureParamEtc* GetMeasureParamEtc() { return pMeasureParamEtc_; }

	// 	void UpdatePAStatus( char* pPAStatus );									// ����� ���¸� ������Ʈ �Ѵ� 

	EN_RUNMODE GetRunMode() { return pThreadState_->hRunMode; }		
	pa::EN_NC_FILESTATE GetNCFileState();

	void SetRunMode( EN_RUNMODE hRunMode ) { 
#ifdef _USE_PMAC_
		pThreadState_->hRunMode = hRunMode; 
#endif
	} 

	void IncRunningTime() {
		pThreadState_->dwRunningTime++;
	}

	void IncFirstHalfRunningTime() {
#ifdef _USE_PA_
		pThreadState_->dwFirstHalfRunningTime++;
#endif
	}

	void IncSecondHalfRunningTime() {
#ifdef _USE_PA_
		pThreadState_->dwSecondHalfRunningTime++;
#endif
	}

	DWORD GetRunningTime() { return pThreadState_->dwRunningTime; }

	//////////////////////////////////////////////////////////////////////////
	//
	void SetIpcCommandComplete( BOOL bComplete ) {
		pThreadState_->bIpcCmdComplete_ = bComplete;
	}
	//////////////////////////////////////////////////////////////////////////

public:
	CPAStatus(void);
	~CPAStatus(void);
};

//////////////////////////////////////////////////////////////////////////
}

