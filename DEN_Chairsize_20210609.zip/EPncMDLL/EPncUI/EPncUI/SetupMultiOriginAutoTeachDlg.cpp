// SetupMultiOriginAutoTeachDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "SetupMultiOriginAutoTeachDlg.h"
#include "NumericInputDlg.h"
#include "SetupMultiOriginDlg.h"
#include "MsgDlg.h"
#include "MsgDlgThread.h"

// CSetupMultiOriginAutoTeachDlg ��ȭ �����Դϴ�.
#define WM_MULTIORG_COMPLETE	(WM_USER+210)

IMPLEMENT_DYNCREATE(CSetupMultiOriginAutoTeachDlg, CDialogListPage)

CSetupMultiOriginAutoTeachDlg::CSetupMultiOriginAutoTeachDlg(CWnd* pParent /*=NULL*/)
	: CDialogListPage(CSetupMultiOriginAutoTeachDlg::IDD, pParent)
{
	pParent_ = NULL;
	nIsPressStopButton_ = -1;
}

CSetupMultiOriginAutoTeachDlg::~CSetupMultiOriginAutoTeachDlg()
{
}

void CSetupMultiOriginAutoTeachDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogListPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_SEL_COORD, cboSelCoord_);
}

void CSetupMultiOriginAutoTeachDlg::StartPageWork()
{
	update_init_control();

	pa::SAutoTeachMultiOrgParam* p = pa::PPAStatus->GetAutoTeachMultiOrgParam();
	memcpy( (void*)&hTempAutoTeachMultiOrgParam_, (void*)p, sizeof(pa::SAutoTeachMultiOrgParam) );

	SetTimer( 1, 500, NULL );
	SetTimer( 2, 100, NULL );

}

void CSetupMultiOriginAutoTeachDlg::StopPageWork()
{
	KillTimer( 1 );
	KillTimer( 2 );
}

void CSetupMultiOriginAutoTeachDlg::UpdatePage()
{

}

// combo ��Ʈ���� ������Ʈ �Ѵ� 
void CSetupMultiOriginAutoTeachDlg::update_init_control()
{
	for( int i = 0; i<10; i++ ) { nIndexToCoordNo_[i] = 0; }

	cboSelCoord_.ResetContent();

	int nNumCoord = pa::PPAStatus->GetMultiOriginData()->nNumGCode;
	CString strData;

	for( int i = 0; i<nNumCoord; i++ )
	{
		int coordno = pa::PPAStatus->GetMultiOriginData()->hMultiOrigin[i].nGcode;
		switch( coordno )
		{
		case 57:
			strData.Format( _T("[H] D-Type [G57]") );
			nIndexToCoordNo_[i] = 57;
			break;
		case 56:
			strData.Format( _T("[H] R-Type [G56]") );
			nIndexToCoordNo_[i] = 56;
			break;
		case 55:
			strData.Format( _T("Single [G55]") );
			nIndexToCoordNo_[i] = 55;
			break;
		case 59:
			strData.Format( _T("[V] D-Type [G59]") );
			nIndexToCoordNo_[i] = 59;
			break;
		case 58:
			strData.Format( _T("[V] R-Type [G58]") );
			nIndexToCoordNo_[i] = 58;
			break;
		default:
			strData.Format( _T("G%d"), coordno );
			nIndexToCoordNo_[i] = 54;
			break;
		}
		cboSelCoord_.AddString( strData );
	}

	cboSelCoord_.SetCurSel( 0 );

	OnCbnSelchangeComboSelCoord();
}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CSetupMultiOriginAutoTeachDlg, CDialogListPage)
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_CTLCOLOR()
	ON_WM_TIMER()
	ON_MESSAGE(WM_NOTIFY_OPTIONDATA_LISTBOX, &CSetupMultiOriginAutoTeachDlg::OnNotifyPointDataListBox)
	ON_BN_CLICKED(IDC_BUTTON_START_STOP, &CSetupMultiOriginAutoTeachDlg::OnBnClickedButtonStartStop)
	ON_BN_CLICKED(IDC_CHECK_RB_1, &CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb1)
	ON_BN_CLICKED(IDC_CHECK_RB_2, &CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb2)
	ON_BN_CLICKED(IDC_CHECK_RB_3, &CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb3)
	ON_CBN_SELCHANGE(IDC_COMBO_SEL_COORD, &CSetupMultiOriginAutoTeachDlg::OnCbnSelchangeComboSelCoord)
	ON_BN_CLICKED(IDC_CHECK_RB_4, &CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb4)
	ON_BN_CLICKED(IDC_CHECK_RB_5, &CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb5)
	ON_BN_CLICKED(IDC_CHECK_RB_6, &CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb6)
	ON_BN_CLICKED(IDC_CHECK_RB_7, &CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb7)
	ON_BN_CLICKED(IDC_CHECK_RB_8, &CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb8)
	ON_BN_CLICKED(IDC_CHECK_RB_9, &CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb9)
	ON_BN_CLICKED(IDC_CHECK_RB_10, &CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb10)
    	ON_MESSAGE(WM_NOTIFY_WINDOW_MOVE,&CSetupMultiOriginAutoTeachDlg::OnWindowMove )
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CSetupMultiOriginAutoTeachDlg �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CSetupMultiOriginAutoTeachDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialogListPage::PreTranslateMessage(pMsg);
}

void CSetupMultiOriginAutoTeachDlg::PreInitDialog()
{

	CDialogListPage::PreInitDialog();
}

BOOL CSetupMultiOriginAutoTeachDlg::OnInitDialog()
{
	CDialogListPage::OnInitDialog();

	//////////////////////////////////////////////////////////////////////////
	// �����츦 ������ ���� ��Ų�� 
	SetWindowPos( &wndTop, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE );
	//////////////////////////////////////////////////////////////////////////

	brhBkgnd_.CreateSolidBrush( RGB(128, 196, 128) );

	fntBtn_.CreateFont(
		28, 0,
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	fntComBo_.CreateFont(
		17, 0,
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	((CButton *)GetDlgItem(IDC_BUTTON_START_STOP))->SetFont( &fntBtn_, TRUE );

	cboSelCoord_.SetFont( &fntComBo_, TRUE );

	//////////////////////////////////////////////////////////////////////////
	//
	CRect rcTemp;

	GetClientRect( &CUIrectSTMOA );
	MoveWindow(0,0,681,500);
	GetClientRect( &rcTemp );

	int		nNumRow = 2;
	CString strRowName[] = { _T("Name"), _T("Value") };
	int		nRowWidth[] = { 260, 140, 90, 90, 90, 90, 90 };		// 420 = 280 + 140

	hcutil::GetControlPos2( IDC_STATIC_TITLE, this, &rcTemp, &CUIrectSTMOA, TRUE );
	pTitleBarWnd_ = new CTitleBarWnd();
	ASSERT( pTitleBarWnd_ );
	pTitleBarWnd_->InitResource( CString(_T("Multi Origin Auto Teaching")), pa::CLR_SETUP_TEACHING, RGB(32, 32, 32), RGB(32, 32, 32), CSize(0, 14) );
	pTitleBarWnd_->InitResourceEx( nNumRow, strRowName, nRowWidth, 24 );
	pTitleBarWnd_->Create( this, rcTemp, IDC_STATIC_TITLE ); //IDC_STATIC_TEACHING_OTION_TITLE_AREA );
	pTitleBarWnd_->SetWindowPos( &wndTop, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE );

	//////////////////////////////////////////////////////////////////////////
	//
	hcutil::GetControlPos2( IDC_STATIC_LIST_AREA, this, &rcTemp, &CUIrectSTMOA, TRUE );

	pParamListBox_ = new COptionDataListBox();
	pParamListBox_->SetBackgroundColor( RGB(180, 180, 180) );
	pParamListBox_->SetFontSize( 0, 15 );
	pParamListBox_->SetItemHeight( 30 );
	pParamListBox_->SetItemWidth( nNumRow, nRowWidth );
	pParamListBox_->SetID( IDC_STATIC_LIST_AREA );
	pParamListBox_->Create( WS_CHILD|WS_VISIBLE, rcTemp, this, IDC_STATIC_LIST_AREA );

	for( int i = 0; i<(int)pa::SAutoTeachMultiOrgParam::PARAM_NUM; i++ )
	{
		int index = pParamListBox_->AddString( pa::SAutoTeachMultiOrgParam::STR_PARAM_NAME[i] );
//		void *p = &(pa::PPAStatus->GetAutoTeachMultiOrgParam()->fParam[i]);
		void *p = &(hTempAutoTeachMultiOrgParam_.fParam[i]);
		pParamListBox_->SetItemDataPtr( i, p );
	}

	CRect recbutton;
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_START_STOP), this, &recbutton, &CUIrectSTMOA);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_RB_1), this, &recbutton, &CUIrectSTMOA);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_RB_2), this, &recbutton, &CUIrectSTMOA);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_RB_3), this, &recbutton, &CUIrectSTMOA);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_RB_4), this, &recbutton, &CUIrectSTMOA);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_RB_5), this, &recbutton, &CUIrectSTMOA);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_RB_6), this, &recbutton, &CUIrectSTMOA);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_RB_7), this, &recbutton, &CUIrectSTMOA);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_RB_8), this, &recbutton, &CUIrectSTMOA);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_RB_9), this, &recbutton, &CUIrectSTMOA);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_RB_10), this, &recbutton, &CUIrectSTMOA);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_TOUCH_SIGNAL2), this, &recbutton, &CUIrectSTMOA);

	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_MSG_1), this, &recbutton, &CUIrectSTMOA);
	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_NUM_ROUNDBAR), this, &recbutton, &CUIrectSTMOA);
	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_G), this, &recbutton, &CUIrectSTMOA);

	hcutil::reposcombo( (CComboBox*)GetDlgItem(IDC_COMBO_SEL_COORD), this, &recbutton, &CUIrectSTMOA);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CSetupMultiOriginAutoTeachDlg::OnDestroy()
{
	brhBkgnd_.DeleteObject();
	fntBtn_.DeleteObject();
	fntComBo_.DeleteObject();

	if( pTitleBarWnd_ ) {
		pTitleBarWnd_->DestroyWindow();
		delete pTitleBarWnd_;
		pTitleBarWnd_ = NULL;
	}

	if( pParamListBox_ ) {
		pParamListBox_->DestroyWindow();
		delete pParamListBox_;
		pParamListBox_ = NULL;
	}

	CDialogListPage::OnDestroy();
}

void CSetupMultiOriginAutoTeachDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting
}

HBRUSH CSetupMultiOriginAutoTeachDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogListPage::OnCtlColor(pDC, pWnd, nCtlColor);

	if( nCtlColor == 4 ) {
		hbr = (HBRUSH)brhBkgnd_;
	}
	else {
		UINT nCtrlID = pWnd->GetDlgCtrlID();
		switch( nCtrlID )
		{
		case IDC_STATIC_MSG_1:				// IDC_STATIC_MSG_1
		case IDC_STATIC_NUM_ROUNDBAR:
			pDC->SetBkMode( TRANSPARENT );
		case IDC_CHECK_TOUCH_SIGNAL:
		case IDC_STATIC_G:
		case IDC_CHECK_TOUCH_SIGNAL2:
		case IDC_CHECK_RB_1:
		case IDC_CHECK_RB_2:
		case IDC_CHECK_RB_3:
		case IDC_CHECK_RB_4:
		case IDC_CHECK_RB_5:
		case IDC_CHECK_RB_6:
		case IDC_CHECK_RB_7:
		case IDC_CHECK_RB_8:
		case IDC_CHECK_RB_9:
		case IDC_CHECK_RB_10:
			hbr = (HBRUSH)brhBkgnd_;
			break;
		}
	}

	return hbr;
}

void CSetupMultiOriginAutoTeachDlg::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 1 )
	{
		KillTimer( 1 );

		update_control_state();

		if( pa::PPAStatus->GetRunMode() == pa::RUNMODE_RUN )
		{
			// Run ����� ��쿡��, CheckBox ���¸� �����Ѵ� 
			updateCheckBoxState();
		}

		if( IsWindowVisible() ) 
		{
			SetTimer( 1, 250, NULL );
		}
	}
	else if( nIDEvent == 2 )
	{
		KillTimer( 2 );

		if( IsWindowVisible() )
		{
			SetTimer( 2, 1000, NULL );
		}
	}

	CDialogListPage::OnTimer(nIDEvent);
}

// AutoTeach MultiOrigin�� 56000 ���� 60000���� step ��ȣ ��� 
void CSetupMultiOriginAutoTeachDlg::update_control_state()
{
	static int PREV_IS_STOP_MODE = -1;
	int is_stop_mode = (pa::PPAStatus->GetRunMode() == pa::RUNMODE_STOP) ? 1 : 0;
	int nCtrlID[] = { 
		IDC_COMBO_SEL_COORD, 
		IDC_CHECK_RB_1, IDC_CHECK_RB_2, IDC_CHECK_RB_3, 
		IDC_CHECK_RB_4, IDC_CHECK_RB_5, IDC_CHECK_RB_6,
		IDC_CHECK_RB_7, IDC_CHECK_RB_8, IDC_CHECK_RB_9,
		IDC_CHECK_RB_10
	};

	//////////////////////////////////////////////////////////////////////////
	//
	if( PREV_IS_STOP_MODE != is_stop_mode )
	{
		PREV_IS_STOP_MODE = is_stop_mode;
		for( int i = 0; i<11; i++ ) {
			((CButton *)GetDlgItem(nCtrlID[i]))->EnableWindow( PREV_IS_STOP_MODE );
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// touch signal 
	int prev_touch_signal = ((CButton*)GetDlgItem(IDC_CHECK_TOUCH_SIGNAL2))->GetCheck();

#ifdef _IO_MAP_VER1_
	int curr_touch_signal = pmac::PState->GetPmacState()->nIn04_AutoCalibration_TouchSignal;
#endif 
#ifdef _IO_MAP_VER2_
	int curr_touch_signal = pmac::PState->GetPmacState()->nIn04_AutoCalibration_TouchSignal;
#endif

#ifdef _PA_G2400_
	int curr_touch_signal = pa::PPAStatus->GetPAStatus()->bInput[];
#endif 
#ifdef _PA_G1600_
	int curr_touch_signal = pa::PPAStatus->GetPAStatus()->bInput[pa::IN10003_AutoCalibrationLeft];
#endif

	if( prev_touch_signal != curr_touch_signal ) 
	{
		((CButton*)GetDlgItem(IDC_CHECK_TOUCH_SIGNAL2))->SetCheck( curr_touch_signal );
	}

	//////////////////////////////////////////////////////////////////////////
	// 
	//////////////////////////////////////////////////////////////////////////
	// run button state 
	// step ��ȣ 56000~ 60000�̸� auto teaching for coordinate offset 
	//	- start		: stop ����� ��,  
	//	- stop		: run ����̰�, 50000 ~ 52000 �� ��,
	//	- disable	: 

	static int PREV_BTN_MODE	= -1;	// 0:stop, 1:start
	static int PREV_BTN_ENABLE	= -1;	// 0:disable, 1:enable
	int curr_btn_mode	= 0;
	int curr_btn_enable	= 0;
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetRunMode();
	int run_step = pa::PPAStatus->GetThreadState()->nRunMode_StepNo;	// >= 50000
	int axis_num = pa::MODEL_INFO.GetNumAxis();

	if( axis_num == 4 || axis_num == 5 ) {
		if( hRunMode == pa::RUNMODE_STOP ) {
			// start ��ư 
			curr_btn_mode = 1;
			curr_btn_enable = 1;
		}
		else if( hRunMode == pa::RUNMODE_RUN ) {
			if( run_step >= 56000 && run_step < 60000 ) {
				// stop ��ư 
				curr_btn_mode = 0;
				curr_btn_enable = 1;
			} else {
				// disable 
				curr_btn_mode = 0;
				curr_btn_enable = 0;
			}
		}
		else {
			// disable 
			curr_btn_mode = 0;
			curr_btn_enable = 0;
		}
	}
	else {
		// disable 
		curr_btn_mode = 0;
		curr_btn_enable = 0;
	}

	if( PREV_BTN_MODE != curr_btn_mode ) {
		PREV_BTN_MODE = curr_btn_mode;
		if( PREV_BTN_MODE == 0 ) 
		{
			((CButton*)GetDlgItem(IDC_BUTTON_START_STOP))->SetWindowText( _T("Stop") );
		}
		else
		{
			((CButton*)GetDlgItem(IDC_BUTTON_START_STOP))->SetWindowText( _T("Start") );

			if( nIsPressStopButton_ == 0 )
			{
#ifdef _WRITE_LOG_PA_COMMAND_
				// �ٽ� ���� 
				((CButton*)GetDlgItem(IDC_CHECK_RB_1))->SetCheck( 1 );
				((CButton*)GetDlgItem(IDC_CHECK_RB_2))->SetCheck( 1 );
				((CButton*)GetDlgItem(IDC_CHECK_RB_3))->SetCheck( 1 );
				OnBnClickedButtonStartStop();
#else 
				// �Ϸ� �޽��� �ڽ�
				TRACE( _T("Auto Teaching Complete !!!\n") );
				CString strMsg;
				strMsg.Format( _T("Auto Teaching Complete !!!") );
				CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_INFO, strMsg );
				CMsgDlgThread::GetInstance()->Wait();	
#endif
				if( pParent_ != NULL ) {
					pParent_->SendMessage( WM_MULTIORG_COMPLETE, 0, 0 );
				}
			}
		}
	} 
	//	if( PREV_BTN_ENABLE != curr_btn_enable ) 
	{
		PREV_BTN_ENABLE = curr_btn_enable;
		((CButton*)GetDlgItem(IDC_BUTTON_START_STOP))->EnableWindow( PREV_BTN_ENABLE );
	}
}

LRESULT CSetupMultiOriginAutoTeachDlg::OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam)
{
	CNumericInputDlg dlg;
	int		nCurSel		= LOWORD( lparam );		// low  word
	int		nCurSelItem = HIWORD( lparam );		// high word

	//////////////////////////////////////////////////////////////////////////
	// 2017.04.28 
	switch( nCurSel )
	{
	case pa::SAutoTeachMultiOrgParam::PARAM_TOOL_NO:
	case pa::SAutoTeachMultiOrgParam::PARAM_TOOL_DIAMETER:
		break;
	default:
		return 0;
	}
	//////////////////////////////////////////////////////////////////////////

	if( pa::GET_CURRENT_USERMODE() < pa::USER_MODE_RND )
	{
		return 0;
	}

	dlg.SetIsFloatType( TRUE );
	dlg.SetPrevNumber( hTempAutoTeachMultiOrgParam_.fParam[nCurSel] );
	//	dlg.SetProperty( CNumericInputDlg::PROPERTY_CALC_BUTTON );
	dlg.SetProperty( 0 );

	if( dlg.DoModal() == IDOK ) 
	{
		double fVal = hcutil::ToDouble( (TCHAR*)(LPCTSTR)dlg.GetNumber(), FALSE );

		//////////////////////////////////////////////////////////////////////////
		// 2017.04.28 ����Ÿ Ȯ�� 
		{
			BOOL	bRet = TRUE;
			CString strErrMsg;
			switch( nCurSel )
			{
			case pa::SAutoTeachMultiOrgParam::PARAM_TOOL_NO:
				// �� ��ȣ�� ����� �� �ִ��� Ȯ�� 
				// Auto Teaching�� ���, 0�� ���� �����Ѵ� 
				bRet = pa::PPAStatus->GetMeasureParamEtc()->CheckToolNo( FALSE, (int)fVal, strErrMsg );
				break;
			case pa::SAutoTeachMultiOrgParam::PARAM_TOOL_DIAMETER:
				// �� �β� Ȯ��
				bRet = pa::PPAStatus->GetMeasureParamEtc()->CheckToolDiameter( FALSE, fVal, strErrMsg );
				break;
			}

			if( bRet == FALSE )
			{
				// ������ ���� 
				CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strErrMsg );
				CMsgDlgThread::GetInstance()->Wait();

				return 0;
			}
		}
		//////////////////////////////////////////////////////////////////////////

		if( nCurSel >= pa::SAutoTeachMultiOrgParam::PARAM_MOVESPEED_FOR_MEAS_POS )
		{
			if( fVal < 1.0 )
			{
				fVal = 1.0;
			}
			else if( fVal > 100.0 ) 
			{
				fVal = 100.0;
			}
		}

		hTempAutoTeachMultiOrgParam_.fParam[nCurSel] = fVal;

		// Modify ���� ���� ���� 
		((CSetupMultiOriginDlg*)GetParent())->SetModifyAutoTeach( TRUE );
	}

	return 0;
}

// original �� temp�� ���� 
void CSetupMultiOriginAutoTeachDlg::Copy_to_Temp()
{
	pa::SAutoTeachMultiOrgParam* p = pa::PPAStatus->GetAutoTeachMultiOrgParam();
	memcpy( (void*)&hTempAutoTeachMultiOrgParam_, (void*)p, sizeof(pa::SAutoTeachMultiOrgParam) );
	pParamListBox_->Invalidate();
}

// temp�� original�� ���� 
void CSetupMultiOriginAutoTeachDlg::Copy_to_Original()
{
	pa::SAutoTeachMultiOrgParam* p = pa::PPAStatus->GetAutoTeachMultiOrgParam();
	memcpy( (void*)p, (void*)&hTempAutoTeachMultiOrgParam_, sizeof(pa::SAutoTeachMultiOrgParam) );
	pParamListBox_->Invalidate();
}

void CSetupMultiOriginAutoTeachDlg::writeLog( LPCTSTR log_msg )
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	WriteLog( CLog::TYPE_OPER, 3, log_msg );
	//////////////////////////////////////////////////////////////////////////
}

void CSetupMultiOriginAutoTeachDlg::OnBnClickedButtonStartStop()
{
	UINT nIDs[] = {
		IDC_CHECK_RB_1, IDC_CHECK_RB_2, IDC_CHECK_RB_3,
		IDC_CHECK_RB_4, IDC_CHECK_RB_5, IDC_CHECK_RB_6,
		IDC_CHECK_RB_7, IDC_CHECK_RB_8, IDC_CHECK_RB_9,
		IDC_CHECK_RB_10
	};
	CString strBtn;
	CString strMsg;

	((CButton*)GetDlgItem(IDC_BUTTON_START_STOP))->GetWindowText( strBtn );

	if( strBtn == CString( _T("Start") ) ) 
	{
#ifdef _WRITE_LOG_PA_COMMAND_
		CMsgDlg::EN_RET ret = CMsgDlg::RET_OK;
#else 
		strMsg.Format( _T("do you want to start auto teaching ?") );
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
		CMsgDlg::EN_RET ret = CMsgDlgThread::GetInstance()->Wait();
#endif
		if( ret == CMsgDlg::RET_OK )
		{
			nIsPressStopButton_ = 0;

			int nCoordIndex = cboSelCoord_.GetCurSel();			// ComboBox���� ����ڰ� ������ ��ǥ�� �ε���		(0, 1, 2, 3, ...)
			int nCoordNo	= nIndexToCoordNo_[nCoordIndex];	// ��ǥ�� �ε����� Coordinate ��ǥ�� ��ȣ�� �ٲ� �� (G57, G56, G55, G59, G54 ...)
			int nNumRoundBar = pa::PPAStatus->GetMultiOriginData()->hMultiOrigin[nCoordIndex].nNumSubCoord;

			// 			pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_CoordinateNo	= nCoordIndex;
			pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_CoordIndex		= nCoordIndex;
			pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_CoordinateNo	= nCoordNo;
			pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_NumRoundBar		= pa::PPAStatus->GetMultiOriginData()->hMultiOrigin[nCoordIndex].nNumSubCoord;

			// pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[0]	= ((CButton*)GetDlgItem(IDC_CHECK_RB_1))->GetCheck();
			// pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[1]	= ((CButton*)GetDlgItem(IDC_CHECK_RB_2))->GetCheck();
			// pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[2]	= ((CButton*)GetDlgItem(IDC_CHECK_RB_3))->GetCheck();
			for( int i = 0; i<10; i++ ) {
				pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[i]	= 0;
			}
			for( int i = 0; i<nNumRoundBar; i++ ) {
				pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[i]	= ((CButton*)GetDlgItem(nIDs[i]))->GetCheck();
			}

			PPNC_IPC_CLIENT->Start_AutoTeach_MultiOrigin();
		}
	}
	else if( strBtn == CString( _T("Stop") ) )
	{
		strMsg.Format( _T("do you want to stop auto teaching ?") );
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
		CMsgDlg::EN_RET ret = CMsgDlgThread::GetInstance()->Wait();

		if( ret == CMsgDlg::RET_OK )
		{
			nIsPressStopButton_ = 1;

			pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_CoordinateNo	= 0;
			pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_NumRoundBar		= 0;
			//pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[0]	= 0;
			//pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[1]	= 0;
			//pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[2]	= 0;
			for( int i = 0; i<10; i++ ) {
				pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[i]	= 0;
			}

			PPNC_IPC_CLIENT->Stop_AutoTeach_MultuOrigin();
		}
	}
}

void CSetupMultiOriginAutoTeachDlg::updateCheckBoxState()
{
	static int PREV_SEL_MULTIORG[10] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
	int nID_CHECKBOX[10] = { 
		IDC_CHECK_RB_1, IDC_CHECK_RB_2, IDC_CHECK_RB_3, 
		IDC_CHECK_RB_4, IDC_CHECK_RB_5, IDC_CHECK_RB_6,
		IDC_CHECK_RB_7, IDC_CHECK_RB_8, IDC_CHECK_RB_9,
		IDC_CHECK_RB_10
	};
	int nCoordIndex		= cboSelCoord_.GetCurSel();
	int nNumRoundBar	= pa::PPAStatus->GetMultiOriginData()->hMultiOrigin[nCoordIndex].nNumSubCoord;

	for( int i = 0; i<nNumRoundBar; i++ )
	{
		if( PREV_SEL_MULTIORG[i] != pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[i] )
		{
			PREV_SEL_MULTIORG[i] = pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[i];
			((CButton*)GetDlgItem(nID_CHECKBOX[i]))->SetCheck( PREV_SEL_MULTIORG[i] );
		}
	}
}

void CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb1()
{
	pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[0]	= ((CButton*)GetDlgItem(IDC_CHECK_RB_1))->GetCheck();
}

void CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb2()
{
	pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[1]	= ((CButton*)GetDlgItem(IDC_CHECK_RB_2))->GetCheck();
}

void CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb3()
{
	pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[2]	= ((CButton*)GetDlgItem(IDC_CHECK_RB_3))->GetCheck();
}

void CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb4()
{
	pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[3]	= ((CButton*)GetDlgItem(IDC_CHECK_RB_4))->GetCheck();
}

void CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb5()
{
	pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[4]	= ((CButton*)GetDlgItem(IDC_CHECK_RB_5))->GetCheck();
}

void CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb6()
{
	pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[5]	= ((CButton*)GetDlgItem(IDC_CHECK_RB_6))->GetCheck();
}


void CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb7()
{
	pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[6]	= ((CButton*)GetDlgItem(IDC_CHECK_RB_7))->GetCheck();
}

void CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb8()
{
	pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[7]	= ((CButton*)GetDlgItem(IDC_CHECK_RB_8))->GetCheck();
}

void CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb9()
{
	pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[8]	= ((CButton*)GetDlgItem(IDC_CHECK_RB_9))->GetCheck();
}

void CSetupMultiOriginAutoTeachDlg::OnBnClickedCheckRb10()
{
	pa::PPAStatus->GetThreadState()->nAutoTeach_MultiOrigin_Sel_RoundBar[9]	= ((CButton*)GetDlgItem(IDC_CHECK_RB_10))->GetCheck();
}

// 2016.10.12 
// ���õ� coordinate �� ����, checkbox ���¸� �ٲ۴� 
void CSetupMultiOriginAutoTeachDlg::OnCbnSelchangeComboSelCoord()
{
	UINT nIDs[] = {
		IDC_CHECK_RB_1, IDC_CHECK_RB_2, IDC_CHECK_RB_3,
		IDC_CHECK_RB_4, IDC_CHECK_RB_5, IDC_CHECK_RB_6,
		IDC_CHECK_RB_7, IDC_CHECK_RB_8, IDC_CHECK_RB_9,
		IDC_CHECK_RB_10
	};
	int nSel = cboSelCoord_.GetCurSel();
	int nNumCoord = pa::PPAStatus->GetMultiOriginData()->nNumGCode;
	int nNumRoundBar = pa::PPAStatus->GetMultiOriginData()->hMultiOrigin[nSel].nNumSubCoord;

	/*
	switch( nSel )
	{
	case 0:	// G57 [Multi]
	case 1:	// G56 [Analog]
		((CButton*)GetDlgItem(IDC_CHECK_RB_1))->ShowWindow( SW_SHOW );
		((CButton*)GetDlgItem(IDC_CHECK_RB_2))->ShowWindow( SW_SHOW );
		((CButton*)GetDlgItem(IDC_CHECK_RB_3))->ShowWindow( SW_SHOW );
		break;
	case 2:	// G55 [Single]
		((CButton*)GetDlgItem(IDC_CHECK_RB_1))->ShowWindow( SW_SHOW );
		((CButton*)GetDlgItem(IDC_CHECK_RB_2))->ShowWindow( SW_HIDE );
		((CButton*)GetDlgItem(IDC_CHECK_RB_3))->ShowWindow( SW_HIDE );
		break;
	}
	*/
//	for( int i = 0; i<6; i++ )
	for( int i = 0; i<10; i++ )
	{
		if( i < nNumRoundBar ) {
			((CButton*)GetDlgItem(nIDs[i]))->ShowWindow( SW_SHOW );
		} else {
			((CButton*)GetDlgItem(nIDs[i]))->ShowWindow( SW_HIDE );
		}
	}
}

LRESULT CSetupMultiOriginAutoTeachDlg::OnWindowMove(WPARAM wparam, LPARAM lparam)
{
    LPPOINT ChangedPos=(LPPOINT)lparam;
    MoveWindow(ChangedPos->x+10,ChangedPos->y+149+10+7, 681,492);   

    return 0;
}
