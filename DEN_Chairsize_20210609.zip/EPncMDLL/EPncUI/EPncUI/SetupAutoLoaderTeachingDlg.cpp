// SetupAutoLoaderTechingDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "SetupAutoLoaderTeachingDlg.h"
#include "NumericInputDlg.h"

// CSetupAutoLoaderTechingDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNCREATE(CSetupAutoLoaderTeachingDlg, CDialogListPage)

CSetupAutoLoaderTeachingDlg::CSetupAutoLoaderTeachingDlg(CWnd* pParent /*=NULL*/)
	: CDialogListPage(CSetupAutoLoaderTeachingDlg::IDD, pParent)
{

}

CSetupAutoLoaderTeachingDlg::~CSetupAutoLoaderTeachingDlg()
{
}

void CSetupAutoLoaderTeachingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogListPage::DoDataExchange(pDX);
}

void CSetupAutoLoaderTeachingDlg::StartPageWork()
{
	SetTimer( 2, 100, NULL );

}

void CSetupAutoLoaderTeachingDlg::StopPageWork()
{
	KillTimer( 2 );
}

void CSetupAutoLoaderTeachingDlg::UpdatePage()
{

}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CSetupAutoLoaderTeachingDlg, CDialogListPage)
	ON_WM_DESTROY()
	ON_MESSAGE(WM_NOTIFY_OPTIONDATA_LISTBOX, &CSetupAutoLoaderTeachingDlg::OnNotifyPointDataListBox)
	ON_WM_TIMER()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CSetupAutoLoaderTeachingDlg �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CSetupAutoLoaderTeachingDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialogListPage::PreTranslateMessage(pMsg);
}

BOOL CSetupAutoLoaderTeachingDlg::OnInitDialog()
{
	CDialogListPage::OnInitDialog();

	CRect rcTemp;

	GetClientRect( &CUIrectSAT );
	MoveWindow(0,0,717,437);
	GetClientRect( &rcTemp );

	int		nNumRow = 2;
	CString strRowName[] = { _T("Name"), _T("Value") };
	int		nRowWidth[] = { 360, 120, 90, 90, 90, 90, 90 };

	//////////////////////////////////////////////////////////////////////////

	hcutil::GetControlPos2( IDC_STATIC_AL_TEACHING_AREA, this, &rcTemp, &CUIrectSAT, TRUE );

	pTitleBar_ALTeaching_= new CTitleBarWnd;
	ASSERT( pTitleBar_ALTeaching_ );
	pTitleBar_ALTeaching_->InitResource( CString(_T("AutoLoader Teaching Point")), pa::CLR_SETUP_AUTOLOADER, RGB(32, 32, 32), RGB(32, 32, 32), CSize(8, 16) );
	pTitleBar_ALTeaching_->InitResourceEx( nNumRow, strRowName, nRowWidth, 24 );
	pTitleBar_ALTeaching_->Create( this, rcTemp, IDC_STATIC_AL_TEACHING_AREA );
	pTitleBar_ALTeaching_->SetWindowPos( &wndTop, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE );

	//////////////////////////////////////////////////////////////////////////

	hcutil::GetControlPos2( IDC_STATIC_LB_AREA, this, &rcTemp, &CUIrectSAT, TRUE );

	pTeachingDataListBox_ = new COptionDataListBox();
	ASSERT( pTeachingDataListBox_ );
	pTeachingDataListBox_->SetBackgroundColor( RGB(180, 180, 180) );
	pTeachingDataListBox_->SetFontSize( 8, 16 );
	pTeachingDataListBox_->SetItemHeight( 30 );
	pTeachingDataListBox_->SetItemWidth( nNumRow, nRowWidth );
	pTeachingDataListBox_->SetID( IDC_STATIC_LB_AREA );
	pTeachingDataListBox_->Create( WS_CHILD|WS_VISIBLE, rcTemp, this, IDC_STATIC_LB_AREA );

	//////////////////////////////////////////////////////////////////////////
	//
	for( int i = 0; i<pa::AUTOLOADER_TP_NUM; i++ ) {
		int index = pTeachingDataListBox_->AddString( pa::STR_AUTOLOADER_TEACHING_POINT_NAME[i] );
		void *p = (void*)&(pa::PAutoLoader->pAutoLoaderConfig_->fTeachingPoint_[i]);
		pTeachingDataListBox_->SetItemDataPtr( index, p );
	}
	//////////////////////////////////////////////////////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CSetupAutoLoaderTeachingDlg::OnDestroy()
{
	if( pTitleBar_ALTeaching_ ) {
		pTitleBar_ALTeaching_->DestroyWindow();
		delete pTitleBar_ALTeaching_;
		pTitleBar_ALTeaching_ = NULL;
	}

	if( pTeachingDataListBox_ ) {
		pTeachingDataListBox_->DestroyWindow();
		delete pTeachingDataListBox_;
		pTeachingDataListBox_ = NULL;
	}

	CDialogListPage::OnDestroy();
}

void CSetupAutoLoaderTeachingDlg::update_TeachingDataListBox()
{
	if( pTeachingDataListBox_ ) {
		pTeachingDataListBox_->Invalidate( FALSE );
	}
}

LRESULT CSetupAutoLoaderTeachingDlg::OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam)
{
	CNumericInputDlg dlg;
	int		nCurSel = LOWORD( lparam );			// low word
	int		nCurSelItem = HIWORD( lparam );		// high word

	// ����� ��带 Ȯ�� �Ѵ� 
	if( pa::GET_CURRENT_USERMODE() < pa::USER_MODE_RND )
	{
		return 0;
	}

	dlg.SetIsFloatType( TRUE );
	dlg.SetPrevNumber( pa::PAutoLoader->GetTeachingPoint((pa::EN_AUTOLOADER_TEACHING_POINT)nCurSel) );
	dlg.SetProperty( CNumericInputDlg::PROPERTY_CALC_BUTTON );

	if( dlg.DoModal() == IDOK ) {
//		double fVal = (double)_wtof( (LPCTSTR)dlg.GetNumber() );
		double fVal = hcutil::ToDouble( (wchar_t*)(LPCTSTR)dlg.GetNumber(), FALSE );
		pa::PAutoLoader->SetTeachingPoint((pa::EN_AUTOLOADER_TEACHING_POINT)nCurSel, fVal); 
	}

	update_TeachingDataListBox();

	return 0;
}

void CSetupAutoLoaderTeachingDlg::UpdateTeachingDataListBox()
{
	update_TeachingDataListBox();
}

void CSetupAutoLoaderTeachingDlg::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 2 )
	{
		KillTimer( 2 );

		if( IsWindowVisible() )
		{
			SetTimer( 2, 1000, NULL );
		}
	}

	CDialogListPage::OnTimer(nIDEvent);
}
