// EPncUIDlg2.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "EPncUIDlg2.h"
#include "ErrorDlg.h"
#include "SetupDlg.h"
#include "MsgDlg.h"
#include "MsgDlgThread.h"
#include "FileCopyDlg.h"
#include "RestartDialog.h"
#include "NCFileMgrDlg2.h"
#include "Dbt.h"

//////////////////////////////////////////////////////////////////////////

double CEPncUIDlg2::F_CURRENT_RUN_RATE = 0.0;

//////////////////////////////////////////////////////////////////////////
// CEPncUIDlg2 ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CEPncUIDlg2, CDialog)

CEPncUIDlg2::CEPncUIDlg2(CWnd* pParent /*=NULL*/)
	: CDialog(CEPncUIDlg2::IDD, pParent)
{
	pResourcePath_ = RESOURCE_2_PATH;
	bConnectedUsbMemory_ = FALSE;
	m_brModelInfo.CreateSolidBrush(RGB(255, 255, 255));
	m_brNCFileInfo.CreateSolidBrush(RGB(255, 255, 255));
	bToolButtonPressed_ = FALSE;
	isUSBConnected_ = FALSE;

	for (int i = 0; i<OPER_BTN_NUM; i++)
	{
		pOperButtonsEx_[i] = NULL;
	}
	pNCFileListBoxEx_ = NULL;
	pAutoLoaderStateWnd_ = NULL;

	for (int i = 0; i<STATUS_ICON_NUM; i++)
	{
		pIconWnd_[i] = NULL;
	}

	NewPos = NULL;
}

CEPncUIDlg2::~CEPncUIDlg2()
{
	CMsgDlgThread::GetInstance()->ExitInstance();
}

void CEPncUIDlg2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CEPncUIDlg2, CDialog)
	ON_WM_PAINT()
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_MESSAGE(WM_IMGBUTTONEX2_CLICKED, &CEPncUIDlg2::OnImgButtonExClicked)
	ON_MESSAGE(WM_AUTOLOADER_REFILL, &CEPncUIDlg2::OnAutoLoaderRefill)
	ON_MESSAGE(WM_USB_MEMORY, &CEPncUIDlg2::OnUsbMemory)
	ON_WM_NCHITTEST()
	ON_WM_MOVE()
	ON_WM_CTLCOLOR()
	ON_WM_DEVICECHANGE()
	ON_MESSAGE(WM_EPNCUI_QUIT, &CEPncUIDlg2::OnEPncUIDlgQuit)
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CEPncUIDlg2 �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

void CEPncUIDlg2::PreInitDialog()
{
	CString strImageFilePath;
	CDC*	pDC = GetDC();
	CRect	rcWnd;
	GetClientRect( &CUICRect_m );

	//���α׷� â ũ�⸦ 1024 X 768 ���� (embedded pc�� pc ���� ������/������ �ٸ��� ���ͼ� ������) 
	MoveWindow(100,100, 1024,768);
	GetClientRect( &rcWnd );
	GetWindowRect( &rcWnd );


	hFntStatusTitle_.CreateFont(
		18, 0, 
		0, 0, FW_BOLD, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") );

	hFntStatus_.CreateFont(
		23, 0, 
		0, 0, FW_BOLD, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") );

	hFntRate_.CreateFont( 
		25, 0, 
		0, 0, FW_BOLD, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") );

	hFntNcFile_.CreateFont( 
		28, 0, 
		0, 0, FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Noto Sans") );

	hFntModel_.CreateFont( 
		50, 0, 
		0, 0, FW_SEMIBOLD, //FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("MS Sans Serif") );

	hFntSystemStatus_.CreateFont(
		43, 0, 
		0, 0, FW_NORMAL, //FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Noto Sans") );

	hFntDeviceStatus_.CreateFont(
		26, 0, 
		0, 0, FW_NORMAL, //FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Noto Sans") );

	hFntToolNo_.CreateFont(
		26, 0, 
		0, 0, FW_NORMAL, //FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Noto Sans") );

	hFntSpindleRPM_.CreateFont(
		//47, 0, 
		42, 0,
		0, 0, FW_NORMAL, //FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Noto Sans Light") );

	hFntMillingTime_.CreateFont(
		//77, 0, 
		56, 0, 
		0, 0, FW_NORMAL, //FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Noto Sans Light") );

	hFntProgRate_.CreateFont(
		22, 0, 
		0, 0, FW_SEMIBOLD, //FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Noto Sans") );

	hFntToolTime_.CreateFont(
		32, 0, 
		0, 0, FW_NORMAL, //FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Noto Sans Light") );

	hFntToolStatus_.CreateFont(
		22, 0, 
		0, 0, FW_NORMAL, //FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		DEFAULT_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Noto Sans") );
	init_status_layout();

	strImageFilePath.Format( _T("%s\\Background4.bmp"), pResourcePath_ );

	pCanvasCE_ = new hcutil::CCanvasCE();
	ASSERT(pCanvasCE_ );
	pCanvasCE_->Create( this, pDC->GetSafeHdc(), rcWnd.Width(), rcWnd.Height(), RGB(1, 1, 0) );
	nBackgroundLayerIndex_	= pCanvasCE_->GetCanvasCELayerMgr()->Add( FALSE, RGB(1, 1, 0) );
	nStatusLayerIndex_		= pCanvasCE_->GetCanvasCELayerMgr()->Add( TRUE, RGB(1, 1, 0) );
	ASSERT( nBackgroundLayerIndex_ != -1 );

	pCanvasCE_->GetCanvasCELayerMgr()->Get( nBackgroundLayerIndex_ )->LoadImageFormFile( strImageFilePath, CPoint(0, 0), CPoint(rcWnd.Width(), rcWnd.Height()) );
	//////////////////////////////////////////////////////////////////////////

	ReleaseDC( pDC );
	pDC = NULL;

	//
	hcutil::CCanvasCELayer* pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get(0);
	COLORREF clrPrev = pLayer->SetTextColor( RGB(160, 160, 160) );
	int nPrevMode = pLayer->SetBkMode( TRANSPARENT );
	CFont* pOldFont = (CFont*)pLayer->SelectObject( &hFntStatusTitle_ );
	pLayer->SelectObject( &hFntStatusTitle_ );
	pLayer->SelectObject( pOldFont );
	pLayer->SetBkMode( nPrevMode );
	pLayer->SetTextColor( clrPrev );

	CDialog::PreInitDialog();
}

void CEPncUIDlg2::init_status_layout()
{
	CRect	rcTemp;

	//////////////////////////////////////////////////////////////////////////
	// Progressbar and Rate 
	rcStatusArea_[STATUS_PROG_RATE1].SetRect( 71, 581, 459, 598 ); //206, 585, 780, 592 );			// progress bar

	//////////////////////////////////////////////////////////////////////////
	// 
	CStatic* numSelectedFileCollapseWnd = (CStatic*)GetDlgItem( IDC_STATIC_NUM_SELECTED_FILE_COLLAPSE );
	CStatic* numSelectedFileExpandWnd = (CStatic*)GetDlgItem( IDC_STATIC_NUM_SELECTED_FILE_EXPAND );
	numSelectedFileCollapseWnd->SetFont( &hFntNcFile_, TRUE );
	numSelectedFileExpandWnd->SetFont( &hFntNcFile_, TRUE );
	
	numSelectedFileCollapseWnd->ModifyStyle( 0, SS_CENTER );
	numSelectedFileExpandWnd->ModifyStyle( 0, SS_CENTER );
	
	((CStatic*)GetDlgItem(IDC_STATIC_NUM_SELECTED_FILE_COLLAPSE))->ShowWindow( SW_HIDE );
}

void CEPncUIDlg2::draw_font()
{
	((CStatic*)GetDlgItem(IDC_STATIC_SYSTEM_STATUS))->SetFont(&hFntSystemStatus_, TRUE);
	((CStatic*)GetDlgItem(IDC_STATIC_MILLING_TIME))->SetFont(&hFntMillingTime_, TRUE);
	((CStatic*)GetDlgItem(IDC_STATIC_PROG_RATE))->SetFont(&hFntProgRate_, TRUE);
	((CStatic*)GetDlgItem(IDC_STATIC_TOOL_TIME))->SetFont(&hFntToolTime_, TRUE);
	((CStatic*)GetDlgItem(IDC_STATIC_TOOL_TIME2))->SetFont(&hFntToolTime_, TRUE);

	((CStatic*)GetDlgItem(IDC_STATIC_PA_CONNECTED))->SetFont(&hFntDeviceStatus_, TRUE);
	((CStatic*)GetDlgItem(IDC_STATIC_IO_CONNECTED))->SetFont(&hFntDeviceStatus_, TRUE);
	((CStatic*)GetDlgItem(IDC_STATIC_TOOL_NO))->SetFont(&hFntToolNo_, TRUE);
	((CStatic*)GetDlgItem(IDC_STATIC_TOOL_NO_2))->SetFont(&hFntToolNo_, TRUE);
	((CStatic*)GetDlgItem(IDC_STATIC_SPINDLE_RPM))->SetFont(&hFntSpindleRPM_, TRUE);
	((CStatic*)GetDlgItem(IDC_STATIC_SPINDLE_RPM2))->SetFont(&hFntSpindleRPM_, TRUE);

	((CStatic*)GetDlgItem(IDC_STATIC_TOOL_ERROR))->SetFont(&hFntToolStatus_, TRUE);
	((CStatic*)GetDlgItem(IDC_STATIC_TOOL_ALARM))->SetFont(&hFntToolStatus_, TRUE);
}

BOOL CEPncUIDlg2::OnInitDialog()
{
	CDialog::OnInitDialog();

	//////////////////////////////////////////////////////////////////////////
	// Chairman ���� �����ʴ� �Ķ���� �����
	((CStatic*)GetDlgItem(IDC_STATIC_NUM_SELECTED_FILE_EXPAND))->ShowWindow(SW_HIDE);
	//////////////////////////////////////////////////////////////////////////
	// Font ���� 
	((CStatic*)GetDlgItem(IDC_STATIC_NC_FILE))->SetFont(&hFntNcFile_, TRUE);
	//////////////////////////////////////////////////////////////////////////
	// 
	NewPos = new CPoint();

	CRect rcWnd;
	GetWindowRect(&rcWnd);

	CSplashDlg::SHOW_DLG();
	MoveWindow(-9999, 0, rcWnd.Width(), rcWnd.Height(), FALSE);

	return TRUE;

	//////////////////////////////////////////////////////////////////////////
	// ���� ����ȭ ���� �ʾƵ�, �Ʒ� �Լ��� ������ ���ϵȴ� 
#ifdef __USE_EPNCM_DLL__
	TRACE(_T("<1>\n"));
	int nRet = INITIALIZE_EPNCM_DLL();
	if (nRet == 0)
	{
		// ���� 
		CDialog::OnCancel();
		return FALSE;
	}
	TRACE(_T("<2>\n"));
#endif
	//////////////////////////////////////////////////////////////////////////


	//////////////////////////////////////////////////////////////////////////
	// 
	CString strErrMsg;

	preinitialize_pmac_object( strErrMsg );

	initialize_ErrorDlg();

	CMsgDlgThread::GetInstance();

	initialize_OperButtons();

	initialize_pmac_object( strErrMsg );

	initialize_SetupDlg();

	initialize_NcFileAddDlg();

	initialize_NCFileListBox( strErrMsg );

	DeleteLeftOverNCFiles();

	initialize_AutoLoaderStateWnd( strErrMsg );

	initialize_StatusIconWnd();

	BOOL b1 = pa::PTool->GetEnableToolUsageTime();
	BOOL b2 = pa::PTool->GetEnableRelatedTool();

	draw_font();

	//////////////////////////////////////////////////////////////////////////
	// Version ���
	memset((void*)pa::PPAStatus->GetThreadState()->szUIProgVersion, 0, sizeof(TCHAR)*128);
	_stprintf_s( pa::PPAStatus->GetThreadState()->szUIProgVersion, 
		128,
		_T("%s"),
		theApp.P_VERSION );

#ifdef _SAVE_RUNTIME_UI_
	//	_tcscat( pa::PPAStatus->GetThreadState()->szMotionProgVersion, _T("-SRT") );
	_tcscat( pa::PPAStatus->GetThreadState()->szUIProgVersion, _T("-SRT") );
#endif

	//////////////////////////////////////////////////////////////////////////
	// Start Timer 
	SetTimer( 1, 1000, NULL );		// Button Blicking Timer 
	SetTimer( 2, 1000, NULL );		// Screen State Timer 
	SetTimer( 3, 1000, NULL );		// NcFile Update for Remote Control
	SetTimer( 4, 2000, NULL );		// USB �޸� ���� ���� Ȯ��  
	SetTimer( 5, 200, NULL );
	//////////////////////////////////////////////////////////////////////////

	pAutoLoaderStateWnd_->ShowWindow( SW_HIDE );
	pNCFileListBoxEx_->ShowWindow(SW_HIDE);

	// NC ���� �����Ȳ ������ ����
	pOperButtonsEx_[OPER_BTN_NC_LOADED]->ShowWindow(SW_SHOW);
	pOperButtonsEx_[OPER_BTN_NC_RUNNING]->ShowWindow(SW_HIDE);
	pOperButtonsEx_[OPER_BTN_NC_FINISHED]->ShowWindow(SW_HIDE);

	updateButtonState();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

BOOL CEPncUIDlg2::Splash_Call_Init(int stepNo)
{
	CString strTitle;
	CString strErrMsg;

	switch (stepNo)
	{
	case 0:
	case 1:
	case 2:
		break;

	case 3:
		{
#ifdef __USE_EPNCM_DLL__
			TRACE(_T("<1>\n"));
			int nRet = INITIALIZE_EPNCM_DLL();
			if (nRet == 0)
			{
// 				// Splash ���̾�α׸� �����				
// 				CSplashDlg::DELETE_DLG();
// 			
// 				// Connect Fail ���̾�α׸� ����, 
// 				CConnectErrorDlg dlg;
// 				strTitle.Format(_T("TITLE"));
// 				strErrMsg.Format(_T("MESSAGE"));
// 				dlg.SetTitle( strTitle );
// 				dlg.SetMessage( strErrMsg );
// 				dlg.SetButtonStatus( FALSE );
// 				dlg.DoModal();
// 
// 				// ���α׷��� ���� 
// 				CDialog::OnCancel();
// 				return FALSE;

				CDialog::OnCancel();
				return FALSE;
			}
			TRACE(_T("<2>\n"));
#endif
		}
		break;

	case 4:
		preinitialize_pmac_object( strErrMsg );
		initialize_ErrorDlg();
		break;

	case 5:
		CMsgDlgThread::GetInstance();
		break;

	case 6:
		initialize_OperButtons();
		initialize_pmac_object( strErrMsg );
		break;

	case 7:
		initialize_SetupDlg();
		break;

	case 8:
		initialize_NcFileAddDlg();
		break;

	case 9:
		initialize_NCFileListBox( strErrMsg );		//
		break;

	case 10:
		DeleteLeftOverNCFiles();
		break;

	case 11:
		initialize_AutoLoaderStateWnd( strErrMsg );	//
		initialize_StatusIconWnd();
		break;

	case 12:
		{
			BOOL b1 = pa::PTool->GetEnableToolUsageTime();
			BOOL b2 = pa::PTool->GetEnableRelatedTool();
		}
		break;

	case 13:
		draw_font();
		break;

	case 14:
		//////////////////////////////////////////////////////////////////////////
		// Version ���
		memset((void*)pa::PPAStatus->GetThreadState()->szUIProgVersion, 0, sizeof(TCHAR)*128);
		_stprintf_s( pa::PPAStatus->GetThreadState()->szUIProgVersion, 
			128,
			_T("%s"),
			theApp.P_VERSION );

#ifdef _SAVE_RUNTIME_UI_
		//	_tcscat( pa::PPAStatus->GetThreadState()->szMotionProgVersion, _T("-SRT") );
		_tcscat( pa::PPAStatus->GetThreadState()->szUIProgVersion, _T("-SRT") );
#endif
		break;

	case 15:
		//////////////////////////////////////////////////////////////////////////
		// Start Timer 
		SetTimer( 1, 1000, NULL );		// Button Blicking Timer 
		SetTimer( 2, 1000, NULL );		// Screen State Timer 
		SetTimer( 3, 1000, NULL );		// NcFile Update for Remote Control
		SetTimer( 4, 2000, NULL );		// USB �޸� ���� ���� Ȯ��  
		SetTimer( 5, 200, NULL );

		// NC ���� �����Ȳ ������ ����
		pOperButtonsEx_[OPER_BTN_NC_LOADED]->ShowWindow(SW_SHOW);
		pOperButtonsEx_[OPER_BTN_NC_RUNNING]->ShowWindow(SW_HIDE);
		pOperButtonsEx_[OPER_BTN_NC_FINISHED]->ShowWindow(SW_HIDE);
		updateButtonState();
		break;

	case 16:
		break;

	case 20:
		CenterWindow();
		break;
	}

	return TRUE;
}

void CEPncUIDlg2::OnDestroy()
{
	KillTimer( 1 );
	Sleep(600);

	destroy_AutoLoaderStateWnd();

	destroy_NCFileListBox();

	destroy_pmac_object();

	destroy_OperButtons();

	destroy_ErrorDlg();

	destroy_SetupDlg();

	destroy_NcFileAddDlg();

	destroy_StatusIconWnd();

	hFntStatus_.DeleteObject();

	hFntStatusTitle_.DeleteObject();

	hFntRate_.DeleteObject();

	hFntNcFile_.DeleteObject();

	hFntModel_.DeleteObject();

	hFntSystemStatus_.DeleteObject();

	hFntDeviceStatus_.DeleteObject();

	hFntToolNo_.DeleteObject();

	hFntSpindleRPM_.DeleteObject();

	hFntMillingTime_.DeleteObject();

	hFntProgRate_.DeleteObject();

	hFntToolTime_.DeleteObject();

	m_brModelInfo.DeleteObject();
	
	m_brNCFileInfo.DeleteObject();

	hFntToolStatus_.DeleteObject();

	if( pCanvasCE_ ) {
		delete pCanvasCE_;
		pCanvasCE_ = NULL;
	}

	if (NewPos)
	{
		delete NewPos;
	}

	CDialog::OnDestroy();

	//////////////////////////////////////////////////////////////////////////
	// ���� ����ȭ ���� �ʾƵ�, �Ʒ� �Լ��� ������ ���ϵȴ� 
#ifdef __USE_EPNCM_DLL__
	TRACE(_T("<3>\n"));
	DESTORY_EPNCM_DLL();
	TRACE(_T("<4>\n"));
#endif
	//////////////////////////////////////////////////////////////////////////
}

void CEPncUIDlg2::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	if( pCanvasCE_ ) {
		pCanvasCE_->Draw( dc, dc.m_ps.rcPaint );
	}
}

BOOL CEPncUIDlg2::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialog::PreTranslateMessage(pMsg);
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

void CEPncUIDlg2::initialize_OperButtons()
{
	UINT nID[] = {
		IDC_BUTTON_V2_EMO, IDC_BUTTON_V2_SETUP, IDC_BUTTON_V2_START, IDC_BUTTON_V2_STOP, 
		IDC_BUTTON_V2_OPEN, IDC_BUTTON_V2_READY_POS, IDC_BUTTON_V2_TOOL,
		IDC_BUTTON_PA_CONNECTED, IDC_BUTTON_IO_CONNECTED, IDC_BUTTON_SPINDLE_RPM, IDC_BUTTON_SPINDLE_RPM2, 
		IDC_BUTTON_TOOL_TIME, IDC_BUTTON_TOOL_TIME2, 
		IDC_BUTTON_LOADED, IDC_BUTTON_RUNNING, IDC_BUTTON_FINISHED, 
		IDC_BUTTON_MINIMIZE, IDC_BUTTON_CLOSE,
		IDC_BUTTON_TOOL_ERROR_STATE, IDC_BUTTON_TOOL_ALARM_STATE //IDC_BUTTON_TOOL_ERROR_STATE
	};

	TCHAR	*pBtnImageFile[OPER_BTN_NUM][CImgButtonEx2::IMAGE_NUM] = 
	{
		{
			// EMO
			_T("btn_emo"),			// IMAGE_NORMAL_ENABLE
			_T("btn_emo_d"),		// IMAGE_NORMAL_DISABLE
			_T("btn_emo_p"),		// IMAGE_NORMAL_PRESS
			_T("btn_reset"),		// IMAGE_SELECT_ENABLE
			_T("btn_reset_d"),		// IMAGE_SELECT_DISABLE
			_T("btn_reset_p"),		// IMAFE_SELECT_DISABLE
			_T("btn_reset"),		// IMAGE_BLINK_1
			_T("btn_reset_p"),		// IMAGE_BLINK_2
		},
		{
			// SETUP
			_T("btn_setup"),
			_T("btn_setup_d"),
			_T("btn_setup_p"),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
		},
		{
			// START
			_T("btn_start"),
			_T("btn_start_d"),
			_T("btn_start_p"),
			_T(""),
			_T(""),
			_T(""),
			_T("btn_start"),
			_T("btn_start_p"),
		},
		{
			// STOP
			_T("btn_stop"),
			_T("btn_stop_d"),
			_T("btn_stop_p"),
			_T(""),
			_T(""),
			_T(""),
			_T("btn_stop"),
			_T("btn_stop_p"),
		},
		{
			// OPEN
			_T("btn_open"),
			_T("btn_open_d"),
			_T("btn_open_p"),
			_T("btn_close"),
			_T("btn_close_d"),
			_T("btn_close_p"),
			_T(""),
			_T(""),
		},
		{
			// READY POSITION
			_T("btn_readyposition"),
			_T("btn_readyposition_d"),
			_T("btn_readyposition_p"),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
		},
		{
			// TOOLS
			_T("btn_tools"),
			_T("btn_tools_d"),
			_T("btn_tools_p"),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
		},
		{
			// PA Connected
			_T("icn_connected"),
			_T("icn_connected"),
			_T("icn_connected"),
			_T("icn_disconnected"),
			_T("icn_disconnected"),
			_T("icn_disconnected"),
			_T(""),
			_T(""),
		},
		{
			// IO Connected
			_T("icn_connected"),
			_T("icn_connected"),
			_T("icn_connected"),
			_T("icn_disconnected"),
			_T("icn_disconnected"),
			_T("icn_disconnected"),
			_T(""),
			_T(""),
		},
		{
			// Spindle RPM
			_T("icn_L_spindle_idle"),
			_T("icn_L_spindle_idle"),
			_T("icn_L_spindle_idle"),
			_T("icn_L_spindle_running"),
			_T("icn_L_spindle_running"),
			_T("icn_L_spindle_running"),
			_T(""),
			_T(""),
		},
		{
			// Spindle RPM2
			_T("icn_R_spindle_idle"),
			_T("icn_R_spindle_idle"),
			_T("icn_R_spindle_idle"),
			_T("icn_R_spindle_running"),
			_T("icn_R_spindle_running"),
			_T("icn_R_spindle_running"),
			_T(""),
			_T(""),
		},
		{
			// Tool Time
			_T("icn_tooltime"),
			_T("icn_tooltime"),
			_T("icn_tooltime"),
			_T("icn_tooltime_red"),
			_T("icn_tooltime_red"),
			_T("icn_tooltime_red"),
			_T(""),
			_T(""),
		},
		{
			// Tool Time2
			_T("icn_tooltime"),
			_T("icn_tooltime"),
			_T("icn_tooltime"),
			_T("icn_tooltime_red"),
			_T("icn_tooltime_red"),
			_T("icn_tooltime_red"),
			_T(""),
			_T(""),
		},
		{
			// NC Loaded
			_T("icn_ncfile_loaded"),
			_T("icn_ncfile_loaded"),
			_T("icn_ncfile_loaded"),
			_T("icn_ncfile_loaded"),
			_T("icn_ncfile_loaded"),
			_T("icn_ncfile_loaded"),
			_T(""),
			_T(""),
		},
		{
			// NC Running
			_T("icn_ncfile_running"),
			_T("icn_ncfile_running"),
			_T("icn_ncfile_running"),
			_T("icn_ncfile_running"),
			_T("icn_ncfile_running"),
			_T("icn_ncfile_running"),
			_T(""),
			_T(""),
		},
		{
			// NC Finished
			_T("icn_ncfile_finished"),
			_T("icn_ncfile_finished"),
			_T("icn_ncfile_finished"),
			_T("icn_ncfile_finished"),
			_T("icn_ncfile_finished"),
			_T("icn_ncfile_finished"),
			_T(""),
			_T(""),
		},
		{
			// Program Collapse
			_T("btn_program_collapse"),	// btn_program_close
			_T(""),
			_T("btn_program_collapse_p"),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
		},
		{
			// Program Close
			_T("btn_program_close"),
			_T(""),
			_T("btn_program_close_p"),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
		},
		{
			// Tool Error
			_T("tool_error"),		// IMAGE_NORMAL_ENABLE
			_T("tool_error_d"),		// IMAGE_NORMAL_DISABLE
			_T("tool_error"),		// IMAGE_NORMAL_PRESS
			_T("tool_error_p"),		// IMAGE_SELECT_ENABLE
			_T("tool_error_p"),		// IMAGE_SELECT_DISABLE
			_T("tool_error_p"),		// IMAGE_SELECT_PRESS
			_T(""),					// IMAGE_BLINK_1
			_T(""),					// IMAGE_BLINK_2
		},
		{
			// Tool Alarm 
			_T("tool_error"),		// IMAGE_NORMAL_ENABLE
			_T("tool_error_d"),		// IMAGE_NORMAL_DISABLE
			_T("tool_error"),		// IMAGE_NORMAL_PRESS
			_T("tool_error_p"),		// IMAGE_SELECT_ENABLE
			_T("tool_error_p"),		// IMAGE_SELECT_DISABLE
			_T("tool_error_p"),		// IMAGE_SELECT_PRESS
			_T(""),					// IMAGE_BLINK_1
			_T(""),					// IMAGE_BLINK_2
		}
	};

	CRect	rcButtons[OPER_BTN_NUM];

	for( int i = 0; i<OPER_BTN_NUM; i++ ) {
		CButton* pBtn = (CButton*)GetDlgItem(nID[i]);
		pBtn->GetWindowRect( &rcButtons[i] );
		ScreenToClient( &rcButtons[i] );
		pBtn->DestroyWindow();	

		// ��ġ �� ���� 
		switch (i)
		{
		case OPER_BTN_START:
		case OPER_BTN_STOP:
			rcButtons[i].left	= 0;
			rcButtons[i].top	= 668;
			rcButtons[i].right	= rcButtons[i].left + 256;
			rcButtons[i].bottom	= rcButtons[i].top + 100;
			break;
		case OPER_BTN_OPEN:
			rcButtons[i].left	= 256;
			rcButtons[i].top	= 668;
			rcButtons[i].right	= rcButtons[i].left + 256;
			rcButtons[i].bottom	= rcButtons[i].top + 100;
			break;
		case OPER_BTN_READY_POS:
			rcButtons[i].left	= 512;
			rcButtons[i].top	= 668;
			rcButtons[i].right	= rcButtons[i].left + 256;
			rcButtons[i].bottom	= rcButtons[i].top + 100;
			break;
		case OPER_BTN_TOOLS:
			rcButtons[i].left	= 768;
			rcButtons[i].top	= 668;
			rcButtons[i].right	= rcButtons[i].left + 256;
			rcButtons[i].bottom	= rcButtons[i].top + 100;
			break;
		}
	}
	
	for( int i = 0; i<OPER_BTN_NUM; i++ ) 
	{
		pOperButtonsEx_[i] = new CImgButtonEx2();

		CString strFilePath[CImgButtonEx2::IMAGE_NUM];
		for( int j = 0; j<CImgButtonEx2::IMAGE_NUM; j++ ) {
			strFilePath[j].Format( _T("%s\\%s.bmp"), pResourcePath_, pBtnImageFile[i][j] );
		}

		pOperButtonsEx_[i]->Create( i, this, rcButtons[i], strFilePath );
	}	
}

void CEPncUIDlg2::destroy_OperButtons()
{
	for( int i = 0; i < OPER_BTN_NUM; i++ )
	{
		if( pOperButtonsEx_[i] ) 
		{
			pOperButtonsEx_[i]->DestroyWindow();
			delete pOperButtonsEx_[i];
			pOperButtonsEx_[i] = NULL;
		}
	}
}

BOOL CEPncUIDlg2::preinitialize_pmac_object( CString& strErrMsg )
{
	BOOL bRet = TRUE;

	pa::PSWConfig = new pa::CPSWConfig();
	if( !pa::PSWConfig->Initialzie( strErrMsg ) ) {
		bRet = FALSE;
	}

	// TODO: choose the correct autoloader.
	// 2017.06.21 bychul2 
//	pa::PAutoLoader = new pa::CBlockAutoLoader();
	pa::PAutoLoader = new pa::CPAutoLoader();
	pa::PAutoLoader->Initialize( CString( INI_AL_TEACHING_POINT_PATH ), strErrMsg );

	WriteLog( CLog::TYPE_OPER, 0, _T("<<< Start. EPncUI program >>>" ) );
	WriteLog( CLog::TYPE_OPER, 1, theApp.P_VERSION );

	return bRet;
}

BOOL CEPncUIDlg2::initialize_pmac_object( CString& strErrMsg )
{
	PPNC_IPC_CLIENT = new CPncIpcClient();
	if( !PPNC_IPC_CLIENT->Initialize( strErrMsg ) ) {
		return FALSE;
	}

	pa::PNCFileMgr = new pa::CPNCFileMgr;
	pa::PNCFileMgr->Initialize( strErrMsg );

	pa::PPAStatus = new pa::CPAStatus();
	pa::PPAStatus->Initialize( strErrMsg );

	pa::PTool = new pa::CPTool();
	pa::PTool->Initialize( strErrMsg );

	return TRUE;
}

void CEPncUIDlg2::destroy_pmac_object()
{
	if( pa::PAutoLoader )
	{
		delete pa::PAutoLoader;
		pa::PAutoLoader = NULL;
	}

	if( PPNC_IPC_CLIENT ) {
		delete PPNC_IPC_CLIENT;
		PPNC_IPC_CLIENT = NULL;
	}

	if( pa::PSWConfig ) {
		delete pa::PSWConfig;
		pa::PSWConfig = NULL;
	}

	if( pa::PNCFileMgr ) {
		delete pa::PNCFileMgr;
		pa::PNCFileMgr = NULL;
	}

	if( pa::PPAStatus ) {
		delete pa::PPAStatus;
		pa::PPAStatus = NULL;
	}

	if( pa::PTool ) {
		delete pa::PTool;
		pa::PTool = NULL;
	}
}

// NCFileMgr�� NC ���� ����Ʈ�� ���� �ش� 
BOOL CEPncUIDlg2::initialize_NCFileListBox( CString& strErrMsg )
{
	CRect rcTemp;
	pNCFileListBoxEx_ = new CNCFileListBoxEx();
	ASSERT( pNCFileListBoxEx_ );
	pNCFileListBoxEx_->SetBackgroundColor( RGB(241, 241, 251) );
	pNCFileListBoxEx_->SetFontSize( 0, 18 );
	pNCFileListBoxEx_->SetItemHeight( 44 );
	//pNCFileListBoxEx_->Create( WS_CHILD | WS_VISIBLE, rcTemp, this, IDC_LISTBOX_NCFILE );
	pNCFileListBoxEx_->Create( WS_CHILD, rcTemp, this, IDC_LISTBOX_NCFILE );
	pNCFileListBoxEx_->UpdateFileList();
	pa::PNCFileMgr->RegisterObserver( (pa::INCFileMgrObserver*)pNCFileListBoxEx_ );
	pNCFileListBoxEx_->ShowWindow(SW_HIDE);

	return TRUE;
}

void CEPncUIDlg2::destroy_NCFileListBox()
{
	if( pNCFileListBoxEx_ ) {
		pNCFileListBoxEx_->DestroyWindow();
		delete pNCFileListBoxEx_;
		pNCFileListBoxEx_ = NULL;
	}
}

// BOOL CEPncUIDlg2::initialize_AutoLoaderStateWnd( CString& strErrMsg )
// {
// 	CRect	rcWnd;
// 	
// 	hcutil::GetControlPos( IDC_BUTTON_AL_BLOCK_STATE_AREA, this, &rcWnd, TRUE );
// 
// 	pAutoLoaderStateWnd_ = new CAutoLoaderStateWnd();
// 	pAutoLoaderStateWnd_->Create( this, rcWnd, 20 );
// 
// 	return TRUE;
// }

BOOL CEPncUIDlg2::initialize_AutoLoaderStateWnd( CString& strErrMsg )
{
	CRect	rcWnd;
	// 2016.11.21 
	int nNumBlock = 20; 

	if( pa::PAutoLoader != NULL )
	{
		nNumBlock = pa::PAutoLoader->GetNumBlock();
	}

//	hcutil::GetControlPos2( IDC_BUTTON_AL_BLOCK_STATE_AREA, this, &rcWnd, &CUICRect_m, TRUE );

	pAutoLoaderStateWnd_ = new CAutoLoaderStateWnd();
	pAutoLoaderStateWnd_->Create( this, rcWnd, nNumBlock );
	pAutoLoaderStateWnd_->SetNumBlock( nNumBlock );			// �ʱ�ȭ �� ��, ȭ�鿡 status windows�� �ȳ��ͼ�, �Լ� �߰� ��  
	pAutoLoaderStateWnd_->ShowWindow(SW_HIDE);

	return TRUE;
}

void CEPncUIDlg2::destroy_AutoLoaderStateWnd()
{
	if( pAutoLoaderStateWnd_ ) {
		pAutoLoaderStateWnd_->DestroyWindow();
		delete pAutoLoaderStateWnd_;
		pAutoLoaderStateWnd_ = NULL;
	}
}

BOOL CEPncUIDlg2::initialize_ErrorDlg()
{
	PERROR_DLG = new CErrorDlg();

	PERROR_DLG->Create(IDD_DIALOG_ERROR, NULL );

	PERROR_DLG->ShowWindow( SW_HIDE );

	return TRUE;
}

void CEPncUIDlg2::destroy_ErrorDlg()
{
	if( PERROR_DLG ) 
	{
		PERROR_DLG->DestroyWindow();
		delete PERROR_DLG;
		PERROR_DLG = NULL;
	}
}

BOOL CEPncUIDlg2::initialize_SetupDlg()
{
	PSETUP_DLG = new CSetupDlg();

	PSETUP_DLG->Create( IDD_DIALOG_SETUP, NULL );

	PSETUP_DLG->ShowWindow( SW_HIDE );

	return TRUE;
}

BOOL CEPncUIDlg2::initialize_NcFileAddDlg()
{
	P_NCFILE_MGR_DLG2 = new CNCFileMgrDlg2();
	
	P_NCFILE_MGR_DLG2->Create( IDD_DIALOG_NCFILE_MGR2, NULL );

	PSETUP_DLG->ShowWindow( SW_HIDE );

	return TRUE;
}

void CEPncUIDlg2::destroy_SetupDlg()
{
	if( PSETUP_DLG ) 
	{
		PSETUP_DLG->DestroyWindow();
		delete PSETUP_DLG;
		PSETUP_DLG = NULL;
	}
}

void CEPncUIDlg2::destroy_NcFileAddDlg()
{
	if( P_NCFILE_MGR_DLG2 ) 
	{
		P_NCFILE_MGR_DLG2->DestroyWindow();
		delete P_NCFILE_MGR_DLG2;
		P_NCFILE_MGR_DLG2 = NULL;
	}
}

BOOL CEPncUIDlg2::initialize_StatusIconWnd()
{
	CString strIconImageFilePath[STATUS_ICON_NUM][CIconWnd::STATUS_NUM] = 
	{
		// USB  
		{
			_T("icon_usb.bmp"),
			_T("icon_usb_s.bmp"),
			_T(""),
		},
		// REMOTE 
		{
			_T("icon_remote.bmp"),
			_T("icon_remote_s.bmp"),
			_T(""),
		},
		// BLOCK 
		{
			_T("icon_block.bmp"),
			_T("icon_block_s.bmp"),
			_T(""),
		}
	};

	for( int i = 0; i<(int)STATUS_ICON_NUM; i++ ) {
		for( int j = 0; j<(int)CIconWnd::STATUS_NUM; j++ ) {
			strIconImageFilePath[i][j] = CString( pResourcePath_ ) + CString( _T("\\") ) + strIconImageFilePath[i][j];
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// DS200 �� ������ ������� �ʱ� ������ �����츦 ������ �ʴ´� 
	// DS200-5P�� ������ ����ϱ� ������ �����츦 ����� 
	for( int i = 0; i<(int)(STATUS_ICON_NUM); i++ )
	{
		pIconWnd_[i] = new CIconWnd();
		ASSERT( pIconWnd_[i] );
		pIconWnd_[i]->Create( this, rcStatusIconArea_[i], strIconImageFilePath[i] );
	}
	//////////////////////////////////////////////////////////////////////////

	return TRUE;
}

void CEPncUIDlg2::destroy_StatusIconWnd()
{
	for( int i = 0; i<(int)STATUS_ICON_NUM; i++ ) 
	{
		if( pIconWnd_[i] ) {
			pIconWnd_[i]->DestroyWindow();
			delete pIconWnd_[i];
			pIconWnd_[i] = NULL;
		}
	}
}


//////////////////////////////////////////////////////////////////////////

void CEPncUIDlg2::OnTimer(UINT_PTR nIDEvent)
{
	static BOOL bBLINK_STATE = FALSE;
	static int	PREV_ERROR_MODE = -1;

	if( nIDEvent == 1 ) 
	{
		//////////////////////////////////////////////////////////////////////////
		// Button ���� ���� 
		//////////////////////////////////////////////////////////////////////////
		// Stop Timer 
		KillTimer( 1 );
		// Blink State 
		for( int i = 0; i<OPER_BTN_NUM; i++ ) {
			pOperButtonsEx_[i]->UpdateBlink( bBLINK_STATE );
		}
		bBLINK_STATE = !bBLINK_STATE;
		// Restser Timer 

		// PA Controller�� ���� ����� ��� ��ư disable
		if( pa::PPAStatus->GetThreadState()->nIsConnectedPAController == 0 ) {
			for( int i = 0; i<OPER_BTN_NUM; i++ )
			{
				if (i != OPER_BTN_PROGRAM_COLLAPSE && i != OPER_BTN_PROGRAM_CLOSE)
				{
					pOperButtonsEx_[i]->SetEnable( FALSE );
				}
			}
			return;
		}

		SetTimer( 1, 500, NULL );
	}
	else if( nIDEvent == 2 ) 
	{
		//////////////////////////////////////////////////////////////////////////
		// Screen State Timer 
		//////////////////////////////////////////////////////////////////////////
		// Stop Timer 
		KillTimer( 2 );

		// ��ư ���� 
		updateButtonState();

		// NCFileListBoxEx, NCFileListBoxSimple 
		updateNCFileListBox();

		updateNCFile();

		updateSystemStatus();

		updateDeviceStatus();

		// 2017.07.21. bIsPauseAirLimit_==TRUE �� ��, �޽��� �ڽ��� ���� 
		static int PREV_IS_PAUSE_AIR_LIMIT = -1;
		int curr_is_puase_air_limit = ( pa::PPAStatus->GetThreadState()->bIsPauseAirLimit_ == TRUE ) ? 1 :0;
		if( PREV_IS_PAUSE_AIR_LIMIT != curr_is_puase_air_limit )
		{
			PREV_IS_PAUSE_AIR_LIMIT = curr_is_puase_air_limit;
			if( PREV_IS_PAUSE_AIR_LIMIT == 1 )
			{
				// �˸� �޽����� �����ش�  
				CString strMsg;
				strMsg.Format( _T("Please wait until the air is charged.") );
				CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_WARM, strMsg );
			}
			else 
			{
				// �˸� �޽����� ����� 
				CMsgDlgThread::GetInstance()->Hide();
			}
		}

		// ���� ����� ���, ���� ���̾�α� �ڽ��� ���� 
		int curr_error_mode = ( pa::PPAStatus->GetRunMode() == pa::RUNMODE_ERROR ) ? 1 : 0;
		if( PREV_ERROR_MODE != curr_error_mode ) {
			PREV_ERROR_MODE = curr_error_mode;
			if( PREV_ERROR_MODE != 0 ) {
				//////////////////////////////////////////////////////////////////////////
				// 2017.07.21 
				// is_pause_ait_limit �޽����� �������� ���� ���, �����	
				if( PREV_IS_PAUSE_AIR_LIMIT == 1 )
				{
					PREV_IS_PAUSE_AIR_LIMIT = 0;
					CMsgDlgThread::GetInstance()->Hide();
				}
				//////////////////////////////////////////////////////////////////////////
				PERROR_DLG->SHOW_ERROR_DLG();
			}
		}

		// Pause By Door Open Ȯ�� 
		if( pa::PPAStatus->GetThreadState()->nPauseByDoorOpen == 1 )
		{
			//////////////////////////////////////////////////////////////////////////
			// 2017.07.21 
			// is_pause_ait_limit �޽����� �������� ���� ���, �����	
			if( PREV_IS_PAUSE_AIR_LIMIT == 1 )
			{
				PREV_IS_PAUSE_AIR_LIMIT = 0;
				CMsgDlgThread::GetInstance()->Hide();
			}
			//////////////////////////////////////////////////////////////////////////
			// ���� ���� 
			pa::PPAStatus->GetThreadState()->nPauseByDoorOpen = 0;
			// �˸� �޽��� 
			CString strMsg;
			strMsg.Format( _T("stop by front door open") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_INFO, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
		}

		SetTimer( 2, 100, NULL );
	}
	else if( nIDEvent == 3 ) 
	{
		KillTimer( 3 );

		// update nc file list for remote control
		if( pa::PPAStatus->GetThreadState()->bUpdateNcFileList_ == TRUE ) 
		{
			pa::PNCFileMgr->UpdateNcFileList();
			pa::PPAStatus->GetThreadState()->bUpdateNcFileList_ = FALSE;

			if( pa::PAutoLoader && pa::PAutoLoader->pAutoLoaderConfig_->bUsingAutoLoader ) 
			{
				// AutoLoader�� ���µ� ������Ʈ �Ѵ� 
				if( pAutoLoaderStateWnd_ ) {
					pAutoLoaderStateWnd_->Invalidate( FALSE );
				}
			}
		}
		// update nc file list for sd memory 
		if( pa::PPAStatus->GetThreadState()->bUpdateNcFileListForSD_ == TRUE ) 
		{
			pa::PNCFileMgr->UpdateNcFileListForSD();
			pa::PPAStatus->GetThreadState()->bUpdateNcFileListForSD_ = FALSE;
		}
		// hide error message box
		if( pa::PPAStatus->GetThreadState()->bRemoteReset_ == TRUE )
		{
			if( PERROR_DLG ) {
			//	PERROR_DLG->ShowWindow( SW_HIDE );
				PERROR_DLG->RESET_SHOW_ERROR_DLG();
			}
			pa::PPAStatus->GetThreadState()->bRemoteReset_ = FALSE;
		}
		//
		SetTimer( 3, 1000, NULL );
	}
	else if( nIDEvent == 4 )
	{
		KillTimer( 4 );

		//////////////////////////////////////////////////////////////////////////
		// updateStatus();
		//
		updateMillingTimeDisp();	// �۾� �ð� ���� 
		//
		updateProgressBarStatus();
		//
		updateToolTime();
		//
		updateNCStatus();

		SetTimer( 4, 1000, NULL );
	}

	else if ( nIDEvent == 5 )
	{
		KillTimer( 5 );

		if (pa::PPAStatus->GetPAStatus()->bLCDEMOclicked)
		{
			doButtonEMO();
			pa::PPAStatus->GetPAStatus()->bLCDEMOclicked = FALSE;
		}

		else if (pa::PPAStatus->GetPAStatus()->bLCDReadyposClicked)
		{
			doButtonReadyPos();
			pa::PPAStatus->GetPAStatus()->bLCDReadyposClicked = FALSE;
		}

		SetTimer(5, 200, NULL);
	}

	CDialog::OnTimer(nIDEvent);
}

LRESULT CEPncUIDlg2::OnImgButtonExClicked(WPARAM wparam, LPARAM lparam)
{
	int nID = (int)wparam;

	// Remote Lock ��� �߰� 
	if( pa::PPAStatus->GetThreadState()->bRemoteLock_ == FALSE &&
		pa::PPAStatus->GetThreadState()->bIsShowUserConfirmDlg == FALSE )
	{
		switch( (EN_OPER_BUTTON)nID )
		{
		case OPER_BTN_EMO:
			doButtonEMO();
			break;
		case OPER_BTN_SETUP:
			doButtonSetup();
			break;
		case OPER_BTN_START:
			doButtonRunPause();
			break;
		case OPER_BTN_STOP:
			doButtonStop();
			break;
		case OPER_BTN_OPEN:
			doButtonOpen();
			break;
		case OPER_BTN_READY_POS:
			doButtonReadyPos();
			break;
		case OPER_BTN_PROGRAM_COLLAPSE:
			doButtonProgramCollapse();
			break;
		case OPER_BTN_PROGRAM_CLOSE:
			doButtonProgramClose();
			break;
		case OPER_BTN_TOOLS:
			doButtonTools();
			break;
		}
	}

	return 0;
}

void CEPncUIDlg2::doButtonEMO()
{
	if( pa::PPAStatus->GetThreadState()->nIsConnectedPAController == 0 )
	{
		return;
	}

	if( pa::PPAStatus->GetThreadState()->hRunMode == pa::RUNMODE_ERROR ) 
	{
		TRACE( _T("CEPncUIDlg::doButtonEmoReset(RESET)\n") );
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog(_T("reset button click"));
		//////////////////////////////////////////////////////////////////////////

		PPNC_IPC_CLIENT->ErrorReset();
		
		PERROR_DLG->RESET_SHOW_ERROR_DLG();	

		//////////////////////////////////////////////////////////////////////////
		// servo�� power �Ӽ��� 0�̸�, 1�̵� �� ���� Wait Dialog�� ���� 
		if( pa::PPAStatus->GetPAStatus()->nServoPower == 0 || pa::PPAStatus->GetPAStatus()->nGPLErrorCode != 0 ||
			pa::PPAStatus->GetThreadState()->nIsConnectedPAController == 0 ) 
		{
			DWORD	dwTime = GetTickCount();
			CString strMsg;
			BOOL	bIsErrorReset = TRUE;
			strMsg.Format( _T("Wait until error clear...\n") );
			if( pa::PPAStatus->GetThreadState()->nIsConnectedPAController == 0 ) {
				/*
				CString strTemp;
				strTemp.Format( _T("(Reconnect with controller...)\n") );
				strMsg += strTemp;
				*/
				strMsg.Format( _T("Disconnected with controller...\nPlease close chairside program") );
				for( int i = 0; i<OPER_BTN_NUM; i++ )
				{
					pOperButtonsEx_[i]->SetEnable( FALSE );
				}
				CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
				return;
			}
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

			while( TRUE )
			{
			//	pa::PPAStatus->GetThreadState()->
			//	if( pa::PPAStatus->GetPAStatus()->nServoPower != 0 ) {
				if( pa::PPAStatus->GetPAStatus()->nServoPower != 0 && pa::PPAStatus->GetThreadState()->nIsConnectedPAController != 0 ) {
					break;
				}
				Sleep( 100 );
				if( ( GetTickCount() - dwTime ) > 70000 ) {
					// timeout
					CMsgDlgThread::GetInstance()->Hide();
					bIsErrorReset = FALSE;
					break;
				}
			}
			if( bIsErrorReset == FALSE )
			{
				strMsg.Format( _T("failed error clear") );
				CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
				CMsgDlgThread::GetInstance()->Wait();
			}
			else 
			{
				CMsgDlgThread::GetInstance()->Hide();
			}
		}
	} 
	else 
	{
		TRACE( _T("CEPncUIDlg::doButtonEmoReset(EMG)\n") );
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog(_T("emg button click"));
		//////////////////////////////////////////////////////////////////////////
		PPNC_IPC_CLIENT->Emergency();
	}
}

#include "PasswordDlg.h"
// #include "NumericInputDlg.h"
// #include "CalculatorDlg.h";
void CEPncUIDlg2::doButtonSetup()
{
	BOOL b = TRUE;

	if( PSETUP_DLG->IsWindowVisible() ) {
		return ;
	}

	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("setup button click") );
	//////////////////////////////////////////////////////////////////////////

// #ifndef _DEBUG
	if( theApp.bNoNeedEnterPassword_ == FALSE ) 
	{
		CPasswordDlg dlg;
		if( dlg.DoModal() != IDOK ) {
			b = FALSE;
		}
	}
	else {
	//	pa::USER_MODE = pa::USER_MODE_RND;
		pa::SET_CURRENT_USERMODE( pa::USER_MODE_RND );
	}
// #else 
// 	pa::USER_MODE = pa::USER_MODE_RND;
// 	b = TRUE;
// #endif

	if( b ) {
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog( _T("password ok. change setup mode") );
		//////////////////////////////////////////////////////////////////////////

		PSETUP_DLG->ShowWindow( SW_SHOW );
		PSETUP_DLG->ShowMain();
	} else {
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog( _T("password fail.") );
		//////////////////////////////////////////////////////////////////////////
	}
}

void CEPncUIDlg2::doButtonRunPause()
{
	pa::EN_RUNMODE run_mode = pa::PPAStatus->GetRunMode();
	int		nStartLine = 0;
	BOOL	bRun = FALSE;
	DWORD	dwTimeout = 0;

	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("run button click") );
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	//Door�� ���� ������ ����ϰ�, ���� ���·� ������ ������ ���, �����.
	BOOL isUsingOpSensor = pa::PSWConfig->GetConfigData()->bUsingOpPanel;
	BOOL isFrontDoorClosed = pa::PPAStatus->GetPAStatus()->bInput[pa::IN20012_DoorSensor];
	if (isUsingOpSensor && !isFrontDoorClosed)
	{
		CString strMsg;
		writeLog( _T("front door opened before start"));
		strMsg.Format( _T("The front door is opened.\n\nPlease close the front door.") );
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_INFO, strMsg );
		CMsgDlgThread::GetInstance()->Wait();
		return;
	}
	//////////////////////////////////////////////////////////////////////////

	if( run_mode == pa::RUNMODE_STOP ) 
	{
		// ���� �ִ� ������ ������, Checking �� ������ ã�´� 
		if( pa::PPAStatus->GetThreadState()->bIsOpenNCFile == FALSE )
		{
			int nNCFileIndex = pa::PNCFileMgr->FindFirstCheckingNCFileIndex( TRUE );	//PNCFileMgr->FindFirstCheckingNCFileIndex();
			
			if( nNCFileIndex == -1 ) 
			{
				// ���� �ִ� ������ ���� 
				//////////////////////////////////////////////////////////////////////////
				// log 
				writeLog( _T("file not exist") );
				//////////////////////////////////////////////////////////////////////////
				return ;
			}
			else 
			{
				//////////////////////////////////////////////////////////////////////////
				// log 
				CString strLog;
				strLog.Format( _T("file open (%d)"), nNCFileIndex );				// index ��° ���� open 
				writeLog( strLog );
				//////////////////////////////////////////////////////////////////////////

				dwTimeout = pa::PNCFileMgr->EstimateLoadingTime(nNCFileIndex);

				// ������ ���� 
				PPNC_IPC_CLIENT->Open( nNCFileIndex );								
				Sleep( 500 );
			}
		}

		// ������ ���� �ִ��� Ȯ�� 
		if( !WaitForFileToOpen(dwTimeout) )
		{
			return ;
		}

		millingStartLine = 0;

		// �̾ ���࿩�� Ȯ�� 
		DWORD dwtemp = pa::PPAStatus->GetThreadState()->hNCFileInfo.machining_lines;
		if( pa::PPAStatus->GetThreadState()->hNCFileInfo.machining_lines != 0 )
		{
			nStartLine = pa::PPAStatus->GetThreadState()->hNCFileInfo.machining_lines;
			int prev_start_line = nStartLine;

			CRestartDialog dlg;
			dlg.SetStartLine( nStartLine );

			if( dlg.DoModal() == IDOK )
			{
				//////////////////////////////////////////////////////////////////////////
				//
				nStartLine = dlg.GetStartLine();
				millingStartLine = nStartLine;
				// 2017.08.09. �̾ ������ ���� ���� Ȯ�� 
				int totalLine = pa::PPAStatus->GetThreadState()->hNCFileInfo.total_lines-1;
				if( nStartLine >= totalLine )
				{
					CString strMsg;
					strMsg.Format( _T("can not input more then %d line"), totalLine );
					CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_WARM, strMsg );
					CMsgDlgThread::GetInstance()->Wait();
					return ;
				}
				//////////////////////////////////////////////////////////////////////////
				// ���� ���ΰ� ����� ������ �ٸ� �� �����Ƿ�, �Ѵ� ��� �Ѵ� 
				CString strLog;
				strLog.Format( _T("restart : %d [<-%d]"), nStartLine, prev_start_line );
				writeLog( strLog );
			}
			else 
			{
				//////////////////////////////////////////////////////////////////////////
				// log
				writeLog( _T("job cancel") );
				//////////////////////////////////////////////////////////////////////////
				// �۾� ��� 
				return ;
			}

		}

		bRun = TRUE;
	}

	if( bRun ) 
	{
		PPNC_IPC_CLIENT->Run(nStartLine);

		//////////////////////////////////////////////////////////////////////////
		// run �̸� milling_time ���� �ʱ�ȭ 
		nPREV_MILLING_TIME_ = 999999999;
		nBEFORE_TOOLCHANGE_RUNNINGTIME_ = 0;

#ifdef _SAVE_RUNTIME_UI_
		SAVE_RUNNING_TIME(TRUE, pa::PPAStatus->GetThreadState()->hNCFileInfo.file_name, 0, 0, 0, 0 );		// �ʱ�ȭ 
#endif		//////////////////////////////////////////////////////////////////////////
	}
}

void CEPncUIDlg2::doButtonStop()
{
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetRunMode();

	if( hRunMode == pa::RUNMODE_RUN || hRunMode == pa::RUNMODE_TORUN || hRunMode == pa::RUNMODE_PAUSE ) 
	{
		PPNC_IPC_CLIENT->Stop();
	} 
}

void CEPncUIDlg2::doButtonOpen()
{
	if( pa::PNCFileMgr->GetCurrentWorkNCFileIndex() == -1 )
	{
		// 1. ����Ʈ �ڽ��� �ִ� NC ���� ��ü üũ
		int nNum = pa::PNCFileMgr->GetNumNCFile();

		for( int i = 0; i<nNum; i++ )
		{
			pa::PNCFileMgr->SetNCFileSelect( i, 1, TRUE );
		}

		// 2. üũ�� ���� ����
		CString strSelectedFileNames[100];
		CString strTemp;
		nNum = 0;

		nNum = pNCFileListBoxEx_->GetSelectedFileName( strSelectedFileNames );

		for( int i = 0; i<nNum; i++ )
		{
			if( pa::PNCFileMgr->RemoveWorkNCFileInfo( strSelectedFileNames[i] ) == FALSE ) 
			{
				// ������ ���� ������, ������ �� ���� 
			}
			else
			{
				CString strFile, strErrMsg;
				strFile.Format( _T("%s\\%s"), NCFILE_PATH, strSelectedFileNames[i] );
				// ���� ���� 
				if( hcutil::DeleteFile( strFile, strErrMsg ) == FALSE ) {
					// ���� ���� �� ���� 
					//	AfxMessageBox( strErrMsg, MB_OK|MB_ICONERROR );
				}
			}
		}

		//////////////////////////////////////////////////////////////////////////
		// Registered Nc ���� ����Ʈ�� ���� �Ѵ� 
		if( pa::PPAStatus->GetThreadState()->bSendRegistered_NCFileList_ == FALSE ) {
			pa::PPAStatus->GetThreadState()->bSendRegistered_NCFileList_ = TRUE;
		}
		//////////////////////////////////////////////////////////////////////////
		// SD �޸��� NC ���� ����Ʈ�� ���� �Ѵ� 
		if( pa::PPAStatus->GetThreadState()->bSendSDMemory_NCFileList_ == FALSE ) {
			pa::PPAStatus->GetThreadState()->bSendSDMemory_NCFileList_ = TRUE;
		}
		//////////////////////////////////////////////////////////////////////////

		// 3. Ž���⿡�� NC������ �����´� (1����)
		CFileDialog hOpenDlg( TRUE, NULL, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("NC Files (*.nc)|*.nc|*.*|") );

		//////////////////////////////////////////////////////////////////////////
		// NC File�� �̸��� �Է¹޴´�
		//////////////////////////////////////////////////////////////////////////
		
		if (isUSBConnected_)
		{
			hOpenDlg.m_ofn.lpstrInitialDir = strDriverName_;
		}

		if( hOpenDlg.DoModal() != IDOK ) {
			return ;
		}

		POSITION pos ( hOpenDlg.GetStartPosition() );

		int i = 0;
		while( pos )
		{
			CString ncFileFullPath(  hOpenDlg.GetNextPathName( pos ) );
			int splitSpot = ncFileFullPath.ReverseFind( '\\' );
			CString ncFileName = ncFileFullPath.Mid(splitSpot+1, ncFileFullPath.GetLength());

			if (ncFileName.GetLength() == 0) {
				CString strMsg;
				strMsg.Format( _T("Failed to copy file") ); 
				CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
				CMsgDlgThread::GetInstance()->Wait();

				writeLog( _T("file copy error") );
				return;
			}

			CopyFile( (LPCTSTR)ncFileFullPath, (LPCTSTR)(CString( NCFILE_PATH ) + CString( _T("\\")) + ncFileName), FALSE );

			CTime time = CTime::GetCurrentTime();
			CString strDateTime = time.Format( _T("%y%m%d_%H%M%S") );
			CString strID;
			strID.Format( _T("%d_%03d"), strDateTime, ++i );

			// �۾� �����Ϳ� �߰� �Ѵ� 
			CString strTemp = ncFileName;
			DWORD dwFileSize = 0;

			strNCFileName = ncFileName; // ���� NC���� �̸� ���

			pa::GET_NCFILE_FULL_PATH( strTemp );
			hcutil::GetFileSize( strTemp, &dwFileSize, strTemp );

			pa::PNCFileMgr->AddWorkNCFileInfo( (TCHAR*)(LPCTSTR)strID, (TCHAR*)(LPCTSTR)ncFileName, dwFileSize, TRUE );
		}

		// 4.Ž���⿡�� ������ NC ���� üũ
		pa::PNCFileMgr->SetNCFileSelect( 0, 1, TRUE );

		// 5. NC������ ����
		int nNumNCFiles = pa::PNCFileMgr->GetNumNCFile();
		int nSelectedIndex = -1;

		pa::PPAStatus->GetThreadState()->nNcFileLoadingRate = 0;

		// ���� �ִ� ������ ������, ���õ� ���� �� ù��° ������ Open �Ѵ�
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog( _T("file open button click") );

		//////////////////////////////////////////////////////////////////////////
		// File�� ���� 

		nSelectedIndex = pa::PNCFileMgr->FindFirstCheckingNCFileIndex( FALSE );

		int PREV_LOADING_RATE = -1;

		// ������ Open �Ѵ�
		if( PPNC_IPC_CLIENT ) 
		{
			pa::PPAStatus->GetThreadState()->bIsFileOpening = TRUE;

			PPNC_IPC_CLIENT->Open( nSelectedIndex );

			Sleep( 500 );

			WaitForFileToOpen( pa::PNCFileMgr->EstimateLoadingTime(nSelectedIndex) );
		}

		if( pNCFileListBoxEx_ ) 
		{
			pNCFileListBoxEx_->NCFMObsvr_UpdateNCFileInfo( nSelectedIndex );
		}
	}

	else 
	{
		// ���� �ִ� ������ ������, ������ �ݰ� is_select�� 0���� �����Ѵ� 
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog( _T("file close button click") );
		//////////////////////////////////////////////////////////////////////////

		int nSelectedIndex = pa::PNCFileMgr->GetCurrentWorkNCFileIndex();

		//pa::PPAStatus->GetPAStatus()->strOpenedFileName = _T("");

		// File�� ���� �� is_select�� 0���� �����Ѵ�  
		pa::PNCFileMgr->SetNCFileSelect( nSelectedIndex, 0, TRUE );
		// File�� �ݴ´� 

		DWORD dwTime = GetTickCount();
		pa::PPAStatus->SetIpcCommandComplete( FALSE );
		PPNC_IPC_CLIENT->Close();
		Sleep( 500 );
		while( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == FALSE ) {
			if( (GetTickCount() - dwTime) > 50000 ) {
				// ����. �� �Ѿ��  
				break;
			}
			Sleep( 100 );
		}

		if( pNCFileListBoxEx_ ) 
		{
			pNCFileListBoxEx_->NCFMObsvr_UpdateNCFileInfo( nSelectedIndex );
		}
	}

	nPREV_MILLING_TIME_ = 999999999;
}

bool CEPncUIDlg2::WaitForFileToOpen(DWORD dwTimeout) 
{
	// ������ ���� �ִ��� Ȯ�� 
	DWORD dwTime = GetTickCount();
	int PREV_LOADING_RATE = -1;
	CString strMsg;

//	if( !pa::PPAStatus->GetThreadState()->bIsOpenNCFile ) {
		strMsg.Format( _T("please...wait until the file is opened") );
		CMsgDlgThread::GetInstance()->Show(CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );
// 	}
	
	while( TRUE ) 
	{
		// 2016.12.14 
	//	if( pa::PPAStatus->GetThreadState()->bIsOpenNCFile ) {
		if( pa::PPAStatus->GetThreadState()->bIsOpenNCFile || pa::PPAStatus->GetRunMode()==pa::RUNMODE_ERROR ) {
			CMsgDlgThread::GetInstance()->Hide();
			return TRUE;
		}

		// �������� ���ϸ� ��� �Ѵ� 
		int curr_loading_rate = pa::PPAStatus->GetThreadState()->nNcFileLoadingRate;
		if( PREV_LOADING_RATE !=  curr_loading_rate ) {
			PREV_LOADING_RATE = curr_loading_rate;
			strMsg.Format( _T("please...wait until the file is opened\n[%d%%]"), PREV_LOADING_RATE );
			CMsgDlgThread::GetInstance()->SetMessage( strMsg );

			dwTime = GetTickCount();
		}

		// �������� 60/100 �� �̻� ������ ������, ���� �޽��� ��� 
		// WinCE6.0���� 30�ʷ� ���� 
		if( (GetTickCount() - dwTime) > dwTimeout ) {
			CMsgDlgThread::GetInstance()->Hide();

			strMsg.Format( _T("Failed to open file") ); 
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
			CMsgDlgThread::GetInstance()->Wait();

			writeLog( _T("file open error") );
			return FALSE;
		}

		Sleep(500);
	}
}


void CEPncUIDlg2::doButtonReadyPos()
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("move to ready position button click") );
	//////////////////////////////////////////////////////////////////////////

	CString strMsg;

	strMsg.Format( _T("Do you want to move to ready position ?") );

	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );

	CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();

	if( hRet == CMsgDlg::RET_CANCEL ) {
		return ;
	}

	// AutoLoader �� �ִ� ����� ���, PNC ARM�� up �Ѵ� 
	if( pa::PAutoLoader && pa::PAutoLoader->IsUsingAutoLoader() )
	{
		PPNC_IPC_CLIENT->XYS_Gripper_Up();
		Sleep( 500 );
		while( !theApp.MotionDone( TRUE ) ) {
			Sleep( 500 );
			if( pa::PPAStatus->GetRunMode() == pa::RUNMODE_ERROR ) {
				break;
			}
		}
	}

	//
	PPNC_IPC_CLIENT->MoveReadyPosition();
}

// Tools ȭ������ ��ȯ �Ǿ��� ��, 
// ��� ��ġ���� ��ȯ�Ǿ����� �����ؾ� �Ѵ�. BACK ��ư ������ �� 
void CEPncUIDlg2::doButtonTools()
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("tools button click") );
	//////////////////////////////////////////////////////////////////////////
	PSETUP_DLG->ShowWindow(SW_SHOW);
	PSETUP_DLG->ShowToolSetup();
}

//////////////////////////////////////////////////////////////////////////

LRESULT CEPncUIDlg2::OnAutoLoaderRefill(WPARAM wparam, LPARAM lparam)
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("autoloader refill button click") ); 
	//////////////////////////////////////////////////////////////////////////

	CAutoLoaderRefillDlg dlg;

	dlg.DoModal();

	return 0;
}

//////////////////////////////////////////////////////////////////////////

void CEPncUIDlg2::updateButtonState()
{
	static int PREV_BTN_ENA[OPER_BTN_NUM] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };	// enable
	static int PREV_BTN_BLK[OPER_BTN_NUM] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };	// blink
	static int PREV_BTN_SEL[OPER_BTN_NUM] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };	// select
	int btn_ena[OPER_BTN_NUM] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	int btn_blk[OPER_BTN_NUM] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	int btn_sel[OPER_BTN_NUM] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

	int nToolNo_ = pa::PPAStatus->GetPAStatus()->nCurrentToolNo;
	int nTool2No_ = pa::PPAStatus->GetPAStatus()->nCurrentTool2No;

	pa::EN_RUNMODE	hRunMode = pa::PPAStatus->GetThreadState()->hRunMode;
	BOOL	bOriginComplete = pa::PPAStatus->GetThreadState()->bIsOriginComplete_;
	BOOL	bIsReady = (pa::PPAStatus->GetPAStatus()->nRunStatus == pa::PA_RUN_STATUS_IDLE );
	BOOL	bPAConnected = (pa::PPAStatus->GetThreadState()->nIsConnectedPAController != 0) ? 1 : 0;
	BOOL	bIOConnected = (pa::PPAStatus->GetThreadState()->nIsConnectedIOBoard != 0) ? 1 : 0;
	BOOL	bIsSpindleRun = (pa::PPAStatus->GetPAStatus()->nSpindleRun != 0) ? 1 : 0;
	BOOL	bIsSpindleRun2 = (pa::PPAStatus->GetPAStatus()->nSpindle2Run !=0 ) ? 1 : 0;
	BOOL	bIsToolErr = (pa::PTool->GetToolData(nToolNo_)->dwErrCode != 0) ? 1 : 0;
	BOOL	bIsTool2Err = (pa::PTool->GetToolData(nTool2No_)->dwErrCode != 0) ? 1 : 0;

	if (nToolNo_ == 0)
	{
		bIsToolErr = 0;
	}

	if (nTool2No_ == 0)
	{
		bIsTool2Err = 0;
	}

	int		nIndex = 0;

//#ifdef _HAS_MACHINE_

		//////////////////////////////////////////////////////////////////////////
		// EMO ��ư 
		btn_ena[nIndex]	= 1;
		btn_blk[nIndex] = ( hRunMode == pa::RUNMODE_ERROR ) ? 1 : 0; 
		btn_sel[nIndex] = 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// setup ��ư 
		btn_ena[nIndex] = ( hRunMode == pa::RUNMODE_STOP || hRunMode == pa::RUNMODE_ERROR ) ? 1 : 0;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// start ��ư:  
		btn_ena[nIndex] = ( bOriginComplete && ( hRunMode == pa::RUNMODE_STOP || hRunMode == pa::RUNMODE_PAUSE ) ) ? 1 : 0;
		btn_blk[nIndex] = ( hRunMode == pa::RUNMODE_PAUSE ) ? 1 : 0;
		btn_sel[nIndex] = 0;
		nIndex++; 

		//////////////////////////////////////////////////////////////////////////
		// stop ��ư 
		btn_ena[nIndex] = ( bOriginComplete && ( hRunMode == pa::RUNMODE_TORUN || hRunMode == pa::RUNMODE_RUN || hRunMode == pa::RUNMODE_PAUSE ) ) ? 1 : 0;
		if ( bOriginComplete && ( hRunMode == pa::RUNMODE_TORUN || hRunMode == pa::RUNMODE_RUN || hRunMode == pa::RUNMODE_PAUSE ))
		{
			pOperButtonsEx_[OPER_BTN_START]->ShowWindow(SW_HIDE);
			pOperButtonsEx_[OPER_BTN_STOP]->ShowWindow(SW_SHOW);
		}
		else
		{
			pOperButtonsEx_[OPER_BTN_START]->ShowWindow(SW_SHOW);
			pOperButtonsEx_[OPER_BTN_STOP]->ShowWindow(SW_HIDE);
		}
		btn_blk[nIndex] = ( hRunMode == pa::RUNMODE_TORUN ) ? 1 : 0;
		btn_sel[nIndex] = 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// open ��ư 
		btn_ena[nIndex] = ( bOriginComplete && hRunMode == pa::RUNMODE_STOP ) ? 1 : 0;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = ( pa::PNCFileMgr->GetCurrentWorkNCFileIndex() != -1 ) ? 1 : 0;
		nIndex++; 

		//////////////////////////////////////////////////////////////////////////
		// ready-pos ��ư 
		btn_ena[nIndex] = ( bOriginComplete && bIsReady && ( hRunMode == pa::RUNMODE_STOP ) );
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// tools ��ư 
		btn_ena[nIndex] = (!bOriginComplete || hRunMode == pa::RUNMODE_RUN || hRunMode == pa::RUNMODE_TORUN || hRunMode == pa::RUNMODE_TOSTOP || hRunMode == pa::RUNMODE_ERROR || hRunMode == pa::RUNMODE_INIT) ? 0 : 1;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// PA Connected ��ư 
		btn_ena[nIndex] = 1;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = (!bPAConnected) ? 1 : 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// IO Connected ��ư 
		btn_ena[nIndex] = 1;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = (!bIOConnected) ? 1 : 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// Spindle RPM ��ư 
		btn_ena[nIndex] = 1;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = (bIsSpindleRun) ? 1 : 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// Spindle RPM2 ��ư 
		btn_ena[nIndex] = 1;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = (bIsSpindleRun2) ? 1 : 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// Tool Time ��ư 
		btn_ena[nIndex] = 1;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = (bIsToolErr) ? 1 : 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// Tool Time2 ��ư 
		btn_ena[nIndex] = 1;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = (bIsTool2Err) ? 1 : 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// OPER_BTN_NC_LOADED,
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// OPER_BTN_NC_RUNNING,
		nIndex++;
		
		//////////////////////////////////////////////////////////////////////////
		// OPER_BTN_NC_FINISHED,
		nIndex++;
		
		//////////////////////////////////////////////////////////////////////////
		//OPER_BTN_PROGRAM_COLLAPSE,
		btn_ena[nIndex] = 1;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = 0;
		nIndex++;
		
		//////////////////////////////////////////////////////////////////////////
		//OPER_BTN_PROGRAM_CLOSE,
		btn_ena[nIndex] = 1;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// TOOL ERROR 
		// WHITE
// 		btn_ena[nIndex] = 1; //0; //1;
// 		btn_blk[nIndex] = 0;
// 		btn_sel[nIndex] = 0; //0;
		if (getToolError() == FALSE) {
			btn_ena[nIndex] = 1; //0; //1;
			btn_blk[nIndex] = 0;
			btn_sel[nIndex] = 0; //0;
		} 
		else {
			btn_ena[nIndex] = 1; //0; //1;
			btn_blk[nIndex] = 0;
			btn_sel[nIndex] = 1; //0;
		}
		nIndex++;
		
		//////////////////////////////////////////////////////////////////////////
		// TOOL ALARM 
// 		btn_ena[nIndex] = 1; //1;
// 		btn_blk[nIndex] = 0;
// 		btn_sel[nIndex] = 0; //0;
		switch (getToolAlarm()) {
			case 0: 
				btn_ena[nIndex] = 1; //0; //1;
				btn_blk[nIndex] = 0;
				btn_sel[nIndex] = 0; //0;
				break;
			case 1:
				btn_ena[nIndex] = 0; //0; //1;
				btn_blk[nIndex] = 0;
				btn_sel[nIndex] = 0; //0;
				break;
			case 2:
				btn_ena[nIndex] = 1; //0; //1;
				btn_blk[nIndex] = 0;
				btn_sel[nIndex] = 1; //0;
				break;
		}
		nIndex++;

// #endif
	
	for( int i = 0; i<OPER_BTN_NUM; i++ )
	{
		if( PREV_BTN_ENA[i] != btn_ena[i] ) {
			PREV_BTN_ENA[i] = btn_ena[i];
			pOperButtonsEx_[i]->SetEnable( btn_ena[i] );
		}
		if( PREV_BTN_BLK[i] != btn_blk[i] ) {
			PREV_BTN_BLK[i] = btn_blk[i];
			pOperButtonsEx_[i]->SetBlink( btn_blk[i] );
		}
		if( PREV_BTN_SEL[i] != btn_sel[i] ) {
			PREV_BTN_SEL[i] = btn_sel[i];
			pOperButtonsEx_[i]->SetSelect( btn_sel[i] );
		}
	}

	int i = 18;
	pOperButtonsEx_[i]->SetEnable( btn_ena[i] );
	pOperButtonsEx_[i]->SetBlink( btn_blk[i] );
	pOperButtonsEx_[i]->SetSelect( btn_sel[i] );
	i = 19;
	pOperButtonsEx_[i]->SetEnable( btn_ena[i] );
	pOperButtonsEx_[i]->SetBlink( btn_blk[i] );
	pOperButtonsEx_[i]->SetSelect( btn_sel[i] );
}

//////////////////////////////////////////////////////////////////////////
// 1.RunMode�� ����Ǿ��� ��. 
void CEPncUIDlg2::updateNCFileListBox()
{
	static pa::EN_RUNMODE PREV_RUNMODE = pa::RUNMODE_NUM;
	pa::EN_RUNMODE currRunMode = pa::PPAStatus->GetRunMode();

	if( PREV_RUNMODE != currRunMode )
	{
		PREV_RUNMODE = currRunMode;

		pNCFileListBoxEx_->UpdateFileList();
	}
}

void CEPncUIDlg2::updateToolInfoDisp()
{
	static COLORREF		CLR_BACKGROUND = RGB(235, 234 ,239);
	static COLORREF		CLR_TEXT = RGB(82, 82, 82);
	static COLORREF		CLR_TEXT_RED = RGB(255, 64, 64);
	static int			PREV_TOOL_NO = -1;
	static int			PREV_TOOL_LENGHT_UPDATE_FLAG = -1;
	static int			PREV_TOOL_TIME[3] = { -1, -1, -1 };
	static double		PREV_USING_RATE = -1.0;

	hcutil::CCanvasCELayer* pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get(1);
	int			nBkMode= pLayer->SetBkMode( TRANSPARENT ); 
	COLORREF	clrOld = pLayer->SetTextColor( CLR_TEXT );
	CFont*		pOldFont = (CFont*)pLayer->SelectObject( &hFntStatus_ );

	CString strTemp;
	int		curr_tool_no = pa::PPAStatus->GetPAStatus()->nCurrentToolNo;
	int		curr_tool_lenght_update_flag = pa::PPAStatus->GetPAStatus()->nToolLengthUpdateFlag;
	DWORD	dwUsingTime = 0;

//	if( PREV_TOOL_NO != curr_tool_no || curr_tool_no != 0 ) 
	if( curr_tool_no != 0 )
	{
//		PREV_TOOL_NO = curr_tool_no;

		DWORD dwUsingTime = pa::PTool->GetToolData( curr_tool_no )->dwUsingTime;

		if( curr_tool_no != 0 )
		{
			// ���� ��� ���� 
			//////////////////////////////////////////////////////////////////////////
			// �� ��ȣ 
			// 2017.8.22. �� ���� ������ �ȵǾ��� ���, �� ��ȣ�� ���������� ǥ�� �Ѵ� 
			if( PREV_TOOL_NO != curr_tool_no ||
				PREV_TOOL_LENGHT_UPDATE_FLAG != curr_tool_lenght_update_flag ) {
				PREV_TOOL_NO = curr_tool_no;
				PREV_TOOL_LENGHT_UPDATE_FLAG = curr_tool_lenght_update_flag;

				if( PREV_TOOL_LENGHT_UPDATE_FLAG == 0 ) {
					pLayer->SetTextColor( CLR_TEXT_RED );
				} else {
					pLayer->SetTextColor( CLR_TEXT );
				}

				strTemp.Format( _T("No.%d"), PREV_TOOL_NO );
				pLayer->FillSolidRect( &rcStatusArea_[STATUS_TOOL_INFO1], CLR_BACKGROUND );
				pLayer->DrawText( strTemp, rcStatusArea_[STATUS_TOOL_INFO1], DT_LEFT );
				InvalidateRect( &rcStatusArea_[STATUS_TOOL_INFO1], FALSE );

				pLayer->SetTextColor( CLR_TEXT );
			}
			// ��� �ð� 
			DWORD dwUsingTime = pa::PTool->GetToolData( PREV_TOOL_NO )->dwUsingTime;
			CTimeSpan tms( dwUsingTime );
			int ttm[3] = { tms.GetHours(), tms.GetMinutes(), tms.GetSeconds() };

			for( int i = 0; i<3; i++ ) {
				if( PREV_TOOL_TIME[i] != ttm[i] ) {
					PREV_TOOL_TIME[i] = ttm[i];
					strTemp.Format( _T("%02d"), PREV_TOOL_TIME[i] );
					if( i != 0 ) {
						strTemp = CString(_T(":")) + strTemp;
					}
					pLayer->FillSolidRect( &rcStatusArea_[STATUS_TOOL_INFO2_1+i], CLR_BACKGROUND );
					pLayer->DrawText( strTemp, &rcStatusArea_[STATUS_TOOL_INFO2_1+i], (i==0) ? DT_RIGHT:DT_LEFT );
					InvalidateRect( rcStatusArea_[STATUS_TOOL_INFO2_1+i], FALSE );
				}
			}

			// ����� 
			double fUsingRate = pa::PTool->GetToolData( PREV_TOOL_NO )->fUsingRate;
			
			if( fabs(PREV_USING_RATE - fUsingRate) > 0.1 ) {
				PREV_USING_RATE = fUsingRate;
				strTemp.Format( _T("[%.1f%%]"), PREV_USING_RATE );
				pLayer->FillSolidRect( &rcStatusArea_[STATUS_TOOL_INFO3], CLR_BACKGROUND );
				pLayer->DrawText( strTemp, &rcStatusArea_[STATUS_TOOL_INFO3], DT_LEFT );
				InvalidateRect( &rcStatusArea_[STATUS_TOOL_INFO3], FALSE );
			}
		}
		else 
		{
			if( PREV_TOOL_NO != -1 ) {
				PREV_TOOL_NO = -1;
				// ���� ������� ���� 
				PREV_TOOL_TIME[0] = PREV_TOOL_TIME[1] = PREV_TOOL_TIME[2] = -1;
				PREV_USING_RATE = -1.0;
				pLayer->FillSolidRect( &rcStatusArea_[STATUS_TOOL_INFO1], CLR_BACKGROUND );		// �� ��ȣ 
				pLayer->FillSolidRect( &rcStatusArea_[STATUS_TOOL_INFO2_1], CLR_BACKGROUND );	// H
				pLayer->FillSolidRect( &rcStatusArea_[STATUS_TOOL_INFO2_2], CLR_BACKGROUND );	// M
				pLayer->FillSolidRect( &rcStatusArea_[STATUS_TOOL_INFO2_3], CLR_BACKGROUND );	// S
				pLayer->FillSolidRect( &rcStatusArea_[STATUS_TOOL_INFO3], CLR_BACKGROUND );		// Rate
				InvalidateRect( &rcStatusArea_[STATUS_TOOL_INFO1], FALSE );
				InvalidateRect( &rcStatusArea_[STATUS_TOOL_INFO2_1], FALSE );
				InvalidateRect( &rcStatusArea_[STATUS_TOOL_INFO2_2], FALSE );
				InvalidateRect( &rcStatusArea_[STATUS_TOOL_INFO2_3], FALSE );
				InvalidateRect( &rcStatusArea_[STATUS_TOOL_INFO3], FALSE );
			}
		}
	}
	else 
	{
		if( PREV_TOOL_NO != -1 ) {
			PREV_TOOL_NO = -1;
			// ���� ������� ���� 
			PREV_TOOL_TIME[0] = PREV_TOOL_TIME[1] = PREV_TOOL_TIME[2] = -1;
			PREV_USING_RATE = -1.0;
			pLayer->FillSolidRect( &rcStatusArea_[STATUS_TOOL_INFO1], CLR_BACKGROUND );		// �� ��ȣ 
			pLayer->FillSolidRect( &rcStatusArea_[STATUS_TOOL_INFO2_1], CLR_BACKGROUND );	// H
			pLayer->FillSolidRect( &rcStatusArea_[STATUS_TOOL_INFO2_2], CLR_BACKGROUND );	// M
			pLayer->FillSolidRect( &rcStatusArea_[STATUS_TOOL_INFO2_3], CLR_BACKGROUND );	// S
			pLayer->FillSolidRect( &rcStatusArea_[STATUS_TOOL_INFO3], CLR_BACKGROUND );		// Rate
			InvalidateRect( &rcStatusArea_[STATUS_TOOL_INFO1], FALSE );
			InvalidateRect( &rcStatusArea_[STATUS_TOOL_INFO2_1], FALSE );
			InvalidateRect( &rcStatusArea_[STATUS_TOOL_INFO2_2], FALSE );
			InvalidateRect( &rcStatusArea_[STATUS_TOOL_INFO2_3], FALSE );
			InvalidateRect( &rcStatusArea_[STATUS_TOOL_INFO3], FALSE );
		}
	}

	pLayer->SetBkMode( nBkMode );
	pLayer->SetTextColor( clrOld );
	pLayer->SelectObject( pOldFont );
}

// ���ɵ� ������ ȭ�鿡 ǥ�� 
void CEPncUIDlg2::updateSpindleInfoDisp()
{
	static COLORREF		CLR_BACKGROUND = RGB(235, 234, 239);
	static COLORREF		CLR_TEXT = RGB(82, 82, 82);
	static int			PREV_SPINDLE_RPM = -1;
	hcutil::CCanvasCELayer	*pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get(1);

	int			nBkMode	= pLayer->SetBkMode( TRANSPARENT );
	COLORREF	clrOld	= pLayer->SetTextColor( CLR_TEXT );
	CFont*		pOldFont= (CFont*)pLayer->SelectObject( &hFntStatus_ );

	int		curr_spindle_rpm = pa::PPAStatus->GetPAStatus()->nSpindleSpeedWithOverride;
	CString strTemp;

	if( PREV_SPINDLE_RPM != curr_spindle_rpm ) 
	{
		PREV_SPINDLE_RPM = curr_spindle_rpm;
		pLayer->FillSolidRect( rcStatusArea_[STATUS_SPINDLE], CLR_BACKGROUND );
		strTemp.Format( _T("%d RPM"), curr_spindle_rpm );
		pLayer->DrawText( strTemp, &rcStatusArea_[STATUS_SPINDLE], DT_LEFT );
		InvalidateRect( rcStatusArea_[STATUS_SPINDLE] );
	}

	pLayer->SetBkMode( nBkMode );
	pLayer->SetTextColor( clrOld );
	pLayer->SelectObject( pOldFont );
}

// FeedRate ������ ȭ�鿡 ǥ�� 
void CEPncUIDlg2::updateFeedRateInfoDisp()
{
	static COLORREF		CLR_BACKGROUND = RGB(235, 234, 239);
	static COLORREF		CLR_TEXT = RGB(82, 82, 82);
	static int			PREV_FEEDRATE = -1;
	hcutil::CCanvasCELayer	*pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get(1);

	int			nBkMode	= pLayer->SetBkMode( TRANSPARENT );
	COLORREF	clrOld	= pLayer->SetTextColor( CLR_TEXT );
	CFont*		pOldFont= (CFont*)pLayer->SelectObject( &hFntStatus_ );

	int		curr_feedrate = pa::PPAStatus->GetPAStatus()->nMotorFeedrate;
	CString	strTemp;

	if( PREV_FEEDRATE != curr_feedrate ) 
	{
		PREV_FEEDRATE = curr_feedrate;
		pLayer->FillSolidRect( rcStatusArea_[STATUS_FEEDRATE], CLR_BACKGROUND );
		strTemp.Format( _T("%d"), curr_feedrate );
		pLayer->DrawText( strTemp, &rcStatusArea_[STATUS_FEEDRATE], DT_LEFT );
		InvalidateRect( rcStatusArea_[STATUS_FEEDRATE] );
	}

	pLayer->SetBkMode( nBkMode );
	pLayer->SetTextColor( clrOld );
	pLayer->SelectObject( pOldFont );
}

// ���� �ð� ������ ȭ�鿡 ǥ�� 
void CEPncUIDlg2::updateMillingTimeDisp()
{
	static CString PREV_MILLING_TIME = _T("");
	CString strTemp;
	DWORD dwRunningTime = pa::PPAStatus->GetThreadState()->dwRunningTime;
	CTimeSpan tms( dwRunningTime );
	int	milling_time[3] = { tms.GetHours(), tms.GetMinutes(), tms.GetSeconds() };

	strTemp.Format(_T("%02d:%02d:%02d"), milling_time[0], milling_time[1], milling_time[2]);

	if (strTemp.Compare(PREV_MILLING_TIME))
	{
		((CStatic*)GetDlgItem(IDC_STATIC_MILLING_TIME))->SetWindowText( strTemp );
		PREV_MILLING_TIME = strTemp;
	}
}

int CEPncUIDlg2::calcExcpetTime( DWORD dwRunningTime, int nTotalLine, int nCurrLine )
{
	int nExcpetTime = 0;

	if( nCurrLine > 0 )
	{
		nExcpetTime = (int)( ( dwRunningTime * ( nTotalLine - nCurrLine ) ) / nCurrLine + 0.5 );
		nExcpetTime = ( nExcpetTime * 0.9 );			// ���� ���� �ð��� 10% ���δ�  
	}

	return nExcpetTime;
}

// pmac::PState->GetThreadState()->nNCFileInfo_SecondToolChageLine ������ ����Ѵ� 
int CEPncUIDlg2::calcExcpetTime2( DWORD dwRunningTime, int nTotalLine, int nCurrLine )
{
	//	static DWORD dwFRONT_RUNNING_TIME = 0;
	int		nExcpetTime = 0;
//	int		nToolChangeLine = pmac::PState->GetThreadState()->nNCFileInfo_SecondToolChageLine;
	int		nToolChangeLine = pa::PPAStatus->GetThreadState()->nNCFileInfo_SecondToolChageLine;
	int		nToolChangeLine_plus = nToolChangeLine + (int)( nTotalLine * 0.1 );

	if( nToolChangeLine > 0 ) 
	{
		if( nCurrLine < nToolChangeLine )
		{
			// Tool Change ���� ���� �ɸ��� �ð� + ���� �ɸ��� �ð� 
			double fGradient = (double)dwRunningTime / (double)nCurrLine;
			// 			 nExcpetTime = ( fGradient * ( nToolChangeLine - nCurrLine ) ) + ( ( fGradient * 0.5 ) * ( nTotalLine - nToolChangeLine ) );
			// 			 nExcpetTime = ( fGradient * ( nToolChangeLine - nCurrLine ) ) + ( ( fGradient * 0.7 ) * ( nTotalLine - nToolChangeLine ) );
			nExcpetTime = ( fGradient * ( nToolChangeLine - nCurrLine ) ) + ( ( fGradient * 0.6 ) * ( nTotalLine - nToolChangeLine ) );
			nBEFORE_TOOLCHANGE_RUNNINGTIME_ = (int)dwRunningTime;
		}
		else if( nCurrLine < nToolChangeLine_plus ) 
		{
			// Tool Change ���� ���� �ɸ��ð��� ����/2 �� ����ؼ� �ð� ��� 
			// 			double fGradient = (double)nBEFORE_TOOLCHANGE_RUNNINGTIME_ / (double)nToolChangeLine * 0.5;
			// 			double fGradient = (double)nBEFORE_TOOLCHANGE_RUNNINGTIME_ / (double)nToolChangeLine * 0.7;
			double fGradient = (double)nBEFORE_TOOLCHANGE_RUNNINGTIME_ / (double)nToolChangeLine * 0.6;
			nExcpetTime = ( fGradient * ( nTotalLine - nCurrLine ) );
		}
		else 
		{
			// Tool Change ���� ���� �ٽ� ���⸦ ���ؼ�, ���� �ð��� ����Ѵ� 
			double fGradient = (double)( dwRunningTime - nBEFORE_TOOLCHANGE_RUNNINGTIME_ ) / (double)( nCurrLine - nToolChangeLine );
			nExcpetTime = fGradient * ( nTotalLine - nCurrLine );
		}
	}
	else 
	{
		double fGradient = (double)dwRunningTime / (double)nCurrLine;
		nExcpetTime = ( fGradient * (nTotalLine - nCurrLine ) );
	}

	return nExcpetTime;
}

int CEPncUIDlg2::findRemainingTime( int nTotalLine, int nCurrLine )
{
	int REQUIRED_MIN_LINES = 2000;
	double M1_CONSTANT = 0.03;
	double M2_CONSTANT = 0.015;
	double M1_M2_RATIO = 0.6; 

	DWORD dwFirstHalfRunningTime = pa::PPAStatus->GetThreadState()->dwFirstHalfRunningTime;	//pmac::PState->GetThreadState()->dwFirstHalfRunningTime;
	DWORD dwSecondHalfRunningTime= pa::PPAStatus->GetThreadState()->dwFirstHalfRunningTime;	//pmac::PState->GetThreadState()->dwFirstHalfRunningTime;

	int nTC2 = pa::PPAStatus->GetThreadState()->nNCFileInfo_SecondToolChageLine;		//pmac::PState->GetThreadState()->nNCFileInfo_SecondToolChageLine;
	int expectedRemainingTime = 0;
	int nNCSoFar = 0;

	// Before tool change 2
	if (nCurrLine < nTC2) 
	{
		// if not enough data, use constant
		nNCSoFar = nCurrLine - millingStartLine;

		// constant estimate
		double m1Constant = M1_CONSTANT;
		double m2Constant = M1_M2_RATIO * m1Constant;
		int constantEstimate = m1Constant * (nTC2 - nCurrLine) + m2Constant * (nTotalLine - nTC2);

		// learned estimate
		double m1Learned = ((double) dwFirstHalfRunningTime) / nNCSoFar;
		double m2Learned = M1_M2_RATIO * m1Learned;
		int learnedEstimate = m1Learned * (nTC2 - nCurrLine) + m2Learned * (nTotalLine - nTC2);

		// Constant�� �̿��� �ð�, Learning�� �̿��� �ð� �� ������ ���. Constant -> Learning ���� �Ѿ�� ������ũ�� �����ִ� �뵵.
		expectedRemainingTime = (nNCSoFar < REQUIRED_MIN_LINES || constantEstimate < learnedEstimate) ? constantEstimate : learnedEstimate;

		// Tool Change 2 ���ķ� �Ѿ���Ԥ��¤��� �����ð��� ����� ����� ����. TC2 ���Ŀ� �����ð��� �ް��� ���ϴ°� �����ش�.
		expectedRemainingTime = (((nTC2 - nCurrLine) * expectedRemainingTime) + (nCurrLine * M2_CONSTANT * (nTotalLine - nTC2))) / nTC2;
		// After tool change 2
	}
	else
	{
		nNCSoFar = nCurrLine - ((millingStartLine > nTC2) ? millingStartLine : nTC2);

		// constant estimate
		double m2Constant = M2_CONSTANT;
		int constantEstimate = m2Constant * (nTotalLine - nCurrLine);

		// learned estimate
		double m2Learned = ((double) dwSecondHalfRunningTime) / nNCSoFar;
		int learnedEstimate = m2Learned * (nTotalLine - nCurrLine);

		// Constant�� �̿��� �ð�, Learning�� �̿��� �ð� �� ������ ���. Constant -> Learning ���� �Ѿ�� ������ũ�� �����ִ� �뵵.
		expectedRemainingTime = (nNCSoFar < REQUIRED_MIN_LINES || constantEstimate < learnedEstimate) ? constantEstimate : learnedEstimate;
	}

	return expectedRemainingTime;
}

// Remote ���� ǥ�� 
void CEPncUIDlg2::updateRemoteModeDisp()
{
	static int PREV_MODE = -1;
	static int PREV_LOCK = -1;
	int curr_mode = pa::PPAStatus->GetThreadState()->bIsClientConnected_ ? 1 : 0;
	int curr_lock = pa::PPAStatus->GetThreadState()->bRemoteLock_ ? 1 : 0;
	BOOL bUpdate = FALSE;

	if( PREV_MODE != curr_mode || PREV_LOCK != curr_lock ) {
		PREV_MODE = curr_mode;
		PREV_LOCK = curr_lock;
		bUpdate = TRUE;
	}

	if( bUpdate ) {
		if( curr_mode != 0 ) {
			pIconWnd_[STATUS_ICON_REMOTE]->SetStatus( CIconWnd::STATUS_ON );
		}
		else {
			pIconWnd_[STATUS_ICON_REMOTE]->SetStatus( CIconWnd::STATUS_OFF );
		}
	}
}

// USB �޸� ���Ῡ�� 
void CEPncUIDlg2::updateUsbMemConnectDisp()
{
	static int PREV_STATE = -1;
	int	curr_state = ( bConnectedUsbMemory_ ) ? 1 : 0;
	
	if( PREV_STATE != curr_state ) {
		PREV_STATE = curr_state;

		if( curr_state != 0 ) {
			pIconWnd_[STATUS_ICON_USB]->SetStatus( CIconWnd::STATUS_ON );
		}
		else {
			pIconWnd_[STATUS_ICON_USB]->SetStatus( CIconWnd::STATUS_OFF );
		}
	} 
}

// ���� ��/�� ǥ�� ��� 
void CEPncUIDlg2::updateBlockExistDisp()
{
	static int PREV_STATE = -1;

#ifdef _PA_G2400_
	int curr_state = pa::PPAStatus->GetPAStatus()->bInput[pa::IN111_MODEL_BLOCK_EXIST];
#endif
#ifdef _PA_G1600_
 	int curr_state = 0;
//	int curr_state = pa::PPAStatus->GetPAStatus()->bInput[pa::IN20017_DetectedBlock];
#endif

	if( pIconWnd_[STATUS_ICON_BLOCK] != NULL )
	{
		if( PREV_STATE != curr_state ) {
			PREV_STATE = curr_state;

			if( curr_state != 0 ) {
				pIconWnd_[STATUS_ICON_BLOCK]->SetStatus( CIconWnd::STATUS_ON );
			}
			else {
				pIconWnd_[STATUS_ICON_BLOCK]->SetStatus( CIconWnd::STATUS_OFF );
			}
		} 
	}
}

// �۾� ������� ǥ�� ���  
void CEPncUIDlg2::updateProgressBarStatus()
{
	static int		PREV_NCFILE_LOADING = -1;
	static double	PREV_PERSENT = -10.0;

	CRect	rcPROG_AREA = rcStatusArea_[STATUS_PROG_RATE1];

	int		nNCFileLoading  = pa::PNCFileMgr->GetCurrentWorkNCFileIndex();
	BOOL	bIsFileLoading	= FALSE;
	BOOL	bUpdateFilePath = FALSE;			// FilePath ������Ʈ 
	BOOL	bUpdateRate		= FALSE;			// �۾� ������ ������Ʈ

	hcutil::CCanvasCELayer*	pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get( nStatusLayerIndex_ );

	//////////////////////////////////////////////////////////////////////////
	if( PREV_NCFILE_LOADING != nNCFileLoading ) 
	{
		PREV_NCFILE_LOADING = nNCFileLoading;
		if( nNCFileLoading != -1 ) 
		{
			// NC ������ ���� ������. NC ������ �������� ó�� �ѹ� ����
			// ���� NC ���� �̸�/��� �� ǥ��
			bIsFileLoading	= TRUE;
			bUpdateFilePath = TRUE;
			bUpdateRate		= TRUE;
			PREV_PERSENT	= 0.0;
		}
		else 
		{
			// NC ������ ������. NC ������ �������� ó�� �ѹ� ����  
			// ���� ���¸� ��� �����, �ʱ� ���� ǥ�� 
			bUpdateFilePath	= TRUE;
			bUpdateRate		= TRUE;
		}
	}

	if( bUpdateRate || 
		( pa::PPAStatus->GetRunMode() == pa::RUNMODE_RUN || pa::PPAStatus->GetRunMode() == pa::RUNMODE_TOSTOP ) ) 
	{
		// �������� ����Ѵ� 
		double fTotalLines	= (double)(pa::PPAStatus->GetThreadState()->hNCFileInfo.total_lines);
		double fCurrStep	= (double)(pa::PPAStatus->GetThreadState()->hNCFileInfo.machining_lines);
		double fCurrRate	= 0.0; //(fCurrStep / fTotalLines ) * 100.0;

		if( fCurrStep < 0.1 || fTotalLines < 0.1 ) {
			fCurrRate = 0.0;
		} else {
			fCurrRate = ( fCurrStep / fTotalLines ) * 100.0;
			fCurrRate = fCurrRate > 100.0 ? 100.0 : fCurrRate;	// �������� 100.0�� ���� �ʵ��� �Ѵ� 
		}

		if( fabs( fCurrRate - PREV_PERSENT ) > 0.1 ) {
			PREV_PERSENT = fCurrRate;
			//////////////////////////////////////////////////////////////////////////
			F_CURRENT_RUN_RATE = fCurrRate;
			//////////////////////////////////////////////////////////////////////////
			bUpdateRate = TRUE;
		} else {
			bUpdateRate = FALSE;
		}
	}

	if( bUpdateRate ) 
	{
		// ������ ǥ�� - �׸� 
		CRect rcTemp = rcPROG_AREA;
		rcTemp.right = rcTemp.left + (int)( rcPROG_AREA.Width() * ( PREV_PERSENT / 100.0 ) + 0.5 );
		pLayer->Clear( rcPROG_AREA, FALSE );
		pLayer->FillSolidRect( &rcTemp, RGB(32,149,231) );
		InvalidateRect( rcPROG_AREA );
		
		// ������ ǥ�� - ����
		CString strRate;
		strRate.Format(_T("%.0f%%"), PREV_PERSENT);
		((CStatic*)GetDlgItem(IDC_STATIC_PROG_RATE))->SetWindowText( strRate );
	} 
}

void CEPncUIDlg2::updateToolTime()
{
	CString strTemp1;
	CString strTemp2;

	static int PREV_TOOL1_NO = -1;
	static int PREV_TOOL2_NO = -1;

	int nTool1No_ = pa::PPAStatus->GetPAStatus()->nCurrentToolNo;
	int nTool2No_ = pa::PPAStatus->GetPAStatus()->nCurrentTool2No;

	static DWORD PREV_REMAIN1 = -1;
	static DWORD PREV_REMAIN2 = -1;
	static int PREV_ERR1 = -1;
	static int PREV_ERR2 = -1;

	DWORD	dwMax1 = pa::PTool->GetToolData(nTool1No_)->dwMaximumTime;
	DWORD	dwCur1 = pa::PTool->GetToolData(nTool1No_)->dwUsingTime;
	DWORD	dwMax2 = pa::PTool->GetToolData(nTool2No_)->dwMaximumTime;
	DWORD	dwCur2 = pa::PTool->GetToolData(nTool2No_)->dwUsingTime;

	if (nTool1No_ == 0)
	{
		dwMax1 = 0;
		dwCur1 = 0;
	}

	if (nTool2No_ == 0)
	{
		dwMax2 = 0;
		dwCur2 = 0;
	}

	DWORD dwRemain1 = (dwMax1 >= dwCur1) ? (dwMax1 - dwCur1) : (dwCur1 - dwMax1);
	DWORD dwRemain2 = (dwMax2 >= dwCur2) ? (dwMax2 - dwCur2) : (dwCur2 - dwMax2);

	int bIsTool1Err = (pa::PTool->GetToolData(nTool1No_)->dwErrCode != 0) ? 1 : 0;
	int	bIsTool2Err = (pa::PTool->GetToolData(nTool2No_)->dwErrCode != 0) ? 1 : 0;

	BOOL isRedrawTool1 = ((PREV_TOOL1_NO != nTool1No_) && (nTool1No_ == 0)) ? TRUE : FALSE;
	BOOL isRedrawTool2 = ((PREV_TOOL2_NO != nTool2No_) && (nTool2No_ == 0)) ? TRUE : FALSE;

	if ((PREV_REMAIN1 != dwRemain1) || (PREV_ERR1 != bIsTool1Err) || (isRedrawTool1 == TRUE))
	{
		int dRemainMinute1 = dwRemain1 / 60;
		int dRemainSecond1 = dwRemain1 - dRemainMinute1 * 60;

		strTemp1.Format(_T("%02d:%02d"), dRemainMinute1, dRemainSecond1);
		((CStatic*)GetDlgItem(IDC_STATIC_TOOL_TIME))->SetWindowText( strTemp1 );

		PREV_REMAIN1 = dwRemain1;
		PREV_ERR1 = bIsTool1Err;
	}

	if ((PREV_REMAIN2 != dwRemain2) || (PREV_ERR2 != bIsTool2Err) || (isRedrawTool2 == TRUE))
	{
		int dRemainMinute2 = dwRemain2 / 60;
		int dRemainSecond2 = dwRemain2 - dRemainMinute2 * 60;

		strTemp2.Format(_T("%02d:%02d"), dRemainMinute2, dRemainSecond2);
		((CStatic*)GetDlgItem(IDC_STATIC_TOOL_TIME2))->SetWindowText( strTemp2 );

		PREV_REMAIN2 = dwRemain2;
		PREV_ERR2 = bIsTool2Err;
	}

	PREV_TOOL1_NO = nTool1No_;
	PREV_TOOL2_NO = nTool2No_;
}

void CEPncUIDlg2::updateNCStatus()
{
	pa::EN_NC_FILESTATE NCFileState = pa::PPAStatus->GetNCFileState();

	switch (NCFileState)
	{
	case pa::NCFILE_STATE_BEFORE:
		pOperButtonsEx_[OPER_BTN_NC_LOADED]->ShowWindow(SW_SHOW);
		pOperButtonsEx_[OPER_BTN_NC_RUNNING]->ShowWindow(SW_HIDE);
		pOperButtonsEx_[OPER_BTN_NC_FINISHED]->ShowWindow(SW_HIDE);
		break;

	case pa::NCFILE_STATE_RUNNING:
		pOperButtonsEx_[OPER_BTN_NC_LOADED]->ShowWindow(SW_HIDE);
		pOperButtonsEx_[OPER_BTN_NC_RUNNING]->ShowWindow(SW_SHOW);
		pOperButtonsEx_[OPER_BTN_NC_FINISHED]->ShowWindow(SW_HIDE);
		break;

	case pa::NCFILE_STATE_COMPLETE:
		pOperButtonsEx_[OPER_BTN_NC_LOADED]->ShowWindow(SW_HIDE);
		pOperButtonsEx_[OPER_BTN_NC_RUNNING]->ShowWindow(SW_HIDE);
		pOperButtonsEx_[OPER_BTN_NC_FINISHED]->ShowWindow(SW_SHOW);
		break;

	default:
		pOperButtonsEx_[OPER_BTN_NC_LOADED]->ShowWindow(SW_HIDE);
		pOperButtonsEx_[OPER_BTN_NC_RUNNING]->ShowWindow(SW_HIDE);
		pOperButtonsEx_[OPER_BTN_NC_FINISHED]->ShowWindow(SW_HIDE);
		break;
	}
}

// Demo ��� ���� ǥ��. ���� 
void CEPncUIDlg2::updateDemoModeDisp()
{
	static int PREV_MODE = -1;
	int curr_mode = pa::PPAStatus->GetThreadState()->bIsDemoMode_ ? 1 : 0;
	CString strMode;
	// 	CRect	rect(920, 10, 1020, 26);
	CRect	rect(920, 4, 1020, 20);

	if( PREV_MODE != curr_mode ) {
		PREV_MODE = curr_mode;

		hcutil::CCanvasCELayer	*pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get(1);
		if( pLayer ) {
			//	pLayer->Clear(FALSE);
			CRect rcTemp = rect;
			rcTemp.InflateRect( 1, 1, 1, 1 );
			pLayer->Clear( rcTemp, FALSE );
			if( curr_mode != 0 ) {
				int			prev_bkmode = pLayer->SetBkMode( TRANSPARENT );
				COLORREF	prev_clr	= pLayer->SetTextColor( RGB(250, 32, 32) );
				strMode.Format( _T("DEMO MODE") );
				pLayer->DrawText( strMode, rect, DT_LEFT|DT_SINGLELINE );
				pLayer->SetBkMode( prev_bkmode );
				pLayer->SetTextColor( prev_clr );
			}
			InvalidateRect( &rcTemp, FALSE );
		}
	}
}

void CEPncUIDlg2::updateNumSelectNcFileDisp()
{
// 	static COLORREF		CLR_BACKGROUND = RGB(235, 234, 239);
// 	static COLORREF		CLR_TEXT = RGB(82, 82, 82);
// 	hcutil::CCanvasCELayer	*pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get(1);
// 
// 	int			nBkMode	= pLayer->SetBkMode( TRANSPARENT );
// 	COLORREF	clrOld	= pLayer->SetTextColor( CLR_TEXT );
// 	CFont*		pOldFont= (CFont*)pLayer->SelectObject( &hFntNcFile_ );
// 
// 	//////////////////////////////////////////////////////////////////////////

	static int PREV_NUM = -1;
	static int PREV_NUM_SELECT = -1;
	int num_ncfile = pa::PNCFileMgr->GetNumNCFile();
	int num_select_ncfile = pa::PNCFileMgr->GetNumSelectedNcFile();
	CString strMsg;

	if( PREV_NUM != num_ncfile || PREV_NUM_SELECT != num_select_ncfile )
	{
		PREV_NUM = num_ncfile;
		PREV_NUM_SELECT = num_select_ncfile;
		
		strMsg.Format( _T("NcFiles [%d/%d]"), num_select_ncfile, num_ncfile );

		((CStatic*)GetDlgItem(IDC_STATIC_NUM_SELECTED_FILE_COLLAPSE))->SetWindowText( strMsg );
		((CStatic*)GetDlgItem(IDC_STATIC_NUM_SELECTED_FILE_EXPAND))->SetWindowText( strMsg );

// 		pLayer->FillSolidRect( rcStatusArea_[STATUS_NUM_SELECT_NCFILE], CLR_BACKGROUND );
// 		pLayer->DrawText( strMsg, rcStatusArea_[STATUS_NUM_SELECT_NCFILE], DT_LEFT|DT_VCENTER|DT_SINGLELINE );
	
//		InvalidateRect( rcStatusArea_[STATUS_NUM_SELECT_NCFILE] );
	}

	//////////////////////////////////////////////////////////////////////////

// 	pLayer->SetBkMode( nBkMode );
// 	pLayer->SetTextColor( clrOld );
// 	pLayer->SelectObject( pOldFont );
}

//////////////////////////////////////////////////////////////////////////

void CEPncUIDlg2::updateNCFile()
{
	static CString PREV_NCFile = _T("");
	CString OpenedNCFile;
	OpenedNCFile = strNCFileName; 

	if (pa::PNCFileMgr->GetCurrentWorkNCFileIndex() == -1)
	{
		OpenedNCFile = _T("");
	}

	if (PREV_NCFile != OpenedNCFile)
	{
		PREV_NCFile = OpenedNCFile;
		((CStatic*)GetDlgItem(IDC_STATIC_NC_FILE))->SetWindowText( OpenedNCFile );
	}
}

void CEPncUIDlg2::updateSystemStatus()
{
	static CString PREV_RUNMODE = _T("");
	CString curr_Runmode;
	pa::EN_RUNMODE runMode;
	runMode = pa::PPAStatus->GetRunMode();
	BOOL	bPAConnected = (pa::PPAStatus->GetThreadState()->nIsConnectedPAController != 0) ? 1 : 0;
	BOOL	bIOConnected = (pa::PPAStatus->GetThreadState()->nIsConnectedIOBoard != 0) ? 1 : 0;
	
	if (!bPAConnected || !bIOConnected)
	{
		curr_Runmode = _T("Not Connected");
	}

	else
	{
		switch (runMode)
		{
		case pa::RUNMODE_INIT:
		case pa::RUNMODE_STOP:
				curr_Runmode = _T("Connected");
			break;
		case pa::RUNMODE_TOSTOP:
		case pa::RUNMODE_TORUN:
		case pa::RUNMODE_RUN:
			curr_Runmode = _T("Running");
			break;
		case pa::RUNMODE_ERROR:
			curr_Runmode = _T("Error");
			break;
		}
	}
	
	if ( curr_Runmode.Compare(PREV_RUNMODE) )
	{
		((CStatic*)GetDlgItem(IDC_STATIC_SYSTEM_STATUS))->SetWindowText( curr_Runmode );
		PREV_RUNMODE = curr_Runmode;
	}
}

void CEPncUIDlg2::updateDeviceStatus()
{
	static CString PREV_PA_CONNECTION_STATUS = _T("");
	static CString PREV_IO_CONNECTION_STATUS = _T("");
	static CString PREV_TOOL_NO = _T("");
	static CString PREV_TOOL_NO2 = _T("");
	static CString PREV_SPINDLE_RPM = _T("");
	static CString PREV_SPINDLE_RPM2 = _T("");

	CString curr_PA_connection_status;
	CString curr_IO_connection_status;
	CString curr_tool_no;
	CString curr_tool_no2;
	CString curr_spindle_rpm;
	CString curr_spindle_rpm_addComma;
	CString curr_spindle_rpm2;
	CString curr_spindle_rpm2_addComma;

	BOOL	bPAConnected = (pa::PPAStatus->GetThreadState()->nIsConnectedPAController != 0) ? 1 : 0;
	BOOL	bIOConnected = (pa::PPAStatus->GetThreadState()->nIsConnectedIOBoard != 0) ? 1 : 0;
	BOOL	bIsSpindleRun = (pa::PPAStatus->GetPAStatus()->nSpindleRun != 0) ? 1 : 0;
	BOOL	bIsSpindleRun2 = (pa::PPAStatus->GetPAStatus()->nSpindle2Run != 0) ? 1 : 0;

	// Controller, IO Board ���� ����
	if (bPAConnected)
	{
		curr_PA_connection_status = _T("Controller");
	}
	else
	{
		curr_PA_connection_status = _T("Controller "); // OnCtlColor�Լ� ȣ���� ����, ���� ���¶� Text�� �ٸ���
	}

	if (bIOConnected)
	{
		curr_IO_connection_status = _T("IO Board");
	}
	else
	{
		curr_IO_connection_status = _T("IO Board "); // OnCtlColor�Լ� ȣ���� ����, ���� ���¶� Text�� �ٸ���
	}
	
	if (curr_PA_connection_status.Compare(PREV_PA_CONNECTION_STATUS))
	{
		((CStatic*)GetDlgItem(IDC_STATIC_PA_CONNECTED))->SetWindowText( curr_PA_connection_status );
		PREV_PA_CONNECTION_STATUS = curr_PA_connection_status;
	}

	if (curr_IO_connection_status.Compare(PREV_IO_CONNECTION_STATUS))
	{
		((CStatic*)GetDlgItem(IDC_STATIC_IO_CONNECTED))->SetWindowText( curr_IO_connection_status );
		PREV_IO_CONNECTION_STATUS = curr_IO_connection_status;
	}

	// Tool No ����
	if ( bIsSpindleRun )
	{
		curr_tool_no.Format(_T("#%d"), pa::PPAStatus->GetPAStatus()->nCurrentToolNo);
	}
	
	else
	{
		curr_tool_no.Format(_T("#%d "), pa::PPAStatus->GetPAStatus()->nCurrentToolNo); // OnCtlColor�Լ� ȣ���� ����, ȸ�� ���¶� Text�� �ٸ���
	}

	if ( bIsSpindleRun2 )
	{
		curr_tool_no2.Format(_T("#%d"), pa::PPAStatus->GetPAStatus()->nCurrentTool2No);
	}

	else
	{
		curr_tool_no2.Format(_T("#%d "), pa::PPAStatus->GetPAStatus()->nCurrentTool2No);
	}

	if (curr_tool_no.Compare(PREV_TOOL_NO))
	{
		((CStatic*)GetDlgItem(IDC_STATIC_TOOL_NO))->SetWindowText( curr_tool_no );
		PREV_TOOL_NO = curr_tool_no;
	}

	if (curr_tool_no2.Compare(PREV_TOOL_NO2))
	{
		((CStatic*)GetDlgItem(IDC_STATIC_TOOL_NO_2))->SetWindowText( curr_tool_no2 );
		PREV_TOOL_NO2 = curr_tool_no2;
	}

	// RPM ����
	curr_spindle_rpm.Format(_T("%d"), pa::PPAStatus->GetPAStatus()->nSpindleSpeed);
	curr_spindle_rpm2.Format(_T("%d"), pa::PPAStatus->GetPAStatus()->nSpindleSpeed2);

	AddCommaToData(curr_spindle_rpm, curr_spindle_rpm_addComma);
	AddCommaToData(curr_spindle_rpm2, curr_spindle_rpm2_addComma);

	if (curr_spindle_rpm_addComma.Compare(PREV_SPINDLE_RPM))
	{
		((CStatic*)GetDlgItem(IDC_STATIC_SPINDLE_RPM))->SetWindowText( curr_spindle_rpm_addComma );
		PREV_SPINDLE_RPM = curr_spindle_rpm_addComma;
	}

	if (curr_spindle_rpm2.Compare(PREV_SPINDLE_RPM2))
	{
		((CStatic*)GetDlgItem(IDC_STATIC_SPINDLE_RPM2))->SetWindowText( curr_spindle_rpm2_addComma );
		PREV_SPINDLE_RPM2 = curr_spindle_rpm2_addComma;
	}

	// Tool Error ���� 
	static int PREV_TOOL_ERROR = -1;
	static int PREV_TOOL_ALARM = -1;
	int toolError = (getToolError() == TRUE) ? 1 : 0;
	int toolAlarm = (getToolAlarm());

	if (PREV_TOOL_ERROR != toolError) {
		PREV_TOOL_ERROR = toolError;
		((CStatic*)GetDlgItem(IDC_STATIC_TOOL_ERROR))->SetWindowText(_T("Tool error occurred"));
	}
	if (PREV_TOOL_ALARM != toolAlarm) {
		PREV_TOOL_ALARM = toolAlarm;
		((CStatic*)GetDlgItem(IDC_STATIC_TOOL_ALARM))->SetWindowText(_T("Alarm of maximum tool usage time"));
	}
}

void CEPncUIDlg2::writeLog( LPCTSTR log_msg )
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	WriteLog( CLog::TYPE_OPER, 1, log_msg );
	//////////////////////////////////////////////////////////////////////////
}

//////////////////////////////////////////////////////////////////////////
// USB �޸� ���� ���� �˸� 
LRESULT CEPncUIDlg2::OnUsbMemory(WPARAM wparam, LPARAM lparam)
{
	BOOL	bIsConnect = (int)(wparam) == 0 ? FALSE : TRUE;

	bConnectedUsbMemory_ = bIsConnect;

	return 0;
}
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
#ifdef _SAVE_RUNTIME_UI_
void CEPncUIDlg2::SAVE_RUNNING_TIME(BOOL b, TCHAR* pFilePath, int nLineNo, int nRunningTime, int nRemainTime, int nRemainTime2 )
{
	if( b )
	{
		DBG_SAVE_RUNNING_TIME = 0;	// �ʱ�ȭ 

		FILE *pf = _tfopen( TXT_RUNNING_TIME_UI_PATH, _T("at") );

		if( pf != NULL )
		{
			_ftprintf( pf, _T("%s\n"), pFilePath );

			fclose( pf );

			pf = NULL;
		}
	}
	else if( pa::PPAStatus->GetThreadState()->hRunMode == pa::RUNMODE_RUN ) 
	{
		int nLineNo = pa::PPAStatus->GetThreadState()->nCurrentNCCodeStepNo;

		if( DBG_SAVE_RUNNING_TIME < nLineNo )
		{
			//////////////////////////////////////////////////////////////////////////
			// ���Ͽ� ����
			FILE *pf = _tfopen( TXT_RUNNING_TIME_UI_PATH, _T("at") );

			if( pf != NULL )
			{
				_ftprintf( pf, _T("%d %d %d %d \n"), nLineNo, nRunningTime, nRemainTime, nRemainTime2 );

				fclose( pf ); 

				pf = NULL;
			}

			//////////////////////////////////////////////////////////////////////////

			DBG_SAVE_RUNNING_TIME += 1000;	// 1000 ���� ������ ����  
		}
	}
}
#endif

void CEPncUIDlg2::doButtonProgramCollapse()
{
	this->ShowWindow(SW_MINIMIZE);
}


void CEPncUIDlg2::doButtonProgramClose()
{
	CDialog::OnOK();
}

// void CEPncUIDlg2::OnLButtonDown(UINT nFlags, CPoint point)
// {
// // 	PostMessage(WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM(point.x, point.y));
// // 	CWnd::OnLButtonDown(nFlags, point);
// }

LRESULT CEPncUIDlg2::OnNcHitTest(CPoint point)
{
  UINT hit = CDialog::OnNcHitTest(point);
  if (hit == HTCLIENT)
  {
    hit = HTCAPTION;
  }
  return hit;
}

//���α׷� â�� �����϶� â�� ��ġ ������ ���� �޼����� ������ (PSETUP_DLG �� �̹����� ��ġ�� ������ child dlg �� �ƴ� pop up dlg �� �Ǿ��ֱ⶧����)
void CEPncUIDlg2::OnMove(int x, int y)
{
	CDialog::OnMove(x, y);

	/*
	CString s;
	s.Format(_T("\n new position:x=%d, y=%d \n"),x,y ); TRACE( s );
	*/

	if ( PSETUP_DLG ) {
		NewPos->x=x;
		NewPos->y=y;
		PSETUP_DLG->PostMessage( WM_NOTIFY_WINDOW_MOVE, (WPARAM)0, (LPARAM)NewPos );
	}

	if ( PERROR_DLG ) {
		NewPos->x=x;
		NewPos->y=y;
		PERROR_DLG->PostMessage( WM_NOTIFY_WINDOW_MOVE, (WPARAM)0, (LPARAM)NewPos );
	}

	CMsgDlg* pMSGDlg = CMsgDlgThread::GetInstance()->GetDlg();
	if ( pMSGDlg ) {
		NewPos->x=x;
		NewPos->y=y;
		pMSGDlg->PostMessage( WM_NOTIFY_WINDOW_MOVE, (WPARAM)0, (LPARAM)NewPos );
	}
	
	// if (pAutoLoaderRefillDlg)
	// {
	// 	pAutoLoaderRefillDlg->PostMessage( WM_NOTIFY_WINDOW_MOVE, (WPARAM)0, (LPARAM)NewPos );
	// }

	if ( P_NCFILE_MGR_DLG2 ) {
		NewPos->x=x;
		NewPos->y=y;
		P_NCFILE_MGR_DLG2->PostMessage( WM_NOTIFY_WINDOW_MOVE, (WPARAM)0, (LPARAM)NewPos );
	}

}

void CEPncUIDlg2::DeleteLeftOverNCFiles() {
	CString strFileNames[100];
	int nNum = hcutil::GetFileNames( NCFILE_PATH, strFileNames );

	for( int i = 0; i<nNum; i++ )
	{
		if ( !pNCFileListBoxEx_->DoesExist( strFileNames[i] ) ) {
			CString strFile, strErrMsg;
			strFile.Format( _T("%s\\%s"), NCFILE_PATH, strFileNames[i] );
			if( hcutil::DeleteFile( strFile, strErrMsg ) == FALSE ) {
			}
		}
	}
}

HBRUSH CEPncUIDlg2::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	switch(nCtlColor)
	{
	case CTLCOLOR_STATIC:
		{
			if (pa::PPAStatus == NULL || pa::PPAStatus->GetPAStatus() == NULL)
				return hbr;

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_MODEL_INFO)
			{
				pDC->SetBkMode(TRANSPARENT);
				pDC->SetTextColor(RGB(103, 103, 111));
				return (HBRUSH)m_brModelInfo;
			}

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_NUM_SELECTED_FILE_EXPAND)
			{
				pDC->SetBkMode(TRANSPARENT);
				pDC->SetTextColor(RGB(0, 0, 0));
				return (HBRUSH)m_brNCFileInfo;
			}

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_NC_FILE)
			{
				pDC->SetBkMode(TRANSPARENT);
				pDC->SetTextColor(RGB(58, 58, 58));
				return (HBRUSH)m_brNCFileInfo;
			}

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_SYSTEM_STATUS)
			{
				pDC->SetBkMode(TRANSPARENT);
				pDC->SetTextColor(RGB(32,149,231));
				return (HBRUSH)m_brNCFileInfo;
			}

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_PA_CONNECTED)
			{
				BOOL	bPAConnected = (pa::PPAStatus->GetThreadState()->nIsConnectedPAController != 0) ? 1 : 0;
				if (bPAConnected)
				{
					pDC->SetBkMode(TRANSPARENT);
					pDC->SetTextColor(RGB(32,149,231));
					return (HBRUSH)m_brNCFileInfo;
				}

				else
				{
					pDC->SetBkMode(TRANSPARENT);
					pDC->SetTextColor(RGB(169,169,169));
					return (HBRUSH)m_brNCFileInfo;
				}
			}

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_IO_CONNECTED)
			{
				BOOL	bIOConnected = (pa::PPAStatus->GetThreadState()->nIsConnectedIOBoard != 0) ? 1 : 0;
				if (bIOConnected)
				{
					pDC->SetBkMode(TRANSPARENT);
					pDC->SetTextColor(RGB(32,149,231));
					return (HBRUSH)m_brNCFileInfo;
				}
				else
				{
					pDC->SetBkMode(TRANSPARENT);
					pDC->SetTextColor(RGB(169,169,169));
					return (HBRUSH)m_brNCFileInfo;
				}
			}

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_TOOL_NO)
			{
				BOOL	bIsSpindleRun = (pa::PPAStatus->GetPAStatus()->nSpindleRun != 0) ? 1 : 0;
				if (bIsSpindleRun)
				{
					pDC->SetBkMode(TRANSPARENT);
					pDC->SetTextColor(RGB(32,149,231));
					return (HBRUSH)m_brNCFileInfo;
				}
				else
				{
					pDC->SetBkMode(TRANSPARENT);
					pDC->SetTextColor(RGB(169,169,169));
					return (HBRUSH)m_brNCFileInfo;
				}
			}

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_TOOL_NO_2)
			{
				BOOL	bIsSpindleRun2 = (pa::PPAStatus->GetPAStatus()->nSpindle2Run != 0) ? 1 : 0;
				if (bIsSpindleRun2)
				{
					pDC->SetBkMode(TRANSPARENT);
					pDC->SetTextColor(RGB(32,149,231));
					return (HBRUSH)m_brNCFileInfo;
				}
				else
				{
					pDC->SetBkMode(TRANSPARENT);
					pDC->SetTextColor(RGB(169,169,169));
					return (HBRUSH)m_brNCFileInfo;
				}
			}

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_SPINDLE_RPM || pWnd->GetDlgCtrlID() == IDC_STATIC_SPINDLE_RPM2)
			{
				pDC->SetBkMode(TRANSPARENT);
				pDC->SetTextColor(RGB(58, 58, 58));
				return (HBRUSH)m_brNCFileInfo;
			}

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_MILLING_TIME )
			{
				pDC->SetBkMode(TRANSPARENT);
				pDC->SetTextColor(RGB(58, 58, 58));
				return (HBRUSH)m_brNCFileInfo;
			}

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_PROG_RATE )
			{
				pDC->SetBkMode(TRANSPARENT);
				pDC->SetTextColor(RGB(32,149,231));
				return (HBRUSH)m_brNCFileInfo;
			}

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_TOOL_TIME )
			{
				static int PREV_TOOL1 = -1;
				int		nToolNo_ = pa::PPAStatus->GetPAStatus()->nCurrentToolNo;
				BOOL	bIsToolErr = FALSE; //(pa::PTool->GetToolData(nToolNo_)->dwErrCode != 0) ? 1 : 0;
				BOOL	bIsOverTime= FALSE; //(pa::PTool->GetToolData(nToolNo_)->dwMaximumTime < pa::PTool->GetToolData(nToolNo_)->dwUsingTime) ? 1 : 0;

				if (nToolNo_ == 0) {
					bIsToolErr  = FALSE;
					bIsOverTime = FALSE;
				}
				else {
					bIsToolErr = (pa::PTool->GetToolData(nToolNo_)->dwErrCode != 0) ? 1 : 0;
					bIsOverTime= (pa::PTool->GetToolData(nToolNo_)->dwMaximumTime < pa::PTool->GetToolData(nToolNo_)->dwUsingTime) ? 1 : 0;
				}

				pDC->SetBkMode(TRANSPARENT);
				if (bIsToolErr == FALSE && bIsOverTime == FALSE) {
					pDC->SetTextColor(RGB(58, 58, 58));
				} else {
					if (bIsOverTime == TRUE) {
						pDC->SetTextColor(RGB(255,172,0));						
					}
					else {
						pDC->SetTextColor(RGB(209,37,43));	
					}
				}
				return (HBRUSH)m_brNCFileInfo;
			}

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_TOOL_TIME2 )
			{
				int		nToolNo_ = pa::PPAStatus->GetPAStatus()->nCurrentTool2No;
				BOOL	bIsToolErr= FALSE; //(pa::PTool->GetToolData(nTool2No_)->dwErrCode != 0) ? 1 : 0;
				BOOL	bIsOverTime= FALSE; //(pa::PTool->GetToolData(nTool2No_)->dwMaximumTime < pa::PTool->GetToolData(nTool2No_)->dwUsingTime) ? 1 : 0;

				if (nToolNo_ == 0) {
					bIsToolErr  = FALSE;
					bIsOverTime = FALSE;
				} 
				else {
					bIsToolErr = (pa::PTool->GetToolData(nToolNo_)->dwErrCode != 0) ? 1 : 0;
					bIsOverTime= (pa::PTool->GetToolData(nToolNo_)->dwMaximumTime < pa::PTool->GetToolData(nToolNo_)->dwUsingTime) ? 1 : 0;
				}

// 				if (bIsTool2Err)
// 				{
// 					pDC->SetBkMode(TRANSPARENT);
// 					pDC->SetTextColor(RGB(209,37,43));
// 					return (HBRUSH)m_brNCFileInfo;
// 				}
// 				else if (bIsOverTime) 
// 				{
// 					pDC->SetBkMode(TRANSPARENT);
// 					pDC->SetTextColor(RGB(255,172,0));
// 					return (HBRUSH)m_brNCFileInfo;
// 				}
// 				else 
// 				{
// 					pDC->SetBkMode(TRANSPARENT);
// 					pDC->SetTextColor(RGB(58, 58, 58));
// 					return (HBRUSH)m_brNCFileInfo;
// 				}
				pDC->SetBkMode(TRANSPARENT);
				if (bIsToolErr == FALSE && bIsOverTime == FALSE) {
					pDC->SetTextColor(RGB(58, 58, 58));
				} else {
					if (bIsOverTime == TRUE) {
						pDC->SetTextColor(RGB(255,172,0));						
					}
					else {
						pDC->SetTextColor(RGB(209,37,43));	
					}
				}
				return (HBRUSH)m_brNCFileInfo;
			}

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_TOOL_ERROR) 
			{
				BOOL isError = getToolError();	// ������ TRUE
				pDC->SetBkMode(TRANSPARENT);
				if (!isError) {
					pDC->SetTextColor(RGB(168, 168, 168));
				}
				else {
					pDC->SetTextColor(RGB(37, 148, 230));
				}
				return (HBRUSH)m_brNCFileInfo;
			}

			if (pWnd->GetDlgCtrlID() == IDC_STATIC_TOOL_ALARM)
			{
				BOOL isError = (getToolAlarm() == 0) ? 0 : 1;
				pDC->SetBkMode(TRANSPARENT);
				if (!isError) {
					pDC->SetTextColor(RGB(168, 168, 168));
				}
				else {
					pDC->SetTextColor(RGB(37, 148, 230));
				}
				return (HBRUSH)m_brNCFileInfo;
			}
		}
	}

	return hbr;
}

BOOL CEPncUIDlg2::OnDeviceChange(UINT nEventType, DWORD dwData)
{
	int i = 0;
	PDEV_BROADCAST_HDR		hdr;
	hdr = (PDEV_BROADCAST_HDR)dwData;

	switch (nEventType)
	{
	case DBT_DEVICEARRIVAL:
		if(hdr->dbch_devicetype == DBT_DEVTYP_VOLUME)
		{
			DWORD		drive_info = ::GetLogicalDrives();
			DWORD		tempdi = drive_info;
			BOOL		bFind = FALSE;
			strDriverName_ = "";

			for (int i =0; tempdi != 0; tempdi >>=1, i++)
			{
				int rtn = tempdi & 1;
				if (rtn == 1)
				{
					TCHAR DriverName[10] = {0};
					DriverName[0] = 'A' + i;
					DriverName[1] = ':';
					DriverName[2] = '\\';
					UINT urtn = ::GetDriveType(DriverName);
					if (::GetDriveType(DriverName) == DRIVE_REMOVABLE)
					{
						strDriverName_ += CString(DriverName);
						isUSBConnected_ = TRUE;
					}
				}
			}
		}
		break;

	case DBT_DEVICEREMOVECOMPLETE:
		if(hdr->dbch_devicetype == DBT_DEVTYP_VOLUME)
		{
			isUSBConnected_ = FALSE;
		}
		break;
	}
	return TRUE;
}

void CEPncUIDlg2::AddCommaToData(CString data, CString &commaData)
{
	if (commaData.GetLength())
	{
		commaData.Format(_T(""));
	}

	int count = data.GetLength();

	for (int i = 0; i < count; i++)
	{
		if (i && !(i % 3))
		{
			commaData = _T(",") + commaData;
		}

		commaData = CString(data[count - 1 - i]) + commaData;
	}
}

void CEPncUIDlg2::Quit()
{
	CDialog::OnOK();
}

LRESULT CEPncUIDlg2::OnEPncUIDlgQuit(WPARAM wparam, LPARAM lparam)
{
	// Splash ���̾�α׸� �����ϰ�
	CSplashDlg::DELETE_DLG();

	// Connect Fail ���̾�α׸� ����
	CConnectErrorDlg dlg;
	CString strTitle, strErrMsg, strTemp;

	strTitle.Format( _T("Connection Fail") );

	strErrMsg.Format( _T("") );
	strTemp.Format(_T(" Not conencted to the motion-controller.\r\n")); strErrMsg += strTemp;
	strTemp.Format(_T(" turn off power and checking the items. \r\n")); strErrMsg += strTemp;
	strTemp.Format(_T("\r\n")); strErrMsg += strTemp;
	strTemp.Format(_T("  > checking.. lan cable connection with motion controller \r\n")); strErrMsg += strTemp;
	strTemp.Format(_T("  > checking.. pc and motion controller's ip-address \r\n")); strErrMsg += strTemp;
	strTemp.Format(_T("  > checking.. motion-controller power-on \r\n")); strErrMsg += strTemp;

	dlg.SetTitle( strTitle );
	dlg.SetMessage( strErrMsg );
	dlg.SetButtonStatus( FALSE );
	dlg.DoModal();

	// ���α׷��� ���� �Ѵ� 
	((CEPncUIDlg2*)AfxGetMainWnd())->Quit();

	CDialog::OnCancel();

	return 0;
}

// 6���� �Ѱ���, �������¸� TRUE ���� 
// �Ѱ��� 100% ��, TRUE ���� 
BOOL CEPncUIDlg2::getToolError()
{
	BOOL bRet = FALSE;

	for (int i = 1; i<=6; i++) {
		if (pa::PTool->GetToolData(i)->dwErrCode != 0) {
			bRet = TRUE;
			break;
		}
	}
	if (bRet == FALSE) {
		if (getToolAlarm() == 2) {
			bRet = TRUE;
		}
	}

	return bRet;
}

// 6���� �Ѱ���, 90% �̻��̸� 1, 100% �̸� 2, �ƴϸ� 0 ���� 
int  CEPncUIDlg2::getToolAlarm()
{
	int nRet = 0;

	for (int i = 1; i<=6; i++) {
		if (pa::PTool->GetToolData(i)->fUsingRate > 99.9) {
			nRet = 2;
		}
		else if (pa::PTool->GetToolData(i)->fUsingRate > 90.0) {
			nRet = 1;
		}
		if (nRet == 2) {
			break;
		}
	}

	return nRet;
}

