#pragma once

//////////////////////////////////////////////////////////////////////////
// CNCStatusBarWnd
//////////////////////////////////////////////////////////////////////////

class CNCStatusBarWnd : public CWnd
{
	DECLARE_DYNAMIC(CNCStatusBarWnd)

	hcutil::CCanvasCE*	pCanvasCE_;

	int		nBkgndIndex_;
	int		nProgDispIndex_;
	int		nFilePathDipsIndex_;

	CRect	rcNCFilePathArea_;			// NC File ��� ǥ�� ����. ���⿡ �۾� �������� ���� ��� �Ѵ�. 
	CRect	rcPersentArea_;				// ������ ǥ�� ���� 

	CFont	hFont_;
	CFont*	pOldFont_;

	void calcLayout();
	void drawBackground();

public:
	CNCStatusBarWnd();
	virtual ~CNCStatusBarWnd();

	BOOL Create( CWnd* pParent, CRect rcWnd );

	void UpdateNCStatusBar();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();

	static double F_CURRENT_RUN_RATE;
};


