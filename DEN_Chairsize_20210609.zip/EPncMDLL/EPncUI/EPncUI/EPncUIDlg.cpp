// EPncUIDlg.cpp : ���� ����
//

#include "stdafx.h"
#include "EPncUI.h"
#include "EPncUIDlg.h"
#include "ErrorDlg.h"
#include "SetupDlg.h"
#include "MsgDlg.h"
#include "MsgDlgThread.h"
#include "FileCopyDlg.h"
#include "RestartDialog.h"
#include "NCFileMgrDlg2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////////
// CEPncUIDlg ��ȭ ����
//////////////////////////////////////////////////////////////////////////

CEPncUIDlg::CEPncUIDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEPncUIDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

 	pResourcePath_ = RESOURCE_PATH;
	bConnectedUsbMemory_ = FALSE;

	for (int i = 0; i>OPER_BTN_NUM; i++)
	{
		pOperButtonsEx_[i] = NULL;
	}
	pNCFileListBoxEx_ = NULL;
	pAutoLoaderStateWnd_ = NULL;
	pNCStateBarWnd_ = NULL;
}

void CEPncUIDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CEPncUIDlg, CDialog)
#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
	ON_WM_SIZE()
#endif
	//}}AFX_MSG_MAP
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_TIMER()
//	ON_MESSAGE(WM_IMGBUTTONEX_CLICKED, &CEPncUIDlg::OnImgButtonExClicked)
	ON_MESSAGE(WM_IMGBUTTONEX2_CLICKED, &CEPncUIDlg::OnImgButtonExClicked)
	ON_MESSAGE(WM_AUTOLOADER_REFILL, &CEPncUIDlg::OnAutoLoaderRefill)
	ON_MESSAGE(WM_USB_MEMORY, &CEPncUIDlg::OnUsbMemory)
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CEPncUIDlg �޽��� ó����
//////////////////////////////////////////////////////////////////////////

void CEPncUIDlg::PreInitDialog()
{
	CString strImageFilePath;
	CDC*	pDC = GetDC();
	CRect	rcWnd;

	//////////////////////////////////////////////////////////////////////////
	strImageFilePath.Format( _T("%s\\Background.bmp"), pResourcePath_ );

	GetClientRect( &rcWnd );

	pCanvasCE_ = new hcutil::CCanvasCE();
	ASSERT(pCanvasCE_ );
	pCanvasCE_->Create( this, pDC->GetSafeHdc(), rcWnd.Width(), rcWnd.Height(), RGB(1, 1, 0) );
	nBackgroundLayerIndex_ = pCanvasCE_->GetCanvasCELayerMgr()->Add( FALSE, RGB(1, 1, 0) );
	pCanvasCE_->GetCanvasCELayerMgr()->Add( TRUE, RGB(1, 1, 0) );
	ASSERT( nBackgroundLayerIndex_ != -1 );

	pCanvasCE_->GetCanvasCELayerMgr()->Get( nBackgroundLayerIndex_ )->LoadImageFormFile( strImageFilePath, CPoint(0, 0), CPoint(rcWnd.Width(), rcWnd.Height()) );
	//////////////////////////////////////////////////////////////////////////

	ReleaseDC( pDC );
	pDC = NULL;

// 	draw_model_info();

	CDialog::PreInitDialog();
}

void CEPncUIDlg::draw_model_info()
{
	hcutil::CCanvasCELayer	*pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get(1);

	CRect	rcTitle(532, 0, 0, 62);
	CRect	rcModel(0, 0, 0, 0);
	CFont	fontTitle, fontModel;
	CString strTitle, strModel;
	CSize	szTitle, szModel;

	strTitle = _T("TITLE"); //pa::PSWConfig->GetConfigData()->szMachineName;
	strModel = _T("model"); //pa::PSWConfig->GetConfigData()->szModelName;

	fontTitle.CreateFont(
		36, 0,
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Courier New") ); //_T("Courier New") );

	fontModel.CreateFont( 
		26, 0,
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Courier New") ); //_T("MS Sans Serif") );

	CFont		*pOldFont = NULL; 
	COLORREF	oldTextColor = pLayer->SetTextColor( RGB(255, 255, 255) );
	int			nPrevBkMode = pLayer->SetBkMode( TRANSPARENT );

	// draw title
	pOldFont = (CFont *)pLayer->SelectObject( &fontTitle );
	szTitle = pLayer->GetOutputTextExtent( strTitle );
	rcTitle.left	= rcTitle.left; 
	rcTitle.top		= rcTitle.bottom - szTitle.cy;
	rcTitle.right	= rcTitle.left + szTitle.cx;
	rcTitle.bottom	= rcTitle.bottom - 3;
	pLayer->DrawText( strTitle, &rcTitle, DT_LEFT|DT_TOP|DT_SINGLELINE );

	pLayer->SelectObject( &fontModel );
	szModel = pLayer->GetOutputTextExtent( strModel );
	rcModel.left	= rcTitle.right + 6;
	rcModel.top		= rcTitle.bottom - szModel.cy;
	rcModel.right	= rcModel.left + szModel.cx;
	rcModel.bottom	= rcTitle.bottom;
	pLayer->DrawText( strModel, &rcModel, DT_LEFT|DT_TOP|DT_SINGLELINE );

	pLayer->SetBkMode( nPrevBkMode );
	pLayer->SelectObject( pOldFont );
	pLayer->SetTextColor( oldTextColor );
	fontTitle.DeleteObject();
	fontModel.DeleteObject();
}

BOOL CEPncUIDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �� ��ȭ ������ �������� �����մϴ�. ���� ���α׷��� �� â�� ��ȭ ���ڰ� �ƴ� ��쿡��
	//  �����ӿ�ũ�� �� �۾��� �ڵ����� �����մϴ�.
	SetIcon(m_hIcon, TRUE);			// ū �������� �����մϴ�.
	SetIcon(m_hIcon, FALSE);		// ���� �������� �����մϴ�.

	//////////////////////////////////////////////////////////////////////////
	// ���� ����ȭ ���� �ʾƵ�, �Ʒ� �Լ��� ������ ���ϵȴ� 
#ifdef __USE_EPNCM_DLL__
	TRACE(_T("<1>\n"));
	INITIALIZE_EPNCM_DLL();
	TRACE(_T("<2>\n"));
#endif
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	// 
	CString strErrMsg;

	preinitialize_pmac_object( strErrMsg );

	initialize_ErrorDlg();

	CMsgDlgThread::GetInstance();

// 	initialize_SetupDlg();

	initialize_OperButtons();

	initialize_pmac_object( strErrMsg );

/*	pmac::SPmacState::INIT_IO_REF_VARIABLE();*/

	initialize_SetupDlg();

	initialize_NCFileListBox( strErrMsg );

	initialize_AutoLoaderStateWnd( strErrMsg );

	initialize_NCStateBarWnd( strErrMsg );

	BOOL b1 = pa::PTool->GetEnableToolUsageTime();
	BOOL b2 = pa::PTool->GetEnableRelatedTool();

// 	pmac::PTool->SetEnableToolUsageTime( TRUE );
// 	pmac::PTool->SetEnableRelatedTool( TRUE );
// 
// 	b1 = pmac::PTool->GetEnableToolUsageTime();
// 	b2 = pmac::PTool->GetEnableRelatedTool();

	draw_model_info();

	//////////////////////////////////////////////////////////////////////////
	// Version ���
	memset((void*)pa::PPAStatus->GetThreadState()->szUIProgVersion, 0, sizeof(TCHAR)*128);
	_stprintf_s( pa::PPAStatus->GetThreadState()->szUIProgVersion, 
					128,
					_T("%s"),
					theApp.P_VERSION );
	//////////////////////////////////////////////////////////////////////////

// 	pmac::SPmacState::INIT_IO_REF_VARIABLE();

	hEvent_ = OpenEvent( EVENT_ALL_ACCESS, FALSE, _T("EVT_EPNC_STARTER") );
	if( hEvent_ != NULL ) {
		SetEvent( hEvent_ );
	}

	//////////////////////////////////////////////////////////////////////////
	// Start Timer 
	SetTimer( 1, 1000, NULL );		// Button Blicking Timer 
	SetTimer( 2, 1000, NULL );		// Screen State Timer 
	SetTimer( 3, 1000, NULL );		// NcFile Update for Remote Control
	SetTimer( 4, 2000, NULL );		// USB �޸� ���� ���� Ȯ��  

	return TRUE;  // ��Ŀ���� ��Ʈ�ѿ� �������� ������ TRUE�� ��ȯ�մϴ�.
}

void CEPncUIDlg::OnDestroy()
{
	CloseHandle( hEvent_ );

	KillTimer( 1 );
	Sleep(600);

	destroy_NCStateBarWnd();

	destroy_AutoLoaderStateWnd();

	destroy_NCFileListBox();

	destroy_pmac_object();

	destroy_OperButtons();

	destroy_ErrorDlg();

	destroy_SetupDlg();

	if( pCanvasCE_ ) {
		delete pCanvasCE_;
		pCanvasCE_ = NULL;
	}

	if( P_NCFILE_MGR_DLG2 ) {
		P_NCFILE_MGR_DLG2->DestroyWindow();
		delete P_NCFILE_MGR_DLG2;
		P_NCFILE_MGR_DLG2 = NULL;
	}

	CDialog::OnDestroy();

	//////////////////////////////////////////////////////////////////////////
	// ���� ����ȭ ���� �ʾƵ�, �Ʒ� �Լ��� ������ ���ϵȴ� 
#ifdef __USE_EPNCM_DLL__
	TRACE(_T("<3>\n"));
	DESTORY_EPNCM_DLL();
	TRACE(_T("<4>\n"));
#endif
	//////////////////////////////////////////////////////////////////////////
}

#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
void CEPncUIDlg::OnSize(UINT /*nType*/, int /*cx*/, int /*cy*/)
{
	if (AfxIsDRAEnabled())
	{
		DRA::RelayoutDialog(
			AfxGetResourceHandle(), 
			this->m_hWnd, 
			DRA::GetDisplayMode() != DRA::Portrait ? 
			MAKEINTRESOURCE(IDD_EPNCUI_DIALOG_WIDE) : 
			MAKEINTRESOURCE(IDD_EPNCUI_DIALOG));
	}
}
#endif

void CEPncUIDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	
	if( pCanvasCE_ ) {
		pCanvasCE_->Draw( dc, dc.m_ps.rcPaint );
	}
}

//////////////////////////////////////////////////////////////////////////

void CEPncUIDlg::initialize_OperButtons()
{
	UINT nID[] = {
		IDC_BUTTON_EMG_RESET, IDC_BUTTON_HOME, IDC_BUTTON_SINGLE_BATCH, IDC_BUTTON_BLOCK_GRIP_UNGRIP, IDC_BUTTON_SETUP,
		IDC_BUTTON_OPEN, IDC_BUTTON_RUN, IDC_BUTTON_PAUSE_STOP, 
		IDC_BUTTON_MGR_NCFILE, IDC_BUTTON_UP_NCFILE, IDC_BUTTON_DN_NCFILE, IDC_BUTTON_MANUAL
	};
	// Normal, Press, Disable, Select, Blink1, Blink2
//	TCHAR* pBtnImageFile[OPER_BTN_NUM][CImgButtonEx::IMAGE_NUM] =
	TCHAR	*pBtnImageFile[OPER_BTN_NUM][CImgButtonEx2::IMAGE_NUM] = 
	{
		{
			// EMG/Reset	
			_T("emo_ne"),		// IMAGE_NORMAL_ENABLE
			_T("emo_nd"),		// IMAGE_NORMAL_DISABLE
			_T("emo_np"),		// IMAGE_NORMAL_PRESS
			_T("emo_se"),		// IMAGE_SELECT_ENABLE
			_T("emo_se"),		// IMAGE_SELECT_DISABLE
			_T("emo_sp"),		// IMAFE_SELECT_DISABLE
			_T("emo_se"),		// IMAGE_BLINK_1
			_T("emo_sp"),		// IMAGE_BLINK_2
		},
		{
			// HOME
			_T("home_ne"),
			_T("home_nd"),
			_T("home_np"),
			_T(""),
			_T(""),
			_T(""),
			_T("home_ne"),
			_T("home_np"),
		},
		{
			// TOOL CLAMP/UNCALMP
			_T("tool_ne"),
			_T("tool_nd"),
			_T("tool_np"),
			_T("tool_se"),
			_T("tool_sd"),
			_T("tool_sp"),
			_T(""),
			_T(""),
		},
		{
			// BLOCK GRIP/UNGRIP
			_T("block_ne"),
			_T("block_nd"),
			_T("block_np"),
			_T("block_se"),
			_T("block_sd"),
			_T("block_sp"),
			_T(""),
			_T(""),
		},
		{
			// SETUP
			_T("setup_ne"),
			_T("setup_nd"),
			_T("setup_np"),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
		},
		{
			// OPEN
			_T("open_ne"),
			_T("open_nd"),
			_T("open_np"),
			_T("open_se"),
			_T("open_sd"),
			_T("open_sp"),
			_T(""),
			_T(""),
		},
		{
			// RUN
			_T("run_ne"),
			_T("run_nd"),
			_T("run_np"),
			_T("run_ne"),
			_T("run_nd"),
			_T("run_np"),
			_T("run_b1"),
			_T("run_b2"),
		},
		{
			// PAUSE/STOP
			_T("pause_ne"),
			_T("pause_nd"),
			_T("pause_np"),
			_T("pause_se"),
			_T("pause_sd"),
			_T("pause_sp"),
			_T(""),
			_T(""),
		},
		{
			// MGR NCFILE
			_T("filemgr_ne"),
			_T("filemgr_nd"),
			_T("filemgr_np"),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
		},
		{
			// UP NCFILE
			_T("filemgrup_ne"),
			_T("filemgrup_nd"),
			_T("filemgrup_np"),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
		},
		{
			// DN NCFILE
			_T("filemgrdn_ne"),
			_T("filemgrdn_nd"),
			_T("filemgrdn_np"),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
		},
		{
			// MANUAL
			_T("moverdy_ne"),
			_T("moverdy_nd"),
			_T("moverdy_np"),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
		}
	};
	CRect	rcButtons[OPER_BTN_NUM];

	for( int i = 0; i<OPER_BTN_NUM; i++ ) {
		CButton* pBtn = (CButton*)GetDlgItem(nID[i]);
		pBtn->GetWindowRect( &rcButtons[i] );
		ScreenToClient( &rcButtons[i] );
		pBtn->DestroyWindow();	
	}

	for( int i = 0; i<OPER_BTN_NUM; i++ ) {
		if( i == OPER_BTN_RUN ) {
			pOperButtonsEx_[i] = new CImgButtonEx2Run();
		}
		else if( i == OPER_BTN_BLOCK_GRIP_UNGRIP ) {
			pOperButtonsEx_[i] = new CImgButtonEx2BlockGrip();
		} 
		else if( i == OPER_BTN_TOOL_CALMP_UNCLAMP ) {
			pOperButtonsEx_[i] = new CImgButtonEx2ToolClamp();
		}
		else {
			pOperButtonsEx_[i] = new CImgButtonEx2();
		}

		CString strFilePath[CImgButtonEx2::IMAGE_NUM];
		for( int j = 0; j<CImgButtonEx2::IMAGE_NUM; j++ ) {
			strFilePath[j].Format( _T("%s\\%s.bmp"), pResourcePath_, pBtnImageFile[i][j] );
		}

		pOperButtonsEx_[i]->Create( i, this, rcButtons[i], strFilePath );
	}	
}

void CEPncUIDlg::destroy_OperButtons()
{
	for( int i = 0; i < OPER_BTN_NUM; i++ )
	{
		if( pOperButtonsEx_[i] ) 
		{
			pOperButtonsEx_[i]->DestroyWindow();
			delete pOperButtonsEx_[i];
			pOperButtonsEx_[i] = NULL;
		}
	}
}

BOOL CEPncUIDlg::preinitialize_pmac_object( CString& strErrMsg )
{
	BOOL	bRet = TRUE;
	CString strAutoLoaderConfigFilePath;
	strAutoLoaderConfigFilePath.Format( INI_AL_TEACHING_POINT_PATH );

	pa::PSWConfig = new pa::CPSWConfig();
	if( !pa::PSWConfig->Initialzie( strErrMsg ) ) {
		bRet = FALSE;
	}

	// TODO: choose the correct autoloader.
	// 2017.06.21
//	pa::PAutoLoader = new pa::CBlockAutoLoader();
	pa::PAutoLoader = new pa::CPAutoLoader();
	pa::PAutoLoader->Initialize( strAutoLoaderConfigFilePath, strErrMsg );

	WriteLog( CLog::TYPE_OPER, 0, _T("<<< Start. EPncUI program >>>") );

	return bRet;
}

BOOL CEPncUIDlg::initialize_pmac_object( CString& strErrMsg )
{
	PPNC_IPC_CLIENT = new CPncIpcClient();
	if( !PPNC_IPC_CLIENT->Initialize( strErrMsg ) ) {
		return FALSE;
	}

	pa::PNCFileMgr = new pa::CPNCFileMgr();
	pa::PNCFileMgr->Initialize( strErrMsg );

	pa::PPAStatus = new pa::CPAStatus();
	pa::PPAStatus->Initialize( strErrMsg );

	pa::PTool = new pa::CPTool();
	pa::PTool->Initialize( strErrMsg );

	return TRUE;
}

void CEPncUIDlg::destroy_pmac_object()
{
	if( pa::PAutoLoader ){
		delete pa::PAutoLoader;
		pa::PAutoLoader = NULL;
	}

	if( PPNC_IPC_CLIENT ) {
		delete PPNC_IPC_CLIENT;
		PPNC_IPC_CLIENT = NULL;
	}

	if( pa::PSWConfig ) {
		delete pa::PSWConfig;
		pa::PSWConfig = NULL;
	}

	if( pa::PNCFileMgr ) {
		delete pa::PNCFileMgr;
		pa::PNCFileMgr = NULL;
	}

	if( pa::PPAStatus ) {
		delete pa::PPAStatus;
		pa::PPAStatus = NULL;
	}

	if( pa::PTool ) {
		delete pa::PTool;
		pa::PTool = NULL;
	}
}

// NCFileMgr�� NC ���� ����Ʈ�� ���� �ش� 
BOOL CEPncUIDlg::initialize_NCFileListBox( CString& strErrMsg )
{
	CRect rcTemp;

	hcutil::GetControlPos( IDC_STATIC_NCFILE_LIST_AREA, this, &rcTemp, TRUE );

	pNCFileListBoxEx_ = new CNCFileListBoxEx();
	ASSERT( pNCFileListBoxEx_ );
	pNCFileListBoxEx_->SetBackgroundColor( RGB(128, 128, 200) );
	pNCFileListBoxEx_->SetFontSize( 7, 18 );	// 8, 20
	pNCFileListBoxEx_->SetItemHeight( 42 );		//    48
	pNCFileListBoxEx_->Create( WS_CHILD | WS_VISIBLE, rcTemp, this, IDC_LISTBOX_NCFILE );

	pNCFileListBoxEx_->UpdateFileList();

	pa::PNCFileMgr->RegisterObserver( (pa::INCFileMgrObserver*)pNCFileListBoxEx_ );

	return TRUE;
}

void CEPncUIDlg::destroy_NCFileListBox()
{
	if( pNCFileListBoxEx_ ) {
		pNCFileListBoxEx_->DestroyWindow();
		delete pNCFileListBoxEx_;
		pNCFileListBoxEx_ = NULL;
	}
}

BOOL CEPncUIDlg::initialize_AutoLoaderStateWnd( CString& strErrMsg )
{
	CStatic*	pStatis = (CStatic *)GetDlgItem(IDC_STATIC_AUTOLOADER_STATE_AREA);
	CRect		rcWnd;
	pStatis->GetWindowRect( &rcWnd );
	ScreenToClient( &rcWnd );
	pStatis->DestroyWindow();

	pAutoLoaderStateWnd_ = new CAutoLoaderStateWnd();
	pAutoLoaderStateWnd_->Create( this, rcWnd, 20 );
	
	return TRUE;
}

void CEPncUIDlg::destroy_AutoLoaderStateWnd()
{
	if( pAutoLoaderStateWnd_ ) {
		pAutoLoaderStateWnd_->DestroyWindow();
		delete pAutoLoaderStateWnd_;
		pAutoLoaderStateWnd_ = NULL;
	}
}

BOOL CEPncUIDlg::initialize_NCStateBarWnd( CString& strErrMgs )
{
	CStatic*	pStatis = (CStatic *)GetDlgItem(IDC_STATIC_NCFILE_LIST_AREA3);
	CRect		rcWnd;
	pStatis->GetWindowRect( &rcWnd );
	ScreenToClient( &rcWnd );
	pStatis->DestroyWindow();

	pNCStateBarWnd_ = new CNCStatusBarWnd();
	pNCStateBarWnd_->Create( this, rcWnd );

	pNCStateBarWnd_->UpdateNCStatusBar();

	return TRUE;
}

void CEPncUIDlg::destroy_NCStateBarWnd()
{
	if( pNCStateBarWnd_ ) {
		pNCStateBarWnd_->DestroyWindow();
		delete pNCStateBarWnd_;
		pNCStateBarWnd_ = NULL;
	}
}


BOOL CEPncUIDlg::initialize_ErrorDlg()
{
	PERROR_DLG = new CErrorDlg();

	PERROR_DLG->Create(IDD_DIALOG_ERROR, NULL );

	PERROR_DLG->ShowWindow( SW_HIDE );

	return TRUE;
}

void CEPncUIDlg::destroy_ErrorDlg()
{
	if( PERROR_DLG ) 
	{
		PERROR_DLG->DestroyWindow();
		delete PERROR_DLG;
		PERROR_DLG = NULL;
	}
}

BOOL CEPncUIDlg::initialize_SetupDlg()
{
	PSETUP_DLG = new CSetupDlg();

	PSETUP_DLG->Create( IDD_DIALOG_SETUP, NULL );
// 	PSETUP_DLG->Create( IDD_DIALOG_SETUP, (CWnd*)this );

	PSETUP_DLG->ShowWindow( SW_HIDE );

	return TRUE;
}

void CEPncUIDlg::destroy_SetupDlg()
{
	if( PSETUP_DLG ) 
	{
		PSETUP_DLG->DestroyWindow();
		delete PSETUP_DLG;
		PSETUP_DLG = NULL;
	}
}


//////////////////////////////////////////////////////////////////////////

void CEPncUIDlg::OnTimer(UINT_PTR nIDEvent)
{
	static BOOL bBLINK_STATE = FALSE;
	static int	PREV_ERROR_MODE = -1;

	if( nIDEvent == 1 ) 
	{
		//////////////////////////////////////////////////////////////////////////
		// Button ���� ���� 
		//////////////////////////////////////////////////////////////////////////
		// Stop Timer 
		KillTimer( 1 );
		// Blink State 
		for( int i = 0; i<OPER_BTN_NUM; i++ ) {
			pOperButtonsEx_[i]->UpdateBlink( bBLINK_STATE );
		}
		bBLINK_STATE = !bBLINK_STATE;
		// Restser Timer 
		SetTimer( 1, 500, NULL );
	}
	else if( nIDEvent == 2 ) 
	{
		//////////////////////////////////////////////////////////////////////////
		// Screen State Timer 
		//////////////////////////////////////////////////////////////////////////
		// Stop Timer 
		KillTimer( 2 );

		// ��ư ���� 
		updateButtonState();

		//////////////////////////////////////////////////////////////////////////
		// ����δ� ���� 
		static int PREV_AUTOLOADER = -1;
		int curr_autoloader = pa::PAutoLoader->IsUsingAutoLoader() ? 1 : 0;
		if( PREV_AUTOLOADER != curr_autoloader ) {
			PREV_AUTOLOADER = curr_autoloader;
			if( pAutoLoaderStateWnd_ ) {
				pAutoLoaderStateWnd_->ResetUsingAutoLoader();
				pAutoLoaderStateWnd_->UpdateAutoLoaderState();
			}
			// Autoloader ��-����� ���, ���� ǥ�� �����츦 Hide ��Ų�� 
			if( curr_autoloader == 0 ) {
				pAutoLoaderStateWnd_->ShowWindow( SW_HIDE );
			} else {
				pAutoLoaderStateWnd_->ShowWindow( SW_SHOW );
			}
		}
		if( pAutoLoaderStateWnd_ && curr_autoloader ) {
			pAutoLoaderStateWnd_->UpdateAutoLoaderState();
		}
		//////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////
		// NCStateBar ���� 
		if( pNCStateBarWnd_ ) {
			pNCStateBarWnd_->UpdateNCStatusBar();
		}
		//////////////////////////////////////////////////////////////////////////

		// NCFileListBoxEx, NCFileListBoxSimple 
		updateNCFileListBox();

		// ���� ����� ���, ���� ���̾�α� �ڽ��� ���� 
		int curr_error_mode = ( pa::PPAStatus->GetRunMode() == pa::RUNMODE_ERROR ) ? 1 : 0;
		if( PREV_ERROR_MODE != curr_error_mode ) {
			PREV_ERROR_MODE = curr_error_mode;
			if( PREV_ERROR_MODE != 0 ) {
				PERROR_DLG->SHOW_ERROR_DLG();
			}
		}

		// 
		updateOperationM28Disp();
		// 
		updateRemoteModeDisp();
		// 
		updateDemoModeDisp();
		//
		updateUsbMemConnectDisp();
		//
		updateConnStatePmac();

		// Restart Timer 
		SetTimer( 2, 100, NULL );
	}
	else if( nIDEvent == 3 ) 
	{
		KillTimer( 3 );
		// update nc file list for remote control
		if( pa::PPAStatus->GetThreadState()->bUpdateNcFileList_ == TRUE )
		{
			pa::PNCFileMgr->UpdateNcFileList();
			pa::PPAStatus->GetThreadState()->bUpdateNcFileList_ = FALSE;

			if( pa::PAutoLoader && pa::PAutoLoader->pAutoLoaderConfig_->bUsingAutoLoader )
			{
				// Autolodaer�� ���µ� ������Ʈ �Ѵ� 
				if( pAutoLoaderStateWnd_ ) {
					pAutoLoaderStateWnd_->Invalidate( FALSE );
				}
			}
		}
		// update nc file list for sd memory 
		if( pa::PPAStatus->GetThreadState()->bUpdateNcFileListForSD_ == TRUE ) 
		{
			pa::PNCFileMgr->UpdateNcFileListForSD();
			pa::PPAStatus->GetThreadState()->bUpdateNcFileListForSD_ = FALSE;
		}
		// hide error message box
		if( pa::PPAStatus->GetThreadState()->bRemoteReset_ == TRUE )
		{
			if( PERROR_DLG ) {
			//	PERROR_DLG->ShowWindow( SW_HIDE );
				PERROR_DLG->RESET_SHOW_ERROR_DLG();
			}			
			pa::PPAStatus->GetThreadState()->bRemoteReset_ = FALSE;
		}
		//
		SetTimer( 3, 1000, NULL );
	}
	else if( nIDEvent == 4 )
	{
		KillTimer( 4 );

		// USB �޸� ���� ���� Ȯ�� 
		static CString STR_USB_NAME(_T("/�ϵ� ��ũ") );
		static int N_USB_EXIST = -1;
		int usb_exist = ( hcutil::IsExistDir( STR_USB_NAME ) == TRUE ) ? 1 : 0;

		if( usb_exist != N_USB_EXIST )
		{
			// usb ���� ���� ���� 
			N_USB_EXIST = usb_exist;

			if( N_USB_EXIST == 0 ) 
			{
				// ���� 
			//	AfxMessageBox( _T("usb notconnect") );
				TRACE( _T("usb notconnect\n") );
				::PostMessage( GetSafeHwnd(), WM_USB_MEMORY, (WPARAM)0, (LPARAM)0 );
			}
			else 
			{
				// ����
			//	AfxMessageBox( _T("usb connect") );
				TRACE( _T("usb connect\n") );
				::PostMessage( GetSafeHwnd(), WM_USB_MEMORY, (WPARAM)1, (LPARAM)0 );
			}
		}

		SetTimer( 4, 1000, NULL );

	}

	CDialog::OnTimer(nIDEvent);
}

//////////////////////////////////////////////////////////////////////////

LRESULT CEPncUIDlg::OnImgButtonExClicked(WPARAM wparam, LPARAM lparam)
{
	int nID = (int)wparam;

	// Remote Lock ��� �߰� 
// 	if( !pmac::PState->GetThreadState()->bRemoteLock_ && !pmac::PState->GetThreadState()->bIsShowUserConfirmDlg )
	if( pa::PPAStatus->GetThreadState()->bRemoteLock_ == FALSE && 
		pa::PPAStatus->GetThreadState()->bIsShowUserConfirmDlg == FALSE )
	{
		switch( (EN_OPER_BUTTON)nID )
		{
		case OPER_BTN_EMG_RESET:
			doButtonEmoReset();
			break;
		case OPER_BTN_HOME:
			doButtonHome();
			break;
	// 	case OPER_BTN_SINGLE_BATCH:
	// 		doButtonOperModeChange();
	// 		break;
		case OPER_BTN_TOOL_CALMP_UNCLAMP:
			doButtonToolClampUnclamp();
			break;
		case OPER_BTN_BLOCK_GRIP_UNGRIP:
			doButtonBlockGripUngrip();
			break;
		case OPER_BTN_SETUP:
			doButtonSetup();
			break;
		case OPER_BTN_OPEN:
			doButtonOpen();
			break;
		case OPER_BTN_RUN:
			doButtonRun();
			break;
		case OPER_BTN_PAUSE_STOP:
			doButtonPauseStop();
			break;
		case OPER_BTN_NCFILE_MGR:
			doButtonNCFileMgr();
			break;
		case OPER_BTN_NCFILE_UP:
			doButtonNCFileUp();
			break;
		case OPER_BTN_NCFILE_DN:
			doButtonNCFuleDn();
			break;
		case OPER_BTN_MANUAL:
			doButtonMoveResdyPosition();
			break;
		}
	}

	return 0;
}

void CEPncUIDlg::doButtonEmoReset()
{
	if( pa::PPAStatus->GetThreadState()->hRunMode == pa::RUNMODE_ERROR ) 
	{
		TRACE( _T("CEPncUIDlg::doButtonEmoReset(RESET)\n") );
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog(_T("reset button click"));
		//////////////////////////////////////////////////////////////////////////
		PPNC_IPC_CLIENT->ErrorReset();
		PERROR_DLG->RESET_SHOW_ERROR_DLG();	// Dialog�� Show �Ӽ��� �����Ѵ� 

		//////////////////////////////////////////////////////////////////////////
		// servo�� power �Ӽ��� 0�̸�, 1�̵� �� ���� Wait Dialog�� ���� 
		if( pa::PPAStatus->GetPAStatus()->nServoPower == 0 ) 
		{
			DWORD	dwTime = GetTickCount();
			CString strMsg;
			BOOL	bIsErrorReset = TRUE;
			strMsg.Format( _T("Wait until error clear...") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );
			
			while( TRUE )
			{
				if( pa::PPAStatus->GetPAStatus()->nServoPower != 0 ) {
					break;
				}
				Sleep( 100 );
				if( ( GetTickCount() - dwTime ) > 10000 ) {
					// timeout
					bIsErrorReset = FALSE;
					break;
				}
			}
			if( bIsErrorReset == FALSE )
			{
				strMsg.Format( _T("failed error clear") );
				CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
				CMsgDlgThread::GetInstance()->Wait();
			}

			CMsgDlgThread::GetInstance()->Hide();
		}
	} 
	else 
	{
		TRACE( _T("CEPncUIDlg::doButtonEmoReset(EMG)\n") );
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog(_T("emg button click"));
		//////////////////////////////////////////////////////////////////////////
		PPNC_IPC_CLIENT->Emergency();
	}
}

void CEPncUIDlg::doButtonHome()
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("home button click") );
	//////////////////////////////////////////////////////////////////////////
	if( pa::PPAStatus->GetThreadState()->hRunMode == pa::RUNMODE_STOP ) {
		PPNC_IPC_CLIENT->Home();
	}
}

// void CEPncUIDlg::doButtonOperModeChange()
// {
// 	if( pmac::PState->GetThreadState()->hOperMode == pmac::OPERMODE_SINGLE ) {
// 		PPNC_IPC_CLIENT->ChangeOperMode( pmac::OPERMODE_BATCH );
// 	}
// 	else if( pmac::PState->GetThreadState()->hOperMode == pmac::OPERMODE_BATCH ) {
// 		PPNC_IPC_CLIENT->ChangeOperMode( pmac::OPERMODE_SINGLE );
// 	}
// }

void CEPncUIDlg::doButtonToolClampUnclamp()
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("tool clamp/unclamp button click") );
	//////////////////////////////////////////////////////////////////////////
#ifdef _PA_G2400_
	if( pa::PPAStatus->GetPAStatus()->bOutput[pa::OUT119_TOOL_CLAMP] == FALSE ) {
#endif 
#ifdef _PA_G1600_
//	if( pa::PPAStatus->GetPAStatus()->bOutput[pa::OUT20034_ToolLeftClamp] == FALSE ) {
	if( pa::PPAStatus->GetPAStatus()->nSpindle1ColletOpenFlag == FALSE ) {
#endif 
		PPNC_IPC_CLIENT->ToolClamp(0, TRUE );
		//////////////////////////////////////////////////////////////////////////
		// ��-Ŭ������ ���, ����ȣ�� ���� �Ѵ� 
		// log
		writeLog( _T("reset tool no.") );
		//////////////////////////////////////////////////////////////////////////
		PPNC_IPC_CLIENT->SendMDACommand( "M138" );
	} else {
		PPNC_IPC_CLIENT->ToolClamp(0, FALSE );
	}
}

void CEPncUIDlg::doButtonBlockGripUngrip()
{
#ifdef _PA_G2400_
	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("block grib/ungrib button click") );
	//////////////////////////////////////////////////////////////////////////
	if( pa::PPAStatus->GetPAStatus()->bOutput[pa::OUT117_BLOCK_CLAMP] == FALSE &&
		pa::PPAStatus->GetPAStatus()->bOutput[pa::OUT118_BLOCK_UNCLAMP] != FALSE )
	{
		// Clamp ����. Unclamp ���� ����
		PPNC_IPC_CLIENT->BlockClamp( FALSE );
	}
	else {
		// Unclamp ����. Clamp ���� ���� 
		PPNC_IPC_CLIENT->BlockClamp( TRUE );
	}
#endif 
}

#include "PasswordDlg.h"
void CEPncUIDlg::doButtonSetup()
{
	BOOL b = TRUE;

	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("setup button click") );
	//////////////////////////////////////////////////////////////////////////

// #ifndef _DEBUG
	if( theApp.bNoNeedEnterPassword_ == FALSE ) {
		CPasswordDlg dlg;
		if( dlg.DoModal() != IDOK ) {
			b = FALSE;
		}
	}
// #else 
// 	b = TRUE;
// #endif

	if( b ) {
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog( _T("password ok. change setup mode") );
		//////////////////////////////////////////////////////////////////////////
		PSETUP_DLG->ShowWindow( SW_SHOW );
	} else {
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog( _T("password fail.") );
		//////////////////////////////////////////////////////////////////////////
	}
}

// ���õ� ������ ã�Ƽ�.. 
void CEPncUIDlg::doButtonOpen()
{
	DWORD dwTime = 0;
	int nNumNCFiles = pa::PNCFileMgr->GetNumNCFile();
	int nSelectedIndex = -1;

	pa::PPAStatus->GetThreadState()->nNcFileLoadingRate = 0;

	if( pa::PNCFileMgr->GetCurrentWorkNCFileIndex() == -1 )
	{
		// ���� �ִ� ������ ������, ���õ� ���� �� ù��° ������ Open �Ѵ�
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog( _T("file open button click") );
		//////////////////////////////////////////////////////////////////////////
		// File�� ���� 
		for( int i = 0; i<nNumNCFiles; i++ )
		{
			if( pa::PNCFileMgr->GetNCFileInfo(i)->is_select != 0 )
			{
				nSelectedIndex = i;
				break;
			}
		}

		if( nSelectedIndex != -1 ) 
		{
			int PREV_LOADING_RATE = -1;
			// ������ Open �Ѵ�
			if( PPNC_IPC_CLIENT ) 
			{
				//////////////////////////////////////////////////////////////////////////
				// Wait MessageBox �߰� 
				CString strMsg;
				BOOL	bHide = TRUE;
				strMsg.Format( _T("please...wait until the file is opened") );
				CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO,  strMsg );
				pa::PPAStatus->GetThreadState()->bIsFileOpening = TRUE;
				Sleep(500);
				dwTime = GetTickCount();

				//////////////////////////////////////////////////////////////////////////
				PPNC_IPC_CLIENT->Open( nSelectedIndex );
				//////////////////////////////////////////////////////////////////////////

				while( TRUE ) {
					if( pa::PPAStatus->GetThreadState()->bIsFileOpening == FALSE ) {
						break;
					}

// 					if( ( GetTickCount() - dwTime ) > 100*1000 ) {
// 						CMsgDlgThread::GetInstance()->Hide();
// 						bHide = FALSE;
// 						// ��� �ð��� 60�� �̻��̸�, ���� �޽��� ��� 
// 						strMsg.Format( _T("file open error !") );
// 						CMsgDlgThread::GetInstance()->Show(CMsgDlg::TYPE_CLOSE, strMsg );
// 						break;
// 					}

					// �������� ���ϸ� ��� �Ѵ� 
					int curr_loading_reate = pa::PPAStatus->GetThreadState()->nNcFileLoadingRate;
					if( PREV_LOADING_RATE !=  curr_loading_reate ) {
						PREV_LOADING_RATE = curr_loading_reate;
						strMsg.Format( _T("please...wait until the file is opened\n[%d%%]"), PREV_LOADING_RATE );
						CMsgDlgThread::GetInstance()->SetMessage( strMsg );

						dwTime = GetTickCount();
					}

					// �������� 10�� �̻� ������ ������, ���� �޽��� ��� 
					// WinCE6.0���� 30�ʷ� ���� 
					if( (GetTickCount() - dwTime) > 10*1000 ) {
						CMsgDlgThread::GetInstance()->Hide();
						bHide = FALSE;
						strMsg.Format( _T("file open error !") );
						CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
						break;
					}

					Sleep( 500 );
				}
				if( bHide == TRUE ) {
					CMsgDlgThread::GetInstance()->Hide();
				} 
			}
		}
		else 
		{
			// ���õ� ������ ����
			writeLog( _T("not found selected nc-file") );
		} 
	}
	else 
	{
		// ���� �ִ� ������ ������, ������ �ݰ� is_select�� 0���� �����Ѵ� 
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog( _T("file close button click") );
		//////////////////////////////////////////////////////////////////////////

		// File�� ���� �� is_select�� 0���� �����Ѵ�  
		pa::PNCFileMgr->SetNCFileSelect( pa::PNCFileMgr->GetCurrentWorkNCFileIndex(), 0, TRUE );
		// File�� �ݴ´� 
		PPNC_IPC_CLIENT->Close();
	}
}

/** 
 * �̾ ���� ���� Ȯ���ؾ� ��.
 */
void CEPncUIDlg::doButtonRun()
{
	pa::EN_RUNMODE run_mode = pa::PPAStatus->GetRunMode();
	int		nStartLine = 0;
	BOOL	bRun = FALSE;

	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("run button click") );
	//////////////////////////////////////////////////////////////////////////

	if( run_mode == pa::RUNMODE_STOP ) 
	{
		// ���� ���� �ִ� ������ �ְ�, ������ machining line�� 0�� �ƴ� ���, 
		// �̾ �������� ���θ� Ȯ���ؾ� �Ѵ� 

		// ���� �ִ� ������ ������, Checking �� ������ ã�´� 
		if( pa::PPAStatus->GetThreadState()->bIsOpenNCFile == FALSE )
		{
			int nNCFileIndex = pa::PNCFileMgr->FindFirstCheckingNCFileIndex( TRUE );	//PNCFileMgr->FindFirstCheckingNCFileIndex();
			if( nNCFileIndex == -1 ) 
			{
				// ���� �ִ� ������ ���� 
				//////////////////////////////////////////////////////////////////////////
				// log 
				writeLog( _T("file not exist") );
				//////////////////////////////////////////////////////////////////////////
				return ;
			}
			else 
			{
				//////////////////////////////////////////////////////////////////////////
				// log 
				CString strLog;
				strLog.Format( _T("file open (%d)"), nNCFileIndex );				// index ��° ���� open 
				writeLog( strLog );
				//////////////////////////////////////////////////////////////////////////

				// ������ ���� 
				PPNC_IPC_CLIENT->Open( nNCFileIndex );								
				Sleep( 500 );
			}
		}

		// ������ ���� �ִ��� Ȯ�� 
		DWORD dwTime = GetTickCount();
		while( TRUE ) 
		{
			if( pa::PPAStatus->GetThreadState()->bIsOpenNCFile == TRUE ) {
				break;
			}
			if( (GetTickCount() - dwTime) > 5000 ) {
				// ����. ������ �� �� ���� 
				CString strMsg;
				strMsg.Format( _T("Failed to open file") ); 
				CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
				CMsgDlgThread::GetInstance()->Wait();
				//////////////////////////////////////////////////////////////////////////
				// log 
				writeLog( _T("file open error") );
				//////////////////////////////////////////////////////////////////////////
				return ;
			}
		}		

		// �̾ ���࿩�� Ȯ�� 
		if( pa::PPAStatus->GetThreadState()->hNCFileInfo.machining_lines != 0 ) 
		{
			/*
			CString strMsg;
			nStartLine = pmac::PState->GetThreadState()->hNCFileInfo.machining_lines;

// 			strMsg.Format( _T("�����۾��� �̾ �Ͻðڽ��ϱ� ?\r\nLine No : %d \r\n - YES : �̾ ����\r\n - NO : ó������ ����\r\n - CANCAL : �۾� ���"), nStartLine );
			strMsg.Format( _T("Please select the start option ?\r\nLine No : %d \r\n - YES : From the selected line\r\n - NO : From begining of current nc-file\r\n - CANCAL : Job cancel"), nStartLine );

			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_YESNOCANCEL, strMsg );
			CMsgDlg::EN_RET ret = CMsgDlgThread::GetInstance()->Wait();
			switch( ret )
			{
			case CMsgDlg::RET_YES:
				// �̾ ���� 
				//////////////////////////////////////////////////////////////////////////
				// log 
				strMsg.Format( _T("continuous run : %d"), nStartLine );
				writeLog( strMsg );
				//////////////////////////////////////////////////////////////////////////
				break;
			case CMsgDlg::RET_NO:
				// ó������ ���� 
				//////////////////////////////////////////////////////////////////////////
				// log 
				writeLog( _T("start from beginning") );
				//////////////////////////////////////////////////////////////////////////
				nStartLine = 0;
				break;
			case CMsgDlg::RET_CANCEL:
				//////////////////////////////////////////////////////////////////////////
				// log 
				writeLog( _T("job cancel") );
				//////////////////////////////////////////////////////////////////////////
				// �۾� ��� 
				return ;
			}
			*/
			
			nStartLine = pa::PPAStatus->GetThreadState()->hNCFileInfo.machining_lines;
			int prev_start_line = nStartLine;

			CRestartDialog dlg;
			dlg.SetStartLine( nStartLine );
			if( dlg.DoModal() == IDOK )
			{
// 				//////////////////////////////////////////////////////////////////////////
// 				//
// 				CString strLog;
// 				strLog.Format( _T("restart : %d"), nStartLine );
// 				writeLog( strLog );
				//////////////////////////////////////////////////////////////////////////
				//
				nStartLine = dlg.GetStartLine();
				//////////////////////////////////////////////////////////////////////////
				// ���� ���ΰ� ����� ������ �ٸ� �� �����Ƿ�, �Ѵ� ��� �Ѵ� 
				CString strLog;
				strLog.Format( _T("restart : %d [<-%d]"), nStartLine, prev_start_line );
				writeLog( strLog );
			}
			else 
			{
				//////////////////////////////////////////////////////////////////////////
				// log
				writeLog( _T("job cancel") );
				//////////////////////////////////////////////////////////////////////////
				// �۾� ��� 
				return ;
			}
		}

		bRun = TRUE;
	}
	else if( run_mode == pa::RUNMODE_PAUSE ) 
	{
		nStartLine = -1;
		bRun = TRUE;
	}

	if( bRun ) 
	{
		PPNC_IPC_CLIENT->Run(nStartLine);
	}
}

void CEPncUIDlg::doButtonPauseStop()
{
	switch( pa::PPAStatus->GetRunMode() )
	{
	case pa::RUNMODE_RUN:
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog( _T("pause button click") );
		//////////////////////////////////////////////////////////////////////////
		PPNC_IPC_CLIENT->Pause();
		break;
	case pa::RUNMODE_PAUSE:
		//////////////////////////////////////////////////////////////////////////
		// log 
		writeLog( _T("stop button click") );
		//////////////////////////////////////////////////////////////////////////
		PPNC_IPC_CLIENT->Stop();
		break;
	}
}

void CEPncUIDlg::doButtonNCFileMgr()
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("nc file manager button click") );
	//////////////////////////////////////////////////////////////////////////

// 	if( PNCFILE_MGR_DLG == NULL ) {
// 		PNCFILE_MGR_DLG = new CNCFileMgrDlg();
// 		ASSERT( PNCFILE_MGR_DLG );
// 		PNCFILE_MGR_DLG->Create( IDD_DIALOG_NCFILE_MGR, NULL );
// 		PNCFILE_MGR_DLG->ShowWindow( SW_SHOW );
// 	}
// 	else {
// 		PNCFILE_MGR_DLG->ShowWindow( SW_SHOW );
// 	}	

	if( P_NCFILE_MGR_DLG2 == NULL ) {
		P_NCFILE_MGR_DLG2 = new CNCFileMgrDlg2();
		ASSERT( P_NCFILE_MGR_DLG2 );
		P_NCFILE_MGR_DLG2->Create( IDD_DIALOG_NCFILE_MGR2, NULL );
		P_NCFILE_MGR_DLG2->ShowWindow( SW_SHOW );
	} 
	else {
		P_NCFILE_MGR_DLG2->ShowWindow( SW_SHOW );
	}
}

void CEPncUIDlg::doButtonNCFileUp()
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("nc file up button click") );
	//////////////////////////////////////////////////////////////////////////

	if( pNCFileListBoxEx_ ) 
	{
		pNCFileListBoxEx_->MoveUp();
	}
}

void CEPncUIDlg::doButtonNCFuleDn()
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("nc file down button click") );
	//////////////////////////////////////////////////////////////////////////

	if( pNCFileListBoxEx_ ) 
	{
		pNCFileListBoxEx_->MoveDown();
	}
}

void CEPncUIDlg::doButtonMoveResdyPosition()
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("move ready position button click") );
	//////////////////////////////////////////////////////////////////////////

	CString strMsg;

	strMsg.Format( _T("Do you want to move ready position ?") );

	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );

	CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();

	if( hRet == CMsgDlg::RET_CANCEL ) {
		return ;
	}

	// AutoLoader �� �ִ� ����� ���, PNC ARM�� up �Ѵ� 
	if( pa::PAutoLoader && pa::PAutoLoader->IsUsingAutoLoader() )
	{
		PPNC_IPC_CLIENT->XYS_Gripper_Up();
		Sleep( 500 );
		while( !theApp.MotionDone( TRUE ) ) {
			Sleep( 500 );
			if( pa::PPAStatus->GetRunMode() == pa::RUNMODE_ERROR ) {
				break;
			}
		}
	}
	//
	PPNC_IPC_CLIENT->MoveReadyPosition();
}

//////////////////////////////////////////////////////////////////////////

LRESULT CEPncUIDlg::OnAutoLoaderRefill(WPARAM wparam, LPARAM lparam)
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("autoloader refill button click") ); 
	//////////////////////////////////////////////////////////////////////////

	CAutoLoaderRefillDlg dlg;

	dlg.DoModal();

	return 0;
}

//////////////////////////////////////////////////////////////////////////

/*
OPER_BTN_EMG_RESET = 0,
OPER_BTN_HOME,
OPER_BTN_TOOL_CLAMP_UNCLAMP,
OPER_BTN_BLOCK_GRIP_UNGRIP,
OPER_BTN_SETUP,

OPER_BTN_OPEN,
OPER_BTN_RUN,
OPER_BTN_PAUSE_STOP,

OPER_BTN_NCFILE_MGR,
OPER_BTN_NCFILE_UP,
OPER_BTN_NCFILE_DN,
*/

/*
void CEPncUIDlg::updateButtonState()
{
	static int nBtnState[6][OPER_BTN_NUM] = 
	{
		{
			// RUNMODE_STOP ���� �϶� ��ư ����. Stop�� ���, NC ������ �ε� ���ο� ���� �ٽ� �޶� ���� 
			CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL, 
			CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL, 
			CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL,
		},
		{
			// RUNMODE_TOSTOP, RUN, TORUN, PAUSE ���� �϶�, ��ư ���� 
			CImgButtonEx::STATE_NORMAL,  CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_NORMAL, 
			CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_BLINK,   CImgButtonEx::STATE_NORMAL, 
			CImgButtonEx::STATE_NORMAL,  CImgButtonEx::STATE_NORMAL,  CImgButtonEx::STATE_NORMAL,
		},
		{
			// PAUSE ���� �϶�, ��ư ���� 
			CImgButtonEx::STATE_NORMAL,  CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_NORMAL, 
			CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_BLINK, CImgButtonEx::STATE_SELECT, 
			CImgButtonEx::STATE_NORMAL,  CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL,
		},
		{
			// INIT ���� �϶�, ��ư ����  
			CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_BLINK, CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_NORMAL, 
			CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_DISABLE, 
			CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL,
		},
		{
			// ERROR ���� �϶�, ��ư ���� 
			CImgButtonEx::STATE_BLINK, CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_NORMAL, 
			CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_DISABLE, 
			CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL,
		},
		{
			// Origin NotComplete ���� �϶�, ��ư ���� 
			CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL, 
			CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_DISABLE, CImgButtonEx::STATE_DISABLE, 
			CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL, CImgButtonEx::STATE_NORMAL,
		}
	};

	static int PREV_BTN_STATE[OPER_BTN_NUM] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };

	pmac::EN_RUNMODE	hRunMode = pmac::PState->GetThreadState()->hRunMode;
	int					nIndex = -1;

	//////////////////////////////////////////////////////////////////////////
	//
	//////////////////////////////////////////////////////////////////////////
	if( pmac::PState->GetThreadState()->bIsOriginComplete_ == TRUE ) 
	{
		switch( hRunMode )
		{
		case pmac::RUNMODE_STOP:
			nIndex = 0;
			if( pmac::PNCFileMgr->GetCurrentWorkNCFileIndex() != -1 ) {
				// ������ ���� �ִ� 
				nBtnState[0][OPER_BTN_OPEN] = CImgButtonEx::STATE_SELECT;	// Close ǥ�� 
			}
			else {
				// ������ ���� ���� �ʴ� 
				nBtnState[0][OPER_BTN_OPEN] = CImgButtonEx::STATE_NORMAL;	// Open ǥ�� 
			}

			// Block
//			if( pmac::PState->GetPmacState()->nOut01_BlockClamp!=0 && pmac::PState->GetPmacState()->nOut02_BlockUnclamp==0 ) {
			if( pmac::PState->GetPmacState()->nOut01_BlockClamp == 0 ) {
				// Clamp ���� 
				nBtnState[0][OPER_BTN_BLOCK_GRIP_UNGRIP] = CImgButtonEx::STATE_SELECT;
			} else {
				// Unlamp ���� 
				nBtnState[0][OPER_BTN_BLOCK_GRIP_UNGRIP] = CImgButtonEx::STATE_NORMAL;
			}

			// Tool
			if( pmac::PState->GetPmacState()->nOut00_ToolClamp != 0 ) {
				// Clamp ���� 
				nBtnState[0][OPER_BTN_TOOL_CALMP_UNCLAMP] = CImgButtonEx::STATE_SELECT;
			} else {
				// Unclamp ���� 
				nBtnState[0][OPER_BTN_TOOL_CALMP_UNCLAMP] = CImgButtonEx::STATE_NORMAL;
			}
			break;

		case pmac::RUNMODE_TOSTOP:
		case pmac::RUNMODE_TORUN:
		case pmac::RUNMODE_RUN:
			nIndex = 1;
			break;

		case pmac::RUNMODE_PAUSE:
			nIndex = 2;
			break;

		case pmac::RUNMODE_INIT:
			nIndex = 3;
			break;

		case pmac::RUNMODE_ERROR:
			nIndex = 4;
			break;

		default:
			return ;
		}
	}
	else 
	{
		if( hRunMode == pmac::RUNMODE_INIT ) {
			nIndex = 3;
		}
		else if( hRunMode == pmac::RUNMODE_ERROR ) {
			nIndex = 4;
		}
		else {
			nIndex = 5;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// ��ư ���� ���� 
	for( int i = 0; i<OPER_BTN_NUM; i++ ) {
		if( PREV_BTN_STATE[i] != nBtnState[nIndex][i] ) {
			PREV_BTN_STATE[i] = nBtnState[nIndex][i];
//			pOperButtons_[i]->SetState( (CImgButtonEx::EN_STATE)nBtnState[nIndex][i] );
		}

		pOperButtonsEx_[i]->SetEnable( TRUE );
		pOperButtonsEx_[i]->SetSelect( FALSE );
	}
	//////////////////////////////////////////////////////////////////////////

}
*/

// ��ư�� ���¸� ���� �Ѵ� 
/*
OPER_BTN_EMG_RESET = 0,
OPER_BTN_HOME,
OPER_BTN_TOOL_CALMP_UNCLAMP,
OPER_BTN_BLOCK_GRIP_UNGRIP,
OPER_BTN_SETUP,
OPER_BTN_OPEN,
OPER_BTN_RUN,
OPER_BTN_PAUSE_STOP,
OPER_BTN_NCFILE_MGR,
OPER_BTN_NCFILE_UP,
OPER_BTN_NCFILE_DN,
*/
void CEPncUIDlg::updateButtonState()
{
	static int PREV_BTN_ENA[OPER_BTN_NUM] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };	// enable
	static int PREV_BTN_BLK[OPER_BTN_NUM] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };	// blink
	static int PREV_BTN_SEL[OPER_BTN_NUM] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };	// select
	int btn_ena[OPER_BTN_NUM] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	int btn_blk[OPER_BTN_NUM] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	int btn_sel[OPER_BTN_NUM] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	
	pa::EN_RUNMODE	hRunMode = pa::PPAStatus->GetThreadState()->hRunMode;
	BOOL bOriginComplete = pa::PPAStatus->GetThreadState()->bIsOriginComplete_;
	int nIndex = 0;

#ifndef _DEBUG
	//////////////////////////////////////////////////////////////////////////
	// EMO ��ư 
// 	btn_ena[nIndex]	= 1;
// 	btn_blk[nIndex] = ( hRunMode == pmac::RUNMODE_ERROR ) ? 1 : 0; 
// 	btn_sel[nIndex] = 0;
// 	nIndex++;

//	if( pmac::PState->GetThreadState()->bConnectedPmac )

//	if( pmac::PState->GetThreadState()->nConnStatePmac == pmac::PMAC_CONN_STATE_CONNECTED )	// 2 is CONN_STATE_CONNETCED
	if( TRUE )
	{
#endif
		//////////////////////////////////////////////////////////////////////////
		// EMO ��ư 
		btn_ena[nIndex]	= 1;
		btn_blk[nIndex] = ( hRunMode == pa::RUNMODE_ERROR ) ? 1 : 0; 
		btn_sel[nIndex] = 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// HOME ��ư 
		// servo power�� 0�� ��� home ��ư�� disable 
		int servo_power = pa::PPAStatus->GetPAStatus()->nServoPower;
		btn_ena[nIndex] = ( hRunMode == pa::RUNMODE_STOP && servo_power == 1 ) ? 1 : 0;
		btn_blk[nIndex] = ( hRunMode == pa::RUNMODE_INIT || !bOriginComplete ) ? 1 : 0;	
		btn_sel[nIndex] = 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// tool ��ư 
		btn_ena[nIndex] = ( hRunMode == pa::RUNMODE_STOP ) ? 1 : 0;
		btn_blk[nIndex]	= 0;
#ifdef _PA_G2400_
		btn_sel[nIndex] = ( pa::PPAStatus->GetPAStatus()->bOutput[pa::OUT119_TOOL_CLAMP] != FALSE ) ? 1 : 0;
#endif 
#ifdef _PA_G1600_
//		btn_sel[nIndex] = ( pa::PPAStatus->GetPAStatus()->bOutput[pa::OUT20034_ToolLeftClamp] != FALSE ) ? 1 : 0;
		btn_sel[nIndex] = ( pa::PPAStatus->GetPAStatus()->nSpindle1ColletOpenFlag != FALSE ) ? 1 : 0;
#endif 
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// block ��ư 
#ifdef _PA_G2400_
		btn_ena[nIndex]	= ( hRunMode == pa::RUNMODE_STOP ) ? 1 : 0;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = ( pa::PPAStatus->GetPAStatus()->bOutput[pa::OUT117_BLOCK_CLAMP] == FALSE ) ? 0 : 1;
#endif 
#ifdef _PA_G1600_
		btn_ena[nIndex] = 0;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = 0;
#endif 
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// setup ��ư 
		btn_ena[nIndex] = 1;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// open ��ư 
		btn_ena[nIndex] = ( bOriginComplete && hRunMode == pa::RUNMODE_STOP ) ? 1 : 0;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = ( pa::PNCFileMgr->GetCurrentWorkNCFileIndex() != -1 ) ? 1 : 0;

		//////////////////////////////////////////////////////////////////////////
		// 2015.09.10 ����� 
		btn_ena[nIndex] = 1;
		//////////////////////////////////////////////////////////////////////////

		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// run ��ư 
		btn_ena[nIndex] = ( bOriginComplete && ( hRunMode == pa::RUNMODE_STOP || hRunMode == pa::RUNMODE_PAUSE ) ) ? 1 : 0;
		btn_blk[nIndex] = ( hRunMode == pa::RUNMODE_TORUN || hRunMode == pa::RUNMODE_RUN || hRunMode == pa::RUNMODE_TOSTOP || hRunMode == pa::RUNMODE_PAUSE ) ? 1 : 0;
		btn_sel[nIndex] = 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// pause/stop ��ư 
		btn_ena[nIndex] = ( bOriginComplete && ( hRunMode == pa::RUNMODE_TORUN || hRunMode == pa::RUNMODE_RUN || hRunMode == pa::RUNMODE_PAUSE ) ) ? 1 : 0;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = ( hRunMode == pa::RUNMODE_PAUSE ) ? 1 : 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// filemgr ��ư 
		btn_ena[nIndex] = 1;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// filemgr up ��ư 
		btn_ena[nIndex] = 1;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// filemgr down ��ư 
		btn_ena[nIndex] = 1;
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////
		// manual ��ư 
		btn_ena[nIndex] = ( bOriginComplete && ( hRunMode == pa::RUNMODE_STOP ) );
		btn_blk[nIndex] = 0;
		btn_sel[nIndex] = 0;
		nIndex++;

		//////////////////////////////////////////////////////////////////////////

#ifndef _DEBUG
	}
	else if( pa::PPAStatus->GetThreadState()->hConnectStatus == pa::CONNECT_STATUS_PANDING )
	{
		for( int i = 0; i<OPER_BTN_NUM; i++ ) {
			btn_ena[i] = 0;
			btn_blk[i] = 0;
			btn_sel[i] = 0;
		}
	}
	else // pmac::PMAC_CONN_STATE_NOT
	{
		for( int i = 1; i<OPER_BTN_NUM; i++ ) {
			btn_ena[i] = 0;
			btn_blk[i] = 0;
			btn_sel[i] = 0;
		}
		btn_ena[0] = 1;
		btn_blk[0] = 1; //( hRunMode == pmac::RUNMODE_ERROR ) ? 1 : 0; 
		btn_sel[0] = 1; //0;
	}
#endif

	//////////////////////////////////////////////////////////////////////////

	for( int i = 0; i<OPER_BTN_NUM; i++ )
	{
		if( PREV_BTN_ENA[i] != btn_ena[i] ) {
			PREV_BTN_ENA[i] = btn_ena[i];
			pOperButtonsEx_[i]->SetEnable( btn_ena[i] );
		}
		if( PREV_BTN_BLK[i] != btn_blk[i] ) {
			PREV_BTN_BLK[i] = btn_blk[i];
			pOperButtonsEx_[i]->SetBlink( btn_blk[i] );
		}
		if( PREV_BTN_SEL[i] != btn_sel[i] ) {
			PREV_BTN_SEL[i] = btn_sel[i];
			pOperButtonsEx_[i]->SetSelect( btn_sel[i] );
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// RunMode�� ���� Pause/Stop ��ư�� MoveReadyPos ��ư��...
	static int PREV_STATE_MANUAL = -1;
	int curr_state_manual = ( hRunMode == pa::RUNMODE_STOP || hRunMode == pa::RUNMODE_ERROR ) ? 1 : 0;
	
	if( PREV_STATE_MANUAL != curr_state_manual ) {
		PREV_STATE_MANUAL = curr_state_manual;
		if( PREV_STATE_MANUAL == 0 ) {
			pOperButtonsEx_[OPER_BTN_PAUSE_STOP]->ShowWindow( SW_SHOW );
			pOperButtonsEx_[OPER_BTN_MANUAL]->ShowWindow( SW_HIDE );
		} else {
			pOperButtonsEx_[OPER_BTN_MANUAL]->ShowWindow( SW_SHOW );
			pOperButtonsEx_[OPER_BTN_PAUSE_STOP]->ShowWindow( SW_HIDE );
		}
	}
}

// 1.RunMode�� ����Ǿ��� ��. 
void CEPncUIDlg::updateNCFileListBox()
{
	static pa::EN_RUNMODE PREV_RUNMODE = pa::RUNMODE_NUM;
	pa::EN_RUNMODE currRunMode = pa::PPAStatus->GetRunMode();

	if( PREV_RUNMODE != currRunMode )
	{
		PREV_RUNMODE = currRunMode;

		pNCFileListBoxEx_->UpdateFileList();
	}
}

void CEPncUIDlg::updateConnStatePmac()
{
	static int PREV_STATE = -1;
	int curr_state = (int)(pa::PPAStatus->GetThreadState()->hConnectStatus);
	CRect	rect(26, 4, 160, 20);
	CString	strText;

	if( PREV_STATE != curr_state )
	{
		PREV_STATE = curr_state;

		hcutil::CCanvasCELayer	*pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get(1);
		if( pLayer )
		{
			CRect		rcTemp = rect;
			COLORREF	clr;
			rcTemp.InflateRect( 1, 1, 1, 1 );
			pLayer->Clear( rcTemp, FALSE );

			clr = RGB(0, 0, 0);
			switch( (pa::EN_CONNECT_STATUS)curr_state )
			{
			case pa::CONNECT_STATUS_NOT:
				strText.Format( _T("CTRL not-connect") );
				clr = RGB(255, 0, 0); 
				break;
			case pa::CONNECT_STATUS_PANDING:
				strText.Format( _T("CTRL pending") );
				clr = RGB(128, 128, 128); 
				break;
			case pa::CONNECT_STATUS_CONNECTED:
				strText.Format( _T("CTRL connected") );
				clr = RGB(0, 255, 0); 
				break;
			}

			int			prev_bkmode = pLayer->SetBkMode( TRANSPARENT );
			COLORREF	prev_clr = pLayer->SetTextColor( clr );
//			CString		strText( _T("PMAC") );
			pLayer->DrawText( strText, rect, DT_LEFT|DT_SINGLELINE );
			pLayer->SetBkMode( prev_bkmode );
			pLayer->SetTextColor( prev_clr );

			InvalidateRect( &rcTemp, FALSE );
		}
	}
}

//
void CEPncUIDlg::updateOperationM28Disp()
{
// 	static int PREV_MODE = -1;
// 	int		curr_mode = pmac::PState->GetPmacState()->nOperationOfM28_;
// 	CString strOperationM32;
// // 	CRect	rect(26, 10, 160, 26);
// // 	CRect	rect(26, 4, 160, 20);
// 	CRect	rect(26, 22, 160, 38);
// 
// 	if( PREV_MODE != curr_mode ) {
// 		PREV_MODE = curr_mode;
// 
// 		hcutil::CCanvasCELayer	*pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get(1);
// 		if( pLayer ) 
// 		{
// 			//	pLayer->Clear(FALSE);
// 			CRect rc = rect;
// 			rc.InflateRect( 1, 1, 1, 1 );
// 			pLayer->Clear( rc, FALSE );
// // 			pLayer->FillSolidRect( &rc, RGB(255, 255, 255) );
// 
// // 			if( curr_mode != 0 ) 
// 			{
// 				int			prev_bkmode = pLayer->SetBkMode( TRANSPARENT );
// 				COLORREF	prev_clr	= pLayer->SetTextColor( RGB(32, 255, 32) );
// 				switch( PREV_MODE )
// 				{
// 				case 0: // ������(Cutting Fluid)
// // 					strOperationM32.Format( _T("CUTTING FLUID") );		// strOperationM32.Format( _T("Cutting Fluid") );
// 					strOperationM32.Format( _T("WET") );		// strOperationM32.Format( _T("Cutting Fluid") );
// 					break;
// 				case 1: // ������(Dust Collector)
// // 					strOperationM32.Format( _T("DUST COLLECTIOR") );	// strOperationM32.Format( _T("Dust Collector") );
// 					strOperationM32.Format( _T("DRY") );	// strOperationM32.Format( _T("Dust Collector") );
// 					break;
// 				default:
// 					strOperationM32.Format( _T("NONE") );
// 					break;
// 				}
// 				pLayer->DrawText( strOperationM32, rect, DT_LEFT|DT_SINGLELINE );
// 				pLayer->SetBkMode( prev_bkmode );
// 				pLayer->SetTextColor( prev_clr );
// 			}
// 
// 			rect.InflateRect( 1, 1, 1, 1 );
// 			InvalidateRect( &rect, FALSE );
// 		}
// 	}
}

//
void CEPncUIDlg::updateRemoteModeDisp()
{
	static int PREV_MODE = -1;
	static int PREV_LOCK = -1;
	int curr_mode = pa::PPAStatus->GetThreadState()->bIsClientConnected_ ? 1 : 0;
	int curr_lock = pa::PPAStatus->GetThreadState()->bRemoteLock_ ? 1 : 0;
	CString strMode;
// 	CRect	rect(26, 28, 160, 44);
// 	CRect	rect(26, 22, 160, 38);
	CRect	rect(26, 40, 160, 56);

	BOOL bUpdate = FALSE;

	if( PREV_MODE != curr_mode || PREV_LOCK != curr_lock ) {
		PREV_MODE = curr_mode;
		PREV_LOCK = curr_lock;
		bUpdate = TRUE;
	}

	if( bUpdate ) 
	{
		hcutil::CCanvasCELayer	*pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get(1);
		if( pLayer ) {
			CRect rcCLR = rect;
			rcCLR.InflateRect( 1, 1, 1, 1 );
			pLayer->Clear( rcCLR, FALSE );
			if( curr_mode != 0 ) {
				int			prev_bkmode = pLayer->SetBkMode( TRANSPARENT );
				COLORREF	prev_clr	= pLayer->SetTextColor( RGB(32, 250, 32) );
				strMode.Format( _T("CONNECTED") );
				if( curr_lock != 0 ) {
					strMode += CString( _T("-LOCK") );
				}
				pLayer->DrawText( strMode, rect, DT_LEFT|DT_SINGLELINE );
				pLayer->SetBkMode( prev_bkmode );
				pLayer->SetTextColor( prev_clr );
			}
			InvalidateRect( &rect, FALSE );
		}
	}
}

//
void CEPncUIDlg::updateUsbMemConnectDisp()
{
	static int PREV_STATE = -1;
	int		curr_state = (bConnectedUsbMemory_) ? 1 : 0;
// 	CRect	rect(26, 46, 160, 62);
// 	CRect	rect(26, 40, 160, 56);
	CRect	rect(26, 58, 160, 74);

	if( PREV_STATE != curr_state )
	{
		PREV_STATE = curr_state;

		hcutil::CCanvasCELayer	*pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get(1);
		if( pLayer )
		{
			CRect rcTemp = rect;
			rcTemp.InflateRect( 1, 1, 1, 1 );
			pLayer->Clear( rcTemp, FALSE );

			if( curr_state == 1 ) 
			{
				int			prev_bkmode = pLayer->SetBkMode( TRANSPARENT );
				COLORREF	prev_clr = pLayer->SetTextColor( RGB(32, 250, 32) );
				CString		strText( _T("USB MEMORY") );
				pLayer->DrawText( strText, rect, DT_LEFT|DT_SINGLELINE );
				pLayer->SetBkMode( prev_bkmode );
				pLayer->SetTextColor( prev_clr );
			}

			InvalidateRect( &rcTemp, FALSE );
		}
	}
}



//
void CEPncUIDlg::updateDemoModeDisp()
{
	static int PREV_MODE = -1;
	int curr_mode = pa::PPAStatus->GetThreadState()->bIsDemoMode_ ? 1 : 0;
	CString strMode;
	CRect	rect(920, 4, 1020, 20);

	if( PREV_MODE != curr_mode ) {
		PREV_MODE = curr_mode;

		hcutil::CCanvasCELayer	*pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get(1);
		if( pLayer ) {
			//	pLayer->Clear(FALSE);
			CRect rcTemp = rect;
			rcTemp.InflateRect( 1, 1, 1, 1 );
			pLayer->Clear( rcTemp, FALSE );
			if( curr_mode != 0 ) {
				int			prev_bkmode = pLayer->SetBkMode( TRANSPARENT );
				COLORREF	prev_clr	= pLayer->SetTextColor( RGB(250, 32, 32) );
				strMode.Format( _T("DEMO MODE") );
				pLayer->DrawText( strMode, rect, DT_LEFT|DT_SINGLELINE );
				pLayer->SetBkMode( prev_bkmode );
				pLayer->SetTextColor( prev_clr );
			}
			InvalidateRect( &rcTemp, FALSE );
		}
	}
}

//////////////////////////////////////////////////////////////////////////

void CEPncUIDlg::writeLog( LPCTSTR log_msg )
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	WriteLog( CLog::TYPE_OPER, 1, log_msg );
	//////////////////////////////////////////////////////////////////////////
}

BOOL CEPncUIDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialog::PreTranslateMessage(pMsg);
}

//////////////////////////////////////////////////////////////////////////

LRESULT CEPncUIDlg::OnUsbMemory(WPARAM wparam, LPARAM lparam)
{
	BOOL	bIsConnect = (int)(wparam) == 0 ? FALSE : TRUE;

	bConnectedUsbMemory_ = bIsConnect;

	return 0;
}



