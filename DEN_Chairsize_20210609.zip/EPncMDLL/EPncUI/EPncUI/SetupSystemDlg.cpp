// SetupSystemDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "SetupSystemDlg.h"
#include "MsgDlg.h"
#include "MsgDlgThread.h"
#include "FileCopyDlg.h"

//////////////////////////////////////////////////////////////////////////
// CSetupSystemDlg ��ȭ �����Դϴ�.
//////////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNCREATE(CSetupSystemDlg, CDialogListPage)

//////////////////////////////////////////////////////////////////////////

CSetupSystemDlg::CSetupSystemDlg(CWnd* pParent /*=NULL*/)
	: CDialogListPage(CSetupSystemDlg::IDD, pParent)
{
	pResourcePath_ = RESOURCE_2_PATH;
}

CSetupSystemDlg::~CSetupSystemDlg()
{

}

void CSetupSystemDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogListPage::DoDataExchange(pDX);
}

void CSetupSystemDlg::StartPageWork()
{
	SetTimer( 1, 1000, NULL );

	PPNC_IPC_CLIENT->UploadIPAddress();

	((CButton*)GetDlgItem(IDC_BUTTON_SET_HOME_OFFSET))->ShowWindow( SW_HIDE );		
	((CButton*)GetDlgItem(IDC_BUTTON_SET_HOME_OFFSET_AB))->ShowWindow( SW_HIDE );
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	// User Level�� ���� ��ư ���� ���� 
	if( pa::GET_CURRENT_USERMODE() == pa::USER_MODE_USR )
	{
		((CButton*)GetDlgItem(IDC_BUTTON_SOFT_LIMIT))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_SPINDLE_INFO))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_RUN_TIME_INFO))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_UPGRADE))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_ATC_TEST))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_CHANGE_IP))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_FILTER_MANAGEMENT))->EnableWindow( FALSE );
	}
	else if( pa::GET_CURRENT_USERMODE() == pa::USER_MODE_MGR )
	{
		((CButton*)GetDlgItem(IDC_BUTTON_SOFT_LIMIT))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_SPINDLE_INFO))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_RUN_TIME_INFO))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_UPGRADE))->EnableWindow( TRUE );
		((CButton*)GetDlgItem(IDC_BUTTON_ATC_TEST))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_CHANGE_IP))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_FILTER_MANAGEMENT))->EnableWindow( TRUE );
	}
	else if( pa::GET_CURRENT_USERMODE() == pa::USER_MODE_RND )
	{
		((CButton*)GetDlgItem(IDC_BUTTON_SOFT_LIMIT))->EnableWindow( TRUE );
		((CButton*)GetDlgItem(IDC_BUTTON_SPINDLE_INFO))->EnableWindow( TRUE );
		((CButton*)GetDlgItem(IDC_BUTTON_RUN_TIME_INFO))->EnableWindow( TRUE );
		((CButton*)GetDlgItem(IDC_BUTTON_UPGRADE))->EnableWindow( TRUE );
		((CButton*)GetDlgItem(IDC_BUTTON_ATC_TEST))->EnableWindow( TRUE );
		((CButton*)GetDlgItem(IDC_BUTTON_CHANGE_IP))->EnableWindow( TRUE );
		((CButton*)GetDlgItem(IDC_BUTTON_FILTER_MANAGEMENT))->EnableWindow( TRUE );
	}
	//////////////////////////////////////////////////////////////////////////

	display_program_version();
}

void CSetupSystemDlg::StopPageWork()
{
	KillTimer( 1 );
}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CSetupSystemDlg, CDialogListPage)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, &CSetupSystemDlg::OnBnClickedButtonClose)
	ON_WM_CTLCOLOR()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_SOFT_LIMIT, &CSetupSystemDlg::OnBnClickedButtonSoftLimit)
	ON_WM_SHOWWINDOW()
	ON_BN_CLICKED(IDC_BUTTON_SPINDLE_INFO, &CSetupSystemDlg::OnBnClickedButtonSpindleInfo)
	ON_BN_CLICKED(IDC_BUTTON_UPGRADE, &CSetupSystemDlg::OnBnClickedButtonUpgrade)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BUTTON_SET_HOME_OFFSET, &CSetupSystemDlg::OnBnClickedButtonSetHomeOffset)
	ON_BN_CLICKED(IDC_BUTTON_SET_HOME_OFFSET_AB, &CSetupSystemDlg::OnBnClickedButtonSetHomeOffsetAb)
	ON_BN_CLICKED(IDC_BUTTON_RUN_TIME_INFO, &CSetupSystemDlg::OnBnClickedButtonRunTimeInfo)
	ON_BN_CLICKED(IDC_BUTTON_CHANGE_IP, &CSetupSystemDlg::OnBnClickedButtonChangeIp)
	ON_BN_CLICKED(IDC_BUTTON_ATC_TEST, &CSetupSystemDlg::OnBnClickedButtonAtcTest)
	ON_BN_CLICKED(IDC_BUTTON_FILTER_MANAGEMENT, &CSetupSystemDlg::OnBnClickedButtonFilterManagement)
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CSetupSystemDlg �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CSetupSystemDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialogListPage::PreTranslateMessage(pMsg);
}

BOOL CSetupSystemDlg::OnInitDialog()
{
	CDialogListPage::OnInitDialog();

	//////////////////////////////////////////////////////////////////////////
	brhBackButton_.CreateSolidBrush( pa::CLR_BUTTON_BACK );
	brhStaticBg_.CreateSolidBrush( RGB(190, 190, 190) );

	//////////////////////////////////////////////////////////////////////////
	fntMenuButton_.CreateFont(
		17, 0, 
		0, 0, FW_BOLD,
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	((CButton*)GetDlgItem(IDC_BUTTON_CLOSE))->SetFont( &fntMenuButton_, TRUE );

	CRect recbutton;
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_CLOSE), this, &recbutton, &CUIrectSS);

	//////////////////////////////////////////////////////////////////////////
	fntButton_.CreateFont(
		18, 0, 
		0, 0, FW_BOLD,
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	((CButton*)GetDlgItem(IDC_BUTTON_SOFT_LIMIT))->SetFont( &fntButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_SPINDLE_INFO))->SetFont( &fntButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_RUN_TIME_INFO))->SetFont( &fntButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_UPGRADE))->SetFont( &fntButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_SET_HOME_OFFSET))->SetFont( &fntButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_SET_HOME_OFFSET_AB))->SetFont( &fntButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_ATC_TEST))->SetFont( &fntButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_CHANGE_IP))->SetFont( &fntButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_FILTER_MANAGEMENT))->SetFont( &fntButton_, TRUE );

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_SOFT_LIMIT), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_SPINDLE_INFO), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_RUN_TIME_INFO), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_UPGRADE), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_SET_HOME_OFFSET), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_SET_HOME_OFFSET_AB), this, &recbutton, &CUIrectSS);
	// hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ATC_TEST), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_CHANGE_IP), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_FILTER_MANAGEMENT), this, &recbutton, &CUIrectSS);

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON1), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON5), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON7), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON14), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON15), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON18), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON21), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON22), this, &recbutton, &CUIrectSS);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON25), this, &recbutton, &CUIrectSS);

	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_EPNCUI_VER), this, &recbutton, &CUIrectSS);
	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_IP_ADDRESS), this, &recbutton, &CUIrectSS);
	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_IO_MAP_VERSION), this, &recbutton, &CUIrectSS);
	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_PA_CONTROLLER_VER), this, &recbutton, &CUIrectSS);
	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_PA_CONTROLLER_DATE), this, &recbutton, &CUIrectSS);

	//////////////////////////////////////////////////////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CSetupSystemDlg::OnDestroy()
{
	brhBackButton_.DeleteObject();
	brhStaticBg_.DeleteObject();

	fntMenuButton_.DeleteObject();

	fntButton_.DeleteObject();

	if( pCanvasCE_ ) {
		delete pCanvasCE_;
		pCanvasCE_ = NULL;
	}

	CDialogListPage::OnDestroy();
}

//void CSetupSystemDlg::OnBnClickedButtonEmoReset()
//{
//	if( pa::PPAStatus->GetRunMode() == pa::RUNMODE_ERROR ) {
//		//////////////////////////////////////////////////////////////////////////
//		// log
//		writeLog( _T("reset button click") );
//		//////////////////////////////////////////////////////////////////////////
//		// Reset
//		PPNC_IPC_CLIENT->ErrorReset();
//	} else {
//		//////////////////////////////////////////////////////////////////////////
//		// log
//		writeLog( _T("emo button click") );
//		//////////////////////////////////////////////////////////////////////////
//		// EMO
//		PPNC_IPC_CLIENT->Emergency();
//	}
//}

void CSetupSystemDlg::OnBnClickedButtonClose()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("back button click") );
	//////////////////////////////////////////////////////////////////////////
	ASSERT( pParentWnd_ );
	pParentWnd_->PostMessage( WM_SETUP, (WPARAM)SETUP_BACK, (LPARAM)0 );
}

void CSetupSystemDlg::writeLog( LPCTSTR log_msg )
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	WriteLog( CLog::TYPE_OPER, 6, log_msg );
	//////////////////////////////////////////////////////////////////////////
}

HBRUSH CSetupSystemDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogListPage::OnCtlColor(pDC, pWnd, nCtlColor);

	if( nCtlColor == 4 ) {
		hbr = hbr;
	}
	else {
		UINT nCtrlID = pWnd->GetDlgCtrlID();
		switch( nCtrlID )
		{
		case IDC_BUTTON_CLOSE:
			return (HBRUSH)brhBackButton_;
			break;

		case IDC_STATIC_EPNCUI_VER:
		case IDC_STATIC_PA_CONTROLLER_VER:
		case IDC_STATIC_IP_ADDRESS:
		case IDC_STATIC_IO_MAP_VERSION:
		case IDC_BUTTON_SET_HOME_OFFSET:
		case IDC_BUTTON_SET_HOME_OFFSET_AB:
		case IDC_STATIC_PA_CONTROLLER_DATE:
			pDC->SetBkMode( TRANSPARENT );
			pDC->SetTextColor( RGB(0, 0, 0) );
			return (HBRUSH)brhStaticBg_;
			break;
		}
	}

	return hbr;
}

void CSetupSystemDlg::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 1 ) 
	{
		KillTimer( 1 );

		updateButtonState();

		if( IsWindowVisible() ) {
			SetTimer( 1, 200, NULL );
		}
	}

	CDialogListPage::OnTimer(nIDEvent);
}

void CSetupSystemDlg::updateButtonState()
{

}

// void CSetupSystemDlg::display_program_version()
// {
// 	CString strTemp;
// 
// 	strTemp.Format( _T("EPncUI Version : %s"), pa::PPAStatus->GetThreadState()->szUIProgVersion );
// 	((CStatic *)GetDlgItem( IDC_STATIC_EPNCUI_VER ))->SetWindowText( strTemp );
// 
// 	strTemp.Format( _T("PA Controller Version : %s"), pa::PPAStatus->GetThreadState()->szPAControllerVersion );
// 	((CStatic *)GetDlgItem( IDC_STATIC_PA_CONTROLLER_VER ))->SetWindowText( strTemp );
// 
// 	strTemp.Format( _T("Ip Address : %s"),  pa::PPAStatus->GetThreadState()->szIpAddress );
// 	((CStatic *)GetDlgItem( IDC_STATIC_IP_ADDRESS ))->SetWindowText( strTemp );
// 
// #ifdef _PA_G2400_
// 	strTemp.Format( _T("I/O Map Version : PA_G2400") );
// #endif 
// #ifdef _PA_G1600_
// 	strTemp.Format( _T("I/O Map Version : PA_G1600") );
// #endif 
// 	((CStatic *)GetDlgItem( IDC_STATIC_IO_MAP_VERSION ))->SetWindowText( strTemp );
// }

void CSetupSystemDlg::display_program_version()
{
	CString strTemp;

	strTemp.Format( _T("PNC Version : %s"), pa::PPAStatus->GetThreadState()->szUIProgVersion );
	((CStatic *)GetDlgItem( IDC_STATIC_EPNCUI_VER ))->SetWindowText( strTemp );

	strTemp.Format( _T("PA Controller Version : %s"), pa::PPAStatus->GetThreadState()->szPAControllerVersion );
	((CStatic *)GetDlgItem( IDC_STATIC_PA_CONTROLLER_VER ))->SetWindowText( strTemp );

	strTemp.Format( _T("Ip Address : %s"),  pa::PPAStatus->GetThreadState()->szIpAddress );
	((CStatic *)GetDlgItem( IDC_STATIC_IP_ADDRESS ))->SetWindowText( strTemp );

	strTemp.Format(_T("PA Controller Date : %04d-%02d-%02d"), 
		pa::PPAStatus->GetThreadState()->nPAYear, 
		pa::PPAStatus->GetThreadState()->nPAMonth, 
		pa::PPAStatus->GetThreadState()->nPADay);
	((CStatic *)GetDlgItem(IDC_STATIC_PA_CONTROLLER_DATE))->SetWindowText(strTemp);

#ifdef _PA_G2400_
	strTemp.Format( _T("I/O Map Version : PA_G2400") );
#endif 
#ifdef _PA_G1600_
	strTemp.Format( _T("I/O Map Version : PA_G1600") );
#endif 
	((CStatic *)GetDlgItem( IDC_STATIC_IO_MAP_VERSION ))->SetWindowText( strTemp );
}


void CSetupSystemDlg::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CDialogListPage::OnShowWindow(bShow, nStatus);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	if( bShow ) {
		PPNC_IPC_CLIENT->UploadIPAddress();
		display_program_version();
	}
}

// Soft-Limt ���� ���̾�α׸� ���� 
#include "SetupSystemSoftLimitDlg.h"
void CSetupSystemDlg::OnBnClickedButtonSoftLimit()
{
	CSetupSystemSoftLimitDlg dlg;
	dlg.DoModal();
}

// SpindleInfo ���̾�α׸� ���� 
#include "SetupSystemToolInfoDlg.h"
void CSetupSystemDlg::OnBnClickedButtonSpindleInfo()
{
	CSetupSystemToolInfoDlg dlg;
	dlg.DoModal();
}

// FilterManagement ���̾�α׸� ����
#include "SetupSystemFilterManagementDlg.h"
void CSetupSystemDlg::OnBnClickedButtonFilterManagement()
{
	CSetupSystemFilterManagementDlg dlg;
	dlg.DoModal();
}

// USB�� EPnc_Upgrade ������ upgrade.ini ������ Ȯ��
//	�ʿ��� ������ �� �ִ��� Ȯ�� �� ��, 
//	SD Memory�� Upgrade ������ ���� �Ѵ� 
// �ٽ� �����Ҷ�, 
//	Startup ���α׷����� ���׷��̵� ������ �ִ��� Ȯ�� �� �� ������ ���� �ϰ�
//	������ ��� ���� �Ѵ�
// 2016.12.15 
//	��� ID��ȣ�� ����ؼ� enpc_upgrade_modelname ������ ã���� �����Ѵ� 
void CSetupSystemDlg::OnBnClickedButtonUpgrade()
{
	//////////////////////////////////////////////////////////////////////////
	// 	CString strFilePath( _T("/�ϵ� ��ũ/epnc_upgrade/") );
	// 2016.12.15 �߰�/���� 
//	CString strModelName = pa::PSWConfig->GetConfigData()->szModelName;
//	TCHAR	*pModelName = pa::PSWConfig->GetConfigData()->szModelName + 5;	// remove "MAXX "
	TCHAR	*pModelName = pa::MODEL_INFO.GetModelName() + 5;		// remove "MAXX "
// 	CString strFilePath( _T("/�ϵ� ��ũ/epnc_upgrade_") );
// 	strFilePath += strModelName + CString( _T("/") );
	CString	strFilePath;
	strFilePath.Format( _T("/�ϵ� ��ũ/epnc_upgrade_%s/"), pModelName );
	//////////////////////////////////////////////////////////////////////////

	CString strIniFilePath = strFilePath + CString( _T("upgrade.ini") );
	CString strMsg;
	BOOL	bError = FALSE;

	//////////////////////////////////////////////////////////////////////////
	// 1. ini ������ �ִ��� Ȯ���Ѵ� 
	if( !hcutil::IsExistFile( strIniFilePath ) ) {
		strMsg.Format( _T("Not found upgrade.ini file") );
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
		CMsgDlgThread::GetInstance()->Wait();
		return ;
	}

	//////////////////////////////////////////////////////////////////////////
	// 2. ini ���Ͽ� �����ϴ�, �����̵� ������ �ִ��� Ȯ���Ѵ� 
	CCEIniFile	hIniFile;
	CString		strKeyName, strValueName;
	CString		strTemp;
	int			nNumFile;

	CString strCopyingFiles[100];
	int		nNumCopyingFiles = 0;

	hIniFile.Open( strIniFilePath );
	
	strKeyName.Format( _T("copy") );
	hIniFile.GetValue( strKeyName, _T("num"), (int*)&nNumFile );

	strCopyingFiles[0].Format( _T("upgrade.ini") );

	for( int i = 0; i<nNumFile; i++ )
	{
		strValueName.Format( _T("file_%d_src"), i+1 );
		hIniFile.GetValue( strKeyName, strValueName, (CString*)&strTemp );
		strCopyingFiles[i+1] = strTemp;

		// ������ �ִ��� Ȯ��. �ϳ��� ������ ����. 
		strTemp = strFilePath + strTemp;
		if( !hcutil::IsExistFile( strTemp ) ) {
			bError = TRUE;
			break;
		}
	}
	if( bError ) {
		strMsg.Format( _T("Upgrade file not found.\r\n(") );
		strMsg += strTemp;
		strMsg += CString( _T(")") );
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
		CMsgDlgThread::GetInstance()->Wait();
		hIniFile.Close();
		return ;
	}

	//////////////////////////////////////////////////////////////////////////
	// 3, ������ �������� ���θ� Ȯ���Ѵ� 
	strMsg.Format( _T("Do you want to upgrade program ?") );
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
	CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();
	if( hRet == CMsgDlg::RET_CANCEL ) {
		hIniFile.Close();
		return;
	}

	//////////////////////////////////////////////////////////////////////////
	// 4. SD�� Upgrade ������ ���� ���, ������ ����� 
	CString strDestFolder( UPGRADE_PATH );
	if( !hcutil::IsExistDir( strDestFolder ) ) {
		CreateDirectory( strDestFolder, NULL );
		Sleep( 500 ); // 500msec ��� 
		if( !hcutil::IsExistDir( strDestFolder ) ) {
			// ���� 
			strMsg.Format( _T("Fail to create upgrade folder at SD Card") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
			hIniFile.Close();
			return ;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// 5. ������ Upgrade ������ ���� �Ѵ� 
	CFileCopyDlg dlg;

	nNumCopyingFiles = nNumFile + 1;	// upgrade.ini ���� ���� 

	dlg.SetSrcFileName(strCopyingFiles, nNumCopyingFiles );
	dlg.SetSrcPath( strFilePath );
	dlg.SetDstPath( strDestFolder );
	dlg.DoModal();

	hIniFile.Close();
}

#include "SetupSystemMultiOriginDlg.h"
//void CSetupSystemDlg::OnBnClickedButtonMultiOrigin()
//{
//	CSetupSystemMultiOriginDlg dlg;
//	dlg.DoModal();
//}

void CSetupSystemDlg::PreInitDialog()
{
	CString strImageFilePath;
	CDC*	pDC = GetDC();
	CRect	rcWnd;
	GetClientRect( &CUIrectSS );
	MoveWindow(0,0,1023,619);

	//////////////////////////////////////////////////////////////////////////
	strImageFilePath.Format( _T("%s\\Background_setup.bmp"), pResourcePath_ );

	GetClientRect( &rcWnd );

	pCanvasCE_ = new hcutil::CCanvasCE();
	ASSERT(pCanvasCE_ );
	pCanvasCE_->Create( this, pDC->GetSafeHdc(), rcWnd.Width(), rcWnd.Height(), RGB(1, 1, 0) );
	pCanvasCE_->GetCanvasCELayerMgr()->Add( FALSE, RGB(0, 0, 0) );
	pCanvasCE_->GetCanvasCELayerMgr()->Add( TRUE, RGB(255, 0, 255) );

	pCanvasCE_->GetCanvasCELayerMgr()->Get( 0 )->FillSolidRect( rcWnd, RGB(190, 190, 190) );
	pCanvasCE_->GetCanvasCELayerMgr()->Get( 1 )->LoadImageFormFile( strImageFilePath, CPoint(0, 0), CPoint(rcWnd.Width(), rcWnd.Height()) );
	//////////////////////////////////////////////////////////////////////////

	ReleaseDC( pDC );
	pDC = NULL;

	CDialogListPage::PreInitDialog();
}

void CSetupSystemDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	if( pCanvasCE_ ) {
		pCanvasCE_->Draw( dc.m_hDC, dc.m_ps.rcPaint );
	}
}

// 2017.08.31. �����缳�� ��� �߰� 
#include "ResetOriginDlg.h"
void CSetupSystemDlg::OnBnClickedButtonSetHomeOffset()
{
// 	CString strMsg;
// 
// 	strMsg.Format( _T("do you want to set home offset ?") );
// 	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_INFO, strMsg );
// 	CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();
// 
// 	if( hRet == CMsgDlg::RET_OK )
// 	{
// 		// ���� ���� 
// 		PPNC_IPC_CLIENT->SetHomeOffset();
// 	}

	CString strMsg;

	strMsg.Format( _T("checking softlimit data...") );
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

	//////////////////////////////////////////////////////////////////////////
	// softlimit �����͸� ���ε� �� ���´� 
	// �� �� �� �����͸� ����Ѵ� (�ະ�� ��) 
	DWORD	dwTime = GetTickCount();
	double	fSoftLimit[pa::AXIS_NUM][2];
	PPNC_IPC_CLIENT->UploadSoftLimit();
	Sleep( 500 );
	while( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == FALSE ) {
		if( GetTickCount() - dwTime > 10000 ) {
			// Timeout ���� 
			strMsg.Format( _T("timeout error occured !") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
			return ;
		}
		Sleep(100);
	}
	for( int i=0; i<pa::AXIS_NUM; i++ ) {
		fSoftLimit[i][0] = pa::PPAStatus->GetThreadState()->fSoftLimit_[i][0];
		fSoftLimit[i][1] = pa::PPAStatus->GetThreadState()->fSoftLimit_[i][1];

		CString strLog;
		strLog.Format( _T("softlimit[%d] : %.3f %.3f"), i, fSoftLimit[i][0], fSoftLimit[i][1] );
		writeLog( strLog );
	}
	CMsgDlgThread::GetInstance()->Hide();

	//////////////////////////////////////////////////////////////////////////
	//
	CResetOriginDlg dlg;
	dlg.DoModal();
}

void CSetupSystemDlg::OnBnClickedButtonSetHomeOffsetAb()
{
	CString strMsg;

	strMsg.Format( _T("do you want to set home offset (A/B axis) ?") );
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_INFO, strMsg );
	CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();

	if( hRet == CMsgDlg::RET_OK )
	{
		// ���� ���� 
		PPNC_IPC_CLIENT->SetHomeOffsetAB();
	}
}

// RunTimeInfo ���̾�α׸� ����
#include "SetupSystemRunTimeInfoDlg.h"
void CSetupSystemDlg::OnBnClickedButtonRunTimeInfo()
{
	CSetupSystemRunTimeInfoDlg dlg;
	dlg.DoModal();
}

// Change I/P ���̾�α׸� ���� 
#include "SetupSystemChangeIPDlg.h"
void CSetupSystemDlg::OnBnClickedButtonChangeIp()
{
	CSetupSystemChangeIPDlg dlg;
	dlg.DoModal();
}

//
#include "SetupSystemATCTestDlg.h"
void CSetupSystemDlg::OnBnClickedButtonAtcTest()
{
	CSetupSystemATCTestDlg dlg;
	dlg.DoModal();
}

