#include "StdAfx.h"
#include "PAutoLoader.h"

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

int pa::CPAutoLoader::AUTOLOADER_AXIS_NO = 5;

//////////////////////////////////////////////////////////////////////////

pa::CPAutoLoader::CPAutoLoader(void)
{
	strFilePath_.Format( _T("") );
	pShMemALConfig_		= NULL;
	pAutoLoaderConfig_	= NULL;
	pShMemBlockState_	= NULL;
	pBlockState_		= NULL;
}

pa::CPAutoLoader::~CPAutoLoader(void)
{
	Destroy();
}

//////////////////////////////////////////////////////////////////////////

BOOL pa::CPAutoLoader::Initialize( CString& strConfigFilePath, CString& strErrMsg )
{
	strFilePath_ = strConfigFilePath;

	pShMemALConfig_ = new hcipc::CSharedMem();
	if( pShMemALConfig_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::CAutoLoader::pShMemALConfig_ object" ) );
		return FALSE;
	} 
	pAutoLoaderConfig_ = (SAutoLoaderConfig *)pShMemALConfig_->Create( NULL, ALCONFIG_ONJECT_NAME, sizeof(SAutoLoaderConfig), FALSE, 0 );
	if( pAutoLoaderConfig_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pmac::CAutoLoader::pAutoLoaderConfig_ object") );
		return FALSE;
	}

	pShMemBlockState_ = new hcipc::CSharedMem();
	if( pShMemBlockState_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::CAutoLoader::pShMemBlockState_ object") );
		return FALSE;
	}
	pBlockState_ = (SAutoLoaderBlockState*)pShMemBlockState_->Create( IPC_FILEPATH, AUTOLOADER_OBJECT_NAME, sizeof(SAutoLoaderBlockState), FALSE, 0 );
	if( pBlockState_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pmac::CAutoLoader::pBlockState_ object") );
		return FALSE;
	}

	pShMemItemLocationState_ = new hcipc::CSharedMem();
	if( pShMemItemLocationState_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::CAutoLoader::pShMemItemLocationState_ object") );
		return FALSE;
	}
	pItemLocationState_ = (ItemLocationState*)pShMemItemLocationState_->Create( IPC_FILEPATH, ITEM_LOCATION_STATE_OBJECT_NAME, sizeof(ItemLocationState), FALSE, 0 );
	if( pItemLocationState_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pmac::CAutoLoader::pItemLocationState_ object") );
		return FALSE;
	}

	return TRUE;
}

void pa::CPAutoLoader::Destroy()
{
	if( pShMemALConfig_ != NULL ) {
		pShMemALConfig_->Destroy();
		delete pShMemALConfig_;
		pShMemALConfig_ = NULL;
		pAutoLoaderConfig_ = NULL;
	}

	if( pShMemBlockState_ != NULL ) {
		pShMemBlockState_->Destroy();
		delete pShMemBlockState_;
		pShMemBlockState_ = NULL;
		pBlockState_ =NULL;
	}

	if( pShMemItemLocationState_ != NULL ) {
		pShMemItemLocationState_->Destroy();
		delete pShMemItemLocationState_;
		pShMemItemLocationState_ = NULL;
		pItemLocationState_ =NULL;
	}
}

void pa::CPAutoLoader::SaveAutoLoaderConfig()
{
	// ini ���Ͽ� ������ ����Ѵ�  
	CCEIniFile	hIniFile;
	CString		strKeyName, strValueName;
	int			nTemp;
	double		fTemp;

	hIniFile.Open( strFilePath_ );

	strKeyName.Format( _T("AutoLoader") );
	hIniFile.SetValue( strKeyName, _T("Using"), (int)( pAutoLoaderConfig_->bUsingAutoLoader == TRUE ? 1 : 0 ) );

	hIniFile.SetValue( strKeyName, _T("NumBlock"), (int)( pAutoLoaderConfig_->nNumBlock_ ) );

	strKeyName.Format( _T("Motor") );
	hIniFile.SetValue( strKeyName, _T("Scale"), (double)( pAutoLoaderConfig_->fScale_ ) );

	strKeyName.Format( _T("TeachingPoint") );
	for( int i = 0; i<AUTOLOADER_TP_NUM; i++ ) {
		strValueName = STR_AUTOLOADER_TEACHING_POINT_NAME[i];
		hIniFile.SetValue( strKeyName, strValueName, (double)( pAutoLoaderConfig_->fTeachingPoint_[i] ) );
	}

	hIniFile.Close();
}

void pa::CPAutoLoader::LoadAutoLoaderConfig()
{
	// ini ���Ͽ� ������ ����Ѵ�  
	CCEIniFile	hIniFile;
	CString		strKeyName, strValueName;
	int			nTemp;
	double		fTemp;

	hIniFile.Open( strFilePath_ );

	strKeyName.Format( _T("AutoLoader") );
	hIniFile.GetValue( strKeyName, _T("Using"), (int*)&nTemp );
	pAutoLoaderConfig_->bUsingAutoLoader = nTemp == 0 ? FALSE : TRUE;

	hIniFile.GetValue( strKeyName, _T("NumBlock"), (int*)&nTemp );
	pAutoLoaderConfig_->nNumBlock_ = nTemp;

	strKeyName.Format( _T("Motor") );
	hIniFile.GetValue( strKeyName, _T("Scale"), (double*)&fTemp );
	pAutoLoaderConfig_->fScale_ = fTemp;

// 	strKeyName.Format( _T("TeachingPoint") );
 	strKeyName.Format( _T("AutoLoader") );
	for( int i = 0; i<AUTOLOADER_TP_NUM; i++ ) {
		strValueName = STR_AUTOLOADER_TEACHING_POINT_NAME[i];
		hIniFile.GetValue( strKeyName, strValueName, (double*)&fTemp );
		pAutoLoaderConfig_->fTeachingPoint_[i] = fTemp;
	}

	hIniFile.Close();
}

//////////////////////////////////////////////////////////////////////////

void pa::CPAutoLoader::ResetBlockStates()
{
	for( int i = 0; i<pAutoLoaderConfig_->nNumBlock_; i++ )
	{
		pBlockState_->hBlockState[i] = pa::BLOCK_STATE_EMPTY;
	}
}

//////////////////////////////////////////////////////////////////////////

pa::EN_AUTOLOADER_BLOCK_STATE pa::CPAutoLoader::GetBlockState( int nIndex )
{
	pa::EN_AUTOLOADER_BLOCK_STATE hBlockState;

	if( pBlockState_ ) {
		hBlockState = pBlockState_->hBlockState[nIndex];
	} else {
		hBlockState = pa::BLOCK_STATE_BEFORE;
	}

	return hBlockState;
}

int pa::CPAutoLoader::GetItemNumberFromSlotIndex(int index) {
	return pBlockState_->slotHolderNumber[index];
}

void pa::CPAutoLoader::SetBlockState( int nIndex, pa::EN_AUTOLOADER_BLOCK_STATE hBlockState )
{
	if( pBlockState_ ) {
		pBlockState_->hBlockState[nIndex] = hBlockState;
		// ���Ͽ� ���� (Flush) 
		pShMemBlockState_->Flush( (void*)(&(pBlockState_->hBlockState[nIndex])), sizeof(pBlockState_->hBlockState[nIndex]) );
	}
}

void pa::CPAutoLoader::SetWorkIndex( int nIndex )
{
	if( pBlockState_ ) {
		pBlockState_->nWorkIndex = nIndex;
		// ���Ͽ� ���� (Flush)
		pShMemBlockState_->Flush( (void*)(&(pBlockState_->nWorkIndex)), sizeof(int) );
	}
}

int pa::CPAutoLoader::GetAutoLoaderHandItemNumber()
{
	return (pItemLocationState_) ? pItemLocationState_->autoLoaderHandItemNumber : -1;
}

int pa::CPAutoLoader::GetItemPasserItemNumber()
{
	return (pItemLocationState_) ? pItemLocationState_->itemPasserItemNumber : -1;
}

int pa::CPAutoLoader::GetWorkSpaceItemNumber()
{
	return (pItemLocationState_) ? pItemLocationState_->workSpaceItemNumber : -1;
}

//////////////////////////////////////////////////////////////////////////

