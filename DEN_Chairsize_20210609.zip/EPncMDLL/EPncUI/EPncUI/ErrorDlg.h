#pragma once

// CErrorDlg ��ȭ �����Դϴ�.

class CErrorDlg : public CDialog
{
	DECLARE_DYNAMIC(CErrorDlg)

	BOOL bIsShow_;

	CBrush	brhBkgnd_;
	CBrush	textBkgnd_;
	CFont	fntTitle_;
	CFont	fntMessage_;
	CFont	fntButton_;

public:
	CErrorDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CErrorDlg();

	void RESET_SHOW_ERROR_DLG();

	void SHOW_ERROR_DLG();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_ERROR };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	CString strErrorType_;
	CString strErrorCode_;
	CString strErrorMessage_;
	BOOL bMelodyOff_;
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnBnClickedButtonOk();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnDestroy();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedButtonClose();
	afx_msg LRESULT OnWindowMove(WPARAM wparam, LPARAM lparam);
	CString strErrorComment_;
};

extern CErrorDlg* PERROR_DLG;
