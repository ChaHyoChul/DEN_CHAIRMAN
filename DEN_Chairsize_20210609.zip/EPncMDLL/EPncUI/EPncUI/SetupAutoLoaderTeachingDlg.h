#pragma once

#include "OptionDataListBox.h"
#include "TitleBarWnd.h"

// CSetupAutoLoaderTechingDlg ��ȭ �����Դϴ�.

class CSetupAutoLoaderTeachingDlg : public CDialogListPage
{
	DECLARE_DYNCREATE(CSetupAutoLoaderTeachingDlg)

	CTitleBarWnd*		pTitleBar_ALTeaching_;
	COptionDataListBox*	pTeachingDataListBox_;

	CRect	CUIrectSAT; 

	void update_TeachingDataListBox();

public:
	CSetupAutoLoaderTeachingDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupAutoLoaderTeachingDlg();

	virtual void StartPageWork();
	virtual void StopPageWork();
	virtual void UpdatePage();

	void UpdateTeachingDataListBox();


// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_AUTOLOADER_TEACHING };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	LRESULT OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
