#pragma once

// CSetupSystemSoftLimitDlg ��ȭ �����Դϴ�.
#include "OptionDataListBox.h"
#include "TitleBarWnd.h"

class CSetupSystemSoftLimitDlg : public CDialog
{
	DECLARE_DYNAMIC(CSetupSystemSoftLimitDlg)

	CTitleBarWnd*		pTitleBar_;
	COptionDataListBox*	pDataListBox_;

	CFont	fntButton_;

	double	fSoftLimitData_[pa::AXIS_NUM][2];			// �� ���� +/- soft-limit 

	void writeLog( LPCTSTR log_msg );

public:
	CSetupSystemSoftLimitDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupSystemSoftLimitDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_SYSTEM_SOFTLIMIT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedButtonUpload();
	afx_msg void OnBnClickedButtonDownloadSave();
	afx_msg void OnBnClickedButtonClose();
	LRESULT OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
