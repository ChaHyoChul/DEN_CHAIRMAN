// SetupOptionDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "SetupOptionDlg.h"
#include "MsgDlgThread.h"
#include "NumericInputDlg.h"

// CSetupOptionDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNCREATE(CSetupOptionDlg, CDialogListPage)

CSetupOptionDlg::CSetupOptionDlg(CWnd* pParent /*=NULL*/)
	: CDialogListPage(CSetupOptionDlg::IDD, pParent)
	, nSelectOperationM28_(0)
	, nToolErrOccureHandingCode_(0)
{
	bEnableDownloadButton_ = FALSE;
	pResourcePath_ = RESOURCE_2_PATH;
}

CSetupOptionDlg::~CSetupOptionDlg()
{
}

void CSetupOptionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogListPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CHECK_USING_BLOCK_AUTOLOADER, chkUsingBlockAutoLoader_);
	DDX_Control(pDX, IDC_CHECK_USING_DETECT_BLOCK_SENSOR, chkUsingDetectBlockSensor_);
	DDX_Control(pDX, IDC_CHECK_USING_AIR_PRESSURE_LIMIT, chkUsingAirPressureLimit_);
	DDX_Control(pDX, IDC_BUTTON_BLOCK_GRIP_INTERVAL, btnBlockGripInterval_);
	DDX_Control(pDX, IDC_BUTTON_AIR_PRESSURE_INTERVAL, btnAirPressureInterval_);
	DDX_Control(pDX, IDC_CHECK_DEMO_MODE, chkDemoMode_);
	DDX_Control(pDX, IDC_CHECK_USING_OP_PANEL, chkUsingOpPanel_);
	DDX_Radio(pDX, IDC_RADIO_SELECT_OPER_M28, nSelectOperationM28_);
	DDX_Radio(pDX, IDC_RADIO_TOOL_ERR_OCCURED_STOP, nToolErrOccureHandingCode_);
	DDX_Control(pDX, IDC_CHECK_USING_FLOW_SENSOR, chkUsingFlowSensor_);
	DDX_Control(pDX, IDC_BUTTON_FLOW_SENSOR_TIMEOUT, btnFlowSensorTimeout_);
	DDX_Control(pDX, IDC_CHECK_INVALID_NC_CODE, chkInvalidNcCode_);
	DDX_Control(pDX, IDC_CHECK_NC_FILE_TAG, chkNcFileTag_);
	DDX_Control(pDX, IDC_CHECK_TRANSFORM_COORDINATE, chkTransformCoord_);
	DDX_Control(pDX, IDC_CHECK_USING_SPINDLE_AIR_PURGE, chkUsingSpindleAirPurge_);
	DDX_Control(pDX, IDC_CHECK_USING_LOGGING, chkUsingLogging_);
	DDX_Control(pDX, IDC_BUTTON_FLOW_SENSOR_START_TIMEOUT, btnFlowSensorStartTimeout_);
	DDX_Control(pDX, IDC_BUTTON_PURGE_AIR_HOLD_TIME, btnPurgeAirHoldTime_);
}

void CSetupOptionDlg::StartPageWork()
{
	bEnableDownloadButton_ = FALSE;

	//////////////////////////////////////////////////////////////////////////
	//
	upload_to_pc();
	//////////////////////////////////////////////////////////////////////////

	updateState();

	SetTimer( 1, 200, NULL );
}

void CSetupOptionDlg::StopPageWork()
{
	KillTimer( 1 );
}

void CSetupOptionDlg::UpdatePage()
{

}

void CSetupOptionDlg::updateState()
{
	CString strTemp;

	chkUsingBlockAutoLoader_.SetCheck( pa::PAutoLoader->IsUsingAutoLoader() );

	chkUsingOpPanel_.SetCheck( pa::PSWConfig->GetConfigData()->bUsingOpPanel );

// 	chkUsingCompleteMelody_.SetCheck( pa::PSWConfig->GetConfigData()->bUsingMelodyForComplete );

// 	chkUsingErrorMelody_.SetCheck( pa::PSWConfig->GetConfigData()->bUsingMelodyForError );

	chkUsingDetectBlockSensor_.SetCheck( pa::PSWConfig->GetConfigData()->bUsingDetectBlock );

	chkUsingAirPressureLimit_.SetCheck( pa::PSWConfig->GetConfigData()->bUsingAirLimitSensor );

	chkDemoMode_.SetCheck( pa::PPAStatus->GetThreadState()->bIsDemoMode_ );

	strTemp.Format( _T("%d"), pa::PSWConfig->GetConfigData()->nDelayGripBlock );
	btnBlockGripInterval_.SetWindowText( strTemp );

	strTemp.Format( _T("%d"), pa::PSWConfig->GetConfigData()->nAirLimitInterval );
	btnAirPressureInterval_.SetWindowText( strTemp );

	//////////////////////////////////////////////////////////////////////////
	// M28 ���� 
	//	- DS200-5Z�� DRY
	//	- DS200-4W�� WET �� ���� ��Ų�� 
// 	switch( pa::PSWConfig->GetConfigData()->nModelID )
// 	{
// 	case 0: 
// 		// DS200-5Z : DRY 
// 		nSelectOperationM28_ = 1;
// 		break;
// 	case 1:
// 	case 2:
// 	case 3:
// 		// DS200-4W(A/S) : WET
// 		nSelectOperationM28_ = 0;
// 		break;
// 	default:
// 		nSelectOperationM28_ = 1;
// 		break;
// 	}
	// 2017.03.24 
	//	- ����⿡�� �о ǥ���ϱ� ������ �� ������ �ʿ� ���� 
	nSelectOperationM28_ = pa::PSWConfig->GetConfigData()->nSelectM28Operation;
	//////////////////////////////////////////////////////////////////////////

	nToolErrOccureHandingCode_ = pa::PSWConfig->GetConfigData()->nToolErrorOccure_HandlingCode;

	chkUsingFlowSensor_.SetCheck( pa::PSWConfig->GetConfigData()->bUsingFlowSensor );

	strTemp.Format( _T("%d"), pa::PSWConfig->GetConfigData()->nFlowSensorTimeout );
	btnFlowSensorTimeout_.SetWindowText( strTemp );
	strTemp.Format( _T("%d"), pa::PSWConfig->GetConfigData()->nFlowSensorStartTimeout );
	btnFlowSensorStartTimeout_.SetWindowText( strTemp );
	chkInvalidNcCode_.SetCheck( pa::PSWConfig->GetConfigData()->bCheckInvalidNcCode );

	chkNcFileTag_.SetCheck( pa::PSWConfig->GetConfigData()->bCheckNcFileTag );
	
	chkTransformCoord_.SetCheck( pa::PSWConfig->GetConfigData()->bTransformNcFile );

	chkUsingSpindleAirPurge_.SetCheck( pa::PSWConfig->GetConfigData()->bUsingSpindleAirPurge );
	strTemp.Format(_T("%d"), pa::PSWConfig->GetConfigData()->nPurgeAirHoldTime);
	btnPurgeAirHoldTime_.SetWindowText(strTemp);

	chkUsingLogging_.SetCheck(
		pa::PSWConfig->GetConfigData()->nEnableOperationLog &&
		pa::PSWConfig->GetConfigData()->nEnableIpcCommLog &&
		pa::PSWConfig->GetConfigData()->nEnableThreadModeLog &&
		pa::PSWConfig->GetConfigData()->nEnableOpPenalLog &&
		pa::PSWConfig->GetConfigData()->nEnableExtLog &&
		pa::PSWConfig->GetConfigData()->nEnableErrLog );

	UpdateData( FALSE );
}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CSetupOptionDlg, CDialogListPage)
	ON_WM_DESTROY()
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, &CSetupOptionDlg::OnBnClickedButtonClose)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, &CSetupOptionDlg::OnBnClickedButtonSave)
	ON_BN_CLICKED(IDC_BUTTON_BLOCK_GRIP_INTERVAL, &CSetupOptionDlg::OnBnClickedButtonBlockGripInterval)
	ON_BN_CLICKED(IDC_BUTTON_AIR_PRESSURE_INTERVAL, &CSetupOptionDlg::OnBnClickedButtonAirPressureInterval)
	ON_BN_CLICKED(IDC_CHECK_DEMO_MODE, &CSetupOptionDlg::OnBnClickedCheckDemoMode)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_RADIO_SELECT_OPER_M28, &CSetupOptionDlg::OnBnClickedRadioSelectOperM28)
	ON_BN_CLICKED(IDC_RADIO_SELECT_OPER_M28_2, &CSetupOptionDlg::OnBnClickedRadioSelectOperM282)
	ON_BN_CLICKED(IDC_CHECK_USING_BLOCK_AUTOLOADER, &CSetupOptionDlg::OnBnClickedCheckUsingBlockAutoloader)
	ON_BN_CLICKED(IDC_CHECK_USING_DETECT_BLOCK_SENSOR, &CSetupOptionDlg::OnBnClickedCheckUsingDetectBlockSensor)
	ON_BN_CLICKED(IDC_BUTTON_FLOW_SENSOR_TIMEOUT, &CSetupOptionDlg::OnBnClickedButtonFlowSensorTimeout)
	ON_BN_CLICKED(IDC_BUTTON_DOWNLOAD_TO_COLTROLLOR, &CSetupOptionDlg::OnBnClickedButtonDownloadToColtrollor)
	ON_BN_CLICKED(IDC_CHECK_USING_FLOW_SENSOR, &CSetupOptionDlg::OnBnClickedCheckUsingFlowSensor)
	ON_BN_CLICKED(IDC_CHECK_INVALID_NC_CODE, &CSetupOptionDlg::OnBnClickedCheckInvalidNcCode)
	ON_BN_CLICKED(IDC_CHECK_NC_FILE_TAG, &CSetupOptionDlg::OnBnClickedCheckNcFileTag)
	ON_BN_CLICKED(IDC_CHECK_TRANSFORM_COORDINATE, &CSetupOptionDlg::OnBnClickedCheckTransformCoordinate)
	ON_BN_CLICKED(IDC_CHECK_USING_SPINDLE_AIR_PURGE, &CSetupOptionDlg::OnBnClickedCheckUsingSpindleAirPurge)
	ON_WM_PAINT()
//	ON_BN_CLICKED(IDC_BUTTON_LOAD, &CSetupOptionDlg::OnBnClickedButtonLoad)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_FROM_FILE, &CSetupOptionDlg::OnBnClickedButtonLoadFromFile)
	ON_BN_CLICKED(IDC_CHECK_USING_OP_PANEL, &CSetupOptionDlg::OnBnClickedCheckUsingOpPanel)
	ON_BN_CLICKED(IDC_CHECK_USING_AIR_PRESSURE_LIMIT, &CSetupOptionDlg::OnBnClickedCheckUsingAirPressureLimit)
	ON_BN_CLICKED(IDC_CHECK_USING_LOGGING, &CSetupOptionDlg::OnBnClickedCheckUsingLogging)
	ON_BN_CLICKED(IDC_RADIO_TOOL_ERR_OCCURED_STOP, &CSetupOptionDlg::OnBnClickedRadioToolErrOccuredStop)
	ON_BN_CLICKED(IDC_RADIO_TOOL_ERR_RESTART_FROM_TOOL_CHANGE_LINE, &CSetupOptionDlg::OnBnClickedRadioToolErrRestartFromToolChangeLine)
	ON_BN_CLICKED(IDC_RADIO_TOOL_ERR_OCCURED_RESTART_FROM_BEGIN, &CSetupOptionDlg::OnBnClickedRadioToolErrOccuredRestartFromBegin)
	ON_BN_CLICKED(IDC_RADIO_TOOL_ERR_OCCURED_START_NEXT_NC_FILE, &CSetupOptionDlg::OnBnClickedRadioToolErrOccuredStartNextNcFile)
	ON_BN_CLICKED(IDC_RADIO_TOOL_ERR_OCCURED_USER_CONFIRM, &CSetupOptionDlg::OnBnClickedRadioToolErrOccuredUserConfirm)
	ON_BN_CLICKED(IDC_BUTTON_FLOW_SENSOR_START_TIMEOUT, &CSetupOptionDlg::OnBnClickedButtonFlowSensorStartTimeout)
	ON_BN_CLICKED(IDC_BUTTON_PURGE_AIR_HOLD_TIME, &CSetupOptionDlg::OnBnClickedButtonPurgeAirHoldTime)
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CSetupOptionDlg �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CSetupOptionDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialogListPage::PreTranslateMessage(pMsg);
}

BOOL CSetupOptionDlg::OnInitDialog()
{
	CDialogListPage::OnInitDialog();

	brhBkgnd_.CreateSolidBrush( pa::CLR_SETUP_OPTION );
	brhBackButton_.CreateSolidBrush( pa::CLR_BUTTON_BACK );

	//////////////////////////////////////////////////////////////////////////
	//
	fntMenuButton_.CreateFont(
		17, 0, 
		0, 0, FW_BOLD,
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );
	
	((CButton*)GetDlgItem(IDC_BUTTON_DOWNLOAD_TO_COLTROLLOR))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_SAVE))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_LOAD_FROM_FILE))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_CLOSE))->SetFont( &fntMenuButton_, TRUE );

	CRect recbutton;

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_DOWNLOAD_TO_COLTROLLOR), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_SAVE), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_LOAD_FROM_FILE), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_CLOSE), this, &recbutton, &CUIrectSO);

	fntCheckBox_.CreateFont(
		16, 0, 
		0, 0, FW_BOLD,
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	chkUsingBlockAutoLoader_.SetFont( &fntCheckBox_, TRUE );
	chkUsingOpPanel_.SetFont( &fntCheckBox_, TRUE );
// 	chkUsingCompleteMelody_.SetFont( &fntCheckBox_, TRUE );
// 	chkUsingErrorMelody_.SetFont( &fntCheckBox_, TRUE );
	chkUsingDetectBlockSensor_.SetFont( &fntCheckBox_, TRUE );
	chkUsingAirPressureLimit_.SetFont( &fntCheckBox_, TRUE );
	chkDemoMode_.SetFont( &fntCheckBox_, TRUE );
	chkUsingFlowSensor_.SetFont( &fntCheckBox_, TRUE );
	btnFlowSensorTimeout_.SetFont( &fntCheckBox_, TRUE );
	btnFlowSensorStartTimeout_.SetFont( &fntCheckBox_, TRUE );
	chkUsingSpindleAirPurge_.SetFont( &fntCheckBox_, TRUE );
	chkUsingLogging_.SetFont( &fntCheckBox_, TRUE );
	btnPurgeAirHoldTime_.SetFont( &fntCheckBox_, TRUE );
	((CStatic*)GetDlgItem(IDC_STATIC_BLOCK_GRIP_INTERVAL))->SetFont( &fntCheckBox_, TRUE );
	((CStatic*)GetDlgItem(IDC_STATIC_AIR_PRESSURE_INTERVAL))->SetFont( &fntCheckBox_, TRUE );
	
	((CStatic*)GetDlgItem(IDC_STATIC_BLOCK_GRIP_INTERVAL2))->SetFont( &fntCheckBox_, TRUE );
	((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28))->SetFont( &fntCheckBox_, TRUE );
	((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28_2))->SetFont( &fntCheckBox_, TRUE );
	((CButton*)GetDlgItem(IDC_STATIC_FLOW_SENSOR_TIMEOUT))->SetFont( &fntCheckBox_, TRUE );
	((CButton*)GetDlgItem(IDC_STATIC_PURGE_AIR_HOLD_TIME))->SetFont( &fntCheckBox_, TRUE );

	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_BLOCK_GRIP_INTERVAL), this, &recbutton, &CUIrectSO);
	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_AIR_PRESSURE_INTERVAL), this, &recbutton, &CUIrectSO);
	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_BLOCK_GRIP_INTERVAL2), this, &recbutton, &CUIrectSO);
	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_PURGE_AIR_HOLD_TIME), this,  &recbutton, &CUIrectSO);

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28_2), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_STATIC_FLOW_SENSOR_TIMEOUT), this, &recbutton, &CUIrectSO);

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_USING_LOGGING), this, &recbutton, &CUIrectSO);

	fntEditBox_.CreateFont(
		16, 0, 
		0, 0, FW_BOLD,
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	btnBlockGripInterval_.SetFont( &fntEditBox_, TRUE );
	btnAirPressureInterval_.SetFont( &fntEditBox_, TRUE );

	///

	((CStatic*)GetDlgItem(IDC_STATIC_TOOL_ERROR_MSG))->SetFont( &fntCheckBox_, TRUE );
	((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_STOP))->SetFont( &fntCheckBox_, TRUE );
	((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_RESTART_FROM_TOOL_CHANGE_LINE))->SetFont( &fntCheckBox_, TRUE );
	((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_RESTART_FROM_BEGIN))->SetFont( &fntCheckBox_, TRUE );
	((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_START_NEXT_NC_FILE))->SetFont( &fntCheckBox_, TRUE );
	((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_USER_CONFIRM))->SetFont( &fntCheckBox_, TRUE );

	/// 

	((CButton*)GetDlgItem(IDC_STATIC_NCFILE_LOADING))->SetFont( &fntCheckBox_, TRUE );
	((CButton*)GetDlgItem(IDC_CHECK_INVALID_NC_CODE))->SetFont( &fntCheckBox_, TRUE );
	((CButton*)GetDlgItem(IDC_CHECK_NC_FILE_TAG))->SetFont( &fntCheckBox_, TRUE );
	((CButton*)GetDlgItem(IDC_CHECK_TRANSFORM_COORDINATE))->SetFont( &fntCheckBox_, TRUE );

	//////////////////////////////////////////////////////////////////////////

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_STATIC_TOOL_ERROR_MSG), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_STOP), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_RESTART_FROM_TOOL_CHANGE_LINE), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_RESTART_FROM_BEGIN), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_START_NEXT_NC_FILE), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_USER_CONFIRM), this, &recbutton, &CUIrectSO);

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_STATIC_NCFILE_LOADING), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_INVALID_NC_CODE), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_NC_FILE_TAG), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_TRANSFORM_COORDINATE), this, &recbutton, &CUIrectSO);

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON4), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON6), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON8), this, &recbutton, &CUIrectSO);

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_USING_FLOW_SENSOR), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_USING_DETECT_BLOCK_SENSOR), this, &recbutton, &CUIrectSO);

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_PURGE_AIR_HOLD_TIME), this, &recbutton, &CUIrectSO);

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_AIR_PRESSURE_INTERVAL), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_BLOCK_GRIP_INTERVAL), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_FLOW_SENSOR_TIMEOUT), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_FLOW_SENSOR_START_TIMEOUT), this, &recbutton, &CUIrectSO);

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_USING_SPINDLE_AIR_PURGE), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_USING_AIR_PRESSURE_LIMIT), this, &recbutton, &CUIrectSO);
	//hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_USING_COMPLETE_MELODY), this, &recbutton, &CUIrectSO);
	//hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_USING_ERROR_MELODY), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_USING_OP_PANEL), this, &recbutton, &CUIrectSO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_USING_BLOCK_AUTOLOADER), this, &recbutton, &CUIrectSO);

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_DEMO_MODE), this, &recbutton, &CUIrectSO);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CSetupOptionDlg::OnDestroy()
{
	brhBkgnd_.DeleteObject();
	brhBackButton_.DeleteObject();

	fntMenuButton_.DeleteObject();
	fntCheckBox_.DeleteObject();
	fntEditBox_.DeleteObject();

	if( pCanvasCE_ ) {
		delete pCanvasCE_;
		pCanvasCE_ = NULL;
	}

// 	if( pTitleBarWnd_ ) {
// 		pTitleBarWnd_->DestroyWindow();
// 		delete pTitleBarWnd_;
// 		pTitleBarWnd_ = NULL;
// 	}

	CDialogListPage::OnDestroy();
}

HBRUSH CSetupOptionDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogListPage::OnCtlColor(pDC, pWnd, nCtlColor);

	pDC->SetBkMode( TRANSPARENT );

	if( nCtlColor == 4 ) {
		hbr = (HBRUSH)brhBkgnd_;
	}
	else {
		int nID = pWnd->GetDlgCtrlID();
		switch( nID )
		{
		case IDC_CHECK_USING_BLOCK_AUTOLOADER:
		case IDC_CHECK_USING_OP_PANEL:
		case IDC_CHECK_USING_COMPLETE_MELODY:
		case IDC_CHECK_USING_ERROR_MELODY:
		case IDC_CHECK_USING_DETECT_BLOCK_SENSOR:
		case IDC_CHECK_USING_AIR_PRESSURE_LIMIT:
		case IDC_CHECK_DEMO_MODE:
		case IDC_STATIC_BLOCK_GRIP_INTERVAL:
		case IDC_STATIC_AIR_PRESSURE_INTERVAL:
		case IDC_BUTTON_BLOCK_GRIP_INTERVAL:
		case IDC_BUTTON_AIR_PRESSURE_INTERVAL:
		case IDC_STATIC_BLOCK_GRIP_INTERVAL2:
		case IDC_RADIO_SELECT_OPER_M28:
		case IDC_RADIO_SELECT_OPER_M28_2:
		case IDC_STATIC_TOOL_ERROR_MSG:
		case IDC_RADIO_TOOL_ERR_OCCURED_STOP:
		case IDC_RADIO_TOOL_ERR_RESTART_FROM_TOOL_CHANGE_LINE:
		case IDC_RADIO_TOOL_ERR_OCCURED_RESTART_FROM_BEGIN:
		case IDC_RADIO_TOOL_ERR_OCCURED_START_NEXT_NC_FILE:
		case IDC_RADIO_TOOL_ERR_OCCURED_USER_CONFIRM:
		case IDC_CHECK_USING_FLOW_SENSOR:
		case IDC_STATIC_FLOW_SENSOR_TIMEOUT:
		case IDC_BUTTON_FLOW_SENSOR_TIMEOUT:
		case IDC_STATIC_NCFILE_LOADING:
		case IDC_CHECK_INVALID_NC_CODE:
		case IDC_CHECK_NC_FILE_TAG:
		case IDC_CHECK_TRANSFORM_COORDINATE:
		case IDC_CHECK_USING_SPINDLE_AIR_PURGE:
		case IDC_CHECK_USING_LOGGING:
		case IDC_STATIC_PURGE_AIR_HOLD_TIME:
			hbr = (HBRUSH)brhBkgnd_;
			break;
		case IDC_BUTTON_CLOSE:
			hbr = (HBRUSH)brhBackButton_;
			break;
		}
	}

	return hbr;
}

void CSetupOptionDlg::OnBnClickedButtonClose()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("back button click") );
	//////////////////////////////////////////////////////////////////////////
	ASSERT( pParentWnd_ );
	pParentWnd_->PostMessage( WM_SETUP, (WPARAM)SETUP_BACK, (LPARAM)0 );
}

//////////////////////////////////////////////////////////////////////////

// void CSetupOptionDlg::OnBnClickedButtonSave()
// {
// 	CString strTemp;
// 	int		nTemp;
// 	DWORD	dwTime;
// 	CString strLog, strMsg;
// 
// 	strMsg.Format( _T("Do you want to save system parameter ?") );
// 	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
// 	CMsgDlg::EN_RET ret = CMsgDlgThread::GetInstance()->Wait();
// 	if( ret == CMsgDlg::RET_CANCEL ) {
// 		updateState();
// 		return ;
// 	}
// 
// 	strTemp.Format( _T("Wait for save data...") );
// 	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strTemp );
// 
// 	//////////////////////////////////////////////////////////////////////////
// 	// log 
// 	writeLog( _T("save button click") );
// 
// 	//////////////////////////////////////////////////////////////////////////
// 	// log
// 	strLog.Format( _T("using block autoloader is %s"), (chkUsingBlockAutoLoader_.GetCheck() == 0) ? _T("FALSE") : _T("TRUE") );
// 	P_LOG->WriteLog_EXT( strLog );
// 	pa::PAutoLoader->SetUsingAutoLoader( chkUsingBlockAutoLoader_.GetCheck() );
// 	//////////////////////////////////////////////////////////////////////////
// 	// log
// 	strLog.Format( _T("using oppanel is %s"), (chkUsingOpPanel_.GetCheck() == 0) ? _T("FALSE") : _T("TRUE") );
// 	P_LOG->WriteLog_EXT( strLog );
// 	pa::PSWConfig->GetConfigData()->bUsingOpPanel	= chkUsingOpPanel_.GetCheck();
// 	//////////////////////////////////////////////////////////////////////////
// 	// log
// 	strLog.Format( _T("using detect block is %s"), (chkUsingDetectBlockSensor_.GetCheck() == 0) ? _T("FALSE") : _T("TRUE") );
// 	P_LOG->WriteLog_EXT( strLog );
// 	pa::PSWConfig->GetConfigData()->bUsingDetectBlock	= chkUsingDetectBlockSensor_.GetCheck();
// 	//////////////////////////////////////////////////////////////////////////
// 	// log
// 	strLog.Format( _T("using air limit sensor is %s"), (chkUsingAirPressureLimit_.GetCheck() == 0) ? _T("FALSE") : _T("TRUE") );
// 	P_LOG->WriteLog_EXT( strLog );
// 	pa::PSWConfig->GetConfigData()->bUsingAirLimitSensor = chkUsingAirPressureLimit_.GetCheck();
// 	//////////////////////////////////////////////////////////////////////////
// 	// log
// 	strLog.Format( _T("using demo mode is %s"), (chkDemoMode_.GetCheck() == 0) ? _T("FALSE") : _T("TRUE") );
// 	P_LOG->WriteLog_EXT( strLog );
// 	pa::PPAStatus->GetThreadState()->bIsDemoMode_ = chkDemoMode_.GetCheck();
// 	//////////////////////////////////////////////////////////////////////////
// 	// log 
// 	strLog.Format( _T("using flow sensor is %s"), (chkUsingFlowSensor_.GetCheck() == 0) ? _T("FALSE") : _T("TRUE") );
// 	P_LOG->WriteLog_EXT( strLog );
// 	pa::PSWConfig->GetConfigData()->bUsingFlowSensor = chkUsingFlowSensor_.GetCheck();
// 	btnFlowSensorTimeout_.GetWindowText( strTemp );
// 	nTemp = (int)_ttoi( strTemp );
// 	strLog.Format( _T("flow sensor timeout is %d"), nTemp );
// 	pa::PSWConfig->GetConfigData()->nFlowSensorTimeout = nTemp;
// 	//////////////////////////////////////////////////////////////////////////
// 	// log
// 	strLog.Format( _T("check invalid nc code is %s"), (chkInvalidNcCode_.GetCheck() == 0) ? _T("FALSE") : _T("TRUE") );
// 	P_LOG->WriteLog_EXT( strLog );
// 	pa::PSWConfig->GetConfigData()->bCheckInvalidNcCode = chkInvalidNcCode_.GetCheck();
// 	strLog.Format( _T("check nc file tag is %s"), (chkNcFileTag_.GetCheck() == 0) ? _T("FALSE") : _T("TRUE") );
// 	P_LOG->WriteLog_EXT( strLog );
// 	pa::PSWConfig->GetConfigData()->bCheckNcFileTag = chkNcFileTag_.GetCheck();
// 	strLog.Format( _T("transform coordinate is %s"), (chkTransformCoord_.GetCheck() == 0) ? _T("FALSE") : _T("TRUE") );
// 	P_LOG->WriteLog_EXT( strLog );
// 	pa::PSWConfig->GetConfigData()->bTransformNcFile = chkTransformCoord_.GetCheck();
// 
// 	//
// 	btnBlockGripInterval_.GetWindowText( strTemp );
// 	nTemp = (int)_ttoi( (LPCTSTR)strTemp );
// 	pa::PSWConfig->GetConfigData()->nDelayGripBlock = nTemp;
// 	// log
// 	strLog.Format( _T("block grip interval is %d"), nTemp );
// 	P_LOG->WriteLog_EXT( strLog );
// 
// 	// 
// 	btnAirPressureInterval_.GetWindowText( strTemp );
// 	nTemp = (int)_ttoi( (LPCTSTR)strTemp );
// 	pa::PSWConfig->GetConfigData()->nAirLimitInterval = nTemp;
// 	// log
// 	strLog.Format( _T("air limit interval is %d"), nTemp );
// 	P_LOG->WriteLog_EXT( strLog );
// 
// 	UpdateData( TRUE );
// 	pa::PSWConfig->GetConfigData()->nToolErrorOccure_HandlingCode = nToolErrOccureHandingCode_;
// 	// log
// 	strLog.Format( _T("error occure handling code is %d"), nToolErrOccureHandingCode_ );
// 	P_LOG->WriteLog_EXT( strLog );
// 
// 	//
// 	if( chkUsingLogging_.GetCheck() == TRUE ) {
// 		pa::PSWConfig->GetConfigData()->nEnableOperationLog = 1;
// 		pa::PSWConfig->GetConfigData()->nEnableIpcCommLog	= 1;
// 		pa::PSWConfig->GetConfigData()->nEnableThreadModeLog= 1;
// 		pa::PSWConfig->GetConfigData()->nEnableOpPenalLog	= 1;
// 		pa::PSWConfig->GetConfigData()->nEnableExtLog		= 1;
// 	} else {
// 		pa::PSWConfig->GetConfigData()->nEnableOperationLog = 0;
// 		pa::PSWConfig->GetConfigData()->nEnableIpcCommLog	= 0;
// 		pa::PSWConfig->GetConfigData()->nEnableThreadModeLog= 0;
// 		pa::PSWConfig->GetConfigData()->nEnableOpPenalLog	= 0;
// 		pa::PSWConfig->GetConfigData()->nEnableExtLog		= 0;
// 	}
// 	// log 
// 	strLog.Format( _T("enable logging is %d"), chkUsingLogging_.GetCheck() );
// 	P_LOG->WriteLog_EXT( strLog );
// 
// 	//////////////////////////////////////////////////////////////////////////
// 	// AutoLoader �����͸� �������� �ʴ´�
// 	/*
// 	pa::PPAStatus->SetIpcCommandComplete( FALSE );
// 	PPNC_IPC_CLIENT->SaveAutoLoaderConfig();
// 	Sleep( 100 );
// 	dwTime = GetTickCount();
// 	while( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == FALSE ) {
// 		if( ( GetTickCount() - dwTime ) > 30000 ) {
// 			// ���� 
// 			strTemp.Format( _T("Timeout error") );
// 			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strTemp );
// 			CMsgDlgThread::GetInstance()->Wait();
// 			return ;
// 		}
// 		Sleep( 100 );
// 	}
// 	*/
// 	//////////////////////////////////////////////////////////////////////////
// 
// 	//////////////////////////////////////////////////////////////////////////
// 	//
// 	pa::PPAStatus->SetIpcCommandComplete( FALSE );
// 	PPNC_IPC_CLIENT->SaveConfig();
// 	Sleep( 100 );
// 	dwTime = GetTickCount();
// 	while( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == FALSE ) {
// 		if( (GetTickCount() - dwTime ) > 30000 ) {
// 			// ���� 
// 			strTemp.Format( _T("Timeout error") );
// 			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strTemp );
// 			CMsgDlgThread::GetInstance()->Wait();
// 			return ;
// 		}
// 		Sleep( 100 );
// 	}
// 	// ���� �Ϸ� �޽���
// 	strMsg.Format( _T("Save Complete !") );
// 	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_INFO, strMsg );
// 	//////////////////////////////////////////////////////////////////////////
// }

void CSetupOptionDlg::OnBnClickedButtonSave()
{
	CString strMsg, strErrMsg;

	strMsg.Format( _T("do you want to save sw-config data in \"swconfig.ini\" file ?") );

	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
	CMsgDlg::EN_RET ret = CMsgDlgThread::GetInstance()->Wait();
	if( ret == CMsgDlg::RET_CANCEL ) {
		return ;
	}

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("save sw config data to file button click") );
	//////////////////////////////////////////////////////////////////////////

	strMsg.Format( _T("wait for save sw config data") );
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

	// Coordinate Offset 
	if( save_sw_config_data( strErrMsg ) ) {
		updateState();	// ������ -> ��Ʈ��
	}
	else {
		// ERROR
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strErrMsg );
		CMsgDlgThread::GetInstance()->Wait();
		return ;
	}

	//////////////////////////////////////////////////////////////////////////
	// 2020.03.19 �߰� 
	//////////////////////////////////////////////////////////////////////////
	// 2. Air Limit Data �� ����⿡ ���� 
	pa::PPAStatus->SetIpcCommandComplete( FALSE );
	PPNC_IPC_CLIENT->SendSALF();
	Sleep( 100 );
	DWORD dwTime = GetTickCount();
	while( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == FALSE ) {
		if( ( GetTickCount() - dwTime ) > 5*1000 ) {
			// ���� 
			strMsg.Format( _T("Timeout error: send air limit parameter data") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
			return ;
		}
		Sleep( 100 );
	}
	// 3. Water ���� �����͸� ����⿡ ���� 
	pa::PPAStatus->SetIpcCommandComplete( FALSE );
	PPNC_IPC_CLIENT->SendSFSF();
	Sleep( 100 );
	dwTime = GetTickCount();
	//	while( pa::PPAStatus->GetThreadState()->bIsClientConnected_ == FALSE ) {
	while( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == FALSE ) {
		if( ( GetTickCount() - dwTime ) > 5*1000 ) {
			// ���� 
			strMsg.Format( _T("Timeout error: send flow sensor parameter data") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
			return ;
		}
		Sleep( 100 );
	}
	// 4. Purge air hold time �����͸� ����⿡ ���� 
	pa::PPAStatus->SetIpcCommandComplete( FALSE );
	PPNC_IPC_CLIENT->SendWPAR();
	Sleep( 100 );
	dwTime = GetTickCount();
	//	while( pa::PPAStatus->GetThreadState()->bIsClientConnected_ == FALSE ) {
	while( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == FALSE ) {
		if( ( GetTickCount() - dwTime ) > 5*1000 ) {
			// ���� 
			strMsg.Format( _T("Timeout error: send purge air hold time data") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
			return ;
		}
		Sleep( 100 );
	}
	
	//
	CMsgDlgThread::GetInstance()->Hide();
}

BOOL CSetupOptionDlg::save_sw_config_data( CString& strErrMsg )
{
	CString		strKeyName, strValueName, strTemp;
	CCEIniFile	hIniFile;
	int		nTemp;

	if( !hIniFile.Open( INI_SW_CONFIG_PATH ) ) {
		strErrMsg.Format( _T("ERROR : config file open fail (CSetupOptionDlg::save_sw_config_data()") );
		return FALSE;
	}

	UpdateData( TRUE );

	strKeyName.Format( _T("SWConfig") );

	// 1. Using. AutoLoader 
//	nTemp = chkUsingBlockAutoLoader_.GetCheck();

	// 1. Using. External OpPanel 
	nTemp = chkUsingOpPanel_.GetCheck();
	hIniFile.SetValue( strKeyName, _T("Using_OpPanel"), (int)nTemp );
	pa::PSWConfig->GetConfigData()->bUsingOpPanel = nTemp == 0 ? FALSE : TRUE;

	// 2. Using. Air Pressure Limit 
	nTemp = chkUsingAirPressureLimit_.GetCheck();
	hIniFile.SetValue( strKeyName, _T("Using_AirPressureLimit"), (int)nTemp );
	pa::PSWConfig->GetConfigData()->bUsingAirLimitSensor = nTemp == 0 ? FALSE : TRUE;

	// 5. Using. Auto Adjust Spindle Air Blow 
	nTemp = chkUsingSpindleAirPurge_.GetCheck();
	hIniFile.SetValue( strKeyName, _T("Using_SpindleAirPurge"), (int)nTemp );
	pa::PSWConfig->GetConfigData()->bUsingSpindleAirPurge = nTemp == 0 ? FALSE : TRUE;

	// 6. Low Air Pressure Interval 
	btnAirPressureInterval_.GetWindowText( strTemp );
	nTemp = _ttoi( strTemp );
	hIniFile.SetValue( strKeyName, _T("AirPressureInterval"), (int)nTemp );
	pa::PSWConfig->GetConfigData()->nAirLimitInterval = nTemp;

	// 7. Using. Detect Block Sensor 
	nTemp = chkUsingDetectBlockSensor_.GetCheck();
	hIniFile.SetValue( strKeyName, _T("Using_DetectBlockSensor"), (int)nTemp );
	pa::PSWConfig->GetConfigData()->bUsingDetectBlock = nTemp == 0 ? FALSE : TRUE;

	// 8. Block Grip Interval 
	btnBlockGripInterval_.GetWindowText( strTemp );
	nTemp = _ttoi( strTemp );
	hIniFile.SetValue( strKeyName, _T("BlockGripInterval"), (int)nTemp );
	pa::PSWConfig->GetConfigData()->nDelayGripBlock = nTemp;

	// 9. Using. Flow Sensor 
	nTemp = chkUsingFlowSensor_.GetCheck();
	hIniFile.SetValue( strKeyName, _T("Using_FlwoSensor"), (int)nTemp );
	pa::PSWConfig->GetConfigData()->bUsingFlowSensor = nTemp == 0 ? FALSE : TRUE;

	// 10. Flow Sensor Timeout 
	btnFlowSensorTimeout_.GetWindowText( strTemp );
	nTemp = _ttoi( strTemp );
	hIniFile.SetValue( strKeyName, _T("FlowSensorTimeout"), (int)nTemp );
	pa::PSWConfig->GetConfigData()->nFlowSensorTimeout = nTemp;

	btnFlowSensorStartTimeout_.GetWindowText( strTemp );
	nTemp = _ttoi( strTemp );
	hIniFile.SetValue( strKeyName, _T("FlowSensorStartTimeout"), (int)nTemp );
	pa::PSWConfig->GetConfigData()->nFlowSensorStartTimeout = nTemp;

	btnPurgeAirHoldTime_.GetWindowText( strTemp );
	nTemp = _ttoi( strTemp );
	hIniFile.SetValue( strKeyName, _T("PurgeAirHoldTime"), (int)nTemp );
	pa::PSWConfig->GetConfigData()->nPurgeAirHoldTime = nTemp;

	// 11. M28 Operation (WET / DRY)
	hIniFile.SetValue( strKeyName, _T("M28_Oprtation"), (int)nSelectOperationM28_ );
	pa::PSWConfig->GetConfigData()->nSelectM28Operation = nSelectOperationM28_;

	// 12. Tool Error Occure...
	hIniFile.SetValue( strKeyName, _T("ToolErrorOccure"), (int)nToolErrOccureHandingCode_ );
	pa::PSWConfig->GetConfigData()->nToolErrorOccure_HandlingCode = nToolErrOccureHandingCode_;

	// 13. When NC-File Loading...
	nTemp = chkInvalidNcCode_.GetCheck();
	hIniFile.SetValue( strKeyName, _T("Check_InvalidNcCode"), (int)nTemp );
	pa::PSWConfig->GetConfigData()->bCheckInvalidNcCode = nTemp == 0 ? FALSE : TRUE;

	nTemp = chkNcFileTag_.GetCheck();
	hIniFile.SetValue( strKeyName, _T("Check_NcFileTag"), (int)nTemp );
	pa::PSWConfig->GetConfigData()->bCheckNcFileTag = nTemp == 0 ? FALSE : TRUE;

	nTemp = chkTransformCoord_.GetCheck();
	hIniFile.SetValue( strKeyName, _T("Check_TransformCoord"), (int)nTemp );
	pa::PSWConfig->GetConfigData()->bTransformNcFile = nTemp == 0 ? FALSE : TRUE;

	nTemp = chkUsingLogging_.GetCheck();
	hIniFile.SetValue( strKeyName, _T("Using_Logging"), (int)nTemp );
	pa::PSWConfig->GetConfigData()->nEnableOperationLog	= nTemp;				// Log option
	pa::PSWConfig->GetConfigData()->nEnableIpcCommLog	= nTemp;				// Log option
	pa::PSWConfig->GetConfigData()->nEnableThreadModeLog= nTemp;				// Log option
	pa::PSWConfig->GetConfigData()->nEnableOpPenalLog	= nTemp;				// Log option
	pa::PSWConfig->GetConfigData()->nEnableExtLog		= nTemp;	
	pa::PSWConfig->GetConfigData()->nEnableErrLog		= nTemp;

	//////////////////////////////////////////////////////////////////////////
	// 1. Using. Autoloader 
	strKeyName.Format( _T("AutoLoader") );
	nTemp = chkUsingBlockAutoLoader_.GetCheck();
	hIniFile.SetValue( strKeyName, _T("Using_AutoLoader"), (int)nTemp );
	if( pa::PAutoLoader ) {
		pa::PAutoLoader->pAutoLoaderConfig_->bUsingAutoLoader = nTemp==0 ? FALSE : TRUE;
	}

	//
	hIniFile.Close();

	//////////////////////////////////////////////////////////////////////////
	// 2017.03.24
	//	M28 Operation�� �ٿ�ε� �Ѵ� 
	DWORD dwTime = GetTickCount();
	pa::PPAStatus->SetIpcCommandComplete( FALSE );
	PPNC_IPC_CLIENT->DownloadOperationM28();
	Sleep( 500 );
	while( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == FALSE )  
	{
		if( GetTickCount() - dwTime > 3000 ) {
			return FALSE;
		}
		Sleep( 100 );
	}
	//////////////////////////////////////////////////////////////////////////

	return TRUE;
}

void CSetupOptionDlg::OnBnClickedButtonLoadFromFile()
{
	CString strMsg, strErrMsg;

	strMsg.Format( _T("do you want to load sw-config data from \"swconfig.ini\" file ?") );

	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
	CMsgDlg::EN_RET ret = CMsgDlgThread::GetInstance()->Wait();
	if( ret == CMsgDlg::RET_CANCEL ) {
		return ;
	}

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("loading sw config data from file button click") );
	//////////////////////////////////////////////////////////////////////////

	strMsg.Format( _T("wait for loading sw-config data") );
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

	// Coordinate Offset 
	if( load_sw_config_data( strErrMsg ) ) {
		updateState();
	} else {
		// ERROR
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strErrMsg );
		CMsgDlgThread::GetInstance()->Wait();
		return ;
	}

	CMsgDlgThread::GetInstance()->Hide();
}

BOOL CSetupOptionDlg::load_sw_config_data( CString& strErrMsg )
{
	CString		strKeyName, strValueName, strTemp;
	CCEIniFile	hIniFile;
	int			nTemp;

	if( !hIniFile.Open( INI_SW_CONFIG_PATH ) ) {
		strErrMsg.Format( _T("ERROR : config file open fail (CSetupOptionDlg::load_sw_config_data()") );
		return FALSE;
	}

	UpdateData( TRUE );

	strKeyName.Format( _T("SWConfig") );

	// 1. Using. External OpPanel 
	hIniFile.GetValue( strKeyName, _T("Using_OpPanel"), (int*)&nTemp );
	chkUsingOpPanel_.SetCheck( nTemp );
	pa::PSWConfig->GetConfigData()->bUsingOpPanel = nTemp==0 ? FALSE : TRUE;

	// 4. Using. Air Pressure Limit 
	hIniFile.GetValue( strKeyName, _T("Using_AirPressureLimit"), (int*)&nTemp );
	chkUsingAirPressureLimit_.SetCheck( nTemp );
	pa::PSWConfig->GetConfigData()->bUsingAirLimitSensor = nTemp==0 ? FALSE : TRUE;

	// 5. Using. Auto Adjust Spindle Air Blow 
	hIniFile.GetValue( strKeyName, _T("Using_SpindleAirPurge"), (int*)&nTemp );
	chkUsingSpindleAirPurge_.SetCheck( nTemp );
	pa::PSWConfig->GetConfigData()->bUsingSpindleAirPurge = nTemp==0 ? FALSE : TRUE;

	// 6. Low Air Pressure Interval 
	hIniFile.GetValue( strKeyName, _T("AirPressureInterval"), (int*)&nTemp );
	strTemp.Format( _T("%d"), nTemp );
	btnAirPressureInterval_.SetWindowText( strTemp );
	pa::PSWConfig->GetConfigData()->nAirLimitInterval = nTemp;

	// 7. Using. Detect Block Sensor 
	hIniFile.GetValue( strKeyName, _T("Using_DetectBlockSensor"), (int*)&nTemp );
	chkUsingDetectBlockSensor_.SetCheck( nTemp );
	pa::PSWConfig->GetConfigData()->bUsingDetectBlock = nTemp==0 ? FALSE : TRUE;

	// 8. Block Grip Interval 
	hIniFile.GetValue( strKeyName, _T("BlockGripInterval"), (int*)&nTemp );
	strTemp.Format( _T("%d"), nTemp );
	btnBlockGripInterval_.SetWindowText( strTemp );
	pa::PSWConfig->GetConfigData()->nDelayGripBlock = nTemp;

	// 9. Using. Flow Sensor 
	hIniFile.GetValue( strKeyName, _T("Using_FlwoSensor"), (int*)&nTemp );
	chkUsingFlowSensor_.SetCheck( nTemp );
	pa::PSWConfig->GetConfigData()->bUsingFlowSensor = nTemp==0 ? FALSE : TRUE;

	// 10. Flow Sensor Timeout 
	hIniFile.GetValue( strKeyName, _T("FlowSensorTimeout"), (int*)&nTemp );
	strTemp.Format( _T("%d"), nTemp );
	btnFlowSensorTimeout_.SetWindowText( strTemp );
	pa::PSWConfig->GetConfigData()->nFlowSensorTimeout = nTemp;

	hIniFile.GetValue( strKeyName, _T("FlowSensorStartTimeout"), (int*)&nTemp );
	strTemp.Format( _T("%d"), nTemp );
	btnFlowSensorStartTimeout_.SetWindowText( strTemp );
	pa::PSWConfig->GetConfigData()->nFlowSensorStartTimeout = nTemp;

	// xx. PurgeAirHoldTime 
	hIniFile.GetValue( strKeyName, _T("PurgeAirHoldTime"), (int*)&nTemp );
	strTemp.Format( _T("%d"), nTemp );
	btnPurgeAirHoldTime_.SetWindowText( strTemp );
	pa::PSWConfig->GetConfigData()->nPurgeAirHoldTime = nTemp;

	// 11. M28 Operation (WET / DRY)
	hIniFile.GetValue( strKeyName, _T("M28_Oprtation"), (int*)&nTemp );
	nSelectOperationM28_ = nTemp;
	pa::PSWConfig->GetConfigData()->nSelectM28Operation = nTemp;

	// 12. Tool Error Occure...
	hIniFile.GetValue( strKeyName, _T("ToolErrorOccure"), (int*)&nTemp ); 
	nToolErrOccureHandingCode_ = nTemp;
	pa::PSWConfig->GetConfigData()->nToolErrorOccure_HandlingCode = nTemp;

	// 13. When NC-File Loading...
	hIniFile.GetValue( strKeyName, _T("Check_InvalidNcCode"), (int*)&nTemp );
	chkInvalidNcCode_.SetCheck( nTemp );
	pa::PSWConfig->GetConfigData()->bCheckInvalidNcCode = nTemp==0 ? FALSE : TRUE;

	hIniFile.GetValue( strKeyName, _T("Check_NcFileTag"), (int*)&nTemp );
	chkNcFileTag_.SetCheck( nTemp );
	pa::PSWConfig->GetConfigData()->bCheckNcFileTag = nTemp==0 ? FALSE : TRUE;

	hIniFile.GetValue( strKeyName, _T("Check_TransformCoord"), (int*)&nTemp );
	chkTransformCoord_.SetCheck( nTemp );
	pa::PSWConfig->GetConfigData()->bTransformNcFile = nTemp==0 ? FALSE : TRUE;

	// 
	hIniFile.GetValue( strKeyName, _T("Using_Logging"), (int*)&nTemp );
	chkUsingLogging_.SetCheck( nTemp );
	pa::PSWConfig->GetConfigData()->nEnableOperationLog	= nTemp;				// Log option
	pa::PSWConfig->GetConfigData()->nEnableIpcCommLog	= nTemp;				// Log option
	pa::PSWConfig->GetConfigData()->nEnableThreadModeLog= nTemp;				// Log option
	pa::PSWConfig->GetConfigData()->nEnableOpPenalLog	= nTemp;				// Log option
	pa::PSWConfig->GetConfigData()->nEnableExtLog		= nTemp;				// Log option

	//////////////////////////////////////////////////////////////////////////
	// 1. Using. Autoloader 
	strKeyName.Format( _T("AutoLoader") );
	hIniFile.GetValue( strKeyName, _T("Using_AutoLoader"), (int*)&nTemp );
	chkUsingBlockAutoLoader_.SetCheck( nTemp );

	//
	hIniFile.Close();

	return TRUE;
}

void CSetupOptionDlg::OnBnClickedButtonBlockGripInterval()
{
	CNumericInputDlg dlg;
	CString	strTemp;

	btnBlockGripInterval_.GetWindowText( strTemp );

	dlg.SetIsFloatType( FALSE );
	dlg.SetPrevNumber( (int)_ttoi((LPCTSTR)strTemp) );
	dlg.SetProperty( CNumericInputDlg::PROPERTY_CALC_BUTTON );

	if( dlg.DoModal() == IDOK ) 
	{
		int nVal = (int)_ttoi( (LPCTSTR)dlg.GetNumber() );
		CString strTemp;
		strTemp.Format( _T("%d"), nVal );
		btnBlockGripInterval_.SetWindowText( strTemp );
	}
}

void CSetupOptionDlg::OnBnClickedButtonAirPressureInterval()
{
	CNumericInputDlg dlg;
	CString strTemp;

	btnAirPressureInterval_.GetWindowText( strTemp );

	dlg.SetIsFloatType( FALSE );
	dlg.SetPrevNumber( (int)_ttoi( (LPCTSTR)strTemp ) );
	dlg.SetProperty( CNumericInputDlg::PROPERTY_CALC_BUTTON );

	if( dlg.DoModal() == IDOK ) 
	{
		int nVal = (int)_ttoi( (LPCTSTR)dlg.GetNumber() );
		CString strTemp;
		strTemp.Format( _T("%d"), nVal );
		btnAirPressureInterval_.SetWindowText( strTemp );
	}
}

void CSetupOptionDlg::OnBnClickedCheckDemoMode()
{
	BOOL b = (BOOL)( chkDemoMode_.GetCheck() == 0 ? FALSE : TRUE ); 

	pa::PPAStatus->GetThreadState()->bIsDemoMode_ = b;
}

void CSetupOptionDlg::OnTimer(UINT_PTR nIDEvent)
{
	KillTimer( 1 );

	updateControlState();

	updateState_MenuButton();

	if( IsWindowVisible() == TRUE ) {
		SetTimer( 1, 200, NULL );
	}

	CDialogListPage::OnTimer(nIDEvent);
}

// stop ��尡 �ƴ� ���, ��� �׸��� disable ��Ų�� 
void CSetupOptionDlg::updateControlState()
{
	static int PREV_STATE = -1;
	int	curr_state = ( pa::PPAStatus->GetRunMode() == pa::RUNMODE_STOP ) ? 1 : 0;

	//////////////////////////////////////////////////////////////////////////
	// 2017.07.25. AirPressureLimit_ �ɼ��� �׻� Disable ��Ų�� 
// 	if( chkUsingSpindleAirPurge_.IsWindowEnabled() == TRUE ) {
// 		chkUsingSpindleAirPurge_.EnableWindow( FALSE );
// 	}
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	//
//	if( pa::USER_MODE < pa::USER_MODE_MGR )
	if( pa::GET_CURRENT_USERMODE() < pa::USER_MODE_MGR )
	{
		// ��� ��Ʈ�� disable 
		chkUsingBlockAutoLoader_.EnableWindow( FALSE );
		chkUsingOpPanel_.EnableWindow( FALSE );
		chkUsingDetectBlockSensor_.EnableWindow( FALSE );
		btnBlockGripInterval_.EnableWindow( FALSE );
		chkUsingFlowSensor_.EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_FLOW_SENSOR_TIMEOUT))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28_2))->EnableWindow( FALSE );
		chkUsingAirPressureLimit_.EnableWindow( FALSE );
		chkUsingOpPanel_.EnableWindow( FALSE );
		btnAirPressureInterval_.EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_SAVE))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_LOAD_FROM_FILE))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_STOP))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_RESTART_FROM_TOOL_CHANGE_LINE))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_RESTART_FROM_BEGIN))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_START_NEXT_NC_FILE))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_USER_CONFIRM))->EnableWindow( FALSE );
//		chkUsingSpindleAirPurge_.EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_CHECK_INVALID_NC_CODE))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_CHECK_NC_FILE_TAG))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_CHECK_TRANSFORM_COORDINATE))->EnableWindow( FALSE );
		chkDemoMode_.EnableWindow( FALSE );
		chkUsingFlowSensor_.EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_FLOW_SENSOR_TIMEOUT))->EnableWindow( FALSE );
		((CStatic*)GetDlgItem(IDC_STATIC_FLOW_SENSOR_TIMEOUT))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_CHECK_USING_LOGGING))->EnableWindow( FALSE );
		
		btnFlowSensorStartTimeout_.EnableWindow(FALSE);

		((CButton*)GetDlgItem(IDC_CHECK_USING_SPINDLE_AIR_PURGE))->EnableWindow(FALSE);
		((CStatic*)GetDlgItem(IDC_STATIC_PURGE_AIR_HOLD_TIME))->EnableWindow(FALSE);
		btnPurgeAirHoldTime_.EnableWindow(FALSE);

		PREV_STATE = -1;
		return ;
	}
	//////////////////////////////////////////////////////////////////////////
//	if( PREV_STATE != curr_state ) 
	else
	{
		PREV_STATE = curr_state;

#ifdef _PA_G2400_
		chkUsingBlockAutoLoader_.EnableWindow( curr_state );
		chkUsingOpPanel_.EnableWindow( curr_state );
		chkUsingDetectBlockSensor_.EnableWindow( curr_state );
		btnBlockGripInterval_.EnableWindow( curr_state );
		chkUsingFlowSensor_.EnableWindow( curr_state );
		((CButton*)GetDlgItem(IDC_BUTTON_FLOW_SENSOR_TIMEOUT))->EnableWindow( curr_state );
		((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28))->EnableWindow( curr_state );
		((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28_2))->EnableWindow( curr_state );
#endif 
#ifdef _USE_AUTOLOADER_ //_PA_G1600_
// 		// 2017.06.22 bychul2. 
// 		switch( pa::PSWConfig->GetConfigData()->nModelID )
// 		{
// 		case 0:	// DS200-5Z
// 		case 1: // DS200-4W
// 		case 2:	// DS200-4WA
// 		case 3:	// DS200-4WAS
// 		case 6:	// DM200-5M
// 		default:
// 			chkUsingBlockAutoLoader_.EnableWindow( FALSE );
// 			chkUsingDetectBlockSensor_.EnableWindow( FALSE );
// 			break;
// 		case 4:	// DM200-5P
// 		case 5:	// DM200-5A
// 			chkUsingBlockAutoLoader_.EnableWindow( curr_state );
// 			chkUsingDetectBlockSensor_.EnableWindow( curr_state );
// 			break;
// 		}
// 
// 		btnBlockGripInterval_.EnableWindow( curr_state );
// 		((CStatic*)GetDlgItem(IDC_STATIC_BLOCK_GRIP_INTERVAL))->EnableWindow( curr_state );
// 		((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28))->EnableWindow( curr_state );
// 		((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28_2))->EnableWindow( curr_state );
// 		((CStatic*)GetDlgItem(IDC_STATIC_SELECT_M28_OPERATION))->EnableWindow( curr_state );
// #elif 
// 		chkUsingBlockAutoLoader_.EnableWindow( FALSE );
// 		chkUsingDetectBlockSensor_.EnableWindow( FALSE );
// 		btnBlockGripInterval_.EnableWindow( FALSE );
// 		((CStatic*)GetDlgItem(IDC_STATIC_BLOCK_GRIP_INTERVAL))->EnableWindow( FALSE );
// 		((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28))->EnableWindow( FALSE );
// 		((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28_2))->EnableWindow( FALSE );
// 		((CStatic*)GetDlgItem(IDC_STATIC_SELECT_M28_OPERATION))->EnableWindow( FALSE );
// #endif 
		// 2017.06.22 bychul2. 
		BOOL bEnableAutoLaoder = (pa::MODEL_INFO.GetAutoLoaderType() == pa::SModelInfo2::AL_TYPE_NONE) ? FALSE : TRUE;
		if( bEnableAutoLaoder == FALSE ) 
		{
			chkUsingBlockAutoLoader_.EnableWindow( bEnableAutoLaoder );
			chkUsingDetectBlockSensor_.EnableWindow( bEnableAutoLaoder );
		}
		else 
		{
			chkUsingBlockAutoLoader_.EnableWindow( curr_state );
			chkUsingDetectBlockSensor_.EnableWindow( curr_state );
		}

		btnBlockGripInterval_.EnableWindow( curr_state );
		((CStatic*)GetDlgItem(IDC_STATIC_BLOCK_GRIP_INTERVAL))->EnableWindow( curr_state );

		// 		((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28))->EnableWindow( curr_state );			// WET
		// 		((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28_2))->EnableWindow( curr_state );		// DRY
		((CStatic*)GetDlgItem(IDC_STATIC_SELECT_M28_OPERATION))->EnableWindow( curr_state );	//
		switch( pa::MODEL_INFO.GetM28Type() )
		{
		case pa::SModelInfo2::M28_TYPE_WET:
			((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28))->EnableWindow( curr_state );			// WET
			((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28_2))->EnableWindow( FALSE );				// DRY
			break;
		case pa::SModelInfo2::M28_TYPE_DRY:
			((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28))->EnableWindow( FALSE );				// WET
			((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28_2))->EnableWindow( curr_state );		// DRY
			break;
		case pa::SModelInfo2::M28_TYPE_SELECT:
		default:
			((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28))->EnableWindow( curr_state );			// WET
			((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28_2))->EnableWindow( curr_state );		// DRY
			break;
		}
#elif 
		chkUsingBlockAutoLoader_.EnableWindow( FALSE );
		chkUsingDetectBlockSensor_.EnableWindow( FALSE );
		btnBlockGripInterval_.EnableWindow( FALSE );
		((CStatic*)GetDlgItem(IDC_STATIC_BLOCK_GRIP_INTERVAL))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_RADIO_SELECT_OPER_M28_2))->EnableWindow( FALSE );
		((CStatic*)GetDlgItem(IDC_STATIC_SELECT_M28_OPERATION))->EnableWindow( FALSE );
#endif 

		chkUsingAirPressureLimit_.EnableWindow( TRUE );
		chkUsingOpPanel_.EnableWindow( curr_state );

		btnAirPressureInterval_.EnableWindow( curr_state );

		((CButton*)GetDlgItem(IDC_BUTTON_SAVE))->EnableWindow( curr_state );
		((CButton*)GetDlgItem(IDC_BUTTON_LOAD_FROM_FILE))->EnableWindow( curr_state );

		((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_STOP))->EnableWindow( curr_state );
		((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_RESTART_FROM_TOOL_CHANGE_LINE))->EnableWindow( curr_state );
		((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_RESTART_FROM_BEGIN))->EnableWindow( curr_state );
		((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_START_NEXT_NC_FILE))->EnableWindow( curr_state );
		((CButton*)GetDlgItem(IDC_RADIO_TOOL_ERR_OCCURED_USER_CONFIRM))->EnableWindow( curr_state );

// 		chkUsingSpindleAirPurge_.EnableWindow( curr_state );

		((CButton*)GetDlgItem(IDC_CHECK_INVALID_NC_CODE))->EnableWindow( curr_state );
		((CButton*)GetDlgItem(IDC_CHECK_NC_FILE_TAG))->EnableWindow( curr_state );
		((CButton*)GetDlgItem(IDC_CHECK_TRANSFORM_COORDINATE))->EnableWindow( curr_state );

		((CButton*)GetDlgItem(IDC_CHECK_USING_LOGGING))->EnableWindow( curr_state );

		chkDemoMode_.EnableWindow( curr_state );

		btnFlowSensorStartTimeout_.EnableWindow(curr_state);

		//////////////////////////////////////////////////////////////////////////
		// Flow Sensor �ɼ�
// 		BOOL bEnableFlowSensor = FALSE;
// 		switch( pa::PSWConfig->GetConfigData()->nModelID )
// 		{
// 		case 0: // DS200-5Z
// 			bEnableFlowSensor = FALSE;
// 			break;
// 		case 1:	// DS200-4W
// 		case 2:	// DS200-4WA
// 		case 3:	// DS200-4WAS
// 		case 6:	// DM200-5M
// 			bEnableFlowSensor = TRUE;
// 			break;
// 		case 4:	// DM200-5P
// 		case 5:	// DM200-5A
// 			bEnableFlowSensor = TRUE;
// 			break;
// 		}
// 		chkUsingFlowSensor_.EnableWindow( bEnableFlowSensor );
// 		((CButton*)GetDlgItem(IDC_BUTTON_FLOW_SENSOR_TIMEOUT))->EnableWindow( bEnableFlowSensor );
// 		((CStatic*)GetDlgItem(IDC_STATIC_FLOW_SENSOR_TIMEOUT))->EnableWindow( bEnableFlowSensor );
		BOOL bEnableFlowSensor = (pa::MODEL_INFO.IsUsingFlowSensor() == 0) ? FALSE : TRUE;

		chkUsingFlowSensor_.EnableWindow( bEnableFlowSensor );
		((CButton*)GetDlgItem(IDC_BUTTON_FLOW_SENSOR_TIMEOUT))->EnableWindow( bEnableFlowSensor );
		((CButton*)GetDlgItem(IDC_BUTTON_FLOW_SENSOR_START_TIMEOUT))->EnableWindow( bEnableFlowSensor );
		((CStatic*)GetDlgItem(IDC_STATIC_FLOW_SENSOR_TIMEOUT))->EnableWindow( bEnableFlowSensor );

		//////////////////////////////////////////////////////////////////////////
		// PurgeAir �Ӽ��� RND ��忡���� ������ �� �ִ� 
		BOOL bPurgeEnable = FALSE;
		if (pa::GET_CURRENT_USERMODE() == pa::USER_MODE_RND)
		{
			bPurgeEnable = TRUE;
		}
		chkUsingSpindleAirPurge_.EnableWindow(bPurgeEnable);
		((CButton*)GetDlgItem(IDC_BUTTON_PURGE_AIR_HOLD_TIME))->EnableWindow(bPurgeEnable && chkUsingSpindleAirPurge_.GetCheck());
	}
}

void CSetupOptionDlg::updateState_MenuButton()
{
	static int PREV_MODE = -1;
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetRunMode();
	int is_stop_mode = ( hRunMode == pa::RUNMODE_STOP ) ? 1 : 0;

	//////////////////////////////////////////////////////////////////////////
	// 
//	if( pa::USER_MODE < pa::USER_MODE_MGR ) 
	if( pa::GET_CURRENT_USERMODE() < pa::USER_MODE_MGR )
	{
		((CButton*)GetDlgItem(IDC_BUTTON_DOWNLOAD_TO_COLTROLLOR))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_SAVE))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_LOAD_FROM_FILE))->EnableWindow( FALSE );
		PREV_MODE = -1;
		return ;
	}
	//////////////////////////////////////////////////////////////////////////

	if( PREV_MODE != is_stop_mode )
	{
		is_stop_mode = PREV_MODE;
		BOOL bEnable		= is_stop_mode == 0 ? FALSE : TRUE;
		BOOL bDLBTN_Enable	= bEnable && bEnableDownloadButton_;
		((CButton*)GetDlgItem(IDC_BUTTON_DOWNLOAD_TO_COLTROLLOR))->EnableWindow( bDLBTN_Enable );
		((CButton*)GetDlgItem(IDC_BUTTON_SAVE))->EnableWindow( bEnable );
		((CButton*)GetDlgItem(IDC_BUTTON_LOAD_FROM_FILE))->EnableWindow( bEnable );
	}
}

//void CSetupOptionDlg::OnBnClickedCheckUsingAirPressureLimit2()
//{
//	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
//}

//void CSetupOptionDlg::OnBnClickedButtonEmoReset4()
//{
//	if( pa::PPAStatus->GetRunMode() == pa::RUNMODE_ERROR ) {
//		//////////////////////////////////////////////////////////////////////////
//		// log
//		writeLog( _T("reset button click") );
//		//////////////////////////////////////////////////////////////////////////
//		// Reset
//		PPNC_IPC_CLIENT->ErrorReset();
//	} else {
//		//////////////////////////////////////////////////////////////////////////
//		// log
//		writeLog( _T("emo button click") );
//		//////////////////////////////////////////////////////////////////////////
//		// EMO
//		PPNC_IPC_CLIENT->Emergency();
//	}
//}

// P2010=0
void CSetupOptionDlg::OnBnClickedRadioSelectOperM28()
{
// 	PPNC_IPC_CLIENT->TerminalCommand( "P2010=0" );
	// ���Ͽ� ���� 
// 	CCEIniFile hIniFile;
// 	hIniFile.Open( INI_INIT_DOWNLOAD_PATH );
// 	hIniFile.SetValue( CString(_T("P2010")), CString(_T("Data")), (int)0 );
// 	hIniFile.Close();
}

// P2010=1
void CSetupOptionDlg::OnBnClickedRadioSelectOperM282()
{
// 	PPNC_IPC_CLIENT->TerminalCommand( "P2010=1" );
	// ���Ͽ� ���� 
// 	CCEIniFile hIniFile;
// 	hIniFile.Open( INI_INIT_DOWNLOAD_PATH );
// 	hIniFile.SetValue( CString(_T("P2010")), CString(_T("Data")), (int)1 );
// 	hIniFile.Close();
}

// AutoLoader�� ��� ������ ������ �� ����, �� ���� ó�� ����� Default�� �����Ѵ� 
void CSetupOptionDlg::OnBnClickedCheckUsingBlockAutoloader()
{
	BOOL b = chkUsingBlockAutoLoader_.GetCheck();

	if( b ) 
	{
		// AutoLoader ��� 
		chkUsingDetectBlockSensor_.SetCheck( TRUE );
		
		// 2017.06.19 
		//	- NC ���� ���� Ȯ�� 
		CMsgDlg::EN_RET hRet = CMsgDlg::RET_NUM;
		CString strTemp, strMsg(_T(""));

		strTemp.Format( _T("do you want to sort nc-file list ?\n\n") );	strMsg += strTemp;
		strTemp.Format( _T(" - yes : sort nc-files\n") ); strMsg += strTemp;
		strTemp.Format( _T(" - no  : don't sort nc-files\n") ); strMsg += strTemp;
		strTemp.Format( _T(" - cancel : don't select autolaoder\n") ); strMsg += strTemp;

		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_YESNOCANCEL, CMsgDlg::ICON_QUEST, strMsg );
		hRet = CMsgDlgThread::GetInstance()->Wait();

		switch( hRet )
		{
		case CMsgDlg::RET_YES:
			pa::PNCFileMgr->SortNCFileList( TRUE );
			break;
		case CMsgDlg::RET_NO:
			break;
		case CMsgDlg::RET_CANCEL:
			// autoloader�� unselect ���·� ����� 
			chkUsingBlockAutoLoader_.SetCheck( FALSE );
			break;
		}
	}
	else 
	{
		// AutoLoadre �̻��
		chkUsingDetectBlockSensor_.SetCheck( FALSE );
	}

	UpdateData( FALSE );

}

void CSetupOptionDlg::writeLog( LPCTSTR log_msg )
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	WriteLog( CLog::TYPE_OPER, 5, log_msg );
	//////////////////////////////////////////////////////////////////////////
}

void CSetupOptionDlg::OnBnClickedCheckUsingDetectBlockSensor()
{
	BOOL b = chkUsingDetectBlockSensor_.GetCheck();
	int  val = 0;

	if( b )
	{
		// Block Sensor ��� 
// 		PPNC_IPC_CLIENT->TerminalCommand( "P5109=0" );
		val = 0;
	}
	else
	{
		// Block Sensot �̻��
// 		PPNC_IPC_CLIENT->TerminalCommand( "P5109=1" );
		val = 1;
	}

	// ���Ͽ� ���� 
	CCEIniFile hIniFile;
	hIniFile.Open( INI_INIT_DOWNLOAD_PATH );
	hIniFile.SetValue( CString(_T("P5019")), CString(_T("Data")), (int)val );
	hIniFile.Close();

}

void CSetupOptionDlg::OnBnClickedButtonFlowSensorTimeout()
{
	CNumericInputDlg dlg;
	CString	strTemp;

	btnFlowSensorTimeout_.GetWindowText( strTemp );

	dlg.SetIsFloatType( FALSE );
	dlg.SetPrevNumber( (int)_ttoi((LPCTSTR)strTemp) );
//	dlg.SetProperty( CNumericInputDlg::PROPERTY_CALC_BUTTON );
	dlg.SetProperty( 0 );

	if( dlg.DoModal() == IDOK ) 
	{
		int nVal = (int)_ttoi( (LPCTSTR)dlg.GetNumber() );
		CString strTemp;
		strTemp.Format( _T("%d"), nVal );
		btnFlowSensorTimeout_.SetWindowText( strTemp );
//		bEnableDownloadButton_ = TRUE;
	}

}

void CSetupOptionDlg::OnBnClickedButtonFlowSensorStartTimeout()
{
	CNumericInputDlg dlg;
	CString	strTemp;

	btnFlowSensorStartTimeout_.GetWindowText( strTemp );

	dlg.SetIsFloatType( FALSE );
	dlg.SetPrevNumber( (int)_ttoi((LPCTSTR)strTemp) );
	dlg.SetProperty( 0 );

//	pa::EN_SCREEN hPrevScrn = SET_CURRENT_SCREEN( pa::SCRN_NUMERIC_INPUT );

	if( dlg.DoModal() == IDOK ) 
	{
		int nVal = (int)_ttoi( (LPCTSTR)dlg.GetNumber() );
		CString strTemp;
		strTemp.Format( _T("%d"), nVal );
		btnFlowSensorStartTimeout_.SetWindowText( strTemp );
	}

// 	SET_CURRENT_SCREEN( hPrevScrn );
// 
// 	send_maxxlink_data();
}

// PC���� ������ �����͸� ���� �Ѵ�
//	- flow sensor ��� ����, timeout ������  
void CSetupOptionDlg::OnBnClickedButtonDownloadToColtrollor()
{
	/*
	CString strMsg;
	DWORD	dwTime;
	
	strMsg.Format( _T("Do you want to upload data from controllor ?") );
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
	CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();
	if( hRet == CMsgDlg::RET_CANCEL ) {
		updateState();
		return ;
	}

	//////////////////////////////////////////////////////////////////////////
	// �����͸� �����Ѵ� 
	CString strTemp;
	btnFlowSensorTimeout_.GetWindowText( strTemp );

//	pmac::PSWConfig->GetConfigData()->bUsingFlowSensor	= chkUsingFlowSensor_.GetCheck();
//	pmac::PSWConfig->GetConfigData()->nFlowSensorTimeout= _ttoi(strTemp);
	pa::PSWConfig->GetConfigData()->bUsingFlowSensor	= chkUsingFlowSensor_.GetCheck();
	pa::PSWConfig->GetConfigData()->nFlowSensorTimeout	= _ttoi(strTemp);

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("download option data button click") );
	//////////////////////////////////////////////////////////////////////////

	strMsg.Format( _T("wait for download option data") );
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

	// �ٿ�ε� 
//	pmac::PState->SetIpcCommandComplete( FALSE );
	pa::PPAStatus->SetIpcCommandComplete( FALSE );
	PPNC_IPC_CLIENT->DownloadFlowSensorData();
	Sleep( 100 );
	dwTime = GetTickCount();
//	while( pmac::PState->GetThreadState()->bIpcCmdComplete_ == FALSE ) {
	while( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == FALSE ) {
		if( ( GetTickCount() - dwTime ) > 10000 ) {
			// ���� 
			//	CMsgDlgThread::GetInstance()->Hide();
			strMsg.Format( _T("Failed to download option data") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_WARM, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
			return ;
		}
		Sleep( 100 );
	}

	CMsgDlgThread::GetInstance()->Hide();

	//////////////////////////////////////////////////////////////////////////
	//
	//////////////////////////////////////////////////////////////////////////

	// 	strMsg.Format( _T("�Ķ��Ÿ�� �����Ͻðڽ��ϱ� ?") );
// 	strMsg.Format( _T("Do you want to save system parameter ?") );
// 	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, strMsg );
// 	CMsgDlg::EN_RET ret = CMsgDlgThread::GetInstance()->Wait();
// 	if( ret == CMsgDlg::RET_OK ) {
	OnBnClickedButtonSave();
// 	}
	*/

	CString strMsg;

	strMsg.Format( _T("not implemented !") );

	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_WARM, strMsg );
	CMsgDlgThread::GetInstance()->Wait();

}

// ����⿡�� PC�� �����͸� ���� �Ѵ� 
void CSetupOptionDlg::upload_to_pc()
{
	CString strMsg;
	DWORD	dwTime;

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("upload option data button click") );
	//////////////////////////////////////////////////////////////////////////

	strMsg.Format( _T("wait for upload option data") );
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

	// ���ε� 
	// 2016.04.05. �Ʒ� ������ option ������ ��ü�� �о���� ������ �����ؾ� �� 
// 	pa::PPAStatus->SetIpcCommandComplete( FALSE );
// 	PPNC_IPC_CLIENT->UploadFlowSensorData();
// 	Sleep( 100 );
// 	dwTime = GetTickCount();
// 	while( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == FALSE ) {
// 		if( ( GetTickCount() - dwTime ) > 10000 ) {
// 			// ���� 
// 			strMsg.Format( _T("Failed to upload option data") );
// 			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_WARM, strMsg );
// 			CMsgDlgThread::GetInstance()->Wait();
// 			return ;
// 		}
// 		Sleep( 100 );
// 	}

	pa::PPAStatus->SetIpcCommandComplete( FALSE );
	PPNC_IPC_CLIENT->UploadOperationM28();
	Sleep( 500 );
	dwTime = GetTickCount();
	while( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == FALSE ) {
		if( GetTickCount()-dwTime > 10000 ) {
			// ���� 
			strMsg.Format( _T("Failed to upload data") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_WARM, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
			updateState();
			return ;
		}
		Sleep( 100 );
	}

	updateState();

	CMsgDlgThread::GetInstance()->Hide();
}

void CSetupOptionDlg::OnBnClickedCheckUsingFlowSensor()
{
// 	bEnableDownloadButton_ = TRUE;
}

// BOOL b = chkUsingBlockAutoLoader_.GetCheck();
// 
// if( b ) 
// {
// 	// AutoLoader ��� 
// 	//		nToolErrOccureHandingCode_ = 3;
// 	chkUsingDetectBlockSensor_.SetCheck( TRUE );
// }
// else 
// {
// 	// AutoLoadre �̻��
// 	//		nToolErrOccureHandingCode_ = 1;
// 	chkUsingDetectBlockSensor_.SetCheck( FALSE );
// }
// 
// UpdateData( FALSE );

void CSetupOptionDlg::OnBnClickedCheckInvalidNcCode()
{
	BOOL b = chkInvalidNcCode_.GetCheck();

	if( b ) {
		chkInvalidNcCode_.SetCheck( TRUE );
	} else {
		chkInvalidNcCode_.SetCheck( FALSE );
	}

	UpdateData( FALSE );
}

void CSetupOptionDlg::OnBnClickedCheckNcFileTag()
{
	BOOL b = chkNcFileTag_.GetCheck();

	if( b ) {
		chkNcFileTag_.SetCheck( TRUE );
	} else {
		chkNcFileTag_.SetCheck( FALSE );
	}

	UpdateData( FALSE );
}

void CSetupOptionDlg::OnBnClickedCheckTransformCoordinate()
{
	BOOL b = chkTransformCoord_.GetCheck();

	if( b ) {
		chkTransformCoord_.SetCheck( TRUE );
	} else {
		chkTransformCoord_.SetCheck( FALSE );
	}

	UpdateData( FALSE );
}

void CSetupOptionDlg::OnBnClickedCheckUsingSpindleAirPurge()
{
	BOOL b = ( chkUsingSpindleAirPurge_.GetCheck() == 0 ) ? FALSE : TRUE;

//	pmac::PSWConfig->GetConfigData()->bUsingSpindleAirPurge = b;
	pa::PSWConfig->GetConfigData()->bUsingSpindleAirPurge = b;
}


void CSetupOptionDlg::PreInitDialog()
{
	CString strImageFilePath;
	CDC*	pDC = GetDC();
	CRect	rcWnd;
	GetClientRect( &CUIrectSO );
	MoveWindow(0,0,1023,619);
	//////////////////////////////////////////////////////////////////////////
	strImageFilePath.Format( _T("%s\\Background_setup.bmp"), pResourcePath_ );

	GetClientRect( &rcWnd );

	pCanvasCE_ = new hcutil::CCanvasCE();
	ASSERT(pCanvasCE_ );
	pCanvasCE_->Create( this, pDC->GetSafeHdc(), rcWnd.Width(), rcWnd.Height(), RGB(1, 1, 0) );
	pCanvasCE_->GetCanvasCELayerMgr()->Add( FALSE, RGB(0, 0, 0) );
	pCanvasCE_->GetCanvasCELayerMgr()->Add( TRUE, RGB(255, 0, 255) );

	pCanvasCE_->GetCanvasCELayerMgr()->Get( 0 )->FillSolidRect( rcWnd, pa::CLR_SETUP_OPTION );
	pCanvasCE_->GetCanvasCELayerMgr()->Get( 1 )->LoadImageFormFile( strImageFilePath, CPoint(0, 0), CPoint(rcWnd.Width(), rcWnd.Height()) );
	//////////////////////////////////////////////////////////////////////////

	ReleaseDC( pDC );
	pDC = NULL;

	CDialogListPage::PreInitDialog();
}

void CSetupOptionDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	if( pCanvasCE_ ) {
		pCanvasCE_->Draw( dc.m_hDC, dc.m_ps.rcPaint );
	}
}

//////////////////////////////////////////////////////////////////////////

void CSetupOptionDlg::OnBnClickedCheckUsingOpPanel()
{
}

void CSetupOptionDlg::OnBnClickedCheckUsingAirPressureLimit()
{
}

void CSetupOptionDlg::OnBnClickedCheckUsingLogging()
{
}

void CSetupOptionDlg::OnBnClickedRadioToolErrOccuredStop()
{
}

void CSetupOptionDlg::OnBnClickedRadioToolErrRestartFromToolChangeLine()
{
}

void CSetupOptionDlg::OnBnClickedRadioToolErrOccuredRestartFromBegin()
{
}

void CSetupOptionDlg::OnBnClickedRadioToolErrOccuredStartNextNcFile()
{
}

void CSetupOptionDlg::OnBnClickedRadioToolErrOccuredUserConfirm()
{
}


void CSetupOptionDlg::OnBnClickedButtonPurgeAirHoldTime()
{
	CNumericInputDlg dlg;
	CString strTemp;

	btnPurgeAirHoldTime_.GetWindowText(strTemp);

	dlg.SetIsFloatType( FALSE );
	dlg.SetPrevNumber( (int)_ttoi( (LPCTSTR)strTemp ) );
	dlg.SetProperty( CNumericInputDlg::PROPERTY_CALC_BUTTON );

	if( dlg.DoModal() == IDOK ) 
	{
		int nVal = (int)_ttoi( (LPCTSTR)dlg.GetNumber() );
		CString strTemp;
		strTemp.Format( _T("%d"), nVal );
		btnPurgeAirHoldTime_.SetWindowText(strTemp);
	}
}
