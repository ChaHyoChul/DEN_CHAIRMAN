#pragma once
#include "afxwin.h"


// CResetOriginDlg ��ȭ �����Դϴ�.

class CResetOriginDlg : public CDialog
{
	DECLARE_DYNAMIC(CResetOriginDlg)

	CFont fntLabel_;
	CFont fntCombo_;
	CFont fntButton_;

	void update_state();

public:
	CResetOriginDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CResetOriginDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_RESET_ORIGIN };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnDestroy();
	CComboBox cboSelectAxis_;
	CButton btnOrigin_;
	CButton btnClose_;
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButtonOrigin();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
