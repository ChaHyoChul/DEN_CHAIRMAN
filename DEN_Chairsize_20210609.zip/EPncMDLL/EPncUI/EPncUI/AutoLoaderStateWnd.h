#pragma once

// CAutoLoaderStateWnd

#define WM_AUTOLOADER_REFILL	(WM_USER + 110)

class CAutoLoaderStateWnd : public CWnd
{
	DECLARE_DYNAMIC(CAutoLoaderStateWnd)

	hcutil::CCanvasCE*	pCanvasCE_;

	int			nNumBlock_;
	CRect		rcBlock_[100];
	CRect		rcIndex_[100];
	CRect		rcWork_[100];
	CRect		alStateBlock_[5];
	CRect		alStateBlockNames_[5];
	COLORREF	clrBlockState_[pa::BLOCK_STATE_NUM+1];
	COLORREF	clrBackground_Normal_;
	COLORREF	clrBackground_Push_;
	COLORREF	clrBackground_Disable_;
	COLORREF	clrIndexText_;				// ����� ���, ���� �� ���� 
	int			nWorkIndex_;
	pa::EN_AUTOLOADER_BLOCK_STATE hBlockState_[100];
	int slotHolderNum_[100];

	BOOL		bIsLBtnDown_;
	DWORD		dwLBtnDownTick_;

	CFont	fntIndex_;

	void calcLayout();
	void drawGround();
	void drawBackground();
	void drawBlockState( int nIndex, BOOL bRedraw );
	void drawWorkIndex( int nIndex );
	void drawAutoLoaderStates( BOOL bRedraw );

	void resetColorMap();

public:
	CAutoLoaderStateWnd();
	virtual ~CAutoLoaderStateWnd();

	BOOL Create( CWnd* pParent, CRect rcWnd, int nNumBlock );

	void UpdateAutoLoaderState();

	void ReloadBlockState();

	void SetWorkIndex( int nIndex );

	void ResetUsingAutoLoader();

	void SetNumBlock( int nNumBlock );

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};


