#pragma once

// CRestartDialog ��ȭ �����Դϴ�.

class CRestartDialog : public CDialog
{
	DECLARE_DYNAMIC(CRestartDialog)

	CFont	fntMessage_;
	CFont	fntLineNo_;
	CFont	fntButton1_;
	CFont	fntButton2_;
	int		nStartLine_;

public:
	CRestartDialog(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CRestartDialog();

	void SetStartLine( int nStartLine );
	int  GetStartLine();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_RESTART };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedButtonCancel();
	afx_msg void OnBnClickedButtonLineNo();
	afx_msg void OnBnClickedButtonFromSelectedLine();
	afx_msg void OnBnClickedButtonFromBegining();
};
