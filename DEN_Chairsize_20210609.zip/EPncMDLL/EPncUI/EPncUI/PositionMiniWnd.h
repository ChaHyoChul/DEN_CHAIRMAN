#pragma once


// CPositionMiniWnd

class CPositionMiniWnd : public CWnd
{
	DECLARE_DYNAMIC(CPositionMiniWnd)

	// Attribute
private:
//	SpCanvas		spCanvas_;
	hcutil::CCanvasCE*	pCECanvas_;
	int				nAxisNo_;				// �� ��ȣ (�Է��� �����)
	CRect			rcName_;				// �� �̸� 
	CRect			rcPosition_;			// ��ġ 
	CRect			rcSensorP_;				// ���� ���� 
	CRect			rcSensorM_;				// ���� ���� 
	CFont			*pFont_;				// 

	// Implement
private:
	void calcLayout();
	void drawBackground();

public:
	CPositionMiniWnd();
	virtual ~CPositionMiniWnd();

public:
	BOOL Create( CWnd *pParent, CRect& rcWnd, int nAxisNo );
	void Update();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
};


