#pragma once

#include "OptionDataListBox.h"
#include "TitleBarWnd.h"

// CSetupTeachingOffsetDlg ��ȭ �����Դϴ�.

class CSetupTeachingOffsetDlg : public CDialogListPage
{
	DECLARE_DYNCREATE(CSetupTeachingOffsetDlg)

	CTitleBarWnd*			pTitleBarWnd_;
	COptionDataListBox*		pOptionDataListBox_;

	CRect	CUIrectSTOff; 

	void update_OptionListBox();

public:
	CSetupTeachingOffsetDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupTeachingOffsetDlg();

	virtual void StartPageWork();
	virtual void StopPageWork();
	virtual void UpdatePage();

	void UpdateOptionListBox() {
		update_OptionListBox();
	}

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_TEACHING_OFFSET };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	LRESULT OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
