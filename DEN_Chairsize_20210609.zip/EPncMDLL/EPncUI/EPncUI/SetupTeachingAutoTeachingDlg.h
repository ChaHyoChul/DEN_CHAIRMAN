#pragma once

#include "OptionDataListBox.h"
#include "TitleBarWnd.h"

// CSetupTeachingAutoTeachingDlg ��ȭ �����Դϴ�.

class CSetupTeachingAutoTeachingDlg : public CDialogListPage
{
	DECLARE_DYNCREATE(CSetupTeachingAutoTeachingDlg)

	CWnd*				pParent_;
	CTitleBarWnd*		pTitleBarWnd_;
	COptionDataListBox*	pParamListBox_;

	CBrush	brhBkgnd_;		// ���� 
	CFont	fntBtn_;		// Run ��ư  
	CRect	CUIrectSTAT; 
	
	int		nIsPressStopButton_;

	void updateCheckBoxState();

	void updateButtonState();

public:
	CSetupTeachingAutoTeachingDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupTeachingAutoTeachingDlg();

	virtual void StartPageWork();
	virtual void StopPageWork();
	virtual void UpdatePage();

	void SetParentWnd( CWnd* pParent ) { pParent_ = pParent; }

	void UpdateParamListBox();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_TEACHING_AUTO_TEACHING };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
protected:
	virtual void PreInitDialog();
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	LRESULT OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedButtonStartStop();
};
