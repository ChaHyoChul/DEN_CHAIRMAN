// PositionMiniWnd.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "PositionMiniWnd.h"

//////////////////////////////////////////////////////////////////////////
// CPositionMiniWnd
//////////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC(CPositionMiniWnd, CWnd)

//////////////////////////////////////////////////////////////////////////

CPositionMiniWnd::CPositionMiniWnd()
{
	nAxisNo_	= 0;
	pFont_		= NULL;
	pCECanvas_	= NULL;
}

CPositionMiniWnd::~CPositionMiniWnd()
{
	if( pCECanvas_ ) {
		delete pCECanvas_;
		pCECanvas_ = NULL;
	}
}

BOOL CPositionMiniWnd::Create( CWnd *pParent, CRect& rcWnd, int nAxisNo )
{
	nAxisNo_ = nAxisNo;

	return CWnd::Create( NULL, NULL, WS_VISIBLE|WS_CHILD, rcWnd, pParent, 0, NULL );
}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CPositionMiniWnd, CWnd)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_PAINT()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CPositionMiniWnd �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////


int CPositionMiniWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	CDC		*pDC = GetDC();
	CRect	rc;

	// Canvas ��ü �ʱ�ȭ 
	GetClientRect(&rc);
	pCECanvas_ = new hcutil::CCanvasCE();
	ASSERT( pCECanvas_ );
	pCECanvas_->Create( this, pDC->GetSafeHdc(), rc.Width(), rc.Height(), RGB(0, 0, 0) );
	pCECanvas_->GetCanvasCELayerMgr()->Add( TRUE, RGB(1, 1, 0) );
	pCECanvas_->GetCanvasCELayerMgr()->Add( TRUE, RGB(1, 1, 0) );
	pCECanvas_->Clear();
	ReleaseDC(pDC);

	// Font ��ü �ʱ�ȭ 
	pFont_ = new CFont();
	ASSERT( pFont_ );
	pFont_->CreateFont( 18, 10, 0, FW_BOLD,
		FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,DEFAULT_PITCH, _T("Courier New") );

	calcLayout();

	drawBackground();

	return 0;
}

void CPositionMiniWnd::OnDestroy()
{
	if( pFont_ ) {
		delete pFont_;
		pFont_ = NULL;
	}

	if( pCECanvas_ ) {
		delete pCECanvas_;
		pCECanvas_ = NULL;
	}

	CWnd::OnDestroy();
}

void CPositionMiniWnd::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	if( pCECanvas_ ) {
		pCECanvas_->Draw( dc.GetSafeHdc(), dc.m_ps.rcPaint );
	}
}

void CPositionMiniWnd::calcLayout()
{
	CRect	rcWnd;

	GetClientRect( &rcWnd );

	rcName_ = rcPosition_ = rcSensorP_ = rcSensorM_ = rcWnd;
	rcName_.right = rcName_.left + 20;

	rcPosition_.left = rcName_.right + 2;
	rcPosition_.right= rcPosition_.right - 28;

	rcSensorP_.left		= rcPosition_.right + 1;
	rcSensorP_.right	= rcSensorP_.left + 14;
	rcSensorM_.left		= rcSensorP_.right;
	rcSensorM_.right	= rcSensorM_.right;
}

void CPositionMiniWnd::drawBackground()
{
// 	static char		AXIS_NAME[] = "XYZABC";
	static TCHAR	AXIS_NAME[] = _T("XYZABC");
	hcutil::CCanvasCELayer	*pLayer = pCECanvas_->GetCanvasCELayerMgr()->Get( 0 );
	COLORREF		oldTextColor = pLayer->SetTextColor( RGB(255, 255, 255) );
	int				nPrevBkMode = pLayer->SetBkMode( TRANSPARENT );
	CFont			*pOldFont = (CFont *)pLayer->SelectObject( pFont_ );

	pLayer->Clear( FALSE );

	CString strTemp;
	strTemp.Format( _T("%c"), AXIS_NAME[nAxisNo_] );
	pLayer->DrawText( strTemp, strTemp.GetLength(), rcName_, DT_CENTER|DT_VCENTER|DT_SINGLELINE );

	pLayer->SetTextColor( oldTextColor );
	pLayer->SetBkMode( nPrevBkMode );
	pLayer->SelectObject( pOldFont );

	Invalidate( FALSE );
}

// ���� ��ġ�� ���� ���¸� �׸���
void CPositionMiniWnd::Update()
{
	enum EN_COLOR { COLOR_NORMAL = 0, COLOR_NOT_INIT, COLOR_ERROR, COLOR_NUM };
	static COLORREF COLOR[] = {
		RGB(0, 255, 0),			// Normal
		RGB(128, 128, 128),		// Not Init
		RGB(255, 0, 0)			// Error
	};

	double fPosition = pa::PPAStatus->GetPAStatus()->fAutoLoaderPosition;

	if( pCECanvas_ == NULL ) {
		return ;
	}

	hcutil::CCanvasCELayer	*pLayer = pCECanvas_->GetCanvasCELayerMgr()->Get( 1 );	// spCanvas_->GetCanvasLayerMgr()->Get( "Position" );
	CFont		*pOldFont = (CFont *)pLayer->SelectObject( pFont_ );
	int			nBkMode = pLayer->SetBkMode( TRANSPARENT );
	COLORREF	clrPosition = COLOR[COLOR_NORMAL];
	COLORREF	clrOld = pLayer->SetTextColor( RGB(0, 0, 0) );

	pLayer->Clear( FALSE );

	if( pa::PPAStatus->GetPAStatus()->nServoHomeState == 0 ) {
		clrPosition = COLOR[COLOR_NOT_INIT];
	} 
	if( pa::PPAStatus->GetPAStatus()->nRunStatus == pa::PA_RUN_STATUS_ERROR || pa::PPAStatus->GetRunMode() == pa::RUNMODE_ERROR ) {
		clrPosition = COLOR[COLOR_ERROR];
	}

	// ��ġ ��� 
	CString strTemp;
	strTemp.Format( _T("%.03f"), fPosition );
	clrOld = pLayer->SetTextColor( clrPosition );
	pLayer->DrawText( strTemp, strTemp.GetLength(), rcPosition_, DT_RIGHT|DT_VCENTER|DT_SINGLELINE ); 

	// ���� ���� ���  
	COLORREF clrPLimit;
	COLORREF clrMLimit;
// 	if( pa::PPAStatus->GetPAStatus()->bInput[pa::IN10007_AL_Z_P_Limit] ) {
// 		clrPLimit = RGB(255, 0, 0);
// 	} else {
// 		clrPLimit = RGB(128, 128, 128);
// 	}
// 	if( pa::PPAStatus->GetPAStatus()->bInput[pa::IN10008_AL_Z_M_Limit] ) {
// 		clrMLimit = RGB(255, 0, 0);
// 	} else {
// 		clrMLimit = RGB(128, 128, 128);
// 	}
	clrPLimit = RGB(255, 0, 0);
	clrMLimit = RGB(255, 0, 0);

	pLayer->SetTextColor( clrPLimit );
	pLayer->DrawText( _T("+"), 1, &rcSensorP_, DT_RIGHT|DT_VCENTER|DT_SINGLELINE );
	pLayer->SetTextColor( clrMLimit );
	pLayer->DrawText( _T("-"), 1, &rcSensorM_, DT_LEFT|DT_VCENTER|DT_SINGLELINE );

	pLayer->SetTextColor( clrOld );
	pLayer->SelectObject( pOldFont );

	Invalidate( FALSE );
}

