#pragma once

#include "OptionDataListBox.h"
#include "TitleBarWnd.h"

// CSetupTeachingSAAutoCalCoordOffsetDlg ��ȭ �����Դϴ�.

class CSetupTeachingSAAutoCalCoordOffsetDlg : public CDialogListPage
{
	DECLARE_DYNCREATE(CSetupTeachingSAAutoCalCoordOffsetDlg)

	CWnd*				pParent_;
	CTitleBarWnd*		pTitleBarWnd_;
	COptionDataListBox*	pParamListBox_;

	CBrush	brhBkgnd_;		// ���� 
	CFont	fntBtn_;		// Run ��ư  
	CRect	CUIrectSTAO; 
	
	int 	nIsPressStopButton_;

	void updateButtonState();
// 	void updateCheckBoxState();

public:
	CSetupTeachingSAAutoCalCoordOffsetDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupTeachingSAAutoCalCoordOffsetDlg();

	virtual void StartPageWork();
	virtual void StopPageWork();
	virtual void UpdatePage();

	void SetParentWnd( CWnd* pParent ) { pParent_ = pParent; }

	void UpdateOptionListBox();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_TEACHING_SA_AUTOCAL_COORD_OFFSET };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
protected:
	virtual void PreInitDialog();
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	LRESULT OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedButtonStartStop();
	int nSelectMeasure_;
	afx_msg void OnBnClickedRadioSelectAaxis();
	afx_msg void OnBnClickedRadioSelectXyzaxis();
};
