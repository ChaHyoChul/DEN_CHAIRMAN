#pragma once
#include "afxwin.h"

// CSetupToolResetDlg ��ȭ �����Դϴ�.

class CSetupToolResetDlg : public CDialog
{
	DECLARE_DYNAMIC(CSetupToolResetDlg)

	int		nToolNo_;
	DWORD	dwMaximumTime_;

	CFont	fntUpDownBtn_;
	CFont	fntOkCancelBtn_;
	CFont	fntTime_;

	BOOL	bIsPressButton_;
	int		nInc_;

	void incHour();
	void decHour();
	void incMinute();
	void decMinute();
	void incSecond();
	void decSecond();
	void updateMaximumTime();

public:
	CSetupToolResetDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupToolResetDlg();

	void SetToolNo( int toolNo );

	DWORD GetMaximunTime(); 

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_TOOL_RESET };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
 	afx_msg void OnBnClickedButtonReset2();
	afx_msg void OnBnClickedButtonCancel();
	CNotifyButton btnHourUp_;
	CNotifyButton btnHourDown_;
	CNotifyButton btnMinuteUp_;
	CNotifyButton btnMinuteDown_;
	CNotifyButton btnSecondUp_;
	CNotifyButton btnSecondDown_;
	afx_msg LRESULT OnNotifyButton(WPARAM wparam, LPARAM lparam);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
