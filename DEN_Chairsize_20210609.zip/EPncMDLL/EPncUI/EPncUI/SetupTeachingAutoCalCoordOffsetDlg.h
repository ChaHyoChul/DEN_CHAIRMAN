#pragma once

#include "OptionDataListBox.h"
#include "TitleBarWnd.h"

// CSetupTeachingAutoCalCoordOffsetDlg ��ȭ �����Դϴ�.

class CSetupTeachingAutoCalCoordOffsetDlg : public CDialogListPage
{
	DECLARE_DYNCREATE(CSetupTeachingAutoCalCoordOffsetDlg)

	CWnd*				pParent_;
	CTitleBarWnd*		pTitleBarWnd_;
	COptionDataListBox*	pParamListBox_;

	CBrush	brhBkgnd_;		// ���� 
	CFont	fntBtn_;		// Run ��ư  
	CRect	CUIrectSTAO; 
	
	int 	nIsPressStopButton_;

	void updateButtonState();
	void updateCheckBoxState();

public:
	CSetupTeachingAutoCalCoordOffsetDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupTeachingAutoCalCoordOffsetDlg();

	virtual void StartPageWork();
	virtual void StopPageWork();
	virtual void UpdatePage();

	void SetParentWnd( CWnd* pParent ) { pParent_ = pParent; }

	void UpdateOptionListBox();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_TEACHING_AUTOCAL_COORD_OFFSET };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
protected:
	virtual void PreInitDialog();
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	LRESULT OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedButtonStartStop();
	afx_msg void OnBnClickedCheckDummy();
	afx_msg void OnBnClickedCheckXaxisCenter();
	afx_msg void OnBnClickedCheckY1axisCenter();
	afx_msg void OnBnClickedCheckY2axisCenter();
	afx_msg void OnBnClickedCheckZ1axisOrgOffset();
	afx_msg void OnBnClickedCheckZ2axisOrgOffset();
};
