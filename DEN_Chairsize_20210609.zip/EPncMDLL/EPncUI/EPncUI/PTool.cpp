#include "StdAfx.h"
#include "PTool.h"

pa::CPTool::CPTool(void)
{
	pShMem_		= NULL;
	pToolData_	= NULL;
}

pa::CPTool::~CPTool(void)
{
	Destroy();
}

BOOL pa::CPTool::Initialize( CString& strErrMsg )
{
	pShMem_ = new hcipc::CSharedMem();
	if( pShMem_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::CPTool::pShMem_ object") );
		return FALSE;
	}
	pToolData_ = (SToolData*)pShMem_->Create( IPC_FILEPATH, TOOL_OBJECT_NAME, sizeof(SToolData), FALSE, 0 );
	if( pToolData_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pmac::CPTool::pToolData_ object") );
		return FALSE;
	}

	return TRUE;
}

void pa::CPTool::Destroy()
{
	if( pShMem_ ) {
		delete pShMem_;
		pShMem_ = NULL;
		pToolData_ = NULL;
	}
}

//////////////////////////////////////////////////////////////////////////

void pa::CPTool::IncToolUsingTime( int nToolNo )
{
	pToolData_->hTool[nToolNo].dwUsingTime++;
	if( pToolData_->hTool[nToolNo].dwMaximumTime > 0 ) {
		pToolData_->hTool[nToolNo].fUsingRate = 
			( (double)pToolData_->hTool[nToolNo].dwUsingTime / (double)pToolData_->hTool[nToolNo].dwMaximumTime ) * 100.0;
	} else {
		pToolData_->hTool[nToolNo].dwUsingTime = 0;
	}
}

void pa::CPTool::ResetToolUsingTime( int nToolNo, DWORD dwMaximumTime )
{
	pToolData_->hTool[nToolNo].dwUsingTime		= 0;
	pToolData_->hTool[nToolNo].dwMaximumTime	= dwMaximumTime;
	pToolData_->hTool[nToolNo].fUsingRate		= 0.0;
}

void pa::CPTool::SetBrokenTool( int nToolNo )
{
	pToolData_->hTool[nToolNo].dwUsingTime		= 0xFFFFFFFF;
	pToolData_->hTool[nToolNo].fUsingRate		= 100.0;
}

// �ش� ���� ���ð� ������ ���� (Flush ���� ���)
void pa::CPTool::SaveToolUsingTime( int nToolNo )
{
	pShMem_->Flush( (void*)&(pToolData_->hTool[nToolNo]), sizeof(STool) );
}

void pa::CPTool::SaveToolUsingTimeAll()
{
	pShMem_->Flush( (void*)&(pToolData_->hTool), sizeof(STool)*MAX_TOOL_NUM );
}

//////////////////////////////////////////////////////////////////////////

void pa::CPTool::SetEnableToolUsageTime( BOOL b )
{
	if( pToolData_->bEnableToolUsageTime != b ) {
		pToolData_->bEnableToolUsageTime = b;
		pShMem_->Flush( (void*)&(pToolData_->bEnableToolUsageTime), sizeof(BOOL) );
	}  
}

BOOL pa::CPTool::GetEnableToolUsageTime()
{
	return pToolData_->bEnableToolUsageTime;
}

void pa::CPTool::SetEnableRelatedTool( BOOL b )
{
	if( pToolData_->bEnableRelatedTool != b ) {
		pToolData_->bEnableRelatedTool = b;
		pShMem_->Flush( (void*)&(pToolData_->bEnableRelatedTool), sizeof(BOOL) );
	}
}

BOOL pa::CPTool::GetEnableRelatedTool()
{
	return pToolData_->bEnableRelatedTool;
}

void pa::CPTool::SetTimeCountZAxisPos( double fZAxisPos )
{
	pToolData_->fTimeCountZAxisPos = fZAxisPos;
	pShMem_->Flush( (void*)&(pToolData_->fTimeCountZAxisPos), sizeof(double) );
}

double pa::CPTool::GetTimeCountZAxisPos()
{
	return pToolData_->fTimeCountZAxisPos;
}

//////////////////////////////////////////////////////////////////////////
// ������ ���� �Լ� 
//////////////////////////////////////////////////////////////////////////

int  pa::CPTool::GetNumRelatedToolData()
{
	return pToolData_->nNumDataForRelatedTool;
}

// M140+M141+ ó��. �� �Ʒ� �߰�  
BOOL pa::CPTool::AddRelatedToolData( const char* p )
{
	if( pToolData_->nNumDataForRelatedTool > MAX_TOOL_NUM ) {
		return FALSE;
	}

	memset( (void*)(pToolData_->szRelateTool[pToolData_->nNumDataForRelatedTool]), 0, sizeof(char)*64 );
	memcpy( (void*)(pToolData_->szRelateTool[pToolData_->nNumDataForRelatedTool]), p, strlen(p) );

	pToolData_->nNumDataForRelatedTool++;

	int len = sizeof(int) + ( sizeof(char) * (MAX_TOOL_NUM+1) * 64 );
	pShMem_->Flush( (void*)&(pToolData_->nNumDataForRelatedTool), len );

	return TRUE;
}

// nIndex ��° �����͸� ���� �ϰ�, �� �� �����͸� �ϳ��� �ø��� 
void pa::CPTool::RemoveRelatedToolData( int nIndex )
{
	if( nIndex >= pToolData_->nNumDataForRelatedTool ) {
		return ;
	}

	int	len = ( pToolData_->nNumDataForRelatedTool - ( nIndex + 1 ) ) * 64;
	memcpy(	(void*)(pToolData_->szRelateTool[nIndex]), 
			(const void*)(pToolData_->szRelateTool[nIndex+1]), 
			sizeof(char)*len );

	pToolData_->nNumDataForRelatedTool--;

	len = sizeof(int) + ( sizeof(char) * (MAX_TOOL_NUM+1) * 64 );
	pShMem_->Flush( (void*)&(pToolData_->nNumDataForRelatedTool), len );
}

// nIndex ��° �����͸� �����Ѵ� 
void pa::CPTool::GetRelatedToolData( int nIndex, char* pRet, int len )
{
	if( nIndex < pToolData_->nNumDataForRelatedTool ) {
		memset( (void*)pRet, 0, sizeof(char)*len );
		memcpy( (void*)pRet, (const void*)(pToolData_->szRelateTool[nIndex]), sizeof(char)*strlen(pToolData_->szRelateTool[nIndex]) );
	}
}

// Tool ��ȣ�� 1���� ����. 0�� ���� ���� 
int pa::CPTool::GetNextRelatedToolNo( int nToolNo )
{
	int		index;
	int		toolNo = 0;
	char	szTemp[32];
	BOOL	bFind = FALSE;

	memset((void*)szTemp, 0, sizeof(char)*32);
	sprintf_s( szTemp, 32, "M%d", 140+nToolNo-1 );

	for( index = 0; index<MAX_TOOL_NUM+1; index++ ) {
		if( pToolData_->szRelateTool[index][0]==szTemp[0] &&
			pToolData_->szRelateTool[index][1]==szTemp[1] &&
			pToolData_->szRelateTool[index][2]==szTemp[2] &&
			pToolData_->szRelateTool[index][3]==szTemp[3] )
		{
			bFind = TRUE;
			break;
		}
	}

	if( bFind == FALSE ) {
		// ���� ���� ���� 
		return 0;
	}
	
	// index ��° �����Ϳ��� ���� �� ��ȣ�� ã�´� 
	int len = strlen( pToolData_->szRelateTool[index] );
	int t = 6;
	while( TRUE ) {
		memset((void*)szTemp, 0, sizeof(char)*32);
		szTemp[0] = pToolData_->szRelateTool[index][t++];
		szTemp[1] = pToolData_->szRelateTool[index][t++];
		szTemp[2] = pToolData_->szRelateTool[index][t++];
		toolNo = (int)atoi(szTemp) - 140 +1;
		// tool no�� �ش��ϴ� ���� ������� Ȯ���Ѵ�
		if( pToolData_->hTool[toolNo].fUsingRate < 99.0 ) {
			break;
		}
		// ���� �������� Ȯ���Ѵ� 
		t += 2;
		if( t > len ) {
			toolNo = 0;
			break;
		}
	}

	return toolNo;
}

