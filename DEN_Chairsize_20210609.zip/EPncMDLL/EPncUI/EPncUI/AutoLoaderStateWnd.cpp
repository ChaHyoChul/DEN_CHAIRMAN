// AutoLoaderStateWnd.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "AutoLoaderStateWnd.h"

#define AL_STATE_NUM 3		// There are three states of AL to keep track of

//////////////////////////////////////////////////////////////////////////
// CAutoLoaderStateWnd
//////////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC(CAutoLoaderStateWnd, CWnd)

CAutoLoaderStateWnd::CAutoLoaderStateWnd()
{
	pCanvasCE_	= NULL;
	nNumBlock_	= 20;
	for( int i = 0; i<100; i++ ) {
		hBlockState_[i] = pa::BLOCK_STATE_NUM;
		slotHolderNum_[i] = -1;
	}
	nWorkIndex_ = -1;

	bIsLBtnDown_	= FALSE;
}

CAutoLoaderStateWnd::~CAutoLoaderStateWnd()
{
}

BOOL CAutoLoaderStateWnd::Create( CWnd* pParent, CRect rcWnd, int nNumBlock )
{
	nNumBlock_ = nNumBlock;

	return CWnd::Create( NULL, NULL, WS_VISIBLE | WS_CHILD, rcWnd, pParent, 0, NULL );
}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CAutoLoaderStateWnd, CWnd)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_TIMER()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CAutoLoaderStateWnd �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

int CAutoLoaderStateWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	CDC*	pDC = GetDC();
	CRect	rcWnd;
	GetClientRect( &rcWnd );
	//////////////////////////////////////////////////////////////////////////

	pCanvasCE_ = new hcutil::CCanvasCE();
	ASSERT( pCanvasCE_ );
	pCanvasCE_->Create( this, pDC->GetSafeHdc(), rcWnd.Width(), rcWnd.Height(), RGB(1, 1, 0) );
	int nGround		= pCanvasCE_->GetCanvasCELayerMgr()->Add( TRUE, RGB(1, 1, 0) );		// 0 : ground index
	int nBkgndIndex = pCanvasCE_->GetCanvasCELayerMgr()->Add( TRUE, RGB(1, 1, 0) );		// 1 : background index	
	int nStateIndex = pCanvasCE_->GetCanvasCELayerMgr()->Add( TRUE, RGB(1, 1, 0) );		// 2 : state display index 
	int nWorkIndex  = pCanvasCE_->GetCanvasCELayerMgr()->Add( TRUE, RGB(1, 1, 0) );		// 3 : work  display index 

	//////////////////////////////////////////////////////////////////////////
	ReleaseDC( pDC ); 
	pDC = NULL;

	//////////////////////////////////////////////////////////////////////////

	fntIndex_.CreateFont( 
		14, 0, 
		0, 0, FW_BOLD,
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("MS Sans Serif") );	//_T("Courier New") ); //_T("MS Sans Serif") );

	//////////////////////////////////////////////////////////////////////////
// 	if( pmac::PAutoLoader->IsUsingAutoLoader() ) 
// 	{
// 		clrBlockState_[pmac::BLOCK_STATE_EMPTY]		= RGB(220, 220, 220);			// ������ ���� 
// 		clrBlockState_[pmac::BLOCK_STATE_BEFORE]	= RGB(250, 150,  50);			// �۾� �� 
// 		clrBlockState_[pmac::BLOCK_STATE_RUNNING]	= RGB(  0, 255,   0);			// �۾� �� 
// 		clrBlockState_[pmac::BLOCK_STATE_COMPLETE]	= RGB(140, 140, 180);			// �۾� �Ϸ� 
// 		clrBlockState_[pmac::BLOCK_STATE_ERROR]		= RGB(255,   0,   0);			// �۾� �� ���� 
// 		clrBlockState_[pmac::BLOCK_STATE_LOST]		= RGB(230, 150, 230);			// �۾� ���� �Ҿ� ����. ToStop���� ������ �������� ���� ���. ���� Block ���� ������ ������� ���� ��� ������� �ʴ´�  
// 		clrBlockState_[pmac::BLOCK_STATE_NUM]		= RGB(0, 0, 0);	
// 		clrBackground_	= RGB(32, 32, 200);
// 	}
// 	else 
// 	{
// 		clrBlockState_[pmac::BLOCK_STATE_EMPTY]		= RGB(64, 64, 180);				// ������ ���� 
// 		clrBlockState_[pmac::BLOCK_STATE_BEFORE]	= RGB(64, 64, 180);				// �۾� �� 
// 		clrBlockState_[pmac::BLOCK_STATE_RUNNING]	= RGB(64, 64, 180);				// �۾� �� 
// 		clrBlockState_[pmac::BLOCK_STATE_COMPLETE]	= RGB(64, 64, 180);				// �۾� �Ϸ� 
// 		clrBlockState_[pmac::BLOCK_STATE_ERROR]		= RGB(64, 64, 180);				// �۾� �� ���� 
// 		clrBlockState_[pmac::BLOCK_STATE_LOST]		= RGB(64, 64, 180);				// �۾� ���� �Ҿ� ����. ToStop���� ������ �������� ���� ���. ���� Block ���� ������ ������� ���� ��� ������� �ʴ´�  
// 		clrBlockState_[pmac::BLOCK_STATE_NUM]		= RGB(64, 64, 180);	
// 		clrBackground_	= RGB(32, 32, 200);
// 	}
	resetColorMap();

//	ResetUsingAutoLoader();

	//////////////////////////////////////////////////////////////////////////

	calcLayout();

	drawGround();

	drawBackground();

	return 0;
}

void CAutoLoaderStateWnd::OnDestroy()
{
	fntIndex_.DeleteObject();

	if( pCanvasCE_ ) {
		delete pCanvasCE_;
		pCanvasCE_ = NULL;
	}

	CWnd::OnDestroy();
}

void CAutoLoaderStateWnd::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	if( pCanvasCE_ ) {
		pCanvasCE_->Draw( dc.GetSafeHdc(), dc.m_ps.rcPaint );
	}
}

void CAutoLoaderStateWnd::SetNumBlock( int nNumBlock )
{
	hcutil::CCanvasCELayer* pLayer0 = pCanvasCE_->GetCanvasCELayerMgr()->Get( 0 );
	hcutil::CCanvasCELayer* pLayer1 = pCanvasCE_->GetCanvasCELayerMgr()->Get( 1 );
	hcutil::CCanvasCELayer* pLayer2 = pCanvasCE_->GetCanvasCELayerMgr()->Get( 2 );
	hcutil::CCanvasCELayer* pLayer3 = pCanvasCE_->GetCanvasCELayerMgr()->Get( 3 );

	pLayer0->Clear( FALSE );
	pLayer1->Clear( FALSE );
	pLayer2->Clear( FALSE );
	pLayer3->Clear( FALSE );

	nNumBlock_ = nNumBlock; 

	resetColorMap();

	calcLayout();

	drawGround();

	drawBackground();

	UpdateAutoLoaderState();

	Invalidate( FALSE );
}

void CAutoLoaderStateWnd::calcLayout()
{
	CRect	rcWnd;
	double	fHeight;

	GetClientRect( &rcWnd );

	rcWnd.DeflateRect( 2, 2, 2, 2 );


	fHeight = (double)( rcWnd.Height() ) / (double)( nNumBlock_ + AL_STATE_NUM+1 );

	for( int i=0; i<AL_STATE_NUM+1; i++) {
		alStateBlock_[i].top = rcWnd.bottom - (int)(fHeight*(nNumBlock_+AL_STATE_NUM+1-i)) + 1;
		alStateBlock_[i].bottom = alStateBlock_[i].top + (int)(fHeight);
		alStateBlock_[i].left = 38;
		alStateBlock_[i].right=rcWnd.right;
		alStateBlock_[i].DeflateRect( 1, 1, 1, 1 );

		alStateBlockNames_[i] = alStateBlock_[i];
		alStateBlockNames_[i].left = 0;
		alStateBlockNames_[i].right= 40;
	}

	for( int i = 0; i<nNumBlock_; i++ ) {
		// ������ �۾� ���� ��� 
		rcBlock_[i].left	= 38;
		rcBlock_[i].top		= rcWnd.bottom - (int)(fHeight*(i+1)) + 1;
		rcBlock_[i].right	= rcWnd.right;
		rcBlock_[i].bottom	= rcBlock_[i].top + (int)(fHeight);
		rcBlock_[i].DeflateRect( 1, 1, 1, 1 );

		// �ε��� ���� ��� ���� 
		rcIndex_[i] = rcBlock_[i];		
		rcIndex_[i].left = 0;
		rcIndex_[i].right= 20;

		// 
		rcWork_[i] = rcBlock_[i];
		rcWork_[i].left = rcIndex_[i].right;
		rcWork_[i].right= rcBlock_[i].left;

		rcBlock_[i].DeflateRect( 1, 1, 1, 1 );
	}
}

void CAutoLoaderStateWnd::drawGround()
{
	hcutil::CCanvasCELayer* pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get( 0 );

	COLORREF clrTemp;

	if( pa::PAutoLoader->IsUsingAutoLoader() == TRUE ) {
		if( bIsLBtnDown_ ) {
			clrTemp = clrBackground_Push_;
		} else {
			clrTemp = clrBackground_Normal_;
		}
	} else {
		clrTemp = clrBackground_Normal_;
	}

	CRect rc( 0, 0, pCanvasCE_->GetWidth(), pCanvasCE_->GetHeight() );

	pLayer->FillSolidRect( &rc, clrTemp );

	Invalidate( FALSE );
}

void CAutoLoaderStateWnd::drawBackground()
{
	hcutil::CCanvasCELayer*	pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get( 1 );	// background index is 0

	for( int i = 0; i<nNumBlock_; i++ ) {
		CRect	rcTemp = rcBlock_[i];
		rcTemp.DeflateRect( 2, 0, 2, 0 );
		pLayer->FillSolidRect( &rcTemp, RGB( 128, 128, 128 ) );
	}

	for( int i = 0; i<nNumBlock_; i++ ) {
		hBlockState_[i] = pa::BLOCK_STATE_EMPTY;
		slotHolderNum_[i] = -1;
		drawBlockState( i, TRUE );
	}

	for( int i = 0; i<nNumBlock_; i++ ) {
		CRect rcTemp = rcWork_[i];
		rcTemp.DeflateRect( 1, 1, 1, 1 );;
		pLayer->FillSolidRect( &rcTemp, clrIndexText_ );
	}

	for( int i = 0; i<AL_STATE_NUM; i++ ) {
		CRect rcTemp = alStateBlock_[i];
		rcTemp.DeflateRect( 2, 0, 2, 0 );
		pLayer->FillSolidRect( &rcTemp, RGB( 128, 128, 128 ) );
	}

	CString		strIndex;
	int			prevBkMode = pLayer->SetBkMode( TRANSPARENT );
	COLORREF	clrOld = pLayer->SetTextColor( clrIndexText_ );
	CFont		*pOldFont = (CFont*)pLayer->SelectObject( &fntIndex_ );

	for( int i = 4; i<nNumBlock_; i+=5 ) {
		strIndex.Format( _T("%d"), i+1 );
		pLayer->DrawText( strIndex, rcIndex_[i], DT_CENTER|DT_VCENTER|DT_SINGLELINE );
	}

	pLayer->DrawText( CString("WORK"), alStateBlockNames_[0], DT_VCENTER|DT_SINGLELINE );
	pLayer->DrawText( CString("GRIP"), alStateBlockNames_[1], DT_VCENTER|DT_SINGLELINE );
	pLayer->DrawText( CString("HAND"), alStateBlockNames_[2], DT_VCENTER|DT_SINGLELINE );

	pCanvasCE_->SelectObject( pOldFont );
	pCanvasCE_->SetBkMode( prevBkMode );
	pCanvasCE_->SetTextColor( clrOld );
}

void CAutoLoaderStateWnd::drawBlockState( int nIndex, BOOL bRedraw )
{
	if( nIndex >= nNumBlock_ ) {
		return ;
	}

	hcutil::CCanvasCELayer* pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get( 2 );
	CRect	rcBlock = rcBlock_[nIndex];

	rcBlock.DeflateRect( 3, 1, 3, 1 );

	pLayer->FillSolidRect( &rcBlock, clrBlockState_[hBlockState_[nIndex]] );

	if (slotHolderNum_[nIndex] >= 0) {
		CString holderNumStr;

		holderNumStr.Format( _T("%d"), slotHolderNum_[nIndex] );
		pLayer->DrawText( holderNumStr, &rcBlock, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
	}
	else {
		if( pa::MODEL_INFO.GetAutoLoaderType() == pa::SModelInfo2::AL_TYPE_DISK && 
			pa::PAutoLoader->GetBlockState(nIndex) != pa::BLOCK_STATE_EMPTY )
		{
			// 2017.07.25 bychul2. 
			// Disk Holder�� ����ϴ� ��쿡��, 
			// Holder ��ȣ�� <0 �̸� unknown���� ǥ�� �Ѵ� 
			pLayer->DrawText( _T("unknown"), &rcBlock, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
		}
	}
	
	if( bRedraw ) {
		InvalidateRect( rcBlock_[nIndex] );
	}
}

void CAutoLoaderStateWnd::drawAutoLoaderStates( BOOL bRedraw )
{
	hcutil::CCanvasCELayer* pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get( 2 );
	CRect	rcBlock;
	CString itemNumberStr;
	int itemNumber;

	rcBlock = alStateBlock_[0];
	rcBlock.DeflateRect( 3, 1, 3, 1 );
	
	pLayer->FillSolidRect( &rcBlock, RGB(240, 240, 240) );

	for(int i=0; i<AL_STATE_NUM; i++) {
		rcBlock = alStateBlock_[i];
		rcBlock.DeflateRect( 3, 1, 3, 1 );
		
		pLayer->FillSolidRect( &rcBlock, RGB(240, 240, 240) );

		// TODO: not the best style...
		switch (i) {
			case 0:
				itemNumber = pa::PAutoLoader->GetWorkSpaceItemNumber();
				break;
			case 1:
				itemNumber = pa::PAutoLoader->GetItemPasserItemNumber();
				break;
			case 2:
				itemNumber = pa::PAutoLoader->GetAutoLoaderHandItemNumber();
				break;
		}
	
// 		if ( itemNumber < 0 ) {
// 			BOOL isEmpty =
// 				( i == 0 ) && ( !pa::PPAStatus->GetPAStatus()->bInput[pa::IN20017_DetectedBlock] ) ||
// 				( i == 1 ) && ( !pa::PPAStatus->GetPAStatus()->bInput[pa::IN20016_AutoLoader_PNC_Sensing_Item] ) ||
// 				( i == 2 ) && ( !pa::PPAStatus->GetPAStatus()->bInput[pa::IN20028_AutoLoader_Sensing_Block] );
// 
// 			itemNumberStr = isEmpty ? CString("empty") : CString("unknown");
// 		} else {
// 			itemNumberStr.Format( _T("%d"), itemNumber );
// 		}

		pLayer->DrawText( itemNumberStr, &rcBlock, DT_CENTER|DT_VCENTER|DT_SINGLELINE );

		if( bRedraw ) {
			InvalidateRect( alStateBlock_[i] );
		}
	}
}

void CAutoLoaderStateWnd::drawWorkIndex( int nIndex )
{
	BOOL bErase = ( nIndex >= nNumBlock_ || pa::PAutoLoader->IsUsingAutoLoader() == FALSE );

	CString str;
	str.Format( _T("drawWorkIndex : %d\n"), nIndex );
	TRACE( str );

	hcutil::CCanvasCELayer* pLayer = pCanvasCE_->GetCanvasCELayerMgr()->Get( 3 );

	CRect rcWork = rcWork_[nIndex];
	rcWork.DeflateRect( 3, 3, 3, 3 );
	pLayer->Clear( TRUE );

	if( !bErase )
	{
		pLayer->FillSolidRect( &rcWork, RGB(94, 208, 94) );
	}

	InvalidateRect( rcWork_[nIndex] );
}

//////////////////////////////////////////////////////////////////////////

void CAutoLoaderStateWnd::OnLButtonDown(UINT nFlags, CPoint point)
{
	static int nWGap = 30; 
	static int nHGap = 0; 

#ifndef _DEBUG
	if( pa::PAutoLoader->IsUsingAutoLoader() == TRUE &&
		pa::PPAStatus->GetThreadState()->hRunMode == pa::RUNMODE_STOP )
	{
		if( pa::PPAStatus->GetThreadState()->hRunMode == pa::RUNMODE_STOP ) {
			if( ( point.x>nWGap && point.x<pCanvasCE_->GetWidth()-nWGap ) &&
				( point.y>nHGap && point.y<pCanvasCE_->GetHeight()-nHGap ) )
			{
				SetTimer( 1, 200, NULL );
			}
		}

		bIsLBtnDown_	= TRUE;

		drawGround();
	}
#else 
	if( pa::PAutoLoader->IsUsingAutoLoader() == TRUE )
	{
		if( pa::PPAStatus->GetThreadState()->hRunMode == pa::RUNMODE_STOP ) {
			if( ( point.x>nWGap && point.x<pCanvasCE_->GetWidth()-nWGap ) &&
				( point.y>nHGap && point.y<pCanvasCE_->GetHeight()-nHGap ) )
			{
				SetTimer( 1, 200, NULL );
			}
		}

		bIsLBtnDown_	= TRUE;

		drawGround();
	}
#endif 

	CWnd::OnLButtonDown(nFlags, point);
}

// ReFill Block ������� ����Ѵ� 
void CAutoLoaderStateWnd::OnLButtonUp(UINT nFlags, CPoint point)
{
	KillTimer( 1 );

	bIsLBtnDown_ = FALSE;

	drawGround();

	CWnd::OnLButtonUp(nFlags, point);
}

void CAutoLoaderStateWnd::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 1 ) 
	{
		KillTimer( 1 );

		bIsLBtnDown_ = FALSE;

		drawGround();

		if( !pa::PPAStatus->GetThreadState()->bRemoteLock_ ) 
		{
			::SendMessage( GetParent()->GetSafeHwnd(), WM_AUTOLOADER_REFILL, 0, 0 );
		}
	}

	CWnd::OnTimer(nIDEvent);
}

//////////////////////////////////////////////////////////////////////////
// �ֱ������� AutoLoader�� ���¸� ���� �Ѵ� 
// ���� ���°� �ٸ��͸� �ٽ� ��� �Ѵ� 
void CAutoLoaderStateWnd::UpdateAutoLoaderState()
{
	for( int i = 0; i<nNumBlock_; i++ ) 
	{
		pa::EN_AUTOLOADER_BLOCK_STATE hTempBlockState = pa::PAutoLoader->GetBlockState( i );
		int tempHolderNumber = pa::PAutoLoader->GetItemNumberFromSlotIndex( i );

		if( hBlockState_[i] != hTempBlockState || slotHolderNum_[i] != tempHolderNumber )
		{
			// ���� ���¸� Update �Ѵ� 
			hBlockState_[i] = hTempBlockState;
			slotHolderNum_[i] = tempHolderNumber;
			drawBlockState( i, TRUE );
		}
	}

	drawAutoLoaderStates( TRUE );

	if( nWorkIndex_ != pa::PAutoLoader->GetWorkIndex() ) 
	{
		nWorkIndex_ = pa::PAutoLoader->GetWorkIndex();
		drawWorkIndex( nWorkIndex_ );
	}
}

//////////////////////////////////////////////////////////////////////////

void CAutoLoaderStateWnd::ResetUsingAutoLoader()
{
	resetColorMap();

	//////////////////////////////////////////////////////////////////////////
	// 2016.11.21 �߰� 
	calcLayout();

	drawGround();
	//////////////////////////////////////////////////////////////////////////

	if( pa::PAutoLoader->IsUsingAutoLoader() ) {
		nWorkIndex_ = pa::PAutoLoader->GetWorkIndex();
	} else {
		nWorkIndex_ = -1;
	}

	//////////////////////////////////////////////////////////////////////////

	drawBackground();

	for( int i = 0; i<nNumBlock_; i++ ) 
	{
		drawBlockState( i, FALSE );
	}

	drawAutoLoaderStates( FALSE );

	drawWorkIndex( nWorkIndex_ );

	Invalidate( TRUE );
}

//////////////////////////////////////////////////////////////////////////

void CAutoLoaderStateWnd::resetColorMap()
{
	// ds200 
	if( pa::PAutoLoader->IsUsingAutoLoader() ) 
	{
		clrBlockState_[pa::BLOCK_STATE_EMPTY]	= RGB(220, 220, 220);			// ������ ���� 
		clrBlockState_[pa::BLOCK_STATE_BEFORE]	= RGB(250, 200, 180);			// RGB(250, 180, 100);			// �۾� �� 
		clrBlockState_[pa::BLOCK_STATE_RUNNING]	= RGB(93, 208, 93);				// RGB(  0, 255,   0);			// �۾� �� 
		clrBlockState_[pa::BLOCK_STATE_COMPLETE]= RGB(125, 200, 240);			// RGB(160, 160, 190);			// �۾� �Ϸ� 
		clrBlockState_[pa::BLOCK_STATE_ERROR]	= RGB(255, 100, 100);			// RGB(220, 100, 100);			// �۾� �� ���� 
		clrBlockState_[pa::BLOCK_STATE_LOST]	= RGB(233, 211, 232);			//RGB(220, 180, 220);			// �۾� ���� �Ҿ� ����. ToStop���� ������ �������� ���� ���. ���� Block ���� ������ ������� ���� ��� ������� �ʴ´�  
		clrBlockState_[pa::BLOCK_STATE_NUM]		= RGB(0, 0, 0);	
		clrBackground_Normal_	= RGB(235, 234, 239);	//RGB(255, 255, 255);
		clrBackground_Disable_	= RGB(235, 234, 239);	//RGB(255, 255, 255);
		clrBackground_Push_		= RGB(94, 208, 94 );	//RGB(120, 120, 144);
		clrIndexText_ = RGB( 134, 134, 136 );
	}
	else 
	{
		clrBlockState_[pa::BLOCK_STATE_EMPTY]	= RGB(230, 230, 230);			// ������ ���� 
		clrBlockState_[pa::BLOCK_STATE_BEFORE]	= RGB(230, 230, 230);			// �۾� �� 
		clrBlockState_[pa::BLOCK_STATE_RUNNING]	= RGB(230, 230, 230);			// �۾� �� 
		clrBlockState_[pa::BLOCK_STATE_COMPLETE]= RGB(230, 230, 230);			// �۾� �Ϸ� 
		clrBlockState_[pa::BLOCK_STATE_ERROR]	= RGB(230, 230, 230);			// �۾� �� ���� 
		clrBlockState_[pa::BLOCK_STATE_LOST]	= RGB(230, 230, 230);			// �۾� ���� �Ҿ� ����. ToStop���� ������ �������� ���� ���. ���� Block ���� ������ ������� ���� ��� ������� �ʴ´�  
		clrBlockState_[pa::BLOCK_STATE_NUM]		= RGB(230, 230, 230);	
		clrBackground_Normal_	= RGB(235, 234, 239);	//RGB(255, 255, 255);
		clrBackground_Disable_	= RGB(235, 234, 239);	//RGB(255, 255, 255);
		clrBackground_Push_		= RGB(235, 234, 239);	//RGB(255, 255, 255);
		clrIndexText_ = RGB(210, 210, 210 );
	}
}

