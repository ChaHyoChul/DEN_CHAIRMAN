#pragma once

#include "PointDataListBox.h"
#include "TitleBarWnd.h"

// CSetupTeachingCoordOffsetDlg ��ȭ �����Դϴ�.

class CSetupTeachingCoordOffsetDlg : public CDialogListPage
{
	DECLARE_DYNCREATE(CSetupTeachingCoordOffsetDlg)

	CTitleBarWnd*		pTitleBarWnd_;
	CPointDataListBox*	pCoordOffsetListBox_;

	CRect	CUIrectSTCO; 

	void update_CoordOffsetListBox();

public:
	CSetupTeachingCoordOffsetDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupTeachingCoordOffsetDlg();

	virtual void StartPageWork();
	virtual void StopPageWork();
	virtual void UpdatePage();

	void UpdateCoordOffsetListBox() {
		update_CoordOffsetListBox();
	}

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_TEACHING_COORD_OFFSET };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	LRESULT OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
