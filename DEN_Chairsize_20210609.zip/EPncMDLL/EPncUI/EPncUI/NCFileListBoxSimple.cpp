// NCFileListBoxSimple.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "NCFileListBoxSimple.h"


//////////////////////////////////////////////////////////////////////////
// CNCFileListBoxSimple
//////////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC(CNCFileListBoxSimple, CListBox)

CNCFileListBoxSimple::CNCFileListBoxSimple()
{
	clrBkgnd_ = RGB( 128, 128, 128 );

	szFont_.SetSize( 16, 10 );
	nItemHeight_ = 24; 
}

CNCFileListBoxSimple::~CNCFileListBoxSimple()
{
}

void CNCFileListBoxSimple::SetBackgroundColor( COLORREF clrBkgnd )
{
	clrBkgnd_ = clrBkgnd;
}

void CNCFileListBoxSimple::SetFontSize( int nCX, int nCY )
{
	szFont_.SetSize( nCX, nCY );
}

void CNCFileListBoxSimple::SetItemHeight( int nItemHeight )
{
	nItemHeight_ = nItemHeight;
}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CNCFileListBoxSimple, CListBox)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_CTLCOLOR_REFLECT()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CNCFileListBoxSimple �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CNCFileListBoxSimple::PreCreateWindow(CREATESTRUCT& cs)
{
// 	cs.style |= WS_VSCROLL /*| WS_TABSTOP*/ | LBS_OWNERDRAWVARIABLE | LBS_NOINTEGRALHEIGHT | LBS_HASSTRINGS | LBS_NOTIFY;	
	cs.style |= WS_VSCROLL /*| WS_TABSTOP*/ | LBS_OWNERDRAWFIXED | LBS_NOINTEGRALHEIGHT | LBS_HASSTRINGS | LBS_NOTIFY;	

	return __super::PreCreateWindow(cs);
}

void CNCFileListBoxSimple::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	lpMeasureItemStruct->itemHeight = nItemHeight_;	// ��Ʈ�� Ű��� ����, Height ���� Ű���� �Ѵ� 
}

int CNCFileListBoxSimple::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (__super::OnCreate(lpCreateStruct) == -1)
		return -1;

	// Font 
	hFont_.CreateFont( 
		szFont_.cy, szFont_.cx, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Courier New") ); //_T("MS Sans Serif") );
	SetFont( &hFont_, TRUE );

	// Background's brush 
	brhBkgnd_.CreateSolidBrush( clrBkgnd_ );

	//
	CRect rc;
	GetClientRect( &rc );
	nLineNumPerCtrl_ = (int)( (double)(rc.Height()) / (double)nItemHeight_ );

	return 0;
}

void CNCFileListBoxSimple::OnDestroy()
{
	hFont_.DeleteObject();
	brhBkgnd_.DeleteObject();

	__super::OnDestroy();
}

HBRUSH CNCFileListBoxSimple::CtlColor(CDC* /*pDC*/, UINT /*nCtlColor*/)
{
	return brhBkgnd_;
}

void CNCFileListBoxSimple::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
// 	static const int nCharPerLine	= 44;		// ���δ� ���ڰ��� 40�� 
// 	static const int nCheckBoxWidth = 32;		// �� Check �ڽ� ���� ũ�� 
// 	static const int nFileSizeWidth = 56;		// File ũ�� ��� ���� ũ�� 
// 	static const int nCharPerLine	= 40;		// ���δ� ���ڰ��� 40�� 

	static const int nCharPerLine	= 42;		// ���δ� ���ڰ��� 40�� 
	static const int nCheckBoxWidth = 42;		// �� Check �ڽ� ���� ũ�� 
	static const int nFileSizeWidth = 56;		// File ũ�� ��� ���� ũ�� 

	CDC		hDC;
	pa::SNCFileInfo*	pInfo = (pa::SNCFileInfo*)lpDrawItemStruct->itemData;
	CRect	rcItem = lpDrawItemStruct->rcItem;
	int		nPrevMode;
	CRect	rcCheckBox;
	CRect	rcFilePath;
	CRect	rcFileSize;
	CRect	rcFileSelect;

	hDC.Attach( lpDrawItemStruct->hDC );
	nPrevMode = hDC.SetBkMode( TRANSPARENT );

	int nFilePathWidth = rcItem.Width() - nCheckBoxWidth - nFileSizeWidth;

	rcCheckBox = rcItem; rcCheckBox.right = nCheckBoxWidth;
	rcFilePath = rcItem; rcFilePath.left = nCheckBoxWidth+1; rcFilePath.right = rcFilePath.left + nFilePathWidth;
	rcFileSize = rcItem; rcFileSize.left = rcItem.Width() - nFileSizeWidth + 1;
	rcFileSelect = rcFilePath;

	//////////////////////////////////////////////////////////////////////////
	// Draw Grid
	hDC.FillSolidRect( rcItem, RGB(180, 180, 180) );
	hDC.Draw3dRect( &rcCheckBox, RGB(128, 128, 128), RGB(64, 64, 64) );			// check box ���� 
	hDC.FillSolidRect( &rcFilePath, pa::CLR_NC_FILESTATE[pInfo->state] );		//
	hDC.Draw3dRect( &rcFilePath, RGB(128, 128, 128), RGB(64, 64, 64) );			// filename ���� 
	hDC.Draw3dRect( &rcFileSize, RGB(128, 128, 128), RGB(64, 64, 64) );			// filesize ���� 

	//////////////////////////////////////////////////////////////////////////
	// Draw CheckBox
	if( pInfo->is_select != 0 ) {
		hDC.DrawFrameControl( &rcCheckBox, DFC_BUTTON, DFCS_BUTTONCHECK | DFCS_CHECKED );
	} else {
		hDC.DrawFrameControl( &rcCheckBox, DFC_BUTTON, DFCS_BUTTONCHECK );
	}

	//////////////////////////////////////////////////////////////////////////
	// Draw FilePath 
	CString strTempFilePath;
	strTempFilePath.Format( _T("%s"), pInfo->file_name );
	strTempFilePath.Insert( nCharPerLine, _T("\r\n") );

	if( pInfo->is_select_updown ) {
		rcFileSelect.DeflateRect( 2, 2, 2, 2 );
// 		hDC.Draw3dRect( &rcFileSelect, RGB(250, 100, 100), RGB(150, 32, 32) );
		hDC.Draw3dRect( &rcFileSelect, RGB(200, 200, 200), RGB(64, 64, 64) );
		rcFileSelect.DeflateRect( 1, 1, 1, 1 );
// 		hDC.Draw3dRect( &rcFileSelect, RGB(250, 100, 100), RGB(150, 32, 32) );
		hDC.Draw3dRect( &rcFileSelect, RGB(200, 200, 200), RGB(64, 64, 64) );
	}

	rcFilePath.DeflateRect( 6, 4 ,6, 4 );
	hDC.DrawText( strTempFilePath, &rcFilePath, DT_LEFT );

	//////////////////////////////////////////////////////////////////////////
	// Draw FileSize 
	CString strFileSize;

	if( pInfo->file_size == 0 ) {
		strFileSize.Format( _T("0.0\r\nbyte") );
	} else {
		if( pInfo->file_size > 1024 * 1024 ) {
			// MB
			strFileSize.Format( _T("%.1f\r\nMB"), (double)pInfo->file_size / ( 1024.0 * 1024.0 ) );
		} 
		else if( pInfo->file_size > 1024 ) {
			// KB
			strFileSize.Format( _T("%.1f\r\nKB"), (double)pInfo->file_size / ( 1024.0 ) );
		}
		else {
			// byte
			strFileSize.Format( _T("%d\r\nbyte"), pInfo->file_size );
		}
	}
	rcFileSize.DeflateRect( 4, 2, 4, 2 );
	hDC.DrawText( strFileSize, &rcFileSize, DT_CENTER );


	hDC.SetBkMode( nPrevMode );

	hDC.Detach();
}

// ~ 42| ~ |56~
void CNCFileListBoxSimple::OnLButtonUp(UINT nFlags, CPoint point)
{
	int		nCurSel = GetCurSel();

	if( nCurSel >= 0 ) 
	{
		CRect	rcCheck, rcFilePath, rcWnd;
		GetItemRect( nCurSel, rcCheck );
		rcFilePath = rcCheck;
		GetClientRect( &rcWnd );
		rcCheck.right = 45;
		rcFilePath.left = 50;
		rcFilePath.right-= 60;
	
		// checking ���� 
		if( rcCheck.PtInRect( point ) == TRUE ) 
		{
			int i = pa::PNCFileMgr->GetNCFileSelect( nCurSel );
			pa::PNCFileMgr->SetNCFileSelect( nCurSel, ( i == 0 ? 1 : 0 ), TRUE );
		}
		// filepath ���� 
		else if( rcFilePath.PtInRect( point ) == TRUE ) 
		{
			int i = pa::PNCFileMgr->GetNCFileSelectUpDown( nCurSel );
			pa::PNCFileMgr->SetNCFileSelectUpDown( nCurSel, ( i == 0 ? 1 : 0 ), TRUE );
		}
		
		//
		// ��ũ�� ���� Ȯ�� 
		int		scroll_pos	= GetScrollPos( 1 );
		CRect	rcScroll	= rcWnd;
		rcScroll.left	= rcScroll.right - 45;
		rcScroll.bottom	= rcWnd.Height() / 3;
		if( scroll_pos > 0 && rcScroll.PtInRect( point ) == TRUE ) {
			// Scroll Up
			SetTopIndex( scroll_pos - 1 );
		}

		rcScroll.top	= rcScroll.bottom * 2;
		rcScroll.bottom	= rcWnd.bottom;
		if( scroll_pos < GetCount() && rcScroll.PtInRect( point ) == TRUE ) {
			// Scroll Down
			SetTopIndex( scroll_pos + 1 );
		}
	}

	__super::OnLButtonUp(nFlags, point);
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

void CNCFileListBoxSimple::UpdateFileList()
{
	int nCount = 0;

	// ����Ʈ���� ��� ������ ���� 
	nCount = GetCount();
	for( int i = 0; i<nCount; i++ ) {
		DeleteString( 0 );
	}

	// ����Ʈ�� NC File ������ �߰� 
	nCount = pa::PNCFileMgr->GetNumNCFile();
	for( int i = 0; i<nCount; i++ ) {
		pa::SNCFileInfo* pInfo = pa::PNCFileMgr->GetNCFileInfo( i );
		if( pInfo ) {
			int index = AddString(_T(""));
			SetItemDataPtr( index, pInfo );
		}
	}
}

void CNCFileListBoxSimple::SelectAll()
{
	int nCount = 0;

	nCount = GetCount();
	for( int i = 0; i<nCount; i++ ) 
	{
		pa::PNCFileMgr->SetNCFileSelect( i, 1, TRUE );
	}
}

void CNCFileListBoxSimple::UnselectAll()
{
	int nCount = 0;

	nCount = GetCount();
	for( int i = 0; i<nCount; i++ ) 
	{
		pa::PNCFileMgr->SetNCFileSelect( i, 0, TRUE );
	}
}

// ���� �ִ� ���� ���� �ø���. �� �ö󰡸� ���� ���ϵ� �ø��� �ʴ´� 
// ù��° ������ ���õǾ� ������ ��� �ø��� �� �Ѵ� 
// ù��° ������ ȭ�鿡�� �Ⱥ��̸�, ����Ʈ�� �� ���� ���̵��� �����Ѵ� 
void CNCFileListBoxSimple::MoveUp()
{
	int		nCount = 0;

	nCount = GetCount();
	for( int i = 0; i<nCount; i++ ) {
		pa::SNCFileInfo* pInfo = pa::PNCFileMgr->GetNCFileInfo( i );
		if( pInfo && pInfo->is_select_updown != 0 ) {
			if( i == 0 ) {
				break;
			}

			pa::PNCFileMgr->MoveUpWorkNCFileInfo( i, TRUE );	// NCFileMgr���� ���� 
															// ���� �� Observer�� ���ؼ� ȭ�� ���� �Լ��� ȣ���Ѵ� 
															// NCFMObsvr_MoveUpNCFile()
			if( i-1 < GetTopIndex() ) {
				SetTopIndex( i-1 );
			}
		}
	}
}

// �Ʒ� �ִ� ���Ϻ��� ������. �� �������� ���� ���ϵ� ������ �� �Ѵ� 
// ������ ������ ���õǸ� ��� ������ �� �Ѵ� 
void CNCFileListBoxSimple::MoveDown()
{
	int	nCount = 0;

	nCount = GetCount();
	for( int i = nCount-1; i>=0; i-- ) {
		pa::SNCFileInfo* pInfo = pa::PNCFileMgr->GetNCFileInfo( i );
		if( pInfo && pInfo->is_select_updown != 0 ) {
			if( i == nCount-1 ) {
				break;
			}
			
			pa::PNCFileMgr->MoveDownWorkNCFileInfo( i, TRUE );

			int topindex = GetTopIndex();
			if( (i+1) > topindex+nLineNumPerCtrl_ ) {
				SetTopIndex( (i+1)-nLineNumPerCtrl_ );
			}
		}
	}
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

// ����Ʈ �������� ���� �۾��� ��� 
void CNCFileListBoxSimple::NCFMObsvr_AddNewNCFile()
{
	UpdateFileList();
}

// nIndex ��° ���� �۾��� ��� 
void CNCFileListBoxSimple::NCFMObsvr_InsertNewNCFile( int nIndex )
{
	UpdateFileList();
}

// nIndex ��° �۾� ������ ����
void CNCFileListBoxSimple::NCFMObsvr_RemoveNCFile( int nIndex ) 
{
	UpdateFileList();
}

// nIndex ��° �۾� ������ Up
// nIndex ��° �����Ϳ� nIndex-1 ��° �����͸� ��ȯ 
void CNCFileListBoxSimple::NCFMObsvr_MoveUpNCFile( int nIndex )
{
//	UpdateFileList();

	Invalidate( TRUE );
}

// nIndex ��° �۾� ������ Down  
void CNCFileListBoxSimple::NCFMObsvr_MoveDownNCFile( int nIndex )
{
//	UpdateFileList();

	Invalidate( TRUE );
}

// nIndex ��° �۾� ������ ���� �� 
void CNCFileListBoxSimple::NCFMObsvr_SetCurrentWorkIndex( int nIndex )
{
//	UpdateFileList();
	
	CRect rect;
	GetItemRect( nIndex, &rect );
	InvalidateRect( &rect );
}

// nIndex ��° �۾� ������ ������ Update �Ѵ� 
void CNCFileListBoxSimple::NCFMObsvr_UpdateNCFileInfo( int nIndex )
{
// 	UpdateFileList();

	CRect rect;
	GetItemRect( nIndex, &rect );
	InvalidateRect( &rect );
}

void CNCFileListBoxSimple::NCFMObsvr_UpdateNCFileList()
{
	UpdateFileList();
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////


