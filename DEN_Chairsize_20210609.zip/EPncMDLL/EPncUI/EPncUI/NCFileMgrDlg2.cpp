// NCFileMgrDlg2.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "NCFileMgrDlg2.h"
#include "FileCopyDlg.h"
#include "MsgDlgThread.h"

//////////////////////////////////////////////////////////////////////////
//
CNCFileMgrDlg2*	P_NCFILE_MGR_DLG2 = NULL;
//////////////////////////////////////////////////////////////////////////
// CNCFileMgrDlg2 ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CNCFileMgrDlg2, CDialog)

CNCFileMgrDlg2::CNCFileMgrDlg2(CWnd* pParent /*=NULL*/)
	: CDialog(CNCFileMgrDlg2::IDD, pParent)
{

}

CNCFileMgrDlg2::~CNCFileMgrDlg2()
{
}

void CNCFileMgrDlg2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CNCFileMgrDlg2, CDialog)
	ON_WM_DESTROY()
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_REFLASH, &CNCFileMgrDlg2::OnBnClickedButtonReflash)
	ON_BN_CLICKED(IDC_BUTTON_ALL_SELECT, &CNCFileMgrDlg2::OnBnClickedButtonAllSelect)
	ON_BN_CLICKED(IDC_BUTTON_UNSELECT, &CNCFileMgrDlg2::OnBnClickedButtonUnselect)
	ON_BN_CLICKED(IDC_BUTTON_COPY_TO_PC, &CNCFileMgrDlg2::OnBnClickedButtonCopyToPc)
	ON_BN_CLICKED(IDC_BUTTON_QUIT, &CNCFileMgrDlg2::OnBnClickedButtonQuit)
	ON_MESSAGE(WM_NOTIFY_WINDOW_MOVE,&CNCFileMgrDlg2::OnWindowMove )
	ON_WM_SHOWWINDOW()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CNCFileMgrDlg2 �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CNCFileMgrDlg2::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CNCFileMgrDlg2::OnInitDialog()
{
	CDialog::OnInitDialog();

	//////////////////////////////////////////////////////////////////////////
	//
	brhBkgnd_.CreateSolidBrush( RGB(246, 245, 248) );

	brhCopyBtn_.CreateSolidBrush( RGB(0, 164, 255) );
	brhQuitBth_.CreateSolidBrush( RGB(255, 164, 0) );

	//////////////////////////////////////////////////////////////////////////
	//
	fntMenuButton_.CreateFont(		
		// 		18, 0, 
		//		16, 0,
		17, 0,
		0, 0, FW_BOLD,
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") );	//_T("Courier New") ); //_T("MS Sans Serif") );

	((CButton*)GetDlgItem(IDC_BUTTON_REFLASH))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_ALL_SELECT))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_UNSELECT))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_COPY_TO_PC))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_QUIT))->SetFont( &fntMenuButton_, TRUE );

	//////////////////////////////////////////////////////////////////////////
	// listbox ��Ʈ���� �ʱ�ȭ �Ѵ� 
	initialize_FileListBox();

	//////////////////////////////////////////////////////////////////////////
	// ����Ʈ�� ������Ʈ �Ѵ�
	if( pFileListBoxForUSB_ ) {
		pFileListBoxForUSB_->UpdateFileList();
	}

	//////////////////////////////////////////////////////////////////////////
	//
	// 	CRect rcWnd;
	// 	GetWindowRect( &rcWnd );
	// 	rcWnd.MoveToY( 78 );
	// 	rcWnd.MoveToX( 1024 - rcWnd.Width() );
	// 	MoveWindow( &rcWnd, TRUE );

	//////////////////////////////////////////////////////////////////////////
	// GUI ������ ����, Setup ������ ��ġ�� �ٸ��� �Ѵ� 
	CRect rcWnd;
	GetClientRect( &rcWnd );

	rcWnd.MoveToX( 1024 - rcWnd.Width() + 86 );
	rcWnd.MoveToY( 768 - rcWnd.Height() + 140 );
	MoveWindow( &rcWnd, TRUE );
	//////////////////////////////////////////////////////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CNCFileMgrDlg2::OnDestroy()
{
	fntMenuButton_.DeleteObject();
	brhBkgnd_.DeleteObject();
	brhCopyBtn_.DeleteObject();
	brhQuitBth_.DeleteObject();

	destroy_FileListBox();
	
	CDialog::OnDestroy();
}

HBRUSH CNCFileMgrDlg2::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	if( nCtlColor == 4 ) {
		hbr = (HBRUSH)brhBkgnd_;
	}
	else {
		UINT nCtrlID = pWnd->GetDlgCtrlID();
		switch( nCtrlID )
		{
		case IDC_BUTTON_ALL_SELECT: 
			break;
		case IDC_BUTTON_UNSELECT:
			break;
		case IDC_BUTTON_COPY_TO_PC:
			hbr = (HBRUSH)brhCopyBtn_;
			break;
		case IDC_BUTTON_QUIT:
			hbr = (HBRUSH)brhQuitBth_;
			break;
		}
	}

	return hbr;
}

void CNCFileMgrDlg2::initialize_FileListBox()
{
	CRect	rcLB;
	CString strExts[] = { _T(".txt"), _T(".nc"), _T(".TXT"), _T(".NC") };

	hcutil::GetControlPos( IDC_STATIC_LIST_AREA, this, &rcLB, TRUE );

	pFileListBoxForUSB_ = new CFileListBox();
	pFileListBoxForUSB_->SetBackgroundColor( RGB(220, 220, 220) );

	pFileListBoxForUSB_->SetPath( pa::P_USB_NCFILE_PATH );		// ( _T("\\�ϵ� ��ũ") );
	pFileListBoxForUSB_->SetExts( strExts, 4 );
	//	pFileListBoxForUSB_->SetFontSize( 8, 20 );
	pFileListBoxForUSB_->SetFontSize( 0, 16, 60 );
	pFileListBoxForUSB_->SetItemHeight( 44 );
	pFileListBoxForUSB_->Create( WS_CHILD|WS_VISIBLE, rcLB, this, IDC_LISTBOX_USB_NCFILE_LIST ); //IDC_LISTBOX_P2_USBMEM_NCFILE );
}

void CNCFileMgrDlg2::destroy_FileListBox()
{
	if( pFileListBoxForUSB_ ) {
		pFileListBoxForUSB_->DestroyWindow();
		delete pFileListBoxForUSB_;
		pFileListBoxForUSB_ = NULL;
	}
}

void CNCFileMgrDlg2::OnBnClickedButtonReflash()
{
	//////////////////////////////////////////////////////////////////////////
	// ����Ʈ�� ������Ʈ �Ѵ�
	if( pFileListBoxForUSB_ ) {
		pFileListBoxForUSB_->UpdateFileList();
		pFileListBoxForUSB_->Invalidate();
	}
}

void CNCFileMgrDlg2::OnBnClickedButtonAllSelect()
{
	if( pFileListBoxForUSB_ ) {
		pFileListBoxForUSB_->SelectAll();
	}
}

void CNCFileMgrDlg2::OnBnClickedButtonUnselect()
{
	if( pFileListBoxForUSB_ ) {
		pFileListBoxForUSB_->UnselectAll();
	}
}

void CNCFileMgrDlg2::OnBnClickedButtonCopyToPc()
{
	CFileCopyDlg dlg;
	int		nNum = 0;
	CString strFileNames[100];
	CString strOpenedFileName(_T(""));	// ���� �ִ� NC File �̸� 
	int		nNCFileLoading = pa::PNCFileMgr->GetCurrentWorkNCFileIndex();
	int		nOpenedFileIndex = -1;

	// ����Ʈ���� ���õ� �׸��� �����Ѵ� 
	nNum = pFileListBoxForUSB_->GetSelectedFileName( strFileNames );

	// ����Ʈ�� ������ ��ϵ� ������ ������ ���� 
	CString strCopyingFileNames[100];
	int nNumCopyingFiles = 0;
	for( int i = 0; i<nNum; i++ ) {
		if( pa::PNCFileMgr->IsExistNCFile( strFileNames[i] ) == FALSE ) {
			strCopyingFileNames[nNumCopyingFiles++] = strFileNames[i];
		}
	}

	if( nNum != nNumCopyingFiles ) {
		CString strMsg;
	//	strMsg.Format( _T("�̹� ��ϵ� NC ������ %d�� �ֽ��ϴ�\r\n�� ���ϵ��� �������� �ʽ��ϴ�."), nNum - nNumCopyingFiles );
		strMsg.Format( _T("\"%d\"NC Files already exists.\r\nExisting files will not be copied"), nNum - nNumCopyingFiles );
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_WARM, strMsg );
		CMsgDlgThread::GetInstance()->Wait();
	}

	if( nNumCopyingFiles > 0 ) {
		// dlg.SetSrcFileName( strFileNames, nNum );
		dlg.SetSrcFileName( strCopyingFileNames, nNumCopyingFiles );
		dlg.SetSrcPath( pa::P_USB_NCFILE_PATH );
		dlg.SetDstPath( NCFILE_PATH );

		if( dlg.DoModal() == IDOK ) {
			pFileListBoxForUSB_->UnselectAll();
		} else {
			// ������ ���� 
			CString strMsg;
			int		nErrorFileIndex = dlg.GetCopyFileIndex();
			DWORD	dwErrCode = dlg.GetErrCode();

		//	strMsg.Format( _T("%d ��° ���� ������ ����(%d)"), nErrorFileIndex+1, dwErrCode );
			strMsg.Format( _T("Failed to copy (%d/%d) file. (ErrorCode:%d)"), nErrorFileIndex+1, nNum, dwErrCode );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
		}
	}

	// SD �޸��� NC ���� ����Ʈ�� ���� �Ѵ� 
	if( pa::PPAStatus->GetThreadState()->bSendSDMemory_NCFileList_ == FALSE ) {
		pa::PPAStatus->GetThreadState()->bSendSDMemory_NCFileList_ = TRUE;
	}
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	// ������ NC ������ ��� �Ѵ� 
	CString strTemp;
	DWORD	dwFileSize = 0;

	if( nNumCopyingFiles > 0 ) {
		CTime	tm = CTime::GetCurrentTime();
		CString	strDateTime = tm.Format( _T("%y%m%d_%H%M%S") );
		CString strID;

		for( int i = 0; i<nNumCopyingFiles; i++ ) {
			strID.Format( _T("%d_%03d"), strDateTime, i+1 );
			// �۾� �����Ϳ� �߰� �Ѵ� 
			strTemp = strCopyingFileNames[i];
			pa::GET_NCFILE_FULL_PATH( strTemp );
			hcutil::GetFileSize( strTemp, &dwFileSize, strTemp );
			// 2017.06.16 ����� 
// 			pa::PNCFileMgr->AddWorkNCFileInfo( (TCHAR*)(LPCTSTR)strID, (TCHAR*)(LPCTSTR)strCopyingFileNames[i], dwFileSize );
			pa::PNCFileMgr->AddWorkNCFileInfo( (TCHAR*)(LPCTSTR)strID, (TCHAR*)(LPCTSTR)strCopyingFileNames[i], dwFileSize, TRUE );
		}
	}

	// Registered Nc ���� ����Ʈ�� ���� �Ѵ� 
	if( pa::PPAStatus->GetThreadState()->bSendRegistered_NCFileList_ == FALSE ) {
		pa::PPAStatus->GetThreadState()->bSendRegistered_NCFileList_ = TRUE;
	}
	//////////////////////////////////////////////////////////////////////////
}

void CNCFileMgrDlg2::OnBnClickedButtonQuit()
{
	ShowWindow( SW_HIDE );
}

void CNCFileMgrDlg2::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CDialog::OnShowWindow(bShow, nStatus);

	if( bShow )
	{
// 		if( pFileListBoxForUSB_ ) {
// 			pFileListBoxForUSB_->UpdateFileList();
// 			pFileListBoxForUSB_->Invalidate(); 
// 		}
	}
	else 
	{
	}
}

//����â�� ��ġ������ �޾� ������Ʈ
LRESULT CNCFileMgrDlg2::OnWindowMove(WPARAM wparam, LPARAM lparam)
{
	LPPOINT ChangedPos=(LPPOINT)lparam;
	MoveWindow(ChangedPos->x + 512,ChangedPos->y+149, 500, 608);

	return 0;
}
