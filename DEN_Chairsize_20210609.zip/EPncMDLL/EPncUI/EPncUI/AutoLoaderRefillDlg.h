#pragma once
#include "afxcmn.h"
#include "afxwin.h"


// CAutoLoaderRefillDlg ��ȭ �����Դϴ�.

class CAutoLoaderRefillDlg : public CDialog
{
	DECLARE_DYNAMIC(CAutoLoaderRefillDlg)

	BOOL bIsStart_;

	CFont fntButton_;

	DWORD rescanStartTime_;

	void updateButtonState();

	void updateProgress();

public:
	CAutoLoaderRefillDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CAutoLoaderRefillDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_AUTOLOADER_REFILL };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonStop();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonStart();
	afx_msg void OnBnClickedButtonClose();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	CProgressCtrl hProgress_;
	CButton hBtnStart_;
	CButton hBtnStop_;
	CButton hBtnClose_;
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	CButton chkAutoClose_;
};
