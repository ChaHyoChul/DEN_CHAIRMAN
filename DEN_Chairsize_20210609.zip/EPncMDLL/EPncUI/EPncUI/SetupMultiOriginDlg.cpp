// SetupMultiOriginDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "SetupMultiOriginDlg.h"
#include "NumericInputDlg.h"
#include "MsgDlg.h"
#include "MsgDlgThread.h"

// CSetupMultiOriginDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNCREATE(CSetupMultiOriginDlg, CDialogListPage)

CSetupMultiOriginDlg::CSetupMultiOriginDlg(CWnd* pParent /*=NULL*/)
	: CDialogListPage(CSetupMultiOriginDlg::IDD, pParent)
{
	pResourcePath_ = RESOURCE_2_PATH;
}

CSetupMultiOriginDlg::~CSetupMultiOriginDlg()
{
}

void CSetupMultiOriginDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogListPage::DoDataExchange(pDX);
}

void CSetupMultiOriginDlg::StartPageWork()
{
	//////////////////////////////////////////////////////////////////////////
	// ���� Dialog�� ��������, �ݴ´�  
	hCurrSubPage_ = SUB_PAGE_MULTI_ORG;
	pDlgMap_->HideAll();

	//////////////////////////////////////////////////////////////////////////
	// ������ ���ε� 
	upload_to_pc();

	// �����͸� �ӽ� ������ ���� 
	// 	memcpy((void*)&hTempMultiOriginData_, (void*)(pmac::PState->GetMultiOriginData()), sizeof(pmac::SMultiOriginData) );

	//////////////////////////////////////////////////////////////////////////
	//
	reflash_listbox();

	//////////////////////////////////////////////////////////////////////////
	//
	reflash_max_min_data();

// 	bIsModify_ = FALSE;
//	bIsModifyAutoTeach_ = FALSE;

	SetTimer( 1, 500, NULL );
	SetTimer( 2, 100, NULL );
}

void CSetupMultiOriginDlg::StopPageWork()
{
// 	bIsModify_ = FALSE;
// 	bIsModifyAutoTeach_ = FALSE;
	bIsModify_ = TRUE;
	bIsModifyAutoTeach_ = TRUE;

	KillTimer( 1 );
	KillTimer( 2 );
}

void CSetupMultiOriginDlg::UpdatePage()
{

}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CSetupMultiOriginDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, &CSetupMultiOriginDlg::OnBnClickedButtonClose)
	ON_MESSAGE(WM_NOTIFY_OPTIONDATA_LISTBOX, &CSetupMultiOriginDlg::OnNotifyPointDataListBox)
	ON_WM_CTLCOLOR()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_DOWNLOAD_TO_CTRL, &CSetupMultiOriginDlg::OnBnClickedButtonDownloadToCtrl)
//	ON_BN_CLICKED(IDC_BUTTON_UPLOAD_TO_PC, &CSetupMultiOriginDlg::OnBnClickedButtonUploadToPc)
	ON_BN_CLICKED(IDC_BUTTON_SAV, &CSetupMultiOriginDlg::OnBnClickedButtonSav)
	ON_BN_CLICKED(IDC_BUTTON_AUTO_TEACH, &CSetupMultiOriginDlg::OnBnClickedButtonAutoTeach)
	ON_BN_CLICKED(IDC_BUTTON_LOAD, &CSetupMultiOriginDlg::OnBnClickedButtonLoad)
	ON_MESSAGE(WM_NOTIFY_WINDOW_MOVE,&CSetupMultiOriginDlg::OnWindowMove )
END_MESSAGE_MAP()


// CSetupMultiOriginDlg �޽��� ó�����Դϴ�.

BOOL CSetupMultiOriginDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialogListPage::PreTranslateMessage(pMsg);
}

void CSetupMultiOriginDlg::PreInitDialog()
{
	CString strImageFilePath;
	CDC*	pDC = GetDC();
	CRect	rcWnd;

	GetClientRect( &CUIrectSMO );
	MoveWindow(0,0,1025,621);

	//////////////////////////////////////////////////////////////////////////
	strImageFilePath.Format( _T("%s\\Background_setup.bmp"), pResourcePath_ );

	GetClientRect( &rcWnd );

	pCanvasCE_ = new hcutil::CCanvasCE();
	ASSERT(pCanvasCE_ );
	pCanvasCE_->Create( this, pDC->GetSafeHdc(), rcWnd.Width(), rcWnd.Height(), RGB(1, 1, 0) );
	pCanvasCE_->GetCanvasCELayerMgr()->Add( FALSE, RGB(0, 0, 0) );
	pCanvasCE_->GetCanvasCELayerMgr()->Add( TRUE, RGB(255, 0, 255) );

	pCanvasCE_->GetCanvasCELayerMgr()->Get( 0 )->FillSolidRect( rcWnd, RGB(128, 196, 128) );
	pCanvasCE_->GetCanvasCELayerMgr()->Get( 1 )->LoadImageFormFile( strImageFilePath, CPoint(0, 0), CPoint(rcWnd.Width(), rcWnd.Height()) );
	//////////////////////////////////////////////////////////////////////////

	ReleaseDC( pDC );
	pDC = NULL;

	CDialogListPage::PreInitDialog();
}

BOOL CSetupMultiOriginDlg::OnInitDialog()
{
	CDialogListPage::OnInitDialog();

// 	bIsModify_ = FALSE;

	//////////////////////////////////////////////////////////////////////////

	brhBackground_.CreateSolidBrush( RGB(128, 196, 128) );
	brhBackButton_.CreateSolidBrush( pa::CLR_BUTTON_BACK );

	//////////////////////////////////////////////////////////////////////////

	fntButton_.CreateFont( 
		17, 0,
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") );

	((CButton*)GetDlgItem(IDC_BUTTON_DOWNLOAD_TO_CTRL))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_SAV))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_LOAD))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_AUTO_TEACH))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_CLOSE))->SetFont( &fntButton_, FALSE );

	CRect recbutton;
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_DOWNLOAD_TO_CTRL), this, &recbutton, &CUIrectSMO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_SAV), this, &recbutton, &CUIrectSMO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_LOAD), this, &recbutton, &CUIrectSMO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_AUTO_TEACH), this, &recbutton, &CUIrectSMO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_CLOSE), this, &recbutton, &CUIrectSMO);

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON2), this, &recbutton, &CUIrectSMO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON4), this, &recbutton, &CUIrectSMO);

	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_MSG1), this, &recbutton, &CUIrectSMO);
	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_MSG2), this, &recbutton, &CUIrectSMO);

	//////////////////////////////////////////////////////////////////////////

	memcpy((void*)&hTempMultiOriginData_, (void*)(pa::PPAStatus->GetMultiOriginData()), sizeof(pa::SMultiOriginData) );

	//////////////////////////////////////////////////////////////////////////

	CRect	rcTemp;
	int		nNumRow = 7;
	CString strRowName[] = { _T("NAME"), _T("X_DIST."), _T("Y_DIST."), _T("Z_DIST."), _T("X_OFFSET"), _T("Y_OFFSET"), _T("Z_OFFSET") };
	int		nRowWidth[] = {190, 100, 100, 100, 100, 100, 100, 100, 100 };

	hcutil::GetControlPos2( IDC_STATIC_TITLE2, this, &rcTemp, &CUIrectSMO, TRUE );

	pTitleBarWnd_ = new CTitleBarWnd();
	ASSERT( pTitleBarWnd_ );
	pTitleBarWnd_->InitResource( CString(_T("Multi origin offset")), pa::CLR_SETUP_TEACHING, RGB(32, 32, 32), RGB(32, 32, 32), CSize(0, 14) );
	pTitleBarWnd_->InitResourceEx( nNumRow, strRowName, nRowWidth, 24 );
	pTitleBarWnd_->Create( this, rcTemp, IDC_STATIC_TITLE2 );
	pTitleBarWnd_->SetWindowPos( &wndTop, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE );

	//////////////////////////////////////////////////////////////////////////

	hcutil::GetControlPos2( IDC_STATIC_TABLE2, this, &rcTemp, &CUIrectSMO, TRUE );

	pDataListBox_ = new COptionDataListBox();
	ASSERT( pDataListBox_ );
	pDataListBox_->SetBackgroundColor( RGB(180, 180, 180) );
	pDataListBox_->SetFontSize( 0, 15 );
	pDataListBox_->SetItemHeight( 30 );
	pDataListBox_->SetItemWidth( nNumRow, nRowWidth );
	pDataListBox_->SetID( IDC_STATIC_TABLE2 );
	pDataListBox_->Create( WS_CHILD|WS_VISIBLE, rcTemp, this, IDC_STATIC_TABLE2 );

	//////////////////////////////////////////////////////////////////////////
	// ������ ���ε� 
	//	upload_to_pc();

	//////////////////////////////////////////////////////////////////////////
	//	reflash_listbox();

	pDataListBox_->AddString( _T("Empty") );

	//////////////////////////////////////////////////////////////////////////

	initialize_DlgMap();

	//////////////////////////////////////////////////////////////////////////

	CString strTemp;
	strTemp.Format( _T("[%.3f ~ %.3f]"), pa::PPAStatus->GetMultiOriginData()->fOffset_Min_, pa::PPAStatus->GetMultiOriginData()->fOffset_Max_ );
	((CStatic *)GetDlgItem(IDC_STATIC_MSG2))->SetWindowText( strTemp );

	//////////////////////////////////////////////////////////////////////////
	//
	((CButton*)GetDlgItem(IDC_BUTTON_DOWNLOAD_TO_CTRL))->EnableWindow( FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_UPLOAD_TO_PC))->EnableWindow( FALSE );
	//////////////////////////////////////////////////////////////////////////

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

// #include "SetupMultiOrgAutoTeachDlg.h"
#include "SetupMultiOriginAutoTeachDlg.h"
void CSetupMultiOriginDlg::initialize_DlgMap()
{
	CRect	rcDlg;

	hcutil::GetControlPos2( IDC_STATIC_AUTO_TEACH, this, &rcDlg, &CUIrectSMO, TRUE );

	pDlgMap_ = new CDialogMap();

	ASSERT( pDlgMap_ );

	if( pDlgMap_->Initialize( this ) == FALSE ) {
		ASSERT( FALSE );
	}

	pDlgMap_->AddDialog( _T("AUTO_TEACH"), RUNTIME_CLASS(CSetupMultiOriginAutoTeachDlg), IDD_DIALOG_MULTIORG_AUTO_TEACH, rcDlg );
	pDlgMap_->HideAll();

	((CSetupMultiOriginAutoTeachDlg*)pDlgMap_->GetDialog( _T("AUTO_TEACH") ))->SetParentWnd( this );
}

void CSetupMultiOriginDlg::destroy_DlgMap()
{
	if( pDlgMap_ ) 
	{
		pDlgMap_->Destroy();
		delete pDlgMap_;
		pDlgMap_ = NULL;
	}
}

void CSetupMultiOriginDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	if( pCanvasCE_ ) {
		pCanvasCE_->Draw( dc.m_hDC, dc.m_ps.rcPaint );
	}
}

void CSetupMultiOriginDlg::reflash_listbox()
{
	int nNumGCode = hTempMultiOriginData_.nNumGCode;

	pDataListBox_->ResetContent();

	for( int i = 0; i<nNumGCode; i++ ) 
	{
		int gcode_no = hTempMultiOriginData_.hMultiOrigin[i].nGcode;
		int num_sub_coord = hTempMultiOriginData_.hMultiOrigin[i].nNumSubCoord;

		CString strItem;
		for( int j = 0; j<num_sub_coord; j++ )
		{
			TCHAR	*pReverseXY = hTempMultiOriginData_.hMultiOrigin[i].bReverseXY[j] == TRUE ? _T("-") : _T("");

			strItem.Format( _T("G%d.%d %s"), gcode_no, j+1, pReverseXY );
			int nIndex = pDataListBox_->AddString( strItem );
			void *p = (void*)(hTempMultiOriginData_.hMultiOrigin[i].fOffset[j]);
			pDataListBox_->SetItemDataPtr( nIndex, p );
		}
	}

	pDataListBox_->Invalidate();
}

// IDC_STATIC_MSG2
void CSetupMultiOriginDlg::reflash_max_min_data()
{
	CString strMsg;

	strMsg.Format( _T("%.3f ~ %.3f"), hTempMultiOriginData_.fOffset_Min_, hTempMultiOriginData_.fOffset_Max_ );
	TRACE( strMsg ); TRACE( _T("\n") );

	((CStatic *)GetDlgItem(IDC_STATIC_MSG2))->SetWindowText( strMsg );
	((CStatic *)GetDlgItem(IDC_STATIC_MSG2))->Invalidate();
}

void CSetupMultiOriginDlg::OnDestroy()
{
	KillTimer( 1 );

	fntButton_.DeleteObject();

	brhBackground_.DeleteObject();
	brhBackButton_.DeleteObject();

	destroy_DlgMap();

	if( pTitleBarWnd_ )
	{
		pTitleBarWnd_->DestroyWindow();
		delete pTitleBarWnd_;
		pTitleBarWnd_ = NULL;
	}
	if( pDataListBox_ ) 
	{
		pDataListBox_->DestroyWindow();
		delete pDataListBox_;
		pDataListBox_ = NULL;
	}

	if( pCanvasCE_ ) {
		delete pCanvasCE_;
		pCanvasCE_ = NULL;
	}

	CDialogListPage::OnDestroy();
}

void CSetupMultiOriginDlg::OnBnClickedButtonClose()
{
	CString strMsg;

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("back button click") );
	//////////////////////////////////////////////////////////////////////////

	pDlgMap_->HideAll();

	if( bIsModify_ == TRUE ) {
		// ������ ���� Ȯ�� 
		// 		strMsg.Format( _T("Data is modified. Do you want to save ?") );
		// 		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, strMsg );
		// 		CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();
		// 
		// 		if( hRet == TRUE ) {
		// 			strMsg.Format( _T("Wait for save data...") );
		// 			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, strMsg );
		// 
		// 			// ������ ���� 
		// 			pmac::SMultiOriginData *p = pmac::PState->GetMultiOriginData();
		// 			memcpy((void*)(p), (void*)&(hTempMultiOriginData_), sizeof(pmac::SMultiOriginData) );
		// 			pmac::PState->GetMultiOriginData()->Save( INI_MULTI_ORIGIN_CONFIG_PATH );
		// 
		// 			CMsgDlgThread::GetInstance()->Hide();
		// 		} 

		// ������ �ٿ�ε� Ȯ�� 
// 		strMsg.Format( _T("data is modified. but did not downloaded !\r\ndo you want to close page ?") );
// 		CMsgDlg::EN_RET hRet;
// 		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
// 		hRet = CMsgDlgThread::GetInstance()->Wait();
// 		if( hRet != CMsgDlg::RET_OK ) {
// 			return;
// 		}
	}

	//////////////////////////////////////////////////////////////////////////
	ASSERT( pParentWnd_ );
	pParentWnd_->PostMessage( WM_SETUP, (WPARAM)SETUP_BACK, (LPARAM)0 );
}

LRESULT CSetupMultiOriginDlg::OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam)
{
	CNumericInputDlg dlg;
	int		nCurSel = LOWORD( lparam );			// low word
	int		nCurSelItem = HIWORD( lparam );		// high word

	if( pa::GET_CURRENT_USERMODE() < pa::USER_MODE_MGR )
	{
		return 0;
	}

	//////////////////////////////////////////////////////////////////////////
	// Auto Teaching ȭ���� �������� ���� 
	// 	CString strCurrSelectedID = pDlgMap_->GetCurrSelectedPageID();
	// 	if( strCurrSelectedID == CString( _T("AUTO_TEACH") ) ) {
	// 		return 0;
	// 	}
	if( hCurrSubPage_ == SUB_PAGE_MULTI_ORG_TEACH ) {
		return 0;
	}

	//////////////////////////////////////////////////////////////////////////
	// X,Y,Z Dist. ���� ������ �� ������ ����. 2015.09.01
	if( nCurSelItem < 3 ) {
		return 0;
	}
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	// nCurSel�� ����ؼ� �ε����� ����Ѵ� 
	int nGCodeIndex = 0;
	int nGCodeSel = 0;
	int nGCodeSubitem = nCurSelItem;

	int nTemp = 0;
	for( int i = 0; i<hTempMultiOriginData_.nNumGCode; i++ )
	{
		int nStop = hTempMultiOriginData_.hMultiOrigin[i].nNumSubCoord;

		if( nCurSel < (nTemp + nStop) ) 
		{
			nGCodeIndex = i;
			nGCodeSel	= nCurSel - nTemp;
			break;
		}

		nTemp += nStop;
	}

	//////////////////////////////////////////////////////////////////////////

	dlg.SetIsFloatType( TRUE );
	dlg.SetPrevNumber( hTempMultiOriginData_.hMultiOrigin[nGCodeIndex].fOffset[nGCodeSel][nGCodeSubitem] );
	dlg.SetProperty( 0 );

	if( dlg.DoModal() == IDOK ) 
	{
		double fVal = hcutil::ToDouble( (wchar_t*)(LPCTSTR)dlg.GetNumber(), FALSE );
		double fMin = pa::PPAStatus->GetMultiOriginData()->fOffset_Min_;
		double fMax = pa::PPAStatus->GetMultiOriginData()->fOffset_Max_;
		if( fVal >= fMin && fVal <= fMax ) {
			hTempMultiOriginData_.hMultiOrigin[nGCodeIndex].fOffset[nGCodeSel][nGCodeSubitem] = fVal;		
// 			bIsModify_ = TRUE;
		} else {
			CString strMsg;
			strMsg.Format( _T("Offset data is available [%.3f ~ %.3f]"), fMin, fMax );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_INFO, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
		}
	}

	if( pDataListBox_ ) {
		pDataListBox_->Invalidate( FALSE );
	}

	return 0;
}

HBRUSH CSetupMultiOriginDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogListPage::OnCtlColor(pDC, pWnd, nCtlColor);

	if( nCtlColor == 4 ) {
		hbr = (HBRUSH)brhBackground_;
	}
	else {
		UINT nCtrlID = pWnd->GetDlgCtrlID();
		switch( nCtrlID )
		{
		case IDC_STATIC_MSG1:
		case IDC_STATIC_MSG2:
			pDC->SetBkMode( TRANSPARENT );
			hbr = (HBRUSH)brhBackground_;
			break;		
		case IDC_BUTTON_CLOSE:
			hbr = (HBRUSH)brhBackButton_;
			break;
		case IDC_BUTTON_AUTO_TEACH:
			{
				if( hCurrSubPage_ == SUB_PAGE_MULTI_ORG_TEACH ) 
				{ 
					hbr = (HBRUSH)brhBackButton_;
				}
			}
			break;
		}
	}

	return hbr;
}

void CSetupMultiOriginDlg::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 1 )
	{
		KillTimer( 1 );
		
		update_button_state();
		
		if( IsWindowVisible() == TRUE ) 
		{
			SetTimer( 1, 200, NULL );
		}
	}
	else if( nIDEvent == 2 )
	{
		KillTimer( 2 );

		if( IsWindowVisible() )
		{
			SetTimer( 2, 1000, NULL );
		}
	}

	CDialogListPage::OnTimer(nIDEvent);
}

void CSetupMultiOriginDlg::update_button_state()
{
	static int PREV_SAVE_BTN_STATE = -1;
	static int PREV_BACK = -1;
	int curr_save_btn_state; // = ( bIsModify_ == TRUE ) ? 1 : 0;

//	if( pa::USER_MODE < pa::USER_MODE_MGR ) {
	if( pa::GET_CURRENT_USERMODE() < pa::USER_MODE_MGR )
	{
		((CButton*)GetDlgItem(IDC_BUTTON_SAV))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_LOAD))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_AUTO_TEACH))->EnableWindow( FALSE );
		PREV_SAVE_BTN_STATE = -1;
		PREV_BACK = -1;
		return ;
	} 

	//////////////////////////////////////////////////////////////////////////
	// save ��ư ���� 
	CString strCurrSelectedID = pDlgMap_->GetCurrSelectedPageID();

	if( hCurrSubPage_ != SUB_PAGE_MULTI_ORG_TEACH ) {
		curr_save_btn_state = 1; //( bIsModify_ == TRUE ) ? 1 : 0;
	}
	else {
		curr_save_btn_state = 1; //( bIsModifyAutoTeach_ == TRUE ) ? 1 : 0;
	}

	if( PREV_SAVE_BTN_STATE != curr_save_btn_state )
	{
		PREV_SAVE_BTN_STATE = curr_save_btn_state;
		((CButton*)GetDlgItem(IDC_BUTTON_SAV))->EnableWindow( curr_save_btn_state );
	}
	((CButton*)GetDlgItem(IDC_BUTTON_LOAD))->EnableWindow( TRUE );

	//////////////////////////////////////////////////////////////////////////
	// teaching ��ư ���� 
// 	((CButton*)GetDlgItem(IDC_BUTTON_AUTO_TEACH))->EnableWindow( TRUE );

	//////////////////////////////////////////////////////////////////////////
	// back ��ư ���� 
	//	auto teach.	56000 ~ 60000
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetRunMode();
	int curr_back = ( ( hRunMode == pa::RUNMODE_RUN ) && 
		              ( pa::PPAStatus->GetThreadState()->nRunMode_StepNo>=56000 && pa::PPAStatus->GetThreadState()->nRunMode_StepNo<60000 ) ) ? 1 : 0;
	if( PREV_BACK != curr_back ) 
	{
		PREV_BACK = curr_back;

		if( curr_back != 0 ) 
		{
			((CButton*)GetDlgItem(IDC_BUTTON_AUTO_TEACH))->EnableWindow( FALSE );
			((CButton*)GetDlgItem(IDC_BUTTON_CLOSE))->EnableWindow( FALSE );
		}
		else 
		{
			((CButton*)GetDlgItem(IDC_BUTTON_AUTO_TEACH))->EnableWindow( TRUE );
			((CButton*)GetDlgItem(IDC_BUTTON_CLOSE))->EnableWindow( TRUE );
		}
	}
}

//////////////////////////////////////////////////////////////////////////
// �����͸� ���ε� �ϰ�, temp ������ ���� �Ѵ� 
void CSetupMultiOriginDlg::upload_to_pc()
{
// 	CString strMsg;
// 	DWORD	dwTime = 0;
// 
// #ifdef _HAS_MACHINE_
// 
// 	//////////////////////////////////////////////////////////////////////////
// 	// log
// 	writeLog( _T("upload multi-origin data button click") );
// 	//////////////////////////////////////////////////////////////////////////
// 
// 	strMsg.Format( _T("wait for upload multi-origin offset data") );
// 	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );
// 
// 	// Coordinate Offset 
// 	pa::PPAStatus->SetIpcCommandComplete( FALSE );
// 	PPNC_IPC_CLIENT->UploadMultiOriginData();
// 	Sleep( 500 );
// 	dwTime = GetTickCount();
// 	while( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == FALSE ) { 
// 		if( ( GetTickCount() - dwTime ) > 10000 ) {
// 			// ���� 
// 			// CMsgDlgThread::GetInstance()->Hide();	
// 			strMsg.Format( _T("Failed  to upload multi-origin data") );
// 			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
// 			CMsgDlgThread::GetInstance()->Wait();
// 			return ;
// 		}
// 		Sleep( 100 );
// 	}
// 
// 	CMsgDlgThread::GetInstance()->Hide();
// 
// 	memcpy((void*)&hTempMultiOriginData_, (void*)(pa::PPAStatus->GetMultiOriginData()), sizeof(pa::SMultiOriginData));
// 
// #endif
// 
// 	bIsModify_ = FALSE;

}

//////////////////////////////////////////////////////////////////////////
// �����͸� ����⿡ �������� �ʴ´� 

void CSetupMultiOriginDlg::OnBnClickedButtonDownloadToCtrl()
{

}

//void CSetupMultiOriginDlg::OnBnClickedButtonUploadToPc()
//{
//
//}

void CSetupMultiOriginDlg::save_control()
{

}

//////////////////////////////////////////////////////////////////////////

void CSetupMultiOriginDlg::OnBnClickedButtonSav()
{
	CString strMsg;

	if( hCurrSubPage_ == SUB_PAGE_MULTI_ORG )
	{
		strMsg.Format( _T("Do you want to save changed data ?") );
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
		CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();

		if( hRet == CMsgDlg::RET_CANCEL ) 
		{
			pa::SMultiOriginData* p = pa::PPAStatus->GetMultiOriginData();
			memcpy((void*)&hTempMultiOriginData_, (void*)p, sizeof(pa::SMultiOriginData) );
		}
		else 
		{
			strMsg.Format( _T("Wait for save data...") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

			// 		pmac::SMultiOriginData *p = pmac::PState->GetMultiOriginData();
			// 		memcpy((void*)(p), (void*)&(hTempMultiOriginData_), sizeof(pmac::SMultiOriginData) );
			// 		pmac::PState->GetMultiOriginData()->Save( INI_MULTI_ORIGIN_CONFIG_PATH );

			// ���Ͽ� ���� 
			hTempMultiOriginData_.Save( INI_MULTI_ORIGIN_CONFIG_PATH );
// 			bIsModify_ = FALSE;

			// ���� ������ ���� 
			pa::SMultiOriginData* p = pa::PPAStatus->GetMultiOriginData();
			memcpy((void*)p, (void*)&hTempMultiOriginData_, sizeof(pa::SMultiOriginData) );

			CMsgDlgThread::GetInstance()->Hide();

			strMsg.Format( _T("Save complete !") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_INFO, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
		}

		pDataListBox_->Invalidate( FALSE );
	}
	else if( hCurrSubPage_ == SUB_PAGE_MULTI_ORG_TEACH )
	{
		strMsg.Format( _T("Do you want to save changed data ?") );
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
		CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();

		if( hRet == CMsgDlg::RET_CANCEL ) 
		{
			// ����(original) �����͸� temp�� ����  
			((CSetupMultiOriginAutoTeachDlg*)(pDlgMap_->GetDialog(_T("AUTO_TEACH"))))->Copy_to_Temp();
		}
		else 
		{
			strMsg.Format( _T("Wait for save data...") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

			// temp�� ����(original)�� ���� 
			((CSetupMultiOriginAutoTeachDlg*)(pDlgMap_->GetDialog(_T("AUTO_TEACH"))))->Copy_to_Original();

			if( !pa::PPAStatus->GetAutoTeachMultiOrgParam()->Save( INI_AUTO_TEACH_MULTI_ORIGIN_PARAM_PATH, strMsg ) ) {
				CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
				CMsgDlgThread::GetInstance()->Wait();
			}
			else {
				CMsgDlgThread::GetInstance()->Hide();
				strMsg.Format( _T("Save comeplte !") );
				CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_INFO, strMsg );
				CMsgDlgThread::GetInstance()->Wait();
			}

// 			bIsModifyAutoTeach_ = FALSE;
		}
	}
	else 
	{
		return ;
	}
}

#include "SetupMultiOriginAutoTeachDlg.h"
void CSetupMultiOriginDlg::OnBnClickedButtonLoad()
{
	CString	strMsg;

	if( hCurrSubPage_ != SUB_PAGE_MULTI_ORG_TEACH )
	{
		strMsg.Format( _T("Do you want to load data from file ?") );
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
		CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();

		if( hRet == CMsgDlg::RET_CANCEL ) 
		{
			// ��� 
			return ;
		}
		else 
		{
			strMsg.Format( _T("Wait for loading data ...") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

			// 2017.05.15 
			// ������ ������ �Ѿ��� ���, ���� �޽����� ���� 
			// hTempMultiOriginData_.Load( INI_MULTI_ORIGIN_CONFIG_PATH );

			pa::SMultiOriginData hT;
			CString strErrMsg;

			if( hT.Load( INI_MULTI_ORIGIN_CONFIG_PATH, strErrMsg, TRUE ) == FALSE )
			{
				// �����͸� �д� ������ ���� ���
				// ���� �����ͷ� �ǵ����� 
				pa::SMultiOriginData *p = pa::PPAStatus->GetMultiOriginData();
				memcpy((void*)&hTempMultiOriginData_, (void*)p, sizeof(pa::SMultiOriginData) );
				// ���� �޽��� �ڽ��� ����  
				CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strErrMsg );
				CMsgDlgThread::GetInstance()->Wait();
			}
			else 
			{
				// �����͸� �о��� ���, �о�� �����ͷ� �����Ѵ� 
				memcpy((void*)&hTempMultiOriginData_, (const void*)&hT, sizeof(pa::SMultiOriginData) );
			}

			reflash_listbox();

			CMsgDlgThread::GetInstance()->Hide();
		}

		pDataListBox_->Invalidate( TRUE );

		reflash_max_min_data();

// 		bIsModify_ = TRUE;
	}
	else 
	{
		//////////////////////////////////////////////////////////////////////////
		// Multi Origin Offst  ȭ�� 
		strMsg.Format( _T("Do you want to load data from backup file ?") );
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
		CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();

		if( hRet == CMsgDlg::RET_CANCEL ) 
		{
			pa::SMultiOriginData* p = pa::PPAStatus->GetMultiOriginData();
			memcpy((void*)&hTempMultiOriginData_, (void*)p, sizeof(pa::SMultiOriginData) );
		}
		else 
		{
			strMsg.Format( _T("Wait for loading data...") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

			if( !pa::PPAStatus->GetAutoTeachMultiOrgParam()->Load( INI_AUTO_TEACH_MULTI_ORIGIN_PARAM_PATH, strMsg ) ) 
			{
				CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
				CMsgDlgThread::GetInstance()->Wait();
			}
			else 
			{
				CMsgDlgThread::GetInstance()->Hide();
				((CSetupMultiOriginAutoTeachDlg*)(pDlgMap_->GetDialog(_T("AUTO_TEACH"))))->Copy_to_Temp();
// 				bIsModifyAutoTeach_ = TRUE;
			}
			
		}
	}
}

void CSetupMultiOriginDlg::writeLog( LPCTSTR log_msg )
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	WriteLog( CLog::TYPE_OPER, 3, log_msg );
	//////////////////////////////////////////////////////////////////////////
}

void CSetupMultiOriginDlg::OnBnClickedButtonAutoTeach()
{
	if( hCurrSubPage_ == SUB_PAGE_MULTI_ORG_TEACH )
	{
		hCurrSubPage_ = SUB_PAGE_MULTI_ORG;
		pDlgMap_->HideAll();

		//////////////////////////////////////////////////////////////////////////
		// multi origin �����͸� ����⿡�� �ٽ� ���ε� �Ѵ� 
		upload_to_pc();
		//////////////////////////////////////////////////////////////////////////
		// ȭ�� ����. �����Ͱ� ���Ѱ��� ������ bIsModify�� TRUE��...
		pa::SMultiOriginData* pMOD = pa::PPAStatus->GetMultiOriginData();
		/*
		for( int i = 0; i<hTempMultiOriginData_.nNumGCode; i++ )
		{
			for( int j = 0; j<hTempMultiOriginData_.hMultiOrigin[i].nNumSubCoord; j++ )
			{
				if( hTempMultiOriginData_.hMultiOrigin[i].fOffset[j][3] == pMOD->hMultiOrigin[i].fOffset[j][3] &&
					hTempMultiOriginData_.hMultiOrigin[i].fOffset[j][4] == pMOD->hMultiOrigin[i].fOffset[j][4] &&
					hTempMultiOriginData_.hMultiOrigin[i].fOffset[j][5] == pMOD->hMultiOrigin[i].fOffset[j][5] )
				{
					;
				}
				else 
				{
					bIsModify_ = TRUE;
					break;
				}
			}
			if( bIsModify_ == TRUE )
			{
				break;
			}
		}
		*/
		memcpy((void*)&hTempMultiOriginData_, (void*)(pa::PPAStatus->GetMultiOriginData()), sizeof(pa::SMultiOriginData) );

		reflash_listbox();

		// ���� ���� Ȯ�� �� ���� 
// 		if( bIsModify_ == TRUE )
// 		{
// 			OnBnClickedButtonSav();
// 		}

	}
	else 
	{
		hCurrSubPage_ = SUB_PAGE_MULTI_ORG_TEACH;
		pDlgMap_->HideAll();
		pDlgMap_->Show( CString( _T("AUTO_TEACH") ) );

		CRect	rcSetup;
		this->GetWindowRect(&rcSetup);
		((CSetupMultiOriginAutoTeachDlg*)pDlgMap_->GetDialog( _T("AUTO_TEACH") ))->MoveWindow(rcSetup.left+10,rcSetup.top+17,681,492);
	}

	((CButton*)GetDlgItem(IDC_BUTTON_AUTO_TEACH))->Invalidate();
}

LRESULT CSetupMultiOriginDlg::OnWindowMove(WPARAM wparam, LPARAM lparam)
{
	LPPOINT ChangedPos=(LPPOINT)lparam;

	((CSetupMultiOriginAutoTeachDlg*)pDlgMap_->GetDialog( _T("AUTO_TEACH") ))->PostMessage(WM_NOTIFY_WINDOW_MOVE, (WPARAM)0, (LPARAM)lparam );
	
	return 0;

}

