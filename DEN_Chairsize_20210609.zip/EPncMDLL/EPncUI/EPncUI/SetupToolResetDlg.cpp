// SetupToolResetDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "SetupToolResetDlg.h"

//////////////////////////////////////////////////////////////////////////
// CSetupToolResetDlg ��ȭ �����Դϴ�.
//////////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC(CSetupToolResetDlg, CDialog)

CSetupToolResetDlg::CSetupToolResetDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetupToolResetDlg::IDD, pParent)
{
	nToolNo_		= 0;
	dwMaximumTime_	= 0;
}

CSetupToolResetDlg::~CSetupToolResetDlg()
{
}

void CSetupToolResetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BUTTON_H_UP, btnHourUp_);
	DDX_Control(pDX, IDC_BUTTON_H_DN, btnHourDown_);
	DDX_Control(pDX, IDC_BUTTON_M_UP, btnMinuteUp_);
	DDX_Control(pDX, IDC_BUTTON_M_DN, btnMinuteDown_);
	DDX_Control(pDX, IDC_BUTTON_S_UP, btnSecondUp_);
	DDX_Control(pDX, IDC_BUTTON_S_DN, btnSecondDown_);
}

void CSetupToolResetDlg::SetToolNo( int toolNo )
{
	if( toolNo <= 0 ) {
		return ;
	}

	nToolNo_ = toolNo;

	dwMaximumTime_ = pa::PTool->GetToolData( nToolNo_ )->dwMaximumTime;
}

DWORD CSetupToolResetDlg::GetMaximunTime()
{
	return dwMaximumTime_;
}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CSetupToolResetDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_RESET2, &CSetupToolResetDlg::OnBnClickedButtonReset2)
	ON_BN_CLICKED(IDC_BUTTON_CANCEL, &CSetupToolResetDlg::OnBnClickedButtonCancel)
	ON_MESSAGE(WM_NOTIFY_BUTTON, &CSetupToolResetDlg::OnNotifyButton)
	ON_WM_TIMER()
	ON_WM_DESTROY()
//	ON_STN_CLICKED(IDC_STATIC_H, &CSetupToolResetDlg::OnStnClickedStaticH)
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CSetupToolResetDlg �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CSetupToolResetDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CSetupToolResetDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	//
	fntUpDownBtn_.CreateFont( 
		16, 8, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Courier New") ); //_T("MS Sans Serif") );

	fntOkCancelBtn_.CreateFont( 
		32, 0, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Courier New") ); //_T("MS Sans Serif") );

	fntTime_.CreateFont( 
		32, 0, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Courier New") ); //_T("MS Sans Serif") );

	//
	((CButton*)GetDlgItem(IDC_BUTTON_H_UP))->SetFont( &fntUpDownBtn_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_H_DN))->SetFont( &fntUpDownBtn_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_M_UP))->SetFont( &fntUpDownBtn_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_M_DN))->SetFont( &fntUpDownBtn_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_S_UP))->SetFont( &fntUpDownBtn_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_S_DN))->SetFont( &fntUpDownBtn_, TRUE );

	//
	((CStatic*)GetDlgItem(IDC_STATIC_H))->SetFont( &fntTime_, TRUE );
	((CStatic*)GetDlgItem(IDC_STATIC_M))->SetFont( &fntTime_, TRUE );
	((CStatic*)GetDlgItem(IDC_STATIC_S))->SetFont( &fntTime_, TRUE );

	//
	((CButton*)GetDlgItem(IDC_BUTTON_RESET2))->SetFont( &fntUpDownBtn_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_CANCEL))->SetFont( &fntUpDownBtn_, TRUE );

	btnHourUp_.SetID( 1 );
	btnHourDown_.SetID( 2 );
	btnMinuteUp_.SetID( 3 );
	btnMinuteDown_.SetID( 4 );
	btnSecondUp_.SetID( 5 );
	btnSecondDown_.SetID( 6 );

	//////////////////////////////////////////////////////////////////////////
	//
	CenterWindow();
	//////////////////////////////////////////////////////////////////////////

	//
	updateMaximumTime();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CSetupToolResetDlg::OnDestroy()
{
	fntUpDownBtn_.DeleteObject();
	fntOkCancelBtn_.DeleteObject();
	fntTime_.DeleteObject();
}

void CSetupToolResetDlg::updateMaximumTime()
{
	CTimeSpan tms( dwMaximumTime_ );
	CString strHour;
	CString strMinute;
	CString strSecond;

	strHour.Format( _T("%d"), tms.GetTotalHours() );
	strMinute.Format( _T("%d"), tms.GetMinutes() );
	strSecond.Format( _T("%d"), tms.GetSeconds() );

	((CStatic*)GetDlgItem(IDC_STATIC_H))->SetWindowText( strHour );
	((CStatic*)GetDlgItem(IDC_STATIC_M))->SetWindowText( strMinute );
	((CStatic*)GetDlgItem(IDC_STATIC_S))->SetWindowText( strSecond );
}

//////////////////////////////////////////////////////////////////////////
// Hour Up/Down
//////////////////////////////////////////////////////////////////////////

void CSetupToolResetDlg::incHour()
{
	DWORD dwHour = 3600; //60*60;		// 60 second * 60 minute
	dwMaximumTime_ += dwHour;	
}

void CSetupToolResetDlg::decHour()
{
	DWORD dwHour = 3600; //60*60;		// 60 second * 60 minute
	if( dwMaximumTime_ >= dwHour ) {
		dwMaximumTime_ -= dwHour;
	}
}

void CSetupToolResetDlg::incMinute()
{
	DWORD	dwMinute = 60;
	dwMaximumTime_ += dwMinute;
}

void CSetupToolResetDlg::decMinute()
{
	DWORD	dwMinute = 60;
	if( dwMaximumTime_ >= dwMinute ) {
		dwMaximumTime_ -= dwMinute;
	}
}

void CSetupToolResetDlg::incSecond()
{
	DWORD	dwSecond = 1;
	dwMaximumTime_ += dwSecond;
}

void CSetupToolResetDlg::decSecond()
{
	DWORD	dwSecond = 1;
	if( dwMaximumTime_ >= dwSecond ) {
		dwMaximumTime_ -= dwSecond;
	}
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

LRESULT CSetupToolResetDlg::OnNotifyButton(WPARAM wparam, LPARAM lparam)
{
	int nButtonID = (int)wparam;
	int nUpDown = (int)lparam;

	if( nUpDown != 0 ) {
		bIsPressButton_ = TRUE;
		// �ϳ� ���� ��Ų ��,
		switch( nButtonID )
		{
		case 1: incHour(); break;
		case 2: decHour(); break;
		case 3: incMinute(); break;
		case 4: decMinute(); break;
		case 5: incSecond(); break;
		case 6: decSecond(); break;
		}
		updateMaximumTime();
		// Timer�� ���� �Ѵ� 
		SetTimer( nButtonID, 1000, NULL );
	}
	else {
		// Up
		bIsPressButton_ = FALSE;
		KillTimer( nButtonID );
	}

	return 0;
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

void CSetupToolResetDlg::OnBnClickedButtonReset2()
{
	CDialog::OnOK();
}

void CSetupToolResetDlg::OnBnClickedButtonCancel()
{
	CDialog::OnCancel();
}

//////////////////////////////////////////////////////////////////////////

void CSetupToolResetDlg::OnTimer(UINT_PTR nIDEvent)
{
	KillTimer( nIDEvent );

	switch( nIDEvent )
	{
	case 1:	incHour(); break;
	case 2: decHour(); break;
	case 3: incMinute(); break;
	case 4: decMinute(); break;
	case 5: incSecond(); break;
	case 6: decSecond(); break;
	}
	updateMaximumTime();

	if( bIsPressButton_ == TRUE ) {
		SetTimer( nIDEvent, 100, NULL );
	}

	CDialog::OnTimer(nIDEvent);
}

//////////////////////////////////////////////////////////////////////////
