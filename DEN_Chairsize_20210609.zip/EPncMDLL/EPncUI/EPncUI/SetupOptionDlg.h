#pragma once
#include "afxwin.h"
#include "TitleBarWnd.h"

// CSetupOptionDlg ��ȭ �����Դϴ�.

class CSetupOptionDlg : public CDialogListPage
{
	DECLARE_DYNCREATE(CSetupOptionDlg)

	CWnd* pParentWnd_;

	TCHAR*				pResourcePath_;
	hcutil::CCanvasCE*	pCanvasCE_;

	BOOL	bEnableDownloadButton_;

	CBrush	brhBkgnd_;
	CBrush	brhBackButton_;

	CFont	fntMenuButton_;
	CFont	fntCheckBox_;
	CFont	fntEditBox_;

	CRect CUIrectSO;

	void updateState();

	void updateControlState();

	void updateState_MenuButton();

	void writeLog( LPCTSTR log_msg );

	void upload_to_pc();

	BOOL save_sw_config_data( CString& strErrMsg );
	BOOL load_sw_config_data( CString& strErrMsg );

public:
	CSetupOptionDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupOptionDlg();

	void SetParentWnd( CWnd* pParent ) { pParentWnd_ = pParent; }

	virtual void StartPageWork();
	virtual void StopPageWork();
	virtual void UpdatePage();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_OPTION };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedButtonClose();
	CButton chkUsingBlockAutoLoader_;
	CButton chkUsingDetectBlockSensor_;
	CButton chkUsingAirPressureLimit_;
	CButton chkDemoMode_;
	afx_msg void OnBnClickedButtonSave();
	CButton btnBlockGripInterval_;
	CButton btnAirPressureInterval_;
	afx_msg void OnBnClickedButtonBlockGripInterval();
	afx_msg void OnBnClickedButtonAirPressureInterval();
	afx_msg void OnBnClickedCheckDemoMode();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	CButton chkUsingOpPanel_;
	int nSelectOperationM28_;
	afx_msg void OnBnClickedRadioSelectOperM28();
	afx_msg void OnBnClickedRadioSelectOperM282();
	int nToolErrOccureHandingCode_;
	afx_msg void OnBnClickedCheckUsingBlockAutoloader();
	afx_msg void OnBnClickedCheckUsingDetectBlockSensor();
	CButton chkUsingFlowSensor_;
	CButton btnFlowSensorTimeout_;
	afx_msg void OnBnClickedButtonFlowSensorTimeout();
	afx_msg void OnBnClickedButtonDownloadToColtrollor();
	afx_msg void OnBnClickedCheckUsingFlowSensor();
	CButton chkInvalidNcCode_;
	CButton chkNcFileTag_;
	CButton chkTransformCoord_;
	afx_msg void OnBnClickedCheckInvalidNcCode();
	afx_msg void OnBnClickedCheckNcFileTag();
	afx_msg void OnBnClickedCheckTransformCoordinate();
	CButton chkUsingSpindleAirPurge_;
	afx_msg void OnBnClickedCheckUsingSpindleAirPurge();
protected:
	virtual void PreInitDialog();
public:
	afx_msg void OnPaint();
//	afx_msg void OnBnClickedButtonLoad();
	CButton chkUsingLogging_;
	afx_msg void OnBnClickedButtonLoadFromFile();
	afx_msg void OnBnClickedCheckUsingOpPanel();
	afx_msg void OnBnClickedCheckUsingAirPressureLimit();
	afx_msg void OnBnClickedCheckUsingLogging();
	afx_msg void OnBnClickedRadioToolErrOccuredStop();
	afx_msg void OnBnClickedRadioToolErrRestartFromToolChangeLine();
	afx_msg void OnBnClickedRadioToolErrOccuredRestartFromBegin();
	afx_msg void OnBnClickedRadioToolErrOccuredStartNextNcFile();
	afx_msg void OnBnClickedRadioToolErrOccuredUserConfirm();
	afx_msg void OnBnClickedButtonFlowSensorStartTimeout();
	CButton btnFlowSensorStartTimeout_;
	CButton btnPurgeAirHoldTime_;
	afx_msg void OnBnClickedButtonPurgeAirHoldTime();
};
