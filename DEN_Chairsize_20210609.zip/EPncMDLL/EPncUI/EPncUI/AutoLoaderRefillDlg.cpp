// AutoLoaderRefillDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "AutoLoaderRefillDlg.h"


// CAutoLoaderRefillDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CAutoLoaderRefillDlg, CDialog)

CAutoLoaderRefillDlg::CAutoLoaderRefillDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAutoLoaderRefillDlg::IDD, pParent)
{

}

CAutoLoaderRefillDlg::~CAutoLoaderRefillDlg()
{
}

void CAutoLoaderRefillDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PROGRESS, hProgress_);
	DDX_Control(pDX, IDC_BUTTON_START, hBtnStart_);
	DDX_Control(pDX, IDC_BUTTON_STOP, hBtnStop_);
	DDX_Control(pDX, IDC_BUTTON_CLOSE, hBtnClose_);
	DDX_Control(pDX, IDC_CHECK_AUTO_CLOSE, chkAutoClose_);
}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CAutoLoaderRefillDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_STOP, &CAutoLoaderRefillDlg::OnBnClickedButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_START, &CAutoLoaderRefillDlg::OnBnClickedButtonStart)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, &CAutoLoaderRefillDlg::OnBnClickedButtonClose)
	ON_WM_TIMER()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CAutoLoaderRefillDlg �޽��� ó�����Դϴ�.

BOOL CAutoLoaderRefillDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialog::PreTranslateMessage(pMsg);
}


BOOL CAutoLoaderRefillDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	fntButton_.CreateFont(
		18, 8, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Courier New") ); //_T("MS Sans Serif") );

	hBtnStart_.SetFont( &fntButton_, FALSE );
	hBtnStop_.SetFont( &fntButton_, FALSE );
	hBtnClose_.SetFont( &fntButton_, FALSE );

	// Dialog�� Top-Most �� ����� 
	SetWindowPos( &wndTopMost, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE );

	hProgress_.SetRange( 0, 100 );
	hProgress_.SetPos( 0 );

	chkAutoClose_.SetCheck( TRUE );

	bIsStart_ = FALSE;

	SetTimer( 1, 250, NULL );
	SetTimer( 2, 300, NULL );

	//////////////////////////////////////////////////////////////////////////
	//
	CRect rcWnd;
	GetWindowRect( &rcWnd );
	int xpos = 1024/2 - rcWnd.Width()/2;
	int ypos = 768/2 - rcWnd.Height()/2;
	SetWindowPos( &wndTopMost, xpos, ypos, 0, 0, SWP_NOSIZE|SWP_SHOWWINDOW );
	//////////////////////////////////////////////////////////////////////////

	rescanStartTime_ = 0;

	CenterWindow();

	hBtnStop_.EnableWindow( FALSE );

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CAutoLoaderRefillDlg::OnBnClickedButtonStart()
{
	bIsStart_ = TRUE;
	rescanStartTime_ = GetTickCount();
	PPNC_IPC_CLIENT->AutoLoaderReFill();

	Sleep( 1000 ); // This is added to make sure Timer 1 fires after Run Mode becomes RUNMODE_RUN.
}

void CAutoLoaderRefillDlg::OnBnClickedButtonStop()
{
	bIsStart_ = FALSE;
	PPNC_IPC_CLIENT->Stop();
}

void CAutoLoaderRefillDlg::OnBnClickedButtonClose()
{
	CDialog::OnOK();
}

void CAutoLoaderRefillDlg::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 1 ) 
	{
		KillTimer( 1 );

		updateButtonState();

		updateProgress();

		if( ( bIsStart_ == TRUE ) && ( pa::PPAStatus->GetRunMode() == pa::RUNMODE_STOP ) ) {
			if( chkAutoClose_.GetCheck() == TRUE ) {
				// ���� 
				CDialog::OnOK();
			}
		}

		if( IsWindowVisible() )
		{
			SetTimer( 1, 250, NULL );
		}
	}
	if( nIDEvent == 2 )
	{
		KillTimer( 2 );

		if( IsWindowVisible() ) 
		{
			SetTimer( 2, 1000, NULL );
		}
	}

	CDialog::OnTimer(nIDEvent);
}

void CAutoLoaderRefillDlg::updateButtonState()
{
	static int PREV_START_BTN = -1;
	static int PREV_STOP_BTN = -1;
	static int PREV_CLOSE_BTN = -1;
	int nStartBtn = 0;
	int nStopBtn = 0;
	int nCloseBtn = 0;

	if( pa::PPAStatus->GetThreadState()->bIsOriginComplete_ == TRUE )
	{
		switch( pa::PPAStatus->GetRunMode() )
		{
		case pa::RUNMODE_STOP:
			nStartBtn	= 1;
			nStopBtn	= 0;
			nCloseBtn	= 1;
			break;

		case pa::RUNMODE_RUN:
			nStartBtn	= 0;
			nStopBtn	= 1;
			nCloseBtn	= 0;
			break;

		case pa::RUNMODE_TOSTOP:
		case pa::RUNMODE_TORUN:
		case pa::RUNMODE_INIT:
		case pa::RUNMODE_PAUSE:
		case pa::RUNMODE_ERROR:
			nStartBtn	= 0;
			nStopBtn	= 0;
			nCloseBtn	= 1;
			break;
		}
	}
	else 
	{
		nStartBtn	= 0;
		nStopBtn	= 0;
		nCloseBtn	= 1;
	}

	if( PREV_START_BTN != nStartBtn ) {
		PREV_START_BTN = nStartBtn;
		hBtnStart_.EnableWindow( PREV_START_BTN == 0 ? FALSE : TRUE );
	}
	if( PREV_STOP_BTN != nStopBtn ) {
		PREV_STOP_BTN = nStopBtn;
		hBtnStop_.EnableWindow( PREV_STOP_BTN == 0 ? FALSE : TRUE );
	}
	if( PREV_CLOSE_BTN != nCloseBtn ) {
		PREV_CLOSE_BTN = nCloseBtn;
		hBtnClose_.EnableWindow( PREV_CLOSE_BTN == 0 ? FALSE : TRUE );
	}
}

void CAutoLoaderRefillDlg::updateProgress()
{
	static int FULL_SCAN_TIME = 80 * 1000; // It takes 1 minute 20 seconds to finish a full scan.

	if( pa::PPAStatus->GetRunMode() == pa::RUNMODE_RUN )
	{
		int nPos = (int)( ( (double)(GetTickCount() - rescanStartTime_) / (double)FULL_SCAN_TIME ) * 100.0 + 0.5 );
		hProgress_.SetPos( nPos );
	}
	else
	{
		hProgress_.SetPos( 0 );
	}
}

