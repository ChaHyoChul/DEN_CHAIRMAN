#include "StdAfx.h"
#include "PNcFile.h"

pa::CPNCFile::CPNCFile(void)
{
	pShMem_			= NULL;
	pFile_			= NULL;
	nNumTotalLines_ = 0;
	nWorkLine_		= 0;
}

pa::CPNCFile::~CPNCFile(void)
{
	Close();
}

BOOL pa::CPNCFile::Open( CString& strNcFilePath, CString& strErrMsg )
{
	DWORD	dwFileSize = 0;

	nNumTotalLines_ = 0;

	//////////////////////////////////////////////////////////////////////////
	// �ϴ� �ݴ´� 
	Close();
	//////////////////////////////////////////////////////////////////////////

	// ���� ũ�⸦ �˾Ƴ���,	
	if( hcutil::GetFileSize( strNcFilePath, &dwFileSize, strErrMsg ) == FALSE ) {
		return FALSE;
	}

	// ������ ���� �޸𸮿� ���� �Ѵ� 
	pShMem_ = new hcipc::CSharedMem();
	if( pShMem_ == NULL ) {
		return FALSE;
	}
	pFile_ = (char*)pShMem_->CreateEx( (TCHAR*)(LPCTSTR)strNcFilePath, _T("NC_FILE_OBJ"), (int)(dwFileSize+1), FALSE, 0 );
	if( pFile_ == NULL ) {
		return FALSE;
	}

	// �� ���ξ� ī��Ʈ �ϸ鼭, �����͸� �����Ѵ� 
	char* pTemp = pFile_;

	pLines_[nNumTotalLines_++] = pFile_;
	while( TRUE ) 
	{
		pLines_[nNumTotalLines_] = strstr( pTemp, ETX_STR );
		if( pLines_[nNumTotalLines_] != NULL ) {
			pLines_[nNumTotalLines_] += ETX_STR_LEN;	// "\n" ���� ���ڸ� ����Ű���� ������ �̵� 
			pTemp = pLines_[nNumTotalLines_];
			nNumTotalLines_++;
			if( nNumTotalLines_ >= MAX_NCFILE_LINES ) {
				// ���� �޽���
				strErrMsg.Format( _T("NC-File is too large") );
				// ���ҽ� ����
				Close();
				return FALSE;
			}
		} else {
			break;
		}
	}

	nWorkLine_ = 0;

	return TRUE;
}

void pa::CPNCFile::Close()
{
	nNumTotalLines_ = 0;
	nWorkLine_ = 0;
	if( pShMem_ ) {
		delete pShMem_;
		pShMem_ = NULL;
		pFile_	= NULL;
		memset((void*)pLines_, 0, sizeof(char*)*MAX_NCFILE_LINES);
	}
}

BOOL pa::CPNCFile::IsOpen()
{
	BOOL b = ( nNumTotalLines_ != 0 ) && ( pFile_ != NULL );

	return b;
}

BOOL pa::CPNCFile::GetLine( int index, BOOL bSetWorkLine, char* pNCCode )
{
	if( index >= nNumTotalLines_ ) {
		return FALSE;
	}

	char* p = strstr( pLines_[index], ETX_STR );

	memcpy( (void*)pNCCode, (const void*)pLines_[index], sizeof(char)*(p - pLines_[nWorkLine_]) );

	if( bSetWorkLine ) {
		nWorkLine_ = index;
	}

	return TRUE;
}

BOOL pa::CPNCFile::GetNextLine( char* pNCCode )
{
	if( nWorkLine_+1 >= nNumTotalLines_ ) {
		return FALSE;
	}

	nWorkLine_++;

	char* p = strstr( pLines_[nWorkLine_], ETX_STR );

	memcpy((void*)pNCCode, (const void*)pLines_[nWorkLine_], sizeof(char)*(p - pLines_[nWorkLine_]));

	return TRUE;
}

