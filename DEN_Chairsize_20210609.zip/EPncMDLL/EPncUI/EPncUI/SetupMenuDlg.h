#pragma once

// CSetupMenuDlg ��ȭ �����Դϴ�.

class CSetupMenuDlg : public CDialogListPage
{
	DECLARE_DYNCREATE(CSetupMenuDlg)

	CWnd* pWndParent_;
	TCHAR*				pResourcePath_;
	hcutil::CCanvasCE*	pCanvasCE_;

	CFont	fntButton_;
	CFont	fntCheckBox_;

	CBrush	brhSetupMain_;
	CBrush	brhTeachingButton_;
	CBrush	brhToolButton_;
	CBrush	brhAutoLoaderButton_;
	CBrush	brhOptionButton_;
	CBrush	brhIOButton_;
	CBrush	brhLogButton_;
	CBrush	brhBackButton_;

	void writeLog( LPCTSTR log_msg );
	void update_service_button_state();
	void reposbutton(CButton* Cbuttn);

public:
	CSetupMenuDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupMenuDlg();

	void SetParentWnd( CWnd* pParent ) { pWndParent_ = pParent; }

	virtual void StartPageWork();
	virtual void StopPageWork();
	virtual void UpdatePage();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_MENU };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedButtonTeaching();
	afx_msg void OnBnClickedButtonClose();
	afx_msg void OnBnClickedButtonTool();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedButtonAutoloader();
	afx_msg void OnBnClickedButtonOption();
	afx_msg void OnBnClickedCheckNoNddePassword();
	afx_msg void OnBnClickedButtonIo();
	afx_msg void OnBnClickedButtonTerm();
	afx_msg void OnBnClickedButtonLog();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnBnClickedButtonSystem();
protected:
	virtual void PreInitDialog();
public:
	afx_msg void OnPaint();
	afx_msg void OnBnClickedButtonMultiorg();
	afx_msg void OnBnClickedButtonService();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
};
