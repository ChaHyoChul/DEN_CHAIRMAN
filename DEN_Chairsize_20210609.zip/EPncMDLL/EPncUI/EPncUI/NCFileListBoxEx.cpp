// NCFileListBoxEx.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "NCFileListBoxEx.h"
#include "MsgDlg.h"
#include "MsgDlgThread.h"

// CNCFileListBoxEx

IMPLEMENT_DYNAMIC(CNCFileListBoxEx, CListBox)

CNCFileListBoxEx::CNCFileListBoxEx()
{
	clrBkgnd_ = RGB( 128, 128, 128 );

	szFont_.SetSize( 16, 10 );
	nItemHeight_ = 24; 

	nPrevSelIndex_ = 0;
}

CNCFileListBoxEx::~CNCFileListBoxEx()
{
}

void CNCFileListBoxEx::SetBackgroundColor( COLORREF clrBkgnd )
{
	clrBkgnd_ = clrBkgnd;
}

void CNCFileListBoxEx::SetFontSize( int nCX, int nCY )
{
	szFont_.SetSize( nCX, nCY );
}

void CNCFileListBoxEx::SetItemHeight( int nItemHeight )
{
	nItemHeight_ = nItemHeight;
}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CNCFileListBoxEx, CListBox)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_CTLCOLOR_REFLECT()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_TIMER()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CNCFileListBoxEx �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CNCFileListBoxEx::PreCreateWindow(CREATESTRUCT& cs)
{
// 	cs.style |= WS_VSCROLL /*| WS_TABSTOP*/ | LBS_OWNERDRAWVARIABLE | LBS_NOINTEGRALHEIGHT | LBS_HASSTRINGS | LBS_NOTIFY;	
	cs.style |= WS_VSCROLL /*| WS_TABSTOP*/ | LBS_OWNERDRAWFIXED | LBS_NOINTEGRALHEIGHT | LBS_HASSTRINGS | LBS_NOTIFY;	

	return __super::PreCreateWindow(cs);
}

void CNCFileListBoxEx::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	lpMeasureItemStruct->itemHeight = nItemHeight_;	// ��Ʈ�� Ű��� ����, Height ���� Ű���� �Ѵ� 
}

int CNCFileListBoxEx::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (__super::OnCreate(lpCreateStruct) == -1)
		return -1;

	// Font 
	hFont_.CreateFont( 
		szFont_.cy, szFont_.cx, 
		0, 0, FW_BOLD, //FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") );	//_T("Courier New") ); //_T("MS Sans Serif") );
//	SetFont( &hFont_, TRUE );

	hFontSelect_.CreateFont( 
		szFont_.cy-2, szFont_.cx, 
		0, 0, FW_BOLD, // FW_BOLD, //FW_NORMAL, 
		TRUE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") );	//_T("Courier New") ); //_T("MS Sans Serif") );


	// Background's brush 
	brhBkgnd_.CreateSolidBrush( clrBkgnd_ );

	//
	CRect rc;
	GetClientRect( &rc );
	nLineNumPerCtrl_ = (int)( (double)(rc.Height()) / (double)nItemHeight_ );

	return 0;
}

void CNCFileListBoxEx::OnDestroy()
{
	hFont_.DeleteObject();
	hFontSelect_.DeleteObject();
	brhBkgnd_.DeleteObject();

	__super::OnDestroy();
}

HBRUSH CNCFileListBoxEx::CtlColor(CDC* /*pDC*/, UINT /*nCtlColor*/)
{
	return brhBkgnd_;
}

void CNCFileListBoxEx::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	static const int nCharPerLine	= 60;		// ���δ� ���ڰ��� 40�� 
	static const int nCheckBoxWidth = 20;		// �� Check �ڽ� ���� ũ�� 
	static const int nTimeWidth		= 86;
	static const int nFileSizeWidth = 56;		// File ũ�� ��� ���� ũ�� 

	CDC		hDC;
	pa::SNCFileInfo*	pInfo = (pa::SNCFileInfo*)lpDrawItemStruct->itemData;
	CRect		rcItem = lpDrawItemStruct->rcItem;
	int			nPrevMode;
	COLORREF	clrPrevText;
	CRect		rcCheckBox;
	CRect		rcCheckBoxGrid;
	CRect		rcTimeBox;
	CRect		rcFilePath;
	CRect		rcFileSize;
	CRect		rcFileSelect;
	CFont		*pOldFont = NULL;

	hDC.Attach( lpDrawItemStruct->hDC );
	nPrevMode	= hDC.SetBkMode( TRANSPARENT );
	clrPrevText	= hDC.SetTextColor( RGB(50, 50, 50) );
	pOldFont	= hDC.SelectObject( &hFont_ );

	int nFilePathWidth = rcItem.Width() - nCheckBoxWidth - 20 - nTimeWidth - nFileSizeWidth;

	rcCheckBox	= rcItem; rcCheckBox.left = rcItem.left + 10; rcCheckBox.right = rcCheckBox.left + nCheckBoxWidth;
	rcCheckBoxGrid = rcItem; rcCheckBoxGrid.right = nCheckBoxWidth + 20;
	rcTimeBox	= rcItem; rcTimeBox.left = rcCheckBox.right + 11; rcTimeBox.right = rcTimeBox.left + nTimeWidth;
	rcFilePath  = rcItem; rcFilePath.left = rcTimeBox.right + 1; rcFilePath.right = rcFilePath.left + nFilePathWidth;
	rcFileSize	= rcItem; rcFileSize.left = rcFilePath.right + 1; rcFileSize.right = rcFileSize.left + nFileSizeWidth - 3;
	rcFileSelect= rcFilePath;

	// TODO: there is an edge case here...
	if (!pInfo) {
		return;
	}
	
	//////////////////////////////////////////////////////////////////////////
	// Draw Grid
	hDC.FillSolidRect( rcItem, RGB(241, 241, 251) );
	hDC.Draw3dRect( &rcCheckBoxGrid, RGB(180, 180, 180), RGB(100, 100, 100) );
	hDC.FillSolidRect( &rcTimeBox, pa::CLR_NC_FILESTATE[pInfo->state] );		//
	hDC.Draw3dRect( &rcTimeBox, RGB(180, 180, 180), RGB(100, 100, 100) );		// time box ���� 
	hDC.FillSolidRect( &rcFilePath, pa::CLR_NC_FILESTATE[pInfo->state] );		//
	hDC.Draw3dRect( &rcFilePath, RGB(180, 180, 180), RGB(100, 100, 100) );		// filename ���� 
 	hDC.Draw3dRect( &rcFileSize, RGB(180, 180, 180), RGB(100, 100, 100) );		// filesize ���� 

	//////////////////////////////////////////////////////////////////////////
	// Draw CheckBox
	if( pInfo->is_select != 0 ) {
		hDC.DrawFrameControl( &rcCheckBox, DFC_BUTTON, DFCS_BUTTONCHECK | DFCS_CHECKED );
	} else {
		hDC.DrawFrameControl( &rcCheckBox, DFC_BUTTON, DFCS_BUTTONCHECK );
	}

	//////////////////////////////////////////////////////////////////////////
	// Draw Time 
	CString strTime;
	strTime.Format( _T("%s\r\n%s"), 
		_tcslen(pInfo->start_time) ? pInfo->start_time : _T("--:--:--"),
		_tcslen(pInfo->work_time)  ? pInfo->work_time  : _T("--:--:--") );
	rcTimeBox.DeflateRect( 0, 3, 0, 0 );
	hDC.DrawText( strTime, &rcTimeBox, DT_CENTER );

	//////////////////////////////////////////////////////////////////////////
	// Draw FilePath 
	if( pInfo->is_select_updown ) {
		hDC.SelectObject( &hFontSelect_ );
	} else {
		hDC.SelectObject( &hFont_ );
	}

	CString strTempFilePath;
//	if( ( pmac::PState->GetThreadState()->bIsOpenNCFile ) && 
//	 	( _tcscmp( pmac::PState->GetThreadState()->hNCFileInfo.id, pInfo->id ) == 0 ) )
	if( ( pa::PPAStatus->GetThreadState()->bIsOpenNCFile ) &&
		( _tcscmp( pa::PPAStatus->GetThreadState()->hNCFileInfo.id, pInfo->id ) == 0 ) )
	{
		strTempFilePath.Format( _T("�� %s"), pInfo->file_name );
	} 
	else 
	{
		strTempFilePath.Format( _T("%s"), pInfo->file_name );
	}
	int is_insert = strTempFilePath.Insert( nCharPerLine, _T("\r\n") );

	if( pInfo->is_select_updown ) {
		rcFileSelect.DeflateRect( 2, 2, 2, 2 );
		hDC.Draw3dRect( &rcFileSelect, RGB(180, 180, 180), RGB(100, 100, 100) );
		rcFileSelect.DeflateRect( 1, 1, 1, 1 );
		hDC.Draw3dRect( &rcFileSelect, RGB(180, 180, 180), RGB(100, 100, 100) );
	}

	rcFilePath.DeflateRect( 6, 2, 6, 4 );
	hDC.DrawText( strTempFilePath, &rcFilePath, DT_LEFT );

	hDC.SelectObject( &hFont_ );

	//////////////////////////////////////////////////////////////////////////
	// Draw FileSize 
	CString strFileSize;

	if( pInfo->file_size == 0 ) {
		strFileSize.Format( _T("0.0\r\nbyte") );
	} else {
		if( pInfo->file_size > 1024 * 1024 ) {
			// MB
			strFileSize.Format( _T("%.1f\r\nMB"), (double)pInfo->file_size / ( 1024.0 * 1024.0 ) );
		} 
		else if( pInfo->file_size > 1024 ) {
			// KB
			strFileSize.Format( _T("%.1f\r\nKB"), (double)pInfo->file_size / ( 1024.0 ) );
		}
		else {
			// byte
			strFileSize.Format( _T("%d\r\nbyte"), pInfo->file_size );
		}
	}
	rcFileSize.DeflateRect( 4, 2, 4, 2 );
	hDC.DrawText( strFileSize, &rcFileSize, DT_CENTER );

	hDC.SetTextColor( clrPrevText );

	hDC.SetBkMode( nPrevMode );

	hDC.SelectObject( pOldFont );

	hDC.Detach();
}

void CNCFileListBoxEx::OnLButtonDown(UINT nFlags, CPoint point)
{
	int		nTopIndex	= GetTopIndex();
	int		nCurSel		= nTopIndex + (int)(point.y / nItemHeight_);

	SetCurSel( nCurSel );

	// remote lock Ȯ�� 
	if( !pa::PPAStatus->GetThreadState()->bRemoteLock_ )
	{
		if( nCurSel >= 0 && pa::PNCFileMgr->GetNumNCFile() > 0 )
		{
			CRect	rcItem, rcFileSelect, rcWnd;
			GetItemRect( nCurSel, rcItem );
			rcFileSelect = rcItem;
			GetClientRect( &rcWnd );
			rcItem.right = 128; //45;
			rcFileSelect.left = 130; //40 + 86  
			rcFileSelect.right-= 60;

			// checking ���� 
			if( rcItem.PtInRect( point ) == TRUE ) 
			{
				bShowAllSelectDlg_ = FALSE;
				SetTimer( 1, 1500, NULL );	// Checking ������ ������ ���, 3�� Ÿ�̸� ����
			}
		}
	}

	__super::OnLButtonDown(nFlags, point);
}

void CNCFileListBoxEx::OnLButtonUp(UINT nFlags, CPoint point)
{
// 	int		nCurSel = GetCurSel();

	KillTimer( 1 );

	if( bShowAllSelectDlg_ == FALSE )
	{
		int		nTopIndex	= GetTopIndex();
		int		nCurSel		= nTopIndex + (int)(point.y / nItemHeight_);

		SetCurSel( nCurSel );

		// remote lock Ȯ�� 
		if( !pa::PPAStatus->GetThreadState()->bRemoteLock_ )
		{
			if( nCurSel >= 0 ) 
			{
				CRect	rcItem, rcFileSelect, rcWnd;
				GetItemRect( nCurSel, rcItem );
				rcFileSelect = rcItem;
				GetClientRect( &rcWnd );
				rcItem.right = 128; //90; //45;		// File Check ������ �ø��� 
				rcFileSelect.left = 130; //40 + 86  
				rcFileSelect.right-= 60;

				// checking ���� 
				if( rcItem.PtInRect( point ) == TRUE ) 
				{
					int i = pa::PNCFileMgr->GetNCFileSelect( nCurSel );
					pa::PNCFileMgr->SetNCFileSelect( nCurSel, ( i == 0 ? 1 : 0 ), TRUE );
				}
				// filepath ���� 
				else if( rcFileSelect.PtInRect( point ) == TRUE ) 
				{
					int i = pa::PNCFileMgr->GetNCFileSelectUpDown( nCurSel );
					pa::PNCFileMgr->SetNCFileSelectUpDown( nCurSel, ( i == 0 ? 1 : 0 ), TRUE );
				}
			
				// ��ũ�� ���� Ȯ�� 
				int		scroll_pos	= GetScrollPos( 1 );
				CRect	rcScroll	= rcWnd;
				rcScroll.left	= rcScroll.right - 45;
				rcScroll.bottom	= rcWnd.Height() / 3;
				if( scroll_pos > 0 && rcScroll.PtInRect( point ) == TRUE ) {
					// Scroll Up
					SetTopIndex( scroll_pos - 1 );
				}

				rcScroll.top	= rcScroll.bottom * 2;
				rcScroll.bottom	= rcWnd.bottom;
				if( scroll_pos < GetCount() && rcScroll.PtInRect( point ) == TRUE ) {
					// Scroll Down
					SetTopIndex( scroll_pos + 1 );
				}
			}
		}
	}

	__super::OnLButtonUp(nFlags, point);
}

void CNCFileListBoxEx::Expand()
{
	MoveWindow( 180, 187, 662, 561 );
	ShowWindow( SW_SHOW );
}

void CNCFileListBoxEx::Collapse()
{
	MoveWindow( 180, 617, 662, 132 );
	ShowWindow( SW_SHOW );
}

//////////////////////////////////////////////////////////////////////////

void CNCFileListBoxEx::UpdateFileList()
{
	int nCount = 0;

	// ����Ʈ���� ��� ������ ���� 
	nCount = GetCount();
	for( int i = 0; i<nCount; i++ ) {
		DeleteString( 0 );
	}

	// ����Ʈ�� NC File ������ �߰� 
	nCount = pa::PNCFileMgr->GetNumNCFile();
	for( int i = 0; i<nCount; i++ ) {
		pa::SNCFileInfo* pInfo = pa::PNCFileMgr->GetNCFileInfo( i );
		if( pInfo ) {
			int index = AddString(_T(""));
			SetItemDataPtr( index, pInfo );
		}
	}

	// nPrevSelIndex_�� ��� �Ѵ� 
	// CurrentWorkNCFileIndex�� -1�̸�, PrevSelIndex_�� ����Ѵ� 
	int nCurrWorkNCFileIndex = pa::PNCFileMgr->GetCurrentWorkNCFileIndex();
	if( nCurrWorkNCFileIndex != -1 ) {
		nPrevSelIndex_ = nCurrWorkNCFileIndex;
		SetCurSel( nCurrWorkNCFileIndex );
	}
	else {
		if( nPrevSelIndex_ < GetCount() ) {
			SetCurSel( nPrevSelIndex_ );
		} else {
			SetCurSel( -1 );
		}
	}
}

void CNCFileListBoxEx::SelectAll()
{
	int nCount = 0;

	nCount = GetCount();
	for( int i = 0; i<nCount; i++ ) 
	{
		pa::PNCFileMgr->SetNCFileSelect( i, 1, TRUE );
	}
}

void CNCFileListBoxEx::UnselectAll()
{
	int nCount = 0;

	nCount = GetCount();
	for( int i = 0; i<nCount; i++ ) 
	{
		pa::PNCFileMgr->SetNCFileSelect( i, 0, TRUE );
	}
}

// ���� �ִ� ���� ���� �ø���. �� �ö󰡸� ���� ���ϵ� �ø��� �ʴ´� 
// ù��° ������ ���õǾ� ������ ��� �ø��� �� �Ѵ� 
void CNCFileListBoxEx::MoveUp( BOOL bSort/*=FALSE*/)
{
	int nCount = 0;

	nCount = GetCount();
	for( int i = 0; i<nCount; i++ ) {
		pa::SNCFileInfo* pInfo = pa::PNCFileMgr->GetNCFileInfo( i );
		if( pInfo && pInfo->is_select_updown != 0 ) {
			if( i == 0 ) {
				break;
			}

			pa::PNCFileMgr->MoveUpWorkNCFileInfo( i, TRUE, bSort );

			if( i-1 < GetTopIndex() ) {
				SetTopIndex( i-1 );
			}
		}
	}
}

// �Ʒ� �ִ� ���Ϻ��� ������. �� �������� ���� ���ϵ� ������ �� �Ѵ� 
// ������ ������ ���õǸ� ��� ������ �� �Ѵ� 
void CNCFileListBoxEx::MoveDown( BOOL bSort/*=FALSE*/ )
{
	int	nCount = 0;

	nCount = GetCount();
	for( int i = nCount-1; i>=0; i-- ) {
		pa::SNCFileInfo* pInfo = pa::PNCFileMgr->GetNCFileInfo( i );
		if( pInfo && pInfo->is_select_updown != 0 ) {
			if( i == nCount-1 ) {
				break;
			}

			pa::PNCFileMgr->MoveDownWorkNCFileInfo( i, TRUE, FALSE );

			int topindex = GetTopIndex();
			if( (i+1) > topindex+nLineNumPerCtrl_ ) {
				SetTopIndex( (i+1)-nLineNumPerCtrl_ );
			}
		}
	}
}

// ���õ� NC File �̸��� ���� �Ѵ� 
int CNCFileListBoxEx::GetSelectedFileName( CString strFileNames[] )
{
	int nCount = GetCount();
	int nIndex = 0; 

	for( int i = 0; i<nCount; i++ )
	{
		pa::SNCFileInfo* pInfo = pa::PNCFileMgr->GetNCFileInfo( i );
		if( pInfo && pInfo->is_select )
		{
			strFileNames[nIndex++].Format( _T("%s"), pInfo->file_name );
		}
	}

	return nIndex;
}

int CNCFileListBoxEx::GetUpDownSelectedFileName( CString strFileNames[] )
{
	int nCount = GetCount();
	int nIndex = 0; 

	for( int i = 0; i<nCount; i++ )
	{
		pa::SNCFileInfo* pInfo = pa::PNCFileMgr->GetNCFileInfo( i );
		if( pInfo && pInfo->is_select_updown )
		{
			strFileNames[nIndex++].Format( _T("%s"), pInfo->file_name );
		}
	}

	return nIndex;
}

BOOL CNCFileListBoxEx::DoesExist( CString strFileName )
{
	int nCount = GetCount();
	int nIndex = 0; 

	for( int i = 0; i<nCount; i++ )
	{
		pa::SNCFileInfo* pInfo = pa::PNCFileMgr->GetNCFileInfo( i );
		if( pInfo )
		{
			CString pFileName;
			pFileName.Format( _T("%s"), pInfo->file_name );

			if (!pFileName.Compare(strFileName)) {
				return TRUE;
			}
		}
	}

	return FALSE;
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

// ����Ʈ �������� ���� �۾��� ��� 
void CNCFileListBoxEx::NCFMObsvr_AddNewNCFile()
{
	UpdateFileList();
	// �������� �߰��� NC ������ ����Ű���� �Ѵ�
	int nNumNcFiles = pa::PNCFileMgr->GetNumNCFile();
	SetCurSel( nNumNcFiles - 1 );
}

// nIndex ��° ���� �۾��� ��� 
void CNCFileListBoxEx::NCFMObsvr_InsertNewNCFile( int nIndex )
{
	UpdateFileList();
	SetCurSel( nIndex );
}

// nIndex ��° �۾� ������ ����
void CNCFileListBoxEx::NCFMObsvr_RemoveNCFile( int nIndex ) 
{
	UpdateFileList();
}

// nIndex ��° �۾� ������ Up
void CNCFileListBoxEx::NCFMObsvr_MoveUpNCFile( int nIndex )
{
//	UpdateFileList();
	Invalidate( TRUE );
}

// nIndex ��° �۾� ������ Down  
void CNCFileListBoxEx::NCFMObsvr_MoveDownNCFile( int nIndex )
{
// 	UpdateFileList();
	Invalidate( TRUE );
}

// nIndex ��° �۾� ������ ���� �� 
void CNCFileListBoxEx::NCFMObsvr_SetCurrentWorkIndex( int nIndex )
{
// 	UpdateFileList();

	CRect rect;
	GetItemRect( nIndex, &rect );
	InvalidateRect( &rect );
}

// nIndex ��° �۾� ������ ������ Update �Ѵ� 
void CNCFileListBoxEx::NCFMObsvr_UpdateNCFileInfo( int nIndex )
{
// 	UpdateFileList();

	CRect rect;
	GetItemRect( nIndex, &rect );
	InvalidateRect( &rect );

	// ���°� ���� NC-File�� ����Ű���� �Ѵ� 
//	SetCurSel( nIndex );
}

void CNCFileListBoxEx::NCFMObsvr_UpdateNCFileList()
{
	UpdateFileList();
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

void CNCFileListBoxEx::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 1 )
	{
		// 3�� �̻� ������. ��ü ����/���� ��� 
		KillTimer( 1 );

		bShowAllSelectDlg_ = TRUE;

		CString strMsg(_T(""));
		CString strTemp;
		strTemp.Format( _T("Do you want to select/release all nc-files ?\n") ); strMsg += strTemp;
		strTemp.Format( _T("   YES : all select\n") ); strMsg += strTemp;
		strTemp.Format( _T("   NO  : all release\n") ); strMsg += strTemp;
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_YESNOCANCEL, CMsgDlg::ICON_QUEST, strMsg );
		CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();

		switch( hRet )
		{
		case CMsgDlg::RET_YES:
			// All Select
			pa::PNCFileMgr->SelectAllNCFiles( TRUE );
			break;
		case CMsgDlg::RET_NO:
			// All Unselect
			pa::PNCFileMgr->DeselectAllNCFiles( TRUE );
			break;
		case CMsgDlg::RET_CANCEL:
		default:
			// Close
			break;		
		}

		bShowAllSelectDlg_ = FALSE;
	}

	__super::OnTimer(nIDEvent);
}
