// SetupTeachingSAAutoCalCoordOffsetDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "SetupTeachingSAAutoCalCoordOffsetDlg.h"
#include "SetupTeachingDlg.h"
#include "NumericInputDlg.h"
#include "MsgDlg.h"
#include "MsgDlgThread.h"

// CSetupTeachingSAAutoCalCoordOffsetDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNCREATE(CSetupTeachingSAAutoCalCoordOffsetDlg, CDialogListPage)

CSetupTeachingSAAutoCalCoordOffsetDlg::CSetupTeachingSAAutoCalCoordOffsetDlg(CWnd* pParent /*=NULL*/)
	: CDialogListPage(CSetupTeachingSAAutoCalCoordOffsetDlg::IDD, pParent)
	, nSelectMeasure_(0)
{
	pParent_ = NULL;
	nIsPressStopButton_ = -1;
}

CSetupTeachingSAAutoCalCoordOffsetDlg::~CSetupTeachingSAAutoCalCoordOffsetDlg()
{
}

void CSetupTeachingSAAutoCalCoordOffsetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogListPage::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_RADIO_SELECT_AAXIS, nSelectMeasure_);
}

void CSetupTeachingSAAutoCalCoordOffsetDlg::StartPageWork()
{
	if( pParent_ ) {
		((CSetupTeachingDlg*)pParent_)->HideModeSelectRadioButton();
	}

	nSelectMeasure_ = 0;
	UpdateData( FALSE );

	SetTimer( 1, 500, NULL );
	SetTimer( 2, 100, NULL );

}

void CSetupTeachingSAAutoCalCoordOffsetDlg::StopPageWork()
{
	if( pParent_ ) {
		((CSetupTeachingDlg*)pParent_)->ShowModeSelectRadioButton();
	}
}

void CSetupTeachingSAAutoCalCoordOffsetDlg::UpdatePage()
{

}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CSetupTeachingSAAutoCalCoordOffsetDlg, CDialogListPage)
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_CTLCOLOR()
	ON_MESSAGE(WM_NOTIFY_OPTIONDATA_LISTBOX, &CSetupTeachingSAAutoCalCoordOffsetDlg::OnNotifyPointDataListBox)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_START_STOP, &CSetupTeachingSAAutoCalCoordOffsetDlg::OnBnClickedButtonStartStop)
	ON_BN_CLICKED(IDC_RADIO_SELECT_AAXIS, &CSetupTeachingSAAutoCalCoordOffsetDlg::OnBnClickedRadioSelectAaxis)
	ON_BN_CLICKED(IDC_RADIO_SELECT_XYZAXIS, &CSetupTeachingSAAutoCalCoordOffsetDlg::OnBnClickedRadioSelectXyzaxis)
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CSetupTeachingSAAutoCalCoordOffsetDlg �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CSetupTeachingSAAutoCalCoordOffsetDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialogListPage::PreTranslateMessage(pMsg);
}

void CSetupTeachingSAAutoCalCoordOffsetDlg::PreInitDialog()
{

	CDialogListPage::PreInitDialog();
}

BOOL CSetupTeachingSAAutoCalCoordOffsetDlg::OnInitDialog()
{
	CDialogListPage::OnInitDialog();

	brhBkgnd_.CreateSolidBrush( pa::CLR_SETUP_TEACHING );

	fntBtn_.CreateFont(
		28, 0,
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	((CButton *)GetDlgItem(IDC_BUTTON_START_STOP))->SetFont( &fntBtn_, TRUE );

	//////////////////////////////////////////////////////////////////////////
	//
	CRect rcTemp;
	GetClientRect( &CUIrectSTAO );
	MoveWindow(0,0,651,492);
	GetClientRect( &rcTemp );

	CRect recbutton;
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_START_STOP), this, &recbutton, &CUIrectSTAO);
	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_G), this, &recbutton, &CUIrectSTAO);

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_TOUCH_SIGNAL), this, &recbutton, &CUIrectSTAO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_RADIO_SELECT_AAXIS), this, &recbutton, &CUIrectSTAO);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_RADIO_SELECT_XYZAXIS), this, &recbutton, &CUIrectSTAO);

	int		nNumRow = 2;
	CString strRowName[] = { _T("Name"), _T("Value") };
	int		nRowWidth[] = { 260, 140, 90, 90, 90, 90, 90 };		// 420 = 280 + 140

	hcutil::GetControlPos2( IDC_STATIC_TITLE, this, &rcTemp, &CUIrectSTAO, TRUE );
	pTitleBarWnd_ = new CTitleBarWnd();
	ASSERT( pTitleBarWnd_ );
	pTitleBarWnd_->InitResource( CString(_T("Parameter")), pa::CLR_SETUP_TEACHING, RGB(32, 32, 32), RGB(32, 32, 32), CSize(0, 14) ); //CSize(8, 16) );
	pTitleBarWnd_->InitResourceEx( nNumRow, strRowName, nRowWidth, 24 );
	pTitleBarWnd_->Create( this, rcTemp, IDC_STATIC_TITLE ); //IDC_STATIC_TEACHING_OTION_TITLE_AREA );
	pTitleBarWnd_->SetWindowPos( &wndTop, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE );

	//////////////////////////////////////////////////////////////////////////
	//
	hcutil::GetControlPos2( IDC_STATIC_LIST_AREA, this, &rcTemp, &CUIrectSTAO, TRUE );

	pParamListBox_ = new COptionDataListBox();
	pParamListBox_->SetBackgroundColor( RGB(180, 180, 180) );
	pParamListBox_->SetFontSize( 0, 15 );
	pParamListBox_->SetItemHeight( 30 );
	pParamListBox_->SetItemWidth( nNumRow, nRowWidth );
	pParamListBox_->SetID( IDC_STATIC_LIST_AREA );
	pParamListBox_->Create( WS_CHILD|WS_VISIBLE, rcTemp, this, IDC_STATIC_LIST_AREA );

	for( int i = 0; i<(int)pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_NUM; i++ )
	{
		int index = pParamListBox_->AddString( pa::SAutoCalSingleAbutmentCoordinateOffsetParam::STR_PARAM_NAME[i] );
		void *p = &(pa::PPAStatus->GetAutoCalSingleAbutmentCoordOffsetParam()->fParam[i] );
		pParamListBox_->SetItemDataPtr( i, p );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CSetupTeachingSAAutoCalCoordOffsetDlg::OnDestroy()
{
	brhBkgnd_.DeleteObject();

	fntBtn_.DeleteObject();

	if( pTitleBarWnd_ ) {
		pTitleBarWnd_->DestroyWindow();
		delete pTitleBarWnd_;
		pTitleBarWnd_ = NULL;
	}

	if( pParamListBox_ ) {
		pParamListBox_->DestroyWindow();
		delete pParamListBox_;
		pParamListBox_ = NULL;
	}

	CDialogListPage::OnDestroy();
}

void CSetupTeachingSAAutoCalCoordOffsetDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting
}

void CSetupTeachingSAAutoCalCoordOffsetDlg::UpdateOptionListBox()
{
	if( pParamListBox_ ) 
	{
		pParamListBox_->Invalidate( TRUE );
	}
}

HBRUSH CSetupTeachingSAAutoCalCoordOffsetDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogListPage::OnCtlColor(pDC, pWnd, nCtlColor);

	if( nCtlColor == 4 ) {
		hbr = (HBRUSH)brhBkgnd_;
	}
	else {
		UINT nCtrlID = pWnd->GetDlgCtrlID();
		switch( nCtrlID )
		{
		case IDC_STATIC_G:
		case IDC_RADIO_SELECT_AAXIS:
		case IDC_RADIO_SELECT_XYZAXIS:
		case IDC_CHECK_TOUCH_SIGNAL:
			hbr = (HBRUSH)brhBkgnd_;
			break;
		}
	}

	return hbr;
}

LRESULT CSetupTeachingSAAutoCalCoordOffsetDlg::OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam)
{
	CNumericInputDlg dlg;
	int		nCurSel		= LOWORD( lparam );		// low  word
	int		nCurSelItem = HIWORD( lparam );		// high word

	//////////////////////////////////////////////////////////////////////////
	// 2017.04.28 
	// User ��忡 �������, Tool ��ȣ�� Tool Diameter, Disk Thickness �̿� �����͸� ������ �� ������ �Ѵ� 
	/*
	PARAM_TOOL_NO,					// P6050
	PARAM_TOOL_DIAMETER,			// P6058 
	PARAM_MEASURE_COUNT,			// P6051
	PARAM_DISK_THICK,				// P6052
	*/
	switch( nCurSel )
	{
	case pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_TOOL_NO:
	case pa::SAutoCalSingleAbutmentCoordinateOffsetParam::PARAM_TOOL_DIAMETER:
		break;
	default:
		return 0;
	}

	if( pa::GET_CURRENT_USERMODE() < pa::USER_MODE_RND )
	{
		return 0;
	}

	dlg.SetIsFloatType( TRUE );
	dlg.SetPrevNumber( pa::PPAStatus->GetAutoCalSingleAbutmentCoordOffsetParam()->fParam[nCurSel] );
	dlg.SetProperty( 0 );

	if( dlg.DoModal() == IDOK ) 
	{
		double fVal = hcutil::ToDouble( (TCHAR*)(LPCTSTR)dlg.GetNumber(), FALSE );

		pa::PPAStatus->GetAutoCalSingleAbutmentCoordOffsetParam()->fParam[nCurSel] = fVal;

		//////////////////////////////////////////////////////////////////////////
		// save to file ��ư�� ���¸� ���� 
		((CSetupTeachingDlg*)pParent_)->ResetSaveToFileButtonState( CSetupTeachingDlg::SUB_PAGE_AT_SA_COORDINATE_OFFSET );
		//////////////////////////////////////////////////////////////////////////
	}

	// 	update_TeachingPointListBox();
	UpdateOptionListBox();

	return 0;
}

void CSetupTeachingSAAutoCalCoordOffsetDlg::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 1 )
	{
		KillTimer( 1 );

		updateButtonState();

		if( pa::PPAStatus->GetRunMode() == pa::RUNMODE_RUN )
		{
// 			updateCheckBoxState();
		}

		if( IsWindowVisible() ) {
			SetTimer( 1, 250, NULL );
		}
	}
	else if( nIDEvent == 2 )
	{
		KillTimer( 2 );

		if( IsWindowVisible() )
		{
			SetTimer( 2, 1000, NULL );
		}
	}

	CDialogListPage::OnTimer(nIDEvent);
}

void CSetupTeachingSAAutoCalCoordOffsetDlg::updateButtonState()
{
	static int PREV_CHECK_STATE[7] = { -1, -1, -1, -1, -1, -1, -1 };
	int is_stop_mode = (pa::PPAStatus->GetRunMode() == pa::RUNMODE_STOP ) ? 1 : 0;

	//////////////////////////////////////////////////////////////////////////
	// touch signal 
	int prev_touch_signal = ((CButton*)GetDlgItem(IDC_CHECK_TOUCH_SIGNAL))->GetCheck();

#ifdef _PA_G2400_
		int curr_touch_signal = pa::PPAStatus->GetPAStatus()->bInput[];
#endif 
#ifdef _PA_G1600_
		int curr_touch_signal = pa::PPAStatus->GetPAStatus()->bInput[pa::IN10003_AutoCalibrationLeft];
#endif 

	if( prev_touch_signal != curr_touch_signal ) 
	{
		((CButton*)GetDlgItem(IDC_CHECK_TOUCH_SIGNAL))->SetCheck( curr_touch_signal );
	}

	//////////////////////////////////////////////////////////////////////////
	// run button state 
	// step ��ȣ 50000~ 52000�̸� auto teaching for coordinate offset 
	//	- start		: stop ����� ��,  
	//	- stop		: run ����̰�, 58000~61999 �� ��,
	//	- disable	: 

	static int PREV_BTN_MODE	= -1;	// 0:stop, 1:start
	static int PREV_BTN_ENABLE	= -1;	// 0:disable, 1:enable
	int curr_btn_mode	= 0;
	int curr_btn_enable	= 0;

	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetRunMode();
	int run_step = pa::PPAStatus->GetThreadState()->nRunMode_StepNo;	// >= 50000
	int axis_num = pa::MODEL_INFO.GetNumAxis();

	if( axis_num == 4 || axis_num == 5 ) {
		if( hRunMode == pa::RUNMODE_STOP ) {
			// start ��ư 
			curr_btn_mode = 1;
			curr_btn_enable = 1;
		}
		else if( hRunMode == pa::RUNMODE_RUN ) {
			if( run_step >= 58000 && run_step < 61999 ) {
				// stop ��ư 
				curr_btn_mode = 0;
				curr_btn_enable = 1;
			} else {
				// disable 
				curr_btn_mode = 0;
				curr_btn_enable = 0;
			}
		}
		else {
			// disable 
			curr_btn_mode = 0;
			curr_btn_enable = 0;
		}
	}
	else {
		// disable 
		curr_btn_mode = 0;
		curr_btn_enable = 0;
	}

	if( PREV_BTN_MODE != curr_btn_mode ) {
		PREV_BTN_MODE = curr_btn_mode;
		if( PREV_BTN_MODE == 0 ) 
		{
			((CButton*)GetDlgItem(IDC_BUTTON_START_STOP))->SetWindowText( _T("Stop") );
		}
		else 
		{
			((CButton*)GetDlgItem(IDC_BUTTON_START_STOP))->SetWindowText( _T("Start") );
				if( nIsPressStopButton_ == 0 )
			{
				// �Ϸ� �޽��� �ڽ�
				TRACE( _T("Auto Calibration Complete !!!\n") );
				CString strMsg;
				strMsg.Format( _T("Auto Calibration Complete !!!") );
				CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_INFO, strMsg );
				CMsgDlgThread::GetInstance()->Wait();		
				//	CMsgDlgThread::GetInstance()->Hide();
			}
		}
	} 
	if( PREV_BTN_ENABLE != curr_btn_enable ) {
		PREV_BTN_ENABLE = curr_btn_enable;
		((CButton*)GetDlgItem(IDC_BUTTON_START_STOP))->EnableWindow( PREV_BTN_ENABLE );
	}
}

void CSetupTeachingSAAutoCalCoordOffsetDlg::OnBnClickedButtonStartStop()
{
	CString strBtn;
	CString strMsg;

	((CButton*)GetDlgItem(IDC_BUTTON_START_STOP))->GetWindowText( strBtn );

	UpdateData( TRUE );		// update nSelectMeasure_

	if( strBtn == CString( _T("Start") ) )
	{
		if( nSelectMeasure_ == 0 )
		{
			// A�� ���� ���� 
			strMsg.Format( _T("do you want to start single abutment auto calibration (a-axis) ?") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
			CMsgDlg::EN_RET ret = CMsgDlgThread::GetInstance()->Wait();

			if( ret == CMsgDlg::RET_OK ) 
			{
				nIsPressStopButton_ = 0;

				PPNC_IPC_CLIENT->Start_SA_AutoCal_CoordinateOffset_A();
			}
		}
		else if( nSelectMeasure_ == 1 )
		{
			// X, Y, Z�� Center ���� 
			strMsg.Format( _T("do you want to start single abutment auto calibration (x,y,z-axis) ?") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
			CMsgDlg::EN_RET ret = CMsgDlgThread::GetInstance()->Wait();

			if( ret == CMsgDlg::RET_OK ) 
			{
				nIsPressStopButton_ = 0;

				PPNC_IPC_CLIENT->Start_SA_AutoCal_CoordinateOffset_XYZ();
			}
		}
	}
	else if( strBtn == CString( _T("Stop") ) )
	{
		if( nSelectMeasure_ == 0 )
		{
			strMsg.Format( _T("do you want to stop single abutment auto calibration (a-axis) ?") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
			CMsgDlg::EN_RET ret = CMsgDlgThread::GetInstance()->Wait();

			if( ret == CMsgDlg::RET_OK ) 
			{
				nIsPressStopButton_ = 1;

				PPNC_IPC_CLIENT->Stop_SA_AutoCal_CoordinateOffset_A();
			}
		}
		else if( nSelectMeasure_ == 1 )
		{
			strMsg.Format( _T("do you want to stop single abutment auto calibration (x,y,z-axis) ?") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
			CMsgDlg::EN_RET ret = CMsgDlgThread::GetInstance()->Wait();

			if( ret == CMsgDlg::RET_OK ) 
			{
				nIsPressStopButton_ = 1;

				PPNC_IPC_CLIENT->Stop_SA_AutoCal_CoordinateOffset_XYZ();
			}
		}
	}
}

void CSetupTeachingSAAutoCalCoordOffsetDlg::OnBnClickedRadioSelectAaxis()
{
	UpdateData( TRUE );
}

void CSetupTeachingSAAutoCalCoordOffsetDlg::OnBnClickedRadioSelectXyzaxis()
{
	UpdateData( TRUE );
}
