// SetupAutoLoaderDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "SetupAutoLoaderDlg.h"
#include "SetupAutoLoaderTeachingDlg.h"
#include "SetupAutoLoaderManualOperDlg.h"
#include "MsgDlgThread.h"

// CSetupAutoLoaderDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNCREATE(CSetupAutoLoaderDlg, CDialogListPage)

CSetupAutoLoaderDlg::CSetupAutoLoaderDlg(CWnd* pParent /*=NULL*/)
	: CDialogListPage(CSetupAutoLoaderDlg::IDD, pParent)
	, nSelMode_(0)
{
	pDlgMap_ = NULL;
	pResourcePath_ = RESOURCE_2_PATH;
	isJogging = FALSE;
}

CSetupAutoLoaderDlg::~CSetupAutoLoaderDlg()
{
}

void CSetupAutoLoaderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogListPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BUTTON_DOWNLOAD_TO_CTRL, btnDownLoadToController_);
	DDX_Control(pDX, IDC_BUTTON_SAV, btnSave_);
	DDX_Control(pDX, IDC_BUTTON_CLOSE, btnClose_);
	DDX_Radio(pDX, IDC_RADIO_TEACHING_POINT2, nSelMode_);
	DDX_Control(pDX, IDC_CHECK_JOG_MODE, chkJogMode_);
	DDX_Control(pDX, IDC_BUTTON_STEP_VAL, btnJogStepVal_);
	// 	DDX_Control(pDX, IDC_BUTTON_JOG_UP, btnJogUp_);
	// 	DDX_Control(pDX, IDC_BUTTON_JOG_DOWN, btnJogDown_);
	DDX_Control(pDX, IDC_BUTTON_EMO_RESET3, btnEmoReset_);
	DDX_Control(pDX, IDC_BUTTON_JOG_MODE_STEP, btnJogModeStep_);
	DDX_Control(pDX, IDC_BUTTON_JOG_MODE_CONTINUE, btnJogModeContinue_);
	DDX_Control(pDX, IDC_BUTTON_LOAD_FROM_FILE, btnLoad_);
}

void CSetupAutoLoaderDlg::StartPageWork()
{
	nSelMode_ = 0;
	PREV_MENU_BUTTON_ENABLE_ = -1;

	setJogSpeedRate( 100 );		// jog speed rate�� 100% ���� �Ѵ� 

	nJogStep_ = 0;
	nJogMode_ = 0;
	OnBnClickedButtonJogModeStep();

	btnDownLoadToController_.EnableWindow( FALSE );
	btnSave_.EnableWindow( TRUE );
	btnLoad_.EnableWindow( TRUE );

	if( pDlgMap_ ) {
		pDlgMap_->HideAll();
		pDlgMap_->Show( _T("TEACHING") );
	}

	upload_to_pc();

	UpdateData( FALSE );

	SetTimer( 1, 200, NULL );

	//////////////////////////////////////////////////////////////////////////
	theApp.hKeyboardMgeReceiveWnd_ = GetSafeHwnd();
	//////////////////////////////////////////////////////////////////////////
	bkeyboard_jog_btn_down_ = FALSE;
}

void CSetupAutoLoaderDlg::StopPageWork()
{
	//////////////////////////////////////////////////////////////////////////
	theApp.hKeyboardMgeReceiveWnd_ = NULL;
	//////////////////////////////////////////////////////////////////////////

	KillTimer( 1 );

	setMotorOverride( 100 );
}

void CSetupAutoLoaderDlg::UpdatePage()
{

}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CSetupAutoLoaderDlg, CDialogListPage)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_RADIO_TEACHING_POINT2, &CSetupAutoLoaderDlg::OnBnClickedRadioTeachingPoint2)
	ON_BN_CLICKED(IDC_RADIO_MANUAL_OPERATION, &CSetupAutoLoaderDlg::OnBnClickedRadioManualOperation)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, &CSetupAutoLoaderDlg::OnBnClickedButtonClose)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_DOWNLOAD_TO_CTRL, &CSetupAutoLoaderDlg::OnBnClickedButtonDownloadToCtrl)
//	ON_BN_CLICKED(IDC_BUTTON_UPOAD_TO_PC, &CSetupAutoLoaderDlg::OnBnClickedButtonUpoadToPc)
	ON_BN_CLICKED(IDC_BUTTON_SAV, &CSetupAutoLoaderDlg::OnBnClickedButtonSav)
	ON_BN_CLICKED(IDC_CHECK_JOG_MODE, &CSetupAutoLoaderDlg::OnBnClickedCheckJogMode)
	ON_BN_CLICKED(IDC_BUTTON_STEP_VAL, &CSetupAutoLoaderDlg::OnBnClickedButtonStepVal)
// 	ON_MESSAGE(WM_NOTIFY_BUTTON, &CSetupAutoLoaderDlg::OnNotifyButton)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_EMO_RESET3, &CSetupAutoLoaderDlg::OnBnClickedButtonEmoReset3)
//	ON_BN_CLICKED(IDC_BUTTON_JOG_UP, &CSetupAutoLoaderDlg::OnBnClickedButtonJogUp)
	ON_BN_CLICKED(IDC_BUTTON_JOG_SPEED_UP, &CSetupAutoLoaderDlg::OnBnClickedButtonJogSpeedUp)
	ON_BN_CLICKED(IDC_BUTTON_JOG_SPEED_DOWN, &CSetupAutoLoaderDlg::OnBnClickedButtonJogSpeedDown)
	ON_MESSAGE(WM_HCCHA_KEY_MSG, &CSetupAutoLoaderDlg::OnHcchaKeyMeg)
	ON_BN_CLICKED(IDC_BUTTON_JOG_MODE_STEP, &CSetupAutoLoaderDlg::OnBnClickedButtonJogModeStep)
	ON_BN_CLICKED(IDC_BUTTON_JOG_MODE_CONTINUE, &CSetupAutoLoaderDlg::OnBnClickedButtonJogModeContinue)
	ON_WM_PAINT()
//	ON_BN_CLICKED(IDC_BUTTON_UPOAD_TO_PC, &CSetupAutoLoaderDlg::OnBnClickedButtonUpoadToPc)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_FROM_FILE, &CSetupAutoLoaderDlg::OnBnClickedButtonLoadFromFile)
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CSetupAutoLoaderDlg �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

#define WM_POINTERENTER                 0x0249
#define WM_POINTERUP                  0x0247

void CSetupAutoLoaderDlg::JOG_START_STOP( int button_id, int axis_no, BOOL dir, MSG *pMsg ) {

	if ( nJogMode_ == 0 ) {
		if( GetDlgItem(button_id)->GetSafeHwnd() == pMsg->hwnd ) {
			if( pMsg->message == WM_LBUTTONDOWN ) {
				startJog( axis_no, dir );
			}
		}
		else if( pMsg->message == WM_LBUTTONUP ) {
			if( nJogMode_ == 1 ) {	
				stopJog( axis_no, dir );
			}
		}
	} else {
		if( GetDlgItem(button_id)->GetSafeHwnd() == pMsg->hwnd) {
			if( pMsg->message == WM_POINTERENTER) {
				if (nJogMode_ == 1 && !isJogging) {
					isJogging = TRUE;
					startJog( axis_no, dir );
				}
			}
			else if( pMsg->message == WM_POINTERUP || pMsg->message == WM_LBUTTONUP ) {
				if( nJogMode_ == 1 ) {
					isJogging = FALSE;
					stopJog( axis_no, dir );
				}
			}
		}
	}
}


BOOL CSetupAutoLoaderDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	JOG_START_STOP(IDC_BUTTON_JOG_UP, 5, TRUE, pMsg);
	JOG_START_STOP(IDC_BUTTON_JOG_DOWN, 5, FALSE, pMsg);

	return CDialogListPage::PreTranslateMessage(pMsg);
}

BOOL CSetupAutoLoaderDlg::OnInitDialog()
{
	CDialogListPage::OnInitDialog();

	fJogStep_[0] = 0.01;
	fJogStep_[1] = 0.02;
	fJogStep_[2] = 0.05;
	fJogStep_[3] = 0.1;
	fJogStep_[4] = 0.2;
	fJogStep_[5] = 0.5;
	fJogStep_[6] = 1.0;
	fJogStep_[7] = 2.0;

	//////////////////////////////////////////////////////////////////////////
	//
	fntMenuButton_.CreateFont(
		17, 0, 
		0, 0, FW_BOLD,
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	btnDownLoadToController_.SetFont( &fntMenuButton_,TRUE );
	btnSave_.SetFont( &fntMenuButton_, TRUE );
	btnLoad_.SetFont( &fntMenuButton_, TRUE );
	btnClose_.SetFont( &fntMenuButton_, TRUE );
	btnEmoReset_.SetFont( &fntMenuButton_, TRUE );

	((CButton*)GetDlgItem(IDC_RADIO_TEACHING_POINT2))->SetFont( &fntMenuButton_,TRUE );
	((CButton*)GetDlgItem(IDC_RADIO_MANUAL_OPERATION))->SetFont( &fntMenuButton_,TRUE );

	CRect recbutton;
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_RADIO_TEACHING_POINT2), this, &recbutton, &PCUIrectSAL);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_RADIO_MANUAL_OPERATION), this, &recbutton, &PCUIrectSAL);

	//////////////////////////////////////////////////////////////////////////
	//
	fntOperButton_.CreateFont(
		14, 0, 
		0, 0, FW_BOLD,
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	((CButton*)GetDlgItem(IDC_BUTTON_JOG_UP))->SetFont( &fntOperButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_JOG_DOWN))->SetFont( &fntOperButton_, TRUE );

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_JOG_UP), this, &recbutton, &PCUIrectSAL);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_JOG_DOWN), this, &recbutton, &PCUIrectSAL);

	btnJogModeStep_.SetFont( &fntOperButton_, TRUE );
	btnJogModeContinue_.SetFont( &fntOperButton_, TRUE );
	btnJogStepVal_.SetFont( &fntOperButton_, TRUE );

	//////////////////////////////////////////////////////////////////////////
	//
	fntJogSpd_.CreateFont(
		18, 0, 
		0, 0, FW_BOLD,
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	((CButton*)GetDlgItem(IDC_STATIC_JOG_SPEED))->SetFont( &fntJogSpd_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_JOG_SPEED_UP))->SetFont( &fntOperButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_JOG_SPEED_DOWN))->SetFont( &fntOperButton_, TRUE );

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_STATIC_JOG_SPEED), this, &recbutton, &PCUIrectSAL);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_JOG_SPEED_UP), this, &recbutton, &PCUIrectSAL);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_JOG_SPEED_DOWN), this, &recbutton, &PCUIrectSAL);

	CString strTemp;
	strTemp.Format( _T("%d%%"), pa::PPAStatus->GetThreadState()->nJogSpeed_ ); //
	((CStatic*)GetDlgItem(IDC_STATIC_JOG_SPEED))->SetWindowText( strTemp );

	//////////////////////////////////////////////////////////////////////////
	//
	CRect rcTemp;
	hcutil::GetControlPos2( IDC_STATIC_AREA, this, &rcTemp, &PCUIrectSAL, TRUE );

	pDlgMap_ = new CDialogMap();
	ASSERT( pDlgMap_ );
	pDlgMap_->Initialize( this );
	pDlgMap_->AddDialog( _T("TEACHING"), RUNTIME_CLASS(CSetupAutoLoaderTeachingDlg), IDD_DIALOG_SETUP_AUTOLOADER_TEACHING, rcTemp );
	pDlgMap_->AddDialog( _T("MANUAL_OPER"), RUNTIME_CLASS(CSetupAutoLoaderManualOperDlg), IDD_DIALOG_SETUP_AUTOLOADER_MANUAL_OPER, rcTemp );
	pDlgMap_->HideAll();
	pDlgMap_->Show( _T("TEACHING") );

	//////////////////////////////////////////////////////////////////////////
	//
	brhBkgnd_.CreateSolidBrush( pa::CLR_SETUP_AUTOLOADER );
	brhEmoResetButton_.CreateSolidBrush( pa::CLR_BUTTON_EMO_RESET );
	brhBackButton_.CreateSolidBrush( pa::CLR_BUTTON_BACK );

	//////////////////////////////////////////////////////////////////////////
	//
	hcutil::GetControlPos2( IDC_STATIC_POS_WND, this, &rcTemp, &PCUIrectSAL, TRUE );
	pPositionMiniWnd_ = new CPositionMiniWnd();
	ASSERT( pPositionMiniWnd_ );
	pPositionMiniWnd_->Create( this, rcTemp, 5 );
	pPositionMiniWnd_->SetWindowPos( &wndTop, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE );
	
	//////////////////////////////////////////////////////////////////////////
	//
	hcutil::GetControlPos2( IDC_STATIC_AL_POS_AREA, this, &rcTemp, &PCUIrectSAL, TRUE );
	pPositionTitleWnd_ = new CTitleBarWnd;
	ASSERT( pPositionTitleWnd_ );
	pPositionTitleWnd_->InitResource( CString(_T("Positiin")), pa::CLR_SETUP_AUTOLOADER, RGB(32, 32, 32), RGB(32, 32, 32), CSize(8, 16) );
	pPositionTitleWnd_->Create( this, rcTemp, IDC_STATIC_AL_POS_AREA );
	pPositionTitleWnd_->SetWindowPos( &wndTop, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE );

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_EMO_RESET3), this, &recbutton, &PCUIrectSAL);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_CLOSE), this, &recbutton, &PCUIrectSAL);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_JOG_MODE_STEP), this, &recbutton, &PCUIrectSAL);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_JOG_MODE_CONTINUE), this, &recbutton, &PCUIrectSAL);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_DOWNLOAD_TO_CTRL), this, &recbutton, &PCUIrectSAL);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_SAV), this, &recbutton, &PCUIrectSAL);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_LOAD_FROM_FILE), this, &recbutton, &PCUIrectSAL);	
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON16), this, &recbutton, &PCUIrectSAL);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON17), this, &recbutton, &PCUIrectSAL);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON27), this, &recbutton, &PCUIrectSAL);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_STEP_VAL), this, &recbutton, &PCUIrectSAL);
	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_AL_JOG), this, &recbutton, &PCUIrectSAL);


	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CSetupAutoLoaderDlg::OnDestroy()
{
	if( pPositionTitleWnd_ ) {
		pPositionTitleWnd_->DestroyWindow();
		delete pPositionTitleWnd_;
		pPositionTitleWnd_ = NULL;
	}

	if( pPositionMiniWnd_ ) {
		pPositionMiniWnd_->DestroyWindow();
		delete pPositionMiniWnd_;
		pPositionMiniWnd_ = NULL;
	}

	if (pDlgMap_){
		pDlgMap_->Destroy();
		delete pDlgMap_;
		pDlgMap_ = NULL;
	}

	fntMenuButton_.DeleteObject();

	fntJogSpd_.DeleteObject();

	fntOperButton_.DeleteObject();

	brhBkgnd_.DeleteObject();

	brhEmoResetButton_.DeleteObject();

	brhBackButton_.DeleteObject();

	if( pCanvasCE_ ) {
		delete pCanvasCE_;
		pCanvasCE_ = NULL;
	}

	CDialogListPage::OnDestroy();
}

void CSetupAutoLoaderDlg::OnBnClickedButtonClose()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("back button click") );
	//////////////////////////////////////////////////////////////////////////
	ASSERT( pParentWnd_ );
	pParentWnd_->PostMessage( WM_SETUP, (WPARAM)SETUP_BACK, (LPARAM)0 );
}

void CSetupAutoLoaderDlg::OnBnClickedRadioTeachingPoint2()
{
	UpdateData( TRUE );
	btnDownLoadToController_.EnableWindow( TRUE );
	btnSave_.EnableWindow( TRUE );
	btnLoad_.EnableWindow( TRUE );

	pDlgMap_->HideAll();
	pDlgMap_->Show( _T("TEACHING") );
}

void CSetupAutoLoaderDlg::OnBnClickedRadioManualOperation()
{
	UpdateData( TRUE );
	btnDownLoadToController_.EnableWindow( FALSE );
	btnSave_.EnableWindow( FALSE );
	btnLoad_.EnableWindow( FALSE );

	pDlgMap_->HideAll();
	pDlgMap_->Show( _T("MANUAL_OPER") );
}


HBRUSH CSetupAutoLoaderDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogListPage::OnCtlColor(pDC, pWnd, nCtlColor);

	pDC->SetBkMode( TRANSPARENT );

	if( nCtlColor == 4 ) {
		hbr = (HBRUSH)brhBkgnd_;
	}
	else {
		UINT nID = pWnd->GetDlgCtrlID();
		if( nID == IDC_STATIC_AL_JOG ) {
			hbr = (HBRUSH)brhBkgnd_;
		}
		else if( nID == IDC_BUTTON_EMO_RESET3 ) {
			hbr = (HBRUSH)brhEmoResetButton_;
		}
		else if( nID == IDC_BUTTON_CLOSE ) {
			hbr = (HBRUSH)brhBackButton_;
		}
		else if( nID == IDC_STATIC_JOG_SPEED ) {
			hbr = (HBRUSH)brhBkgnd_;
			pDC->SetBkMode( TRANSPARENT );
		}
		else if( nID == IDC_BUTTON_JOG_MODE_STEP ) {
			if( nJogMode_ == 0 ) {
				pDC->SetTextColor( RGB(255, 0, 0 ) );
			} else {
				pDC->SetTextColor( RGB(64, 64, 64 ) );
			}
		}
		else if( nID == IDC_BUTTON_JOG_MODE_CONTINUE ) {
			if( nJogMode_ == 1 ) {
				pDC->SetTextColor( RGB( 255, 0, 0 ) );
			} else {
				pDC->SetTextColor( RGB( 64, 64, 64 ) );
			}
		}
	}
	
	return hbr;
}

// AutoLoader �����͸� ������ �ٿ�ε� �Ѵ� 
void CSetupAutoLoaderDlg::OnBnClickedButtonDownloadToCtrl()
{
	CString strMsg;
	DWORD dwTime = 0;

	UpdateData( TRUE );

	strMsg.Format( _T("Do you want to download data to controllor ?") );
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
	CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();
	if( hRet == CMsgDlg::RET_CANCEL ) {
		return ;
	}

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("download autoloader teaching point data button click") );
	//////////////////////////////////////////////////////////////////////////

	strMsg.Format( _T("wait for download autoloader teaching point data") );
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

	// Autoloader teaching point 
	pa::PPAStatus->SetIpcCommandComplete( FALSE );
	PPNC_IPC_CLIENT->DownloadAutoLoaderTeachingPoint();
	Sleep( 100 );
	dwTime = GetTickCount();
	while( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == FALSE ) {
		if( ( GetTickCount() - dwTime ) > 60*1000 ) {
			// ���� 
			strMsg.Format( _T("Timeout error") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_ERROR, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
			return ;
		}
		Sleep( 100 );
	}

	CMsgDlgThread::GetInstance()->Hide();

	//////////////////////////////////////////////////////////////////////////
	// 2016.02.25: �ٿ�ε带 ���� ���, ���� ���� ���� ���� ���� �Ѵ� 
	int nTempNumBlock = pa::PAutoLoader->GetTeachingPoint( pa::AUTOLOADER_TP_NUM_BLOCK );
	pa::PAutoLoader->pAutoLoaderConfig_->nNumBlock_ = nTempNumBlock;
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	// ���� ���� Ȯ�� 
	//////////////////////////////////////////////////////////////////////////
	OnBnClickedButtonSav();
}

// ����⸦ �����Ѵ� 
void CSetupAutoLoaderDlg::OnBnClickedButtonSav()
{
	CString strMsg, strErrMsg;

	strMsg.Format( _T("do you want to save autoloader teaching point data in \"al_teachingpoint.ini\" file ?") );

	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
	CMsgDlg::EN_RET ret = CMsgDlgThread::GetInstance()->Wait();
	if( ret == CMsgDlg::RET_CANCEL ) {
		return ;
	}

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("save autoloader teaching point data to file button click") );
	//////////////////////////////////////////////////////////////////////////

	strMsg.Format( _T("wait for save autoloader teaching point data") );
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

	// Coordinate Offset 
	if( save_to_file_autoloader_teaching_point( strErrMsg ) ) {
		CMsgDlgThread::GetInstance()->Hide();
		((CSetupAutoLoaderTeachingDlg*)pDlgMap_->GetDialog( _T("TEACHING")) )->UpdateTeachingDataListBox();
	} else {
		// ERROR
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strErrMsg );
		CMsgDlgThread::GetInstance()->Wait();
	}
}

//////////////////////////////////////////////////////////////////////////

void CSetupAutoLoaderDlg::OnBnClickedCheckJogMode()
{
	// ��� ���� 
}

#include "SelectJogStepDlg.h"
void CSetupAutoLoaderDlg::OnBnClickedButtonStepVal()
{
	CSelectJogStepDlg dlg;
	CRect	rcBtn;
	CString strTemp;

	btnJogStepVal_.GetWindowRect( &rcBtn );

	dlg.SetInitPos( CPoint( rcBtn.left, rcBtn.bottom + 2 ) );
	dlg.SetJogStepIndex( nJogStep_ );
	dlg.DoModal();

	updateJogStepVal( dlg.GetJogStepIndex() );
}

void CSetupAutoLoaderDlg::updateJogStepVal( int nJogStep )
{
	CString strTemp;

	nJogStep_ = nJogStep;

	strTemp.Format( _T("%.2f mm"), fJogStep_[nJogStep_] );

	btnJogStepVal_.SetWindowText( strTemp );
}	

//////////////////////////////////////////////////////////////////////////
//

void CSetupAutoLoaderDlg::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 1 ) 
	{
		KillTimer( 1 );

		update_PositionMiniWnd();

		updateState_MenuButton();

		updateState_JobButton();

		if( IsWindowVisible() ) {
			SetTimer( 1, 200, NULL );
		}
	}

	CDialogListPage::OnTimer(nIDEvent);
}

void CSetupAutoLoaderDlg::update_PositionMiniWnd()
{
	if( pPositionMiniWnd_ ) {
		pPositionMiniWnd_->Update();
	}
}

void CSetupAutoLoaderDlg::updateState_MenuButton()
{
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetRunMode();	//::PState->GetRunMode();
	int nEnable = 1;

	//////////////////////////////////////////////////////////////////////////
	//
	if( pa::GET_CURRENT_USERMODE() < pa::USER_MODE_MGR ) 
	{
		((CButton*)GetDlgItem(IDC_BUTTON_DOWNLOAD_TO_CTRL))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_SAV))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_LOAD_FROM_FILE))->EnableWindow( FALSE );
		return ;
	}

	//////////////////////////////////////////////////////////////////////////
	//
	if(
		( hRunMode != pa::RUNMODE_STOP ) ||
		( pa::PPAStatus->GetPAStatus()->nRunStatus != pa::PA_RUN_STATUS_IDLE ) ||
		( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == FALSE ) ||
		( nSelMode_ == 1 ) )
	{
		nEnable = 0;
	}

	if( PREV_MENU_BUTTON_ENABLE_ != nEnable )
	{
		PREV_MENU_BUTTON_ENABLE_ = nEnable;
		((CButton*)GetDlgItem(IDC_BUTTON_DOWNLOAD_TO_CTRL))->EnableWindow( nEnable );
		((CButton*)GetDlgItem(IDC_BUTTON_SAV))->EnableWindow( nEnable );
		((CButton*)GetDlgItem(IDC_BUTTON_LOAD_FROM_FILE))->EnableWindow( nEnable );	// IDC_BUTTON_UPOAD_TO_PC
	}

}

void CSetupAutoLoaderDlg::updateState_JobButton()
{
	static int PREV_ENABLE = -1;
	pa::EN_RUNMODE hRunMode = pa::PPAStatus->GetRunMode();
	int nEnable = 0;

	//////////////////////////////////////////////////////////////////////////
	//
	if( pa::GET_CURRENT_USERMODE() < pa::USER_MODE_MGR )
	{
		((CButton*)GetDlgItem(IDC_BUTTON_JOG_MODE_STEP))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_JOG_MODE_CONTINUE))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_STEP_VAL))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_JOG_UP))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_JOG_DOWN))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_JOG_SPEED_UP))->EnableWindow( FALSE );
		((CButton*)GetDlgItem(IDC_BUTTON_JOG_SPEED_DOWN))->EnableWindow( FALSE );
		PREV_ENABLE = -1;
	}
	else 
	{
		if( hRunMode == pa::RUNMODE_STOP || hRunMode == pa::RUNMODE_ERROR ) {
			nEnable = 1;
		}

		if( PREV_ENABLE != nEnable ) {
			PREV_ENABLE = nEnable;
			((CButton*)GetDlgItem(IDC_BUTTON_JOG_MODE_STEP))->EnableWindow( nEnable );
			((CButton*)GetDlgItem(IDC_BUTTON_JOG_MODE_CONTINUE))->EnableWindow( nEnable );
			((CButton*)GetDlgItem(IDC_BUTTON_STEP_VAL))->EnableWindow( nEnable );
			((CButton*)GetDlgItem(IDC_BUTTON_JOG_UP))->EnableWindow( nEnable );
			((CButton*)GetDlgItem(IDC_BUTTON_JOG_DOWN))->EnableWindow( nEnable );
// 			((CButton*)GetDlgItem(IDC_BUTTON_JOG_SPEED_UP))->EnableWindow( nEnable );
// 			((CButton*)GetDlgItem(IDC_BUTTON_JOG_SPEED_DOWN))->EnableWindow( nEnable );

			if (theApp.IsMotorStop() == TRUE) {
				((CButton*)GetDlgItem(IDC_BUTTON_JOG_SPEED_UP))->EnableWindow( nEnable );
				((CButton*)GetDlgItem(IDC_BUTTON_JOG_SPEED_DOWN))->EnableWindow( nEnable );
			} else {
				((CButton*)GetDlgItem(IDC_BUTTON_JOG_SPEED_UP))->EnableWindow( FALSE );
				((CButton*)GetDlgItem(IDC_BUTTON_JOG_SPEED_DOWN))->EnableWindow( FALSE );
			}
		}
	}
	// Jog Speed Rate�� update �Ѵ� 
	static int PREV_JOG_SPEED_RATE = -1;
	if( PREV_JOG_SPEED_RATE != pa::PPAStatus->GetThreadState()->nJogSpeed_ ) {
		PREV_JOG_SPEED_RATE = pa::PPAStatus->GetThreadState()->nJogSpeed_;
		CString strTemp;
		strTemp.Format( _T("%d%%"), PREV_JOG_SPEED_RATE );
		((CStatic*)GetDlgItem(IDC_STATIC_JOG_SPEED))->SetWindowText( strTemp );
	}
}

void CSetupAutoLoaderDlg::OnBnClickedButtonEmoReset3()
{
	if( pa::PPAStatus->GetRunMode() == pa::RUNMODE_ERROR ) {
		//////////////////////////////////////////////////////////////////////////
		// log
		writeLog( _T("reset button click") );
		//////////////////////////////////////////////////////////////////////////
		// Reset
		PPNC_IPC_CLIENT->ErrorReset();
	} else {
		//////////////////////////////////////////////////////////////////////////
		// log
		writeLog( _T("emo button click") );
		//////////////////////////////////////////////////////////////////////////
		// EMO
		PPNC_IPC_CLIENT->Emergency();
	}
}

void CSetupAutoLoaderDlg::writeLog( LPCTSTR log_msg )
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	WriteLog( CLog::TYPE_OPER, 8, log_msg );
	//////////////////////////////////////////////////////////////////////////
}

void CSetupAutoLoaderDlg::startJog( int axis, BOOL dir )
{
	BOOL	is_step = nJogMode_ == 0 ? TRUE : FALSE;
	double	stepVal = fJogStep_[nJogStep_];

	//////////////////////////////////////////////////////////////////////////
	// log 
	CString strLog;
	strLog.Format( _T("start log. %s(%.3f) C%s"), 
		(is_step ? _T("STEP") : _T("CONT")), 
		stepVal, 
		(dir ? _T("+") : _T("-")) );
	writeLog( strLog );
	//////////////////////////////////////////////////////////////////////////

	PPNC_IPC_CLIENT->StartJog( (pa::EN_AXIS)axis, dir, is_step, stepVal );
}

void CSetupAutoLoaderDlg::startJog( pa::EN_AXIS axis, BOOL dir, int nstep )
{
	if( nstep < 0 ) {
		return ;
	}

	BOOL	is_step = ( nstep == 0 ) ? FALSE : TRUE;
	double	stepVal = fJogStep_[nJogStep_];

	//////////////////////////////////////////////////////////////////////////
	// log 
	static TCHAR *AXIS_NAME = _T("XYZABC");
	CString strLog;
	strLog.Format( _T("start jog. %s(%.3f) %c%s"), 
		(is_step ? _T("STEP") : _T("CONT")), 
		stepVal, 
		AXIS_NAME[axis],
		(dir ? _T("+") : _T("-")) );
	writeLog( strLog );
	//////////////////////////////////////////////////////////////////////////

	PPNC_IPC_CLIENT->StartJog( axis, dir, is_step, stepVal );
}

void CSetupAutoLoaderDlg::stopJog( int axis, BOOL dir )
{
	PPNC_IPC_CLIENT->StopJog( (pa::EN_AXIS)axis, dir );
}

void CSetupAutoLoaderDlg::OnBnClickedButtonJogSpeedUp()
{
	int nNewSpdRate = pa::PPAStatus->GetThreadState()->nJogSpeed_ + 5; 
	setJogSpeedRate( nNewSpdRate );
}

void CSetupAutoLoaderDlg::OnBnClickedButtonJogSpeedDown()
{
	int nNewSpdRate = pa::PPAStatus->GetThreadState()->nJogSpeed_ - 5; 
	setJogSpeedRate( nNewSpdRate );
}

void CSetupAutoLoaderDlg::setMotorOverride( int nNewOvr )
{
	char	szCommand[32];

	nNewOvr = (nNewOvr <= 0) ? 0 : nNewOvr;
	nNewOvr = (nNewOvr >= 200) ? 200 : nNewOvr;

	memset( (void*)szCommand, 0, sizeof(char)*32 );

	sprintf_s( szCommand, 31, "%%%d", nNewOvr );

//	PPNC_IPC_CLIENT->TerminalCommand( szCommand );
}

void CSetupAutoLoaderDlg::setJogSpeedRate( int nNewSpdRate )
{
	int nJogSpeedRate = nNewSpdRate;

	if( nJogSpeedRate < 5 ) {
		nJogSpeedRate = 5;
	} 
	else if( nJogSpeedRate > 100 ) {
		nJogSpeedRate = 100;
	}

	//////////////////////////////////////////////////////////////////////////
	//
	char szTemp[64];
	sprintf_s( szTemp, 64, "WJSS %d", nJogSpeedRate );
	PPNC_IPC_CLIENT->SendCommand( szTemp, 5000 );
	pa::PPAStatus->GetThreadState()->nJogSpeed_ = nJogSpeedRate;
	//////////////////////////////////////////////////////////////////////////
}

//////////////////////////////////////////////////////////////////////////

LRESULT CSetupAutoLoaderDlg::OnHcchaKeyMeg(WPARAM wparam, LPARAM lparam)
{
	MSG		*pMsg = (MSG*)wparam;
	LRESULT	ret = 0;

	UINT	nVirtualKeyCode = pMsg->wParam;
	BOOL	bPressLShiftKey = (BOOL)( GetAsyncKeyState( VK_LSHIFT ) != 0 );		// ������ 1
	BOOL	bPressLCtrlKey	= (BOOL)( GetAsyncKeyState( VK_LCONTROL ) != 0 );	// ������ 1
	int		nTemp = 0;

	if( pMsg->message == WM_KEYDOWN ) 
	{
		int is_step;
		if( bPressLCtrlKey ) { is_step = 1; }
		else if( bPressLShiftKey ) { is_step = 0; }
		else { is_step = -1; }

		// Ű���尡 �������� ���� ���, �����Ѵ� 
		if( is_step == 1 && bkeyboard_jog_btn_down_ == TRUE ) {
			return 1;
		}

		bkeyboard_jog_btn_down_ = TRUE;

		switch( nVirtualKeyCode )
		{
		case 37:	// X+ ����Ű �������� �ʵ���...
		case 39:	// X-
		case 40:	// Y+
		case 38:	// Y-
			ret = 1; 
			break;

		case 33:	// Z+
			startJog( (pa::EN_AXIS)5, TRUE, is_step ); ret = 1; break;
		case 34:	// Z-
			startJog( (pa::EN_AXIS)5, FALSE, is_step ); ret = 1; break;

		case 187:	// JogSpd+
			setMotorOverride( pa::PPAStatus->GetPAStatus()->nMotorOverride + 5 ); ret = 1; break;

		case 189:	// JpgSpd-
			setMotorOverride( pa::PPAStatus->GetPAStatus()->nMotorOverride - 5 ); ret = 1; break;

		case 81:	// step val + 81 'q'
			nJogStep_ += 1;
			nJogStep_ %= 8;
			updateJogStepVal( nJogStep_ );
			break;
		case 65:	// step val - 65 'a'
			nJogStep_ -= 1;
			if( nJogStep_ < 0 ) {
				nJogStep_ = 7;
			}
			updateJogStepVal( nJogStep_ );
			break;

			//////////////////////////////////////////////////////////////////////////
			// ��� ����
		case VK_ESCAPE:
		case VK_SPACE:
			PPNC_IPC_CLIENT->Emergency();
			break;
			//////////////////////////////////////////////////////////////////////////

		}
		CString str;
		str.Format( _T("VK : %d\n"), nVirtualKeyCode );
		TRACE( str );
	}
	else if( pMsg->message == WM_KEYUP )
	{
		switch( nVirtualKeyCode )
		{
		case 33:	// Z+
			stopJog( (pa::EN_AXIS)5, TRUE ); 
			ret = 1; 
			break;
		case 34:	// Z-
			stopJog( (pa::EN_AXIS)5, FALSE ); 
			ret = 1; 
			break;
		}

		bkeyboard_jog_btn_down_ = FALSE;
	}

	return ret;
}

//////////////////////////////////////////////////////////////////////////

void CSetupAutoLoaderDlg::OnBnClickedButtonJogModeStep()
{
	nJogMode_ = 0;
	btnJogModeStep_.Invalidate( FALSE );
	btnJogModeContinue_.Invalidate( FALSE );

	updateJogStepVal( nJogStep_ );
	btnJogStepVal_.EnableWindow( TRUE );
}

void CSetupAutoLoaderDlg::OnBnClickedButtonJogModeContinue()
{
	nJogMode_ = 1;
	btnJogModeStep_.Invalidate( FALSE );
	btnJogModeContinue_.Invalidate( FALSE );

	btnJogStepVal_.SetWindowText( _T("") );
	btnJogStepVal_.EnableWindow( FALSE );
}


void CSetupAutoLoaderDlg::PreInitDialog()
{
	CString strImageFilePath;
	CDC*	pDC = GetDC();
	CRect	rcWnd;

	//////////////////////////////////////////////////////////////////////////
	strImageFilePath.Format( _T("%s\\Background_setup.bmp"), pResourcePath_ );

	GetClientRect( &PCUIrectSAL );
	MoveWindow(0,0,1023,619);
	GetClientRect( &rcWnd );

	pCanvasCE_ = new hcutil::CCanvasCE();
	ASSERT(pCanvasCE_ );
	pCanvasCE_->Create( this, pDC->GetSafeHdc(), rcWnd.Width(), rcWnd.Height(), RGB(1, 1, 0) );
	pCanvasCE_->GetCanvasCELayerMgr()->Add( FALSE, RGB(0, 0, 0) );
	pCanvasCE_->GetCanvasCELayerMgr()->Add( TRUE, RGB(255, 0, 255) );

	pCanvasCE_->GetCanvasCELayerMgr()->Get( 0 )->FillSolidRect( rcWnd, pa::CLR_SETUP_AUTOLOADER );
	pCanvasCE_->GetCanvasCELayerMgr()->Get( 1 )->LoadImageFormFile( strImageFilePath, CPoint(0, 0), CPoint(rcWnd.Width(), rcWnd.Height()) );
	//////////////////////////////////////////////////////////////////////////

	ReleaseDC( pDC );
	pDC = NULL;

	CDialogListPage::PreInitDialog();
}

void CSetupAutoLoaderDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	if( pCanvasCE_ ) {
		pCanvasCE_->Draw( dc.m_hDC, dc.m_ps.rcPaint );
	}
}

void CSetupAutoLoaderDlg::upload_to_pc()
{
	CString strMsg;
	DWORD	dwTime;

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("upload autoloader teaching point data") );
	//////////////////////////////////////////////////////////////////////////

#ifdef _HAS_MACHINE_
	strMsg.Format( _T("wait for upload autoloader teaching point data") );
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

	pa::PPAStatus->SetIpcCommandComplete( FALSE );
	pa::PPAStatus->GetThreadState()->bIpcUpDownLoadComplete_ = FALSE;
	PPNC_IPC_CLIENT->UploadAutoLoaderTeachingPoint();
	Sleep( 100 );
	dwTime = GetTickCount();
	while( pa::PPAStatus->GetThreadState()->bIpcUpDownLoadComplete_ == FALSE ) 
	{
		//	AfxMessageBox( _T("sleep") );
		if( ( GetTickCount() - dwTime ) > 5*1000 ) {
			// ���� 
			strMsg.Format( _T("Failed  to upload autoloader teaching point data") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
			return ;
		}
		Sleep( 100 );
	}

	CMsgDlgThread::GetInstance()->Hide();
	((CSetupAutoLoaderTeachingDlg*)pDlgMap_->GetDialog( _T("TEACHING")) )->UpdateTeachingDataListBox();
#endif

}

// teaching point �����͸� ���Ͽ� ���� �Ѵ� 
BOOL CSetupAutoLoaderDlg::save_to_file_autoloader_teaching_point( CString& strErrMsg )
{
	CString		strKeyName, strValueName;
	CCEIniFile	hIniFile;

	if( !hIniFile.Open( INI_AL_TEACHING_POINT_PATH ) ) {
		strErrMsg.Format( _T("ERROR : config file open fail (CSetupAutoLoaderDlg::save_to_file_autoloader_teaching_point())") );
		return FALSE;
	}

	strKeyName.Format( _T("AutoLoader") );

	for( int i = 0; i<(int)pa::AUTOLOADER_TP_NUM; i++ )
	{
		strValueName = pa::STR_AUTOLOADER_TEACHING_POINT_NAME[i];
		hIniFile.SetValue( strKeyName, strValueName, (double)pa::PAutoLoader->pAutoLoaderConfig_->fTeachingPoint_[i] );
	}

	hIniFile.Close();

	return TRUE;
}

// ���Ͽ��� teching point �����͸� �о� ���δ� 
BOOL CSetupAutoLoaderDlg::load_from_file_autoloader_teaching_point( CString& strErrMsg )
{
	CString		strKeyName, strValueName;
	CCEIniFile	hIniFile;
	double		fTemp;

	if( !hIniFile.Open( INI_AL_TEACHING_POINT_PATH ) ) {
		strErrMsg.Format( _T("ERROR : config file open fail (CSetupAutoLoaderDlg::save_to_file_autoloader_teaching_point())") );
		return FALSE;
	}

	strKeyName.Format( _T("AutoLoader") );

	for( int i = 0; i<(int)pa::AUTOLOADER_TP_NUM; i++ )
	{
		strValueName = pa::STR_AUTOLOADER_TEACHING_POINT_NAME[i];
		hIniFile.GetValue( strKeyName, strValueName, (double*)&fTemp );
		pa::PAutoLoader->pAutoLoaderConfig_->fTeachingPoint_[i] = fTemp;
	}

	hIniFile.Close();

	return TRUE;
}

void CSetupAutoLoaderDlg::OnBnClickedButtonLoadFromFile()
{
	CString strMsg, strErrMsg;

	strMsg.Format( _T("do you want to load autoloader teaching point data in \"al_teachingpoint.ini\" file ?") );

	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
	CMsgDlg::EN_RET ret = CMsgDlgThread::GetInstance()->Wait();
	if( ret == CMsgDlg::RET_CANCEL ) {
		return ;
	}

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("load autoloader teaching point data to file button click") );
	//////////////////////////////////////////////////////////////////////////

	strMsg.Format( _T("wait for loading autoloader teaching point data") );
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

	// Coordinate Offset 
	if( load_from_file_autoloader_teaching_point( strErrMsg ) ) {
		CMsgDlgThread::GetInstance()->Hide();
		((CSetupAutoLoaderTeachingDlg*)pDlgMap_->GetDialog( _T("TEACHING")) )->UpdateTeachingDataListBox();
	} else {
		// ERROR
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strErrMsg );
		CMsgDlgThread::GetInstance()->Wait();
	}
}
