// RegisterRelToolDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "RegisterRelToolDlg.h"


// CRegisterRelToolDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CRegisterRelToolDlg, CDialog)

CRegisterRelToolDlg::CRegisterRelToolDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRegisterRelToolDlg::IDD, pParent)
{

}

CRegisterRelToolDlg::~CRegisterRelToolDlg()
{
}

void CRegisterRelToolDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_MGR, stcMsg_);
	DDX_Control(pDX, IDC_BUTTON_M140, btnM140_);
	DDX_Control(pDX, IDC_BUTTON_M141, btnM141_);
	DDX_Control(pDX, IDC_BUTTON_M142, btnM142_);
	DDX_Control(pDX, IDC_BUTTON_M143, btnM143_);
	DDX_Control(pDX, IDC_BUTTON_M144, btnM144_);
	DDX_Control(pDX, IDC_BUTTON_M145, btnM145_);
	DDX_Control(pDX, IDC_BUTTON_M146, btnM146_);
	DDX_Control(pDX, IDC_BUTTON_M147, btnM147_);
	DDX_Control(pDX, IDC_BUTTON_CLR, btnCLR_);
	DDX_Control(pDX, IDC_BUTTON_CANCEL, btnCancel_);
	DDX_Control(pDX, IDC_BUTTON_OK, btnOk_);
}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CRegisterRelToolDlg, CDialog)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_CANCEL, &CRegisterRelToolDlg::OnBnClickedButtonCancel)
	ON_BN_CLICKED(IDC_BUTTON_M140, &CRegisterRelToolDlg::OnBnClickedButtonM140)
	ON_BN_CLICKED(IDC_BUTTON_M141, &CRegisterRelToolDlg::OnBnClickedButtonM141)
	ON_BN_CLICKED(IDC_BUTTON_M142, &CRegisterRelToolDlg::OnBnClickedButtonM142)
	ON_BN_CLICKED(IDC_BUTTON_M143, &CRegisterRelToolDlg::OnBnClickedButtonM143)
	ON_BN_CLICKED(IDC_BUTTON_M144, &CRegisterRelToolDlg::OnBnClickedButtonM144)
	ON_BN_CLICKED(IDC_BUTTON_M145, &CRegisterRelToolDlg::OnBnClickedButtonM145)
	ON_BN_CLICKED(IDC_BUTTON_M146, &CRegisterRelToolDlg::OnBnClickedButtonM146)
	ON_BN_CLICKED(IDC_BUTTON_M147, &CRegisterRelToolDlg::OnBnClickedButtonM147)
	ON_BN_CLICKED(IDC_BUTTON_CLR, &CRegisterRelToolDlg::OnBnClickedButtonClr)
	ON_BN_CLICKED(IDC_BUTTON_OK, &CRegisterRelToolDlg::OnBnClickedButtonOk)
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CRegisterRelToolDlg �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CRegisterRelToolDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CRegisterRelToolDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Font 
	fntStc_.CreateFont( 
		32, 0, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Courier New") ); //_T("MS Sans Serif") );

	fntBtn_.CreateFont( 
		20, 0, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Courier New") ); //_T("MS Sans Serif") );


	stcMsg_.SetFont( &fntStc_, TRUE );
	btnM140_.SetFont( &fntBtn_, TRUE );
	btnM141_.SetFont( &fntBtn_, TRUE );
	btnM142_.SetFont( &fntBtn_, TRUE );
	btnM143_.SetFont( &fntBtn_, TRUE );
	btnM144_.SetFont( &fntBtn_, TRUE );
	btnM145_.SetFont( &fntBtn_, TRUE );
	btnM146_.SetFont( &fntBtn_, TRUE );
	btnM147_.SetFont( &fntBtn_, TRUE );
	btnCLR_.SetFont( &fntBtn_, TRUE );
	btnCancel_.SetFont( &fntBtn_, TRUE );
	btnOk_.SetFont( &fntBtn_, TRUE );

	strMsg_.Format( _T("") );
	
	//////////////////////////////////////////////////////////////////////////
	// Center Window 
	CenterWindow();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CRegisterRelToolDlg::OnDestroy()
{
	fntStc_.DeleteObject();
	fntBtn_.DeleteObject();

	CDialog::OnDestroy();
}


void CRegisterRelToolDlg::OnBnClickedButtonCancel()
{
	CDialog::OnCancel();
}

void CRegisterRelToolDlg::OnBnClickedButtonOk()
{
	CDialog::OnOK();
}

//////////////////////////////////////////////////////////////////////////

void CRegisterRelToolDlg::OnBnClickedButtonM140()
{
	addTool( 140 );
}

void CRegisterRelToolDlg::OnBnClickedButtonM141()
{
	addTool( 141 );
}

void CRegisterRelToolDlg::OnBnClickedButtonM142()
{
	addTool( 142 );
}

void CRegisterRelToolDlg::OnBnClickedButtonM143()
{
	addTool( 143 );
}

void CRegisterRelToolDlg::OnBnClickedButtonM144()
{
	addTool( 144 );
}

void CRegisterRelToolDlg::OnBnClickedButtonM145()
{
	addTool( 145 );
}

void CRegisterRelToolDlg::OnBnClickedButtonM146()
{
	addTool( 146 );
}

void CRegisterRelToolDlg::OnBnClickedButtonM147()
{
	addTool( 147 );
}

void CRegisterRelToolDlg::OnBnClickedButtonClr()
{
	strMsg_.Format( _T("") );
	stcMsg_.SetWindowText( strMsg_ );
}

void CRegisterRelToolDlg::addTool( int toolNo )
{
	CString strTemp;

// 	if( strMsg_.IsEmpty() ) {
// 		strTemp.Format( _T("M%d"), toolNo );
// 	}
// 	else {
// 		strTemp.Format( _T("+M%d"), toolNo );
// 	}

	strTemp.Format( _T("M%d+"), toolNo );

	strMsg_ += strTemp;
	
	stcMsg_.SetWindowText( strMsg_ );
}

//////////////////////////////////////////////////////////////////////////
