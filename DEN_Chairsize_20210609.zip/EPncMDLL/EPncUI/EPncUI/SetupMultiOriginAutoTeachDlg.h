#pragma once

#include "OptionDataListBox.h"
#include "TitleBarWnd.h"
#include "afxwin.h"

// CSetupMultiOriginAutoTeachDlg ��ȭ �����Դϴ�.

class CSetupMultiOriginAutoTeachDlg : public CDialogListPage
{
	DECLARE_DYNCREATE(CSetupMultiOriginAutoTeachDlg)

	CWnd*	pParent_;
	CTitleBarWnd*		pTitleBarWnd_;
	COptionDataListBox*	pParamListBox_;

	pa::SAutoTeachMultiOrgParam	hTempAutoTeachMultiOrgParam_;	// ������ �����...

	CBrush	brhBkgnd_;		// ���� 
	CFont	fntComBo_;		// 
	CFont	fntBtn_;		// Run ��ư  
	int		nIsPressStopButton_;	// 

	CRect	CUIrectSTMOA; 

	void updateButtonState();
	void updateCheckBoxState();

	void update_init_control();

	void writeLog( LPCTSTR log_msg );

	void update_control_state();

	int nIndexToCoordNo_[10];

public:
	CSetupMultiOriginAutoTeachDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupMultiOriginAutoTeachDlg();

	virtual void StartPageWork();
	virtual void StopPageWork();
	virtual void UpdatePage();

	void SetParentWnd( CWnd* pParent ) { pParent_ = pParent; }

	void UploadToPC() { }

	void Copy_to_Temp();		// copy_to_temp
	void Copy_to_Original();	// copy_to_original


// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_MULTIORG_AUTO_TEACH };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	CComboBox cboSelCoord_;
	virtual BOOL PreTranslateMessage(MSG* pMsg);
protected:
	virtual void PreInitDialog();
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	LRESULT OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam);
	afx_msg void OnBnClickedButtonStartStop();
	afx_msg void OnBnClickedCheckRb1();
	afx_msg void OnBnClickedCheckRb2();
	afx_msg void OnBnClickedCheckRb3();
	afx_msg void OnCbnSelchangeComboSelCoord();
	afx_msg void OnBnClickedCheckRb4();
	afx_msg void OnBnClickedCheckRb5();
	afx_msg void OnBnClickedCheckRb6();
	afx_msg void OnBnClickedCheckRb7();
	afx_msg void OnBnClickedCheckRb8();
	afx_msg void OnBnClickedCheckRb9();
	afx_msg void OnBnClickedCheckRb10();
	afx_msg LRESULT OnWindowMove(WPARAM wparam, LPARAM lparam);
};
