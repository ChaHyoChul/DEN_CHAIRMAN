#pragma once

#include "TitleBarWnd.h"
#include "OptionDataListBox.h"

// CSetupSystemMultiOriginDlg ��ȭ �����Դϴ�.

class CSetupSystemMultiOriginDlg : public CDialog
{
	DECLARE_DYNAMIC(CSetupSystemMultiOriginDlg)

	BOOL	bIsModify_;

	CTitleBarWnd*		pTitleBarWnd_;
	CFont				fntButton_;
	CBrush				brhBackground_;

	COptionDataListBox*	pDataListBox_;

	// ����� ������ 
	pa::SMultiOriginData	hTempMultiOriginData_;

	//
	void update_button_state();

public:
	CSetupSystemMultiOriginDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupSystemMultiOriginDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_SYSTEM_MULTI_ORIGIN };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
//	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButtonClose();
	afx_msg void OnBnClickedButtonSave();
	LRESULT OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
