#pragma once

namespace pa 
{
//////////////////////////////////////////////////////////////////////////
/*
struct SAutoLoaderConfig
{
	BOOL	bUsingAutoLoader;						// AutoLoader ��� ��/�� 
	int		nNumBlock_;								// ���� ���� 
	double	fScale_;								// ������ ������ 
	double	fTeachingPoint_[AUTOLOADER_TP_NUM];		// Teaching ��ġ ���� 
};
*/

class CPAutoLoader
{
private:
	CString strFilePath_;
// 	BOOL	bUsingAutoLoader_;						// AutoLoader ��� ���� 
// 	int		nNumBlock_;								// ������ ���� 
// 	double	fAxisScale_;							// ������ Scale 
	// 	double	fTeachingPoint_[AUTOLOADER_TP_NUM];		// AutoLoader�� ƼĪ ��ġ

public:
	hcipc::CSharedMem		*pShMemALConfig_;
	SAutoLoaderConfig		*pAutoLoaderConfig_;
	
	hcipc::CSharedMem		*pShMemBlockState_;		// ������ ���¸� �����ϴ� ���� �޸� �ּ� 
	SAutoLoaderBlockState	*pBlockState_;			// 

	hcipc::CSharedMem		*pShMemItemLocationState_;
	ItemLocationState		*pItemLocationState_;
public:
	BOOL Initialize( CString& strConfigFilePath, CString& strErrMsg );
	void Destroy();

	BOOL IsUsingAutoLoader() { return pAutoLoaderConfig_->bUsingAutoLoader; }		//{ return bUsingAutoLoader_; }
	void SetUsingAutoLoader( BOOL b ) {
		pAutoLoaderConfig_->bUsingAutoLoader = b;
	}

	int  GetNumBlock() { return pAutoLoaderConfig_->nNumBlock_; }					//{ return nNumBlock_; }
	double GetAxisScale() { return pAutoLoaderConfig_->fScale_; }					// { return fAxisScale_; }
	double GetTeachingPoint( EN_AUTOLOADER_TEACHING_POINT teachingPoint ) {			// return fTeachingPoint_[teachingPoint]; }
		return pAutoLoaderConfig_->fTeachingPoint_[teachingPoint];
	}
	void SetTeachingPoint( EN_AUTOLOADER_TEACHING_POINT teachingPoint, double fVal ) {
		pAutoLoaderConfig_->fTeachingPoint_[teachingPoint] = fVal;
	} 
	void ResetBlockStates();

	EN_AUTOLOADER_BLOCK_STATE GetBlockState( int nIndex );
	int GetItemNumberFromSlotIndex(int index);
	void SetBlockState( int nIndex, EN_AUTOLOADER_BLOCK_STATE hBlockState );

	void SetWorkIndex( int nIndex ); 
	int  GetWorkIndex() { return pBlockState_->nWorkIndex; }

	void SaveAutoLoaderConfig();					// AutoLoader �����͸� ini ���Ͽ� �����Ѵ� 
	void LoadAutoLoaderConfig();

	int GetAutoLoaderHandItemNumber();
	int GetItemPasserItemNumber();
	int GetWorkSpaceItemNumber();
public:
	CPAutoLoader(void);
	~CPAutoLoader(void);

	static int AUTOLOADER_AXIS_NO;
};

//////////////////////////////////////////////////////////////////////////
}

