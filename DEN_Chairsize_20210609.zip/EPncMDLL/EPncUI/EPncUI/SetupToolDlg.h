#pragma once

#include "ToolTimeDispWnd.h"
#include "afxwin.h"
#include "TitleBarWnd.h"

// CSetupToolDlg ��ȭ �����Դϴ�.

class CSetupToolDlg : public CDialogListPage
{
	DECLARE_DYNCREATE(CSetupToolDlg)

	CTitleBarWnd*	pTitleBarWnd_;
	CTitleBarWnd*	pRelRegToolTitleBarWnd_;
	CTitleBarWnd*	pSpindleRPMTitleBarWnd_;

	int		nNumTools_;
	BOOL	bDirectAccess_;					// Operation ȭ�鿡�� ���� ���� 

	CBrush	brhBkgnd_;						// ���̾�α� ��� �� 
	CBrush	brhBackButton_;

	CFont	fntButton_;						// ��ư�� ��Ʈ 
	CFont	fntRelToolList_;				// ����Ʈ�� ��Ʈ 
	CFont	fntMenuButton_;					// �Ŵ� ��ư 
	CFont	fntSpindleRPM_;

	CRect	CUIrectSetT; 

	CToolTimeDispWnd*	pToolTimeDispWnd_[pa::MAX_TOOL_NUM+1];

	CWnd* pParentWnd_;

	TCHAR*				pResourcePath_;
	hcutil::CCanvasCE*	pCanvasCE_;

	int		nSpindleOverride_;

	void updateButtonState();
	void updateToolTimeWnd();
	void updateToolRelatedData();
	void updateToolErrMsg();
	void doResetTool( int nToolNo );

	void updateState_MenuButton();

	void updateSpindleRPM();

	void setSpindleRPMOverride( int new_ovr );

	void writeLog( LPCTSTR log_msg );

public:
	CSetupToolDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupToolDlg();

	virtual void StartPageWork();
	virtual void StopPageWork();
	virtual void UpdatePage();

	void SetParentWnd( CWnd* p ) { pParentWnd_ = p; }

	void SetDirectAccess( BOOL b ) { bDirectAccess_ = b; };

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_TOOL };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedButtonClose();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedButtonGetTool1();
	afx_msg void OnBnClickedButtonGetTool2();
	afx_msg void OnBnClickedButtonGetTool3();
	afx_msg void OnBnClickedButtonGetTool4();
	afx_msg void OnBnClickedButtonGetTool5();
	afx_msg void OnBnClickedButtonGetTool6();
	afx_msg void OnBnClickedButtonGetTool7();
	afx_msg void OnBnClickedButtonGetTool8();
	afx_msg void OnBnClickedButtonToolReturn();
	afx_msg void OnBnClickedButtonResetToolNo();
//	afx_msg void OnBnClickedButtonToolClampUnclamp();
	afx_msg void OnBnClickedButtonResetTool1();
	afx_msg void OnBnClickedButtonResetTool2();
	afx_msg void OnBnClickedButtonResetTool3();
	afx_msg void OnBnClickedButtonResetTool4();
	afx_msg void OnBnClickedButtonResetTool5();
	afx_msg void OnBnClickedButtonResetTool6();
	afx_msg void OnBnClickedButtonResetTool7();
	afx_msg void OnBnClickedButtonResetTool8();
	afx_msg void OnBnClickedCheckToolClampUnclamp();
//	afx_msg void OnBnClickedButtonResetToolNo2();
//	afx_msg void OnBnClickedButtonSpindle();
	afx_msg void OnBnClickedCheckSpindleRun();
	CButton chkBtnToolClamp_;
	CButton chkBtnTool2Clamp_;
	CButton chkBtnSpindleRun_;
	CButton chkBtnSpindle2Run_;
	afx_msg void OnBnClickedButtonRegisterRelatedTool();
	afx_msg void OnBnClickedButtonRemoveRelatedTool();
	CListBox lbRelTool_;
	afx_msg void OnBnClickedCheckAtcDoor();
	CButton chkMaxToolUsageTime_;
	CButton chkUsingRelatedTool_;
	afx_msg void OnBnClickedCheckToolMaxUsageTime();
	afx_msg void OnBnClickedCheckToolRelated();
	afx_msg void OnBnClickedButtonIncSpindleOvr();
	afx_msg void OnBnClickedButtonDecSpindleOvr();
protected:
	virtual void PreInitDialog();
public:
	afx_msg void OnPaint();
	afx_msg void OnBnClickedButtonTool2Return();
	afx_msg void OnBnClickedCheckTool2ClampUnclamp();
	afx_msg void OnBnClickedCheckSpindle2Run();
	afx_msg void OnBnClickedButtonResetTool2No();
};

