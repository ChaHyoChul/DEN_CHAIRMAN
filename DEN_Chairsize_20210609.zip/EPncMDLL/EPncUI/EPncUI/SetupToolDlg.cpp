// SetupToolDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "SetupToolDlg.h"
#include "SetupToolResetDlg.h"

//////////////////////////////////////////////////////////////////////////
// CSetupToolDlg ��ȭ �����Դϴ�.
//////////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNCREATE(CSetupToolDlg, CDialogListPage)

CSetupToolDlg::CSetupToolDlg(CWnd* pParent /*=NULL*/)
	: CDialogListPage(CSetupToolDlg::IDD, pParent)
{
	nNumTools_	= 6;

	pParentWnd_ = NULL;

	bDirectAccess_ = FALSE;

	for( int i = 0; i<pa::MAX_TOOL_NUM; i++ ) {
		pToolTimeDispWnd_[i] = NULL;
	}

	pResourcePath_ = RESOURCE_2_PATH;
}

CSetupToolDlg::~CSetupToolDlg()
{
}

void CSetupToolDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogListPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CHECK_TOOL_CLAMP_UNCLAMP, chkBtnToolClamp_);
	DDX_Control(pDX, IDC_CHECK_TOOL2_CLAMP_UNCLAMP, chkBtnTool2Clamp_);
	DDX_Control(pDX, IDC_CHECK_SPINDLE_RUN, chkBtnSpindleRun_);
	DDX_Control(pDX, IDC_CHECK_SPINDLE2_RUN, chkBtnSpindle2Run_);
	DDX_Control(pDX, IDC_LIST_REL_TOOL, lbRelTool_);
	DDX_Control(pDX, IDC_CHECK_TOOL_MAX_USAGE_TIME, chkMaxToolUsageTime_);
	DDX_Control(pDX, IDC_CHECK_TOOL_RELATED, chkUsingRelatedTool_);
}

void CSetupToolDlg::StartPageWork()
{
	setSpindleRPMOverride( 100 );

	updateToolRelatedData();
	
	chkMaxToolUsageTime_.SetCheck( pa::PTool->GetEnableToolUsageTime() );
	chkUsingRelatedTool_.SetCheck( pa::PTool->GetEnableRelatedTool() );

	SetTimer( 1, 200, NULL );
	SetTimer( 2, 1000, NULL );						// tool Info ���� 

}

void CSetupToolDlg::StopPageWork()
{
	KillTimer( 1 );
	KillTimer( 2 );

	setSpindleRPMOverride( 100 );
}

void CSetupToolDlg::UpdatePage()
{

}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CSetupToolDlg, CDialogListPage)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, &CSetupToolDlg::OnBnClickedButtonClose)
	ON_WM_CTLCOLOR()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_GET_TOOL_1, &CSetupToolDlg::OnBnClickedButtonGetTool1)
	ON_BN_CLICKED(IDC_BUTTON_GET_TOOL_2, &CSetupToolDlg::OnBnClickedButtonGetTool2)
	ON_BN_CLICKED(IDC_BUTTON_GET_TOOL_3, &CSetupToolDlg::OnBnClickedButtonGetTool3)
	ON_BN_CLICKED(IDC_BUTTON_GET_TOOL_4, &CSetupToolDlg::OnBnClickedButtonGetTool4)
	ON_BN_CLICKED(IDC_BUTTON_GET_TOOL_5, &CSetupToolDlg::OnBnClickedButtonGetTool5)
	ON_BN_CLICKED(IDC_BUTTON_GET_TOOL_6, &CSetupToolDlg::OnBnClickedButtonGetTool6)
	ON_BN_CLICKED(IDC_BUTTON_GET_TOOL_7, &CSetupToolDlg::OnBnClickedButtonGetTool7)
	ON_BN_CLICKED(IDC_BUTTON_GET_TOOL_8, &CSetupToolDlg::OnBnClickedButtonGetTool8)
	ON_BN_CLICKED(IDC_BUTTON_TOOL_RETURN, &CSetupToolDlg::OnBnClickedButtonToolReturn)
	ON_BN_CLICKED(IDC_BUTTON_RESET_TOOL_NO, &CSetupToolDlg::OnBnClickedButtonResetToolNo)
	ON_BN_CLICKED(IDC_BUTTON_RESET_TOOL_1, &CSetupToolDlg::OnBnClickedButtonResetTool1)
	ON_BN_CLICKED(IDC_BUTTON_RESET_TOOL_2, &CSetupToolDlg::OnBnClickedButtonResetTool2)
	ON_BN_CLICKED(IDC_BUTTON_RESET_TOOL_3, &CSetupToolDlg::OnBnClickedButtonResetTool3)
	ON_BN_CLICKED(IDC_BUTTON_RESET_TOOL_4, &CSetupToolDlg::OnBnClickedButtonResetTool4)
	ON_BN_CLICKED(IDC_BUTTON_RESET_TOOL_5, &CSetupToolDlg::OnBnClickedButtonResetTool5)
	ON_BN_CLICKED(IDC_BUTTON_RESET_TOOL_6, &CSetupToolDlg::OnBnClickedButtonResetTool6)
	ON_BN_CLICKED(IDC_BUTTON_RESET_TOOL_7, &CSetupToolDlg::OnBnClickedButtonResetTool7)
	ON_BN_CLICKED(IDC_BUTTON_RESET_TOOL_8, &CSetupToolDlg::OnBnClickedButtonResetTool8)
	ON_BN_CLICKED(IDC_CHECK_TOOL_CLAMP_UNCLAMP, &CSetupToolDlg::OnBnClickedCheckToolClampUnclamp)
	ON_BN_CLICKED(IDC_CHECK_SPINDLE_RUN, &CSetupToolDlg::OnBnClickedCheckSpindleRun)
	ON_BN_CLICKED(IDC_BUTTON_REGISTER_RELATED_TOOL, &CSetupToolDlg::OnBnClickedButtonRegisterRelatedTool)
	ON_BN_CLICKED(IDC_BUTTON_REMOVE_RELATED_TOOL, &CSetupToolDlg::OnBnClickedButtonRemoveRelatedTool)
	ON_BN_CLICKED(IDC_CHECK_ATC_DOOR, &CSetupToolDlg::OnBnClickedCheckAtcDoor)
	ON_BN_CLICKED(IDC_CHECK_TOOL_MAX_USAGE_TIME, &CSetupToolDlg::OnBnClickedCheckToolMaxUsageTime)
	ON_BN_CLICKED(IDC_CHECK_TOOL_RELATED, &CSetupToolDlg::OnBnClickedCheckToolRelated)
	ON_BN_CLICKED(IDC_BUTTON_INC_SPINDLE_OVR, &CSetupToolDlg::OnBnClickedButtonIncSpindleOvr)
	ON_BN_CLICKED(IDC_BUTTON_DEC_SPINDLE_OVR, &CSetupToolDlg::OnBnClickedButtonDecSpindleOvr)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BUTTON_TOOL2_RETURN, &CSetupToolDlg::OnBnClickedButtonTool2Return)
	ON_BN_CLICKED(IDC_CHECK_TOOL2_CLAMP_UNCLAMP, &CSetupToolDlg::OnBnClickedCheckTool2ClampUnclamp)
	ON_BN_CLICKED(IDC_CHECK_SPINDLE2_RUN, &CSetupToolDlg::OnBnClickedCheckSpindle2Run)
	ON_BN_CLICKED(IDC_BUTTON_RESET_TOOL2_NO, &CSetupToolDlg::OnBnClickedButtonResetTool2No)
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CSetupToolDlg �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CSetupToolDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialogListPage::PreTranslateMessage(pMsg);
}

BOOL CSetupToolDlg::OnInitDialog()
{
	CDialogListPage::OnInitDialog();

	const int NUM_TOOLS = 6;

	//////////////////////////////////////////////////////////////////////////
	//
	CRect	rcTitleBar;
 	hcutil::GetControlPos2( IDC_STATIC_TOOL_TITLE_AREA, this, &rcTitleBar, &CUIrectSetT, TRUE );
 	pTitleBarWnd_ = new CTitleBarWnd();
 	pTitleBarWnd_->InitResource( CString(_T("Tool Management")), pa::CLR_SETUP_TOOL, RGB(32, 32, 32), RGB(32, 32, 32), CSize(8, 16) );
 	pTitleBarWnd_->Create( this, rcTitleBar, IDC_STATIC_TOOL_TITLE_AREA );
 	pTitleBarWnd_->SetWindowPos( &wndTop, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE );

 	hcutil::GetControlPos2( IDC_STATIC_TOOL_REL_REG_TITLE_AREA, this, &rcTitleBar, &CUIrectSetT, TRUE );
 	pRelRegToolTitleBarWnd_ = new CTitleBarWnd();
 	pRelRegToolTitleBarWnd_->InitResource( CString( _T("Related Tool")), pa::CLR_SETUP_TOOL, RGB(32, 32, 32), RGB(32, 32, 32), CSize(8, 16) );
 	pRelRegToolTitleBarWnd_->Create( this, rcTitleBar, IDC_STATIC_TOOL_REL_REG_TITLE_AREA );
 	pRelRegToolTitleBarWnd_->SetWindowPos( &wndTop, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE );

 	hcutil::GetControlPos2( IDC_STATIC_SPINDLE_RPM_TITLE_AREA, this, &rcTitleBar, &CUIrectSetT, TRUE );
 	pSpindleRPMTitleBarWnd_ = new CTitleBarWnd();
 	pSpindleRPMTitleBarWnd_->InitResource( CString( _T("Spindle RPM && Override")), pa::CLR_SETUP_TOOL, RGB(32, 32, 32), RGB(32, 32, 32), CSize(8, 16) );
 	pSpindleRPMTitleBarWnd_->Create( this, rcTitleBar, IDC_STATIC_SPINDLE_RPM_TITLE_AREA );
 	pSpindleRPMTitleBarWnd_->SetWindowPos( &wndTop, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE );

	//////////////////////////////////////////////////////////////////////////
	// 
//	brhBackground_.CreateSolidBrush( RGB( 120, 120, 120 ) );
	brhBkgnd_.CreateSolidBrush( pa::CLR_SETUP_TOOL );
	brhBackButton_.CreateSolidBrush( pa::CLR_BUTTON_BACK );

	//////////////////////////////////////////////////////////////////////////
	// ��ư ��Ʈ �ʱ�ȭ 
	fntButton_.CreateFont( 
		16, 0,  
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") );

	fntRelToolList_.CreateFont( 
		22, 0, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") );

	fntMenuButton_.CreateFont( 
		17, 0, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") );

	fntSpindleRPM_.CreateFont( 
		18, 0, 
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") );

	//////////////////////////////////////////////////////////////////////////
	// ��ư �ʱ�ȭ 
	int nToolButtonIDs[] = {
		IDC_BUTTON_GET_TOOL_1, IDC_BUTTON_GET_TOOL_2, IDC_BUTTON_GET_TOOL_3, IDC_BUTTON_GET_TOOL_4,
		IDC_BUTTON_GET_TOOL_5, IDC_BUTTON_GET_TOOL_6, IDC_BUTTON_GET_TOOL_7, IDC_BUTTON_GET_TOOL_8
	};
	int nResetButtonIDs[] = {
		IDC_BUTTON_RESET_TOOL_1, IDC_BUTTON_RESET_TOOL_2, IDC_BUTTON_RESET_TOOL_3, IDC_BUTTON_RESET_TOOL_4, 
		IDC_BUTTON_RESET_TOOL_5, IDC_BUTTON_RESET_TOOL_6, IDC_BUTTON_RESET_TOOL_7, IDC_BUTTON_RESET_TOOL_8
	};

	CRect recbutton;

	for( int i = 0; i<nNumTools_; i++ ) {
		((CButton*)GetDlgItem(nToolButtonIDs[i]))->SetFont( &fntButton_, TRUE );
		((CButton*)GetDlgItem(nResetButtonIDs[i]))->SetFont( &fntButton_, TRUE );

		hcutil::reposbutton( (CButton*)GetDlgItem(nToolButtonIDs[i]), this, &recbutton, &CUIrectSetT);
		hcutil::reposbutton( (CButton*)GetDlgItem(nResetButtonIDs[i]), this, &recbutton, &CUIrectSetT);
	}

	((CButton*)GetDlgItem(IDC_BUTTON_INC_SPINDLE_OVR))->SetFont( &fntButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_DEC_SPINDLE_OVR))->SetFont( &fntButton_, TRUE );

	((CStatic*)GetDlgItem(IDC_STATIC_SPINDLE_RPM))->SetFont( &fntSpindleRPM_, TRUE );
	((CStatic*)GetDlgItem(IDC_STATIC_SPINDLE_OVR))->SetFont( &fntSpindleRPM_, TRUE );

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_INC_SPINDLE_OVR), this, &recbutton, &CUIrectSetT);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_DEC_SPINDLE_OVR), this, &recbutton, &CUIrectSetT );
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_STATIC_SPINDLE_RPM), this, &recbutton, &CUIrectSetT );
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_STATIC_SPINDLE_OVR), this, &recbutton, &CUIrectSetT);

	((CButton*)GetDlgItem(IDC_CHECK_ATC_DOOR))->ShowWindow(SW_HIDE);
	((CButton*)GetDlgItem(IDC_BUTTON_GET_TOOL_7))->ShowWindow(SW_HIDE);
	((CButton*)GetDlgItem(IDC_BUTTON_GET_TOOL_8))->ShowWindow(SW_HIDE);
	((CButton*)GetDlgItem(IDC_BUTTON_RESET_TOOL_7))->ShowWindow(SW_HIDE);
	((CButton*)GetDlgItem(IDC_BUTTON_RESET_TOOL_8))->ShowWindow(SW_HIDE);

	//////////////////////////////////////////////////////////////////////////
	// Tool �ð� ������ �ʱ�ȭ 
	int nTimeWndIDs[] = {
		IDC_STATIC_TOOL_1, IDC_STATIC_TOOL_2, IDC_STATIC_TOOL_3, IDC_STATIC_TOOL_4, 
		IDC_STATIC_TOOL_5, IDC_STATIC_TOOL_6
	};
	CRect	rcTemp;

	for( int i = 0; i<nNumTools_; i++ )
	{
		hcutil::GetControlPos2( nTimeWndIDs[i], this, &rcTemp, &CUIrectSetT, TRUE );
		
		pToolTimeDispWnd_[i] = new CToolTimeDispWnd();
		ASSERT( pToolTimeDispWnd_[i] );
		pToolTimeDispWnd_[i]->Create( i+1, this, rcTemp, 1999+i );
		pToolTimeDispWnd_[i]->Invalidate( TRUE );
		pToolTimeDispWnd_[i]->SetWindowPos( &wndTop, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE );
	}

	//////////////////////////////////////////////////////////////////////////
	// Related Tool List 
	lbRelTool_.SetFont( &fntRelToolList_, TRUE );
// 	lbRelTool_.AddString( _T("M140+M144") );
// 	lbRelTool_.AddString( _T("M141+M145") );
	((CButton*)GetDlgItem(IDC_BUTTON_REGISTER_RELATED_TOOL))->SetFont( &fntButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_REMOVE_RELATED_TOOL))->SetFont( &fntButton_, TRUE );

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_REGISTER_RELATED_TOOL), this, &recbutton, &CUIrectSetT);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_REMOVE_RELATED_TOOL), this, &recbutton, &CUIrectSetT);

	//////////////////////////////////////////////////////////////////////////
	//
	chkMaxToolUsageTime_.SetFont( &fntButton_, TRUE );
	chkUsingRelatedTool_.SetFont( &fntButton_, TRUE );

	//////////////////////////////////////////////////////////////////////////
	// Menu Button 
	((CButton*)GetDlgItem(IDC_BUTTON_TOOL_RETURN))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_TOOL2_RETURN))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_RESET_TOOL_NO))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_RESET_TOOL2_NO))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_CHECK_TOOL_CLAMP_UNCLAMP))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_CHECK_TOOL2_CLAMP_UNCLAMP))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_CHECK_SPINDLE_RUN))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_CHECK_SPINDLE2_RUN))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_CHECK_ATC_DOOR))->SetFont( &fntMenuButton_, TRUE );
	((CButton*)GetDlgItem(IDC_BUTTON_CLOSE))->SetFont( &fntMenuButton_, TRUE );

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_TOOL_RETURN), this, &recbutton, &CUIrectSetT);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_TOOL2_RETURN), this, &recbutton, &CUIrectSetT);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_RESET_TOOL_NO), this, &recbutton, &CUIrectSetT);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_RESET_TOOL2_NO), this, &recbutton, &CUIrectSetT);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_TOOL_CLAMP_UNCLAMP), this, &recbutton, &CUIrectSetT);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_TOOL2_CLAMP_UNCLAMP), this, &recbutton, &CUIrectSetT);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_SPINDLE_RUN), this, &recbutton, &CUIrectSetT);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_SPINDLE2_RUN), this, &recbutton, &CUIrectSetT);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_ATC_DOOR), this, &recbutton, &CUIrectSetT);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_CLOSE), this, &recbutton, &CUIrectSetT);

	//////////////////////////////////////////////////////////////////////////
	// 
	int nErrMsgID[] = {
		IDC_STATIC_TE_1, IDC_STATIC_TE_2, IDC_STATIC_TE_3, IDC_STATIC_TE_4, 
		IDC_STATIC_TE_5, IDC_STATIC_TE_6
	};
	for( int i = 0; i<nNumTools_; i++ ) {
		(CStatic*)GetDlgItem(nErrMsgID[i])->SetWindowPos(&wndTop, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE );
		hcutil::reposstatic( (CStatic*)GetDlgItem(nErrMsgID[i]), this, &recbutton, &CUIrectSetT);
	}

	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_TOOL_AREA), this, &recbutton, &CUIrectSetT);
	hcutil::reposstatic( (CStatic*)GetDlgItem(IDC_STATIC_REL_TOOL_AREA), this, &recbutton, &CUIrectSetT);

	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_TOOL_MAX_USAGE_TIME), this, &recbutton, &CUIrectSetT);
	hcutil::reposbutton( (CButton*)GetDlgItem(IDC_CHECK_TOOL_RELATED), this, &recbutton, &CUIrectSetT);

	hcutil::reposlist( (CListBox*)GetDlgItem(IDC_LIST_REL_TOOL), this, &recbutton, &CUIrectSetT);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CSetupToolDlg::OnDestroy()
{
	for( int i = 0; i<pa::MAX_TOOL_NUM; i++ ) {
		if( pToolTimeDispWnd_[i] ) {
			pToolTimeDispWnd_[i]->DestroyWindow();
			delete pToolTimeDispWnd_[i];
			pToolTimeDispWnd_[i] = NULL;
		}
	}

	brhBkgnd_.DeleteObject();
	brhBackButton_.DeleteObject();

	fntButton_.DeleteObject();
	fntRelToolList_.DeleteObject();
	fntMenuButton_.DeleteObject();
	fntSpindleRPM_.DeleteObject();

	if( pTitleBarWnd_ ) {
		pTitleBarWnd_->DestroyWindow();
		delete pTitleBarWnd_;
		pTitleBarWnd_ = NULL;
	}

	if( pRelRegToolTitleBarWnd_ ) {
		pRelRegToolTitleBarWnd_->DestroyWindow();
		delete pRelRegToolTitleBarWnd_;
		pRelRegToolTitleBarWnd_ = NULL;
	}

	if( pSpindleRPMTitleBarWnd_ ) {
		pSpindleRPMTitleBarWnd_->DestroyWindow();
		delete pSpindleRPMTitleBarWnd_;
		pSpindleRPMTitleBarWnd_ = NULL;
	}

	if( pCanvasCE_ ) {
		delete pCanvasCE_;
		pCanvasCE_ = NULL;
	}

	CDialogListPage::OnDestroy();
}

void CSetupToolDlg::OnBnClickedButtonClose()
{
// 	ASSERT( pParentWnd_ );
// 	pParentWnd_->PostMessage( WM_SETUP, (WPARAM)SETUP_BACK, (LPARAM)0 );
	ASSERT( pParentWnd_ );
	if( bDirectAccess_ == FALSE ) 
	{
		pParentWnd_->PostMessage( WM_SETUP, (WPARAM)SETUP_BACK, (LPARAM)0 );
	}
	else 
	{
		pParentWnd_->PostMessage( WM_SETUP, (WPARAM)SETUP_EXIT, (LPARAM)0 );
		SetDirectAccess( FALSE );
	}
}

HBRUSH CSetupToolDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogListPage::OnCtlColor(pDC, pWnd, nCtlColor);

	pDC->SetBkMode( TRANSPARENT );

	if( nCtlColor == 4 ) {
		hbr = (HBRUSH)brhBkgnd_;
	}
	else {
		UINT nID = pWnd->GetDlgCtrlID();
		if( nID == IDC_STATIC_TOOL_AREA ||
			nID == IDC_STATIC_REL_TOOL_AREA )
		{
			hbr = (HBRUSH)brhBkgnd_;
		}
		else if( nID == IDC_LIST_REL_TOOL ) 
		{
			pDC->SetBkMode( TRANSPARENT );
			hbr = (HBRUSH)brhBkgnd_;
		}
		else if( nID == IDC_CHECK_TOOL_MAX_USAGE_TIME ) {
			hbr = (HBRUSH)brhBkgnd_;
		}
		else if( nID == IDC_CHECK_TOOL_RELATED ) {
			hbr = (HBRUSH)brhBkgnd_;
		}
		else if( nID == IDC_BUTTON_CLOSE ) {
			hbr = (HBRUSH)brhBackButton_;
		}
		else if( nID == IDC_STATIC_TE_1 || nID == IDC_STATIC_TE_2 || nID == IDC_STATIC_TE_3 || nID == IDC_STATIC_TE_4 ||
				 nID == IDC_STATIC_TE_5 || nID == IDC_STATIC_TE_6 ) {
			hbr = (HBRUSH)brhBkgnd_;
		}
		else if( nID == IDC_STATIC_SPINDLE_RPM || nID == IDC_STATIC_SPINDLE_OVR ) {
			hbr = (HBRUSH)brhBkgnd_;
			pDC->SetBkMode( TRANSPARENT );
		}
	}

	return hbr;
}

void CSetupToolDlg::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 1 ) 
	{
		KillTimer( 1 );

		//////////////////////////////////////////////////////////////////////////
		// ��ư ���� ������Ʈ 
		updateButtonState();

		//////////////////////////////////////////////////////////////////////////
		// ��ư�� �ð� ������Ʈ 
		updateToolTimeWnd();

		//////////////////////////////////////////////////////////////////////////
		// �� ���� �޽��� ������Ʈ
		updateToolErrMsg();

		//////////////////////////////////////////////////////////////////////////
		// �Ŵ� ��ư ���� 
		updateState_MenuButton();

		//////////////////////////////////////////////////////////////////////////
		// Spindle RPM ���� 
		updateSpindleRPM();

		if( IsWindowVisible() == TRUE ) 
		{
			SetTimer( 1, 200, NULL );
		}
	}
	else if( nIDEvent == 2 )
	{
		KillTimer( 2 );

		if( IsWindowVisible() == TRUE )
		{
			SetTimer( 2, 1000, NULL );
		}
	}

	CDialogListPage::OnTimer(nIDEvent);
}

void CSetupToolDlg::updateButtonState()
{
	static int PREV_STATE = -1;
	BOOL bEnable;

	int nToolButtonIDs[] = {
		IDC_BUTTON_GET_TOOL_1, IDC_BUTTON_GET_TOOL_2, IDC_BUTTON_GET_TOOL_3, IDC_BUTTON_GET_TOOL_4,
		IDC_BUTTON_GET_TOOL_5, IDC_BUTTON_GET_TOOL_6, IDC_BUTTON_GET_TOOL_7, IDC_BUTTON_GET_TOOL_8
	};
	int nResetButtonIDs[] = {
		IDC_BUTTON_RESET_TOOL_1, IDC_BUTTON_RESET_TOOL_2, IDC_BUTTON_RESET_TOOL_3, IDC_BUTTON_RESET_TOOL_4, 
		IDC_BUTTON_RESET_TOOL_5, IDC_BUTTON_RESET_TOOL_6, IDC_BUTTON_RESET_TOOL_7, IDC_BUTTON_RESET_TOOL_8
	};

	int currState	= ( pa::PPAStatus->GetRunMode() == pa::RUNMODE_STOP ) ? 1 : 0;
	int runningState= ( pa::PPAStatus->GetPAStatus()->nRunStatus == pa::PA_RUN_STATUS_IDLE ) ? 0 : 1;

 	currState = ( currState==1 && runningState==0 ) ? 1 : 0;

	if( PREV_STATE != currState ) 
 	{
 		PREV_STATE = currState;
 
 		bEnable = currState != 0 ? TRUE : FALSE;
 
 		for( int i = 0; i<nNumTools_; i++ ) 
 		{
 			((CButton*)GetDlgItem(nToolButtonIDs[i]))->EnableWindow( bEnable );
 		}
 		for( int i = 0; i<nNumTools_; i++ ) 
 		{
 			((CButton*)GetDlgItem(nResetButtonIDs[i]))->EnableWindow( bEnable );
 		}
// 
// 		((CButton*)GetDlgItem(IDC_BUTTON_TOOL_RETURN))->EnableWindow( bEnable );
// 
// 		((CButton*)GetDlgItem(IDC_BUTTON_RESET_TOOL_NO))->EnableWindow( bEnable );
// 
// 		((CButton*)GetDlgItem(IDC_CHECK_TOOL_CLAMP_UNCLAMP))->EnableWindow( bEnable );
// 
// 		((CButton*)GetDlgItem(IDC_CHECK_SPINDLE_RUN))->EnableWindow( bEnable );
// 
// 		((CButton*)GetDlgItem(IDC_CHECK_TOOL_CLAMP_UNCLAMP))->EnableWindow( bEnable );
// 
// 		((CButton*)GetDlgItem(IDC_CHECK_ATC_DOOR))->EnableWindow( bEnable );
 	}

	//////////////////////////////////////////////////////////////////////////
	// 
//	if( pa::USER_MODE < pa::USER_MODE_MGR ) {
// 	if( pa::GET_CURRENT_USERMODE() < pa::USER_MODE_MGR )
// 	{
// 		((CButton*)GetDlgItem(IDC_BUTTON_REGISTER_RELATED_TOOL))->EnableWindow( FALSE );
// 		((CButton*)GetDlgItem(IDC_BUTTON_REMOVE_RELATED_TOOL))->EnableWindow( FALSE );
// 		chkMaxToolUsageTime_.EnableWindow( FALSE );
// 		chkUsingRelatedTool_.EnableWindow( FALSE );
// 		((CButton*)GetDlgItem(IDC_BUTTON_INC_SPINDLE_OVR))->EnableWindow( FALSE );
// 		((CButton*)GetDlgItem(IDC_BUTTON_DEC_SPINDLE_OVR))->EnableWindow( FALSE );
// 	} 
// 	else 
// 	{
// 		((CButton*)GetDlgItem(IDC_BUTTON_REGISTER_RELATED_TOOL))->EnableWindow( currState );
// 		((CButton*)GetDlgItem(IDC_BUTTON_REMOVE_RELATED_TOOL))->EnableWindow( currState );
// 		chkMaxToolUsageTime_.EnableWindow( currState );
// 		chkUsingRelatedTool_.EnableWindow( currState );
// 		((CButton*)GetDlgItem(IDC_BUTTON_INC_SPINDLE_OVR))->EnableWindow( currState );
// 		((CButton*)GetDlgItem(IDC_BUTTON_DEC_SPINDLE_OVR))->EnableWindow( currState );
// 	}
	//////////////////////////////////////////////////////////////////////////
}

void CSetupToolDlg::updateToolTimeWnd()
{
	for( int i = 0; i<nNumTools_; i++ ) 
	{
		pToolTimeDispWnd_[i]->UpdateState();
		pToolTimeDispWnd_[i]->UpdateState2();
	}
}

void CSetupToolDlg::updateToolErrMsg()
{
	static TCHAR *P_ERR_MSG[] = {
// 		_T("NO Tool No"),
		_T("Empty"),
		_T("Tool broken"),
		_T("Tool long"),
		_T("Tool short"),
		_T("Unknown")
	};
	static DWORD PREV_TOOL_ERR[10] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };

	UINT nID[] = { 0,
		IDC_STATIC_TE_1, IDC_STATIC_TE_2, IDC_STATIC_TE_3, IDC_STATIC_TE_4,
		IDC_STATIC_TE_5, IDC_STATIC_TE_6 };
	CString strErrMsg;

	for( int i = 1; i<=nNumTools_; i++ )
	{
		DWORD dwTemp = pa::PTool->GetToolData(i)->dwErrCode;
		if( PREV_TOOL_ERR[i] != dwTemp ) {
			PREV_TOOL_ERR[i] = dwTemp;
			if( PREV_TOOL_ERR[i] != 0 ) {
				int err_msg_index = 0;
				switch( dwTemp )
				{
// 				case 7: err_msg_index = 0; break;
// 				case 24: err_msg_index = 1; break;
// 				case 25: err_msg_index = 2; break;
// 				case 26: err_msg_index = 3; break;
// 				default: err_msg_index = 4; break;
				case 10010:
				case 20010:
					err_msg_index = 0; break;
				case 10014: 
				case 20014:
					err_msg_index = 1; break;
				case 10018:
				case 20018:
					err_msg_index = 2; break;
				case 10019:
				case 20019: 
					err_msg_index = 3; break;
				default: 
					err_msg_index = 4; break;
				}
				strErrMsg.Format( _T("[%d]%s"), dwTemp, P_ERR_MSG[err_msg_index] );
			} else {
				strErrMsg.Format( _T("") );
			}
			((CStatic *)GetDlgItem(nID[i]))->SetWindowText( strErrMsg );
		} 
	}
}

// listbox�� ��� 
void CSetupToolDlg::updateToolRelatedData()
{
	lbRelTool_.ResetContent();

	int		nNum = pa::PTool->GetNumRelatedToolData();
	char	szTemp[128];
	CString strTemp;

	for( int i = 0; i<nNum; i++ ) {
		memset( (void*)szTemp, 0, 128 );
		pa::PTool->GetRelatedToolData( i, szTemp, 128 );
		strTemp = hcutil::ASCII_TO_CSTRING( szTemp );
		lbRelTool_.AddString( strTemp );
	}
}

void CSetupToolDlg::updateState_MenuButton()
{
	static int PREV_TOOLRETURN	= -1;
	static int PREV_RESET_TOOLNO= -1;
	static int PREV_TOOL_UNCLAMP= -1;
	static int PREV_SPINDLE_RUN = -1;
	static int PREV_ATCDOOR_OPEN= -1;
	static int PREV_BACK_BTN	= -1;
	int curr_tool_return;
	int curr_reset_toolno;
	int curr_tool_unclamp;
	int curr_spindle_run;
	int curr_atcdoor_open;
	int curr_back_btn;

	BOOL isMotorStop	= pa::PPAStatus->GetPAStatus()->nRunStatus == 0 ? TRUE : FALSE; //theApp.MotionDone( TRUE ); //theApp.IsMotorStop();
	BOOL isStopMode		= (BOOL)( pa::PPAStatus->GetRunMode() == pa::RUNMODE_STOP && isMotorStop );
	BOOL isIpcComplete	= TRUE; // (BOOL)( pa::PPAStatus->GetThreadState()->bIpcCmdComplete_ == TRUE ); => ������ �ǹ� ���� 
	BOOL isLeftSpindleRun	= (BOOL)( pa::PPAStatus->GetPAStatus()->nSpindleRun != 0 );
	BOOL isRightSpindleRun	= (BOOL)( pa::PPAStatus->GetPAStatus()->nSpindle2Run != 0);
//	BOOL isLeftColletOpen	= (BOOL)( pa::PPAStatus->GetPAStatus()->bOutput[pa::OUT20034_ToolLeftClamp] );
	BOOL isLeftColletOpen	= (BOOL)( pa::PPAStatus->GetPAStatus()->nSpindle1ColletOpenFlag );
//	BOOL isRightColletOpen	= (BOOL)( pa::PPAStatus->GetPAStatus()->bOutput[pa::OUT20035_ToolRightClamp] );
	BOOL isRightColletOpen	= (BOOL)( pa::PPAStatus->GetPAStatus()->nSpindle2ColletOpenFlag );

	curr_tool_return = (BOOL)( isStopMode && isIpcComplete && !isLeftSpindleRun && !isRightSpindleRun ? 1 : 0 );
	curr_reset_toolno= (BOOL)( isStopMode && isIpcComplete && !isLeftSpindleRun && !isRightSpindleRun ? 1 : 0 );
	curr_tool_unclamp= (BOOL)( isStopMode && isIpcComplete && !isLeftSpindleRun && !isRightSpindleRun ? 1 : 0 );
	curr_spindle_run = (BOOL)( isStopMode && isIpcComplete && !isLeftColletOpen && !isRightColletOpen ? 1 : 0 );		// spindle_run ��ư�� collet open ���� �߰� 
	curr_atcdoor_open= (BOOL)( isStopMode && isIpcComplete && !isLeftSpindleRun && !isRightSpindleRun ? 1 : 0 );
	curr_back_btn = (BOOL)( isStopMode && isIpcComplete && !isLeftColletOpen && !isRightColletOpen ? 1 : 0);

	// 5z�� disable ��Ų�� 
// 	switch( pa::PSWConfig->GetConfigData()->nModelID )
// 	{
// 	case 0: // DS200-5Z
// 		curr_atcdoor_open = 0;
// 		break;
// 	case 1:	// DS200-4W
// 	case 2:	// DS200-4WA
// 	case 3:	// DS200-4WAS
// 	case 4:	// DM200-5P
// 	case 5:	// DM200-5A
// 	case 6:	// DM200-5M
// 		curr_atcdoor_open = curr_tool_return;
// 		break;
// 	}
	curr_atcdoor_open = ( pa::MODEL_INFO.IsUsingATCDoor() == 0 ) ? 0 : curr_atcdoor_open; 

	// ��ư ���� ���� 
	{
		PREV_TOOLRETURN = curr_tool_return;
		((CButton*)GetDlgItem(IDC_BUTTON_TOOL_RETURN))->EnableWindow( PREV_TOOLRETURN );
		((CButton*)GetDlgItem(IDC_BUTTON_TOOL2_RETURN))->EnableWindow( PREV_TOOLRETURN );
	}
	{
		PREV_RESET_TOOLNO = curr_reset_toolno;
		((CButton*)GetDlgItem(IDC_BUTTON_RESET_TOOL_NO))->EnableWindow( PREV_RESET_TOOLNO );
		((CButton*)GetDlgItem(IDC_BUTTON_RESET_TOOL2_NO))->EnableWindow( PREV_RESET_TOOLNO );
	}
	{
		PREV_TOOL_UNCLAMP = curr_tool_unclamp;
		((CButton*)GetDlgItem(IDC_CHECK_TOOL_CLAMP_UNCLAMP))->EnableWindow( PREV_TOOL_UNCLAMP );
		((CButton*)GetDlgItem(IDC_CHECK_TOOL2_CLAMP_UNCLAMP))->EnableWindow( PREV_TOOL_UNCLAMP );
	}
	{
		PREV_SPINDLE_RUN = curr_spindle_run;
		((CButton*)GetDlgItem(IDC_CHECK_SPINDLE_RUN))->EnableWindow( PREV_SPINDLE_RUN );
		((CButton*)GetDlgItem(IDC_CHECK_SPINDLE2_RUN))->EnableWindow( PREV_SPINDLE_RUN );
	}
	{
		PREV_ATCDOOR_OPEN = curr_atcdoor_open;
		((CButton*)GetDlgItem(IDC_CHECK_ATC_DOOR))->EnableWindow( PREV_ATCDOOR_OPEN );
	}
	{
		PREV_BACK_BTN = curr_back_btn;
		((CButton*)GetDlgItem(IDC_BUTTON_CLOSE))->EnableWindow(PREV_BACK_BTN);
	}

	//////////////////////////////////////////////////////////////////////////
	//
	//////////////////////////////////////////////////////////////////////////

	// tool clamp
	static int PREV_NAME_TOOL_CLAMP = -1;
	static int PREV_NAME_TOOL2_CLAMP = -1;
#ifdef _PA_G1600_
//	int curr_name_tool_clamp = pa::PPAStatus->GetPAStatus()->bOutput[pa::OUT20034_ToolLeftClamp];
	int curr_name_tool_clamp = pa::PPAStatus->GetPAStatus()->nSpindle1ColletOpenFlag;
//	int curr_name_tool2_clamp = pa::PPAStatus->GetPAStatus()->bOutput[pa::OUT20035_ToolRightClamp];
	int curr_name_tool2_clamp = pa::PPAStatus->GetPAStatus()->nSpindle2ColletOpenFlag;
#endif 
	if( PREV_NAME_TOOL_CLAMP != curr_name_tool_clamp ) {
		PREV_NAME_TOOL_CLAMP = curr_name_tool_clamp;
		if( curr_name_tool_clamp != 0 ) {
			// clamp
			((CButton*)GetDlgItem(IDC_CHECK_TOOL_CLAMP_UNCLAMP))->SetCheck(1);	
			((CButton*)GetDlgItem(IDC_CHECK_TOOL_CLAMP_UNCLAMP))->SetWindowText( _T("L. Tool\r\nClamp") );
		}
		else {
			// unclamp
			((CButton*)GetDlgItem(IDC_CHECK_TOOL_CLAMP_UNCLAMP))->SetCheck(0);	
			((CButton*)GetDlgItem(IDC_CHECK_TOOL_CLAMP_UNCLAMP))->SetWindowText( _T("L. Tool\r\nUnclamp") );
		}
	}

	if( PREV_NAME_TOOL2_CLAMP != curr_name_tool2_clamp ) {
		PREV_NAME_TOOL2_CLAMP = curr_name_tool2_clamp;
		if( curr_name_tool2_clamp != 0 ) {
			// clamp
			((CButton*)GetDlgItem(IDC_CHECK_TOOL2_CLAMP_UNCLAMP))->SetCheck(1);	
			((CButton*)GetDlgItem(IDC_CHECK_TOOL2_CLAMP_UNCLAMP))->SetWindowText( _T("R. Tool\r\nClamp") );
		}
		else {
			// unclamp
			((CButton*)GetDlgItem(IDC_CHECK_TOOL2_CLAMP_UNCLAMP))->SetCheck(0);	
			((CButton*)GetDlgItem(IDC_CHECK_TOOL2_CLAMP_UNCLAMP))->SetWindowText( _T("R. Tool\r\nUnclamp") );
		}
	}


	// spindle run
	static int PREV_NAME_SPINDLE_RUN = -1;
	static int PREV_NAME_SPINDLE2_RUN = -1;
	int curr_name_spindle_run = pa::PPAStatus->GetPAStatus()->nSpindleRun;
	int curr_name_spindle2_run = pa::PPAStatus->GetPAStatus()->nSpindle2Run;

	if( PREV_NAME_SPINDLE_RUN != curr_name_spindle_run ) {
		PREV_NAME_SPINDLE_RUN = curr_name_spindle_run;
		if( curr_name_spindle_run != 0 ) {
			// spindle run
			((CButton*)GetDlgItem(IDC_CHECK_SPINDLE_RUN))->SetCheck(1);
			((CButton*)GetDlgItem(IDC_CHECK_SPINDLE_RUN))->SetWindowText( _T("L. Spindle\r\nStop") );
		}
		else {
			// spindle stop
			((CButton*)GetDlgItem(IDC_CHECK_SPINDLE_RUN))->SetCheck(0);
			((CButton*)GetDlgItem(IDC_CHECK_SPINDLE_RUN))->SetWindowText( _T("L. Spindle\r\nRun") );
		}
	}

	if( PREV_NAME_SPINDLE2_RUN != curr_name_spindle2_run ) {
		PREV_NAME_SPINDLE2_RUN = curr_name_spindle2_run;
		if( curr_name_spindle2_run != 0 ) {
			// spindle run
			((CButton*)GetDlgItem(IDC_CHECK_SPINDLE2_RUN))->SetCheck(1);
			((CButton*)GetDlgItem(IDC_CHECK_SPINDLE2_RUN))->SetWindowText( _T("R. Spindle\r\nStop") );
		}
		else {
			// spindle stop
			((CButton*)GetDlgItem(IDC_CHECK_SPINDLE2_RUN))->SetCheck(0);
			((CButton*)GetDlgItem(IDC_CHECK_SPINDLE2_RUN))->SetWindowText( _T("R. Spindle\r\nRun") );
		}
	}
}

void CSetupToolDlg::updateSpindleRPM()
{
	static int PREV_SPINDLE_RPM = -1;
	static int PREV_SPINDLE_OVR = -1;

	int spindle_rpm = pa::PPAStatus->GetPAStatus()->nSpindleSpeedWithOverride;
	int spindle_ovr = pa::PPAStatus->GetPAStatus()->nSpindleOverride;
	CString strTemp;

	if( PREV_SPINDLE_RPM != spindle_rpm ) {
		PREV_SPINDLE_RPM = spindle_rpm;
		strTemp.Format( _T("%d"), spindle_rpm );
		((CStatic*)GetDlgItem(IDC_STATIC_SPINDLE_RPM))->SetWindowText( strTemp );
	}
	if( PREV_SPINDLE_OVR != spindle_ovr ) {
		PREV_SPINDLE_OVR = spindle_ovr;
		strTemp.Format( _T("%d%%"), spindle_ovr );
		((CStatic*)GetDlgItem(IDC_STATIC_SPINDLE_OVR))->SetWindowText( strTemp );
	}
}

//////////////////////////////////////////////////////////////////////////

void CSetupToolDlg::OnBnClickedButtonGetTool1()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("get tool #1 button click") );
	//////////////////////////////////////////////////////////////////////////	
	PPNC_IPC_CLIENT->SendMDACommand( "M140" );
}

void CSetupToolDlg::OnBnClickedButtonGetTool2()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("get tool #2  button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->SendMDACommand( "M141" );
}

void CSetupToolDlg::OnBnClickedButtonGetTool3()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("get tool #3 button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->SendMDACommand( "M142" );
}

void CSetupToolDlg::OnBnClickedButtonGetTool4()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("get tool #4 button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->SendMDACommand( "M143" );
}

void CSetupToolDlg::OnBnClickedButtonGetTool5()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("get tool #5 button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->SendMDACommand( "M144" );
}

void CSetupToolDlg::OnBnClickedButtonGetTool6()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("get tool #6 button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->SendMDACommand( "M145" );
}

void CSetupToolDlg::OnBnClickedButtonGetTool7()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("get tool #7 button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->SendMDACommand( "M146" );
}

void CSetupToolDlg::OnBnClickedButtonGetTool8()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("get tool #8 button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->SendMDACommand( "M147" );
}

void CSetupToolDlg::OnBnClickedButtonToolReturn()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("Left tool return button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->SendMDACommand( "M1480" );
}

void CSetupToolDlg::OnBnClickedButtonTool2Return()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("Right tool return button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->SendMDACommand( "M1481" );
}


void CSetupToolDlg::OnBnClickedButtonResetToolNo()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("reset left tool no. button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->SendMDACommand( "M138" );
}

void CSetupToolDlg::OnBnClickedButtonResetTool2No()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("reset right tool no. button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->SendMDACommand( "M139" );
}

void CSetupToolDlg::OnBnClickedButtonResetTool1()
{
	doResetTool( 1 );
}

void CSetupToolDlg::OnBnClickedButtonResetTool2()
{
	doResetTool( 2 );
}

void CSetupToolDlg::OnBnClickedButtonResetTool3()
{
	doResetTool( 3 );
}

void CSetupToolDlg::OnBnClickedButtonResetTool4()
{
	doResetTool( 4 );
}

void CSetupToolDlg::OnBnClickedButtonResetTool5()
{
	doResetTool( 5 );
}

void CSetupToolDlg::OnBnClickedButtonResetTool6()
{
	doResetTool( 6 );
}

void CSetupToolDlg::OnBnClickedButtonResetTool7()
{
	doResetTool( 7 );
}

void CSetupToolDlg::OnBnClickedButtonResetTool8()
{
	doResetTool( 8 );
}

void CSetupToolDlg::doResetTool( int nToolNo )
{
	CSetupToolResetDlg dlg;

	dlg.SetToolNo( nToolNo );

	if( dlg.DoModal() == IDOK ) 
	{
		DWORD dwMaximumTime = dlg.GetMaximunTime();

		CString strLog;
		strLog.Format( _T("reset time tool #%d [%d] button click"), nToolNo, dwMaximumTime );
		writeLog( strLog );

		PPNC_IPC_CLIENT->ResetToolUsingTime( nToolNo, dwMaximumTime );
	}
}

void CSetupToolDlg::OnBnClickedCheckToolClampUnclamp()
{
	int nBtnChk = chkBtnToolClamp_.GetCheck();

	if( nBtnChk == 0 ) {
		//////////////////////////////////////////////////////////////////////////
		// log
		writeLog( _T("left tool clamp button click") );
		//////////////////////////////////////////////////////////////////////////
		// Clamp
		//PPNC_IPC_CLIENT->ToolClamp(0, FALSE );		// IO ���� ������
		PPNC_IPC_CLIENT->SendMDACommand( "M911" );
	} else {
		//////////////////////////////////////////////////////////////////////////
		// log
		writeLog( _T("left tool unclamp button click") );
		//////////////////////////////////////////////////////////////////////////
		// Unclamp
		//PPNC_IPC_CLIENT->ToolClamp(0, TRUE );		// IO ���� ������
		PPNC_IPC_CLIENT->SendMDACommand( "M910" );
		//////////////////////////////////////////////////////////////////////////
		// ��-Ŭ������ ���, ����ȣ�� ���� �Ѵ� 
		// log
		writeLog( _T("reset left tool no.") );
		//////////////////////////////////////////////////////////////////////////
		PPNC_IPC_CLIENT->SendMDACommand( "M138" );
	}
}

void CSetupToolDlg::OnBnClickedCheckTool2ClampUnclamp()
{
	int nBtnChk = chkBtnTool2Clamp_.GetCheck();

	if( nBtnChk == 0 ) {
		//////////////////////////////////////////////////////////////////////////
		// log
		writeLog( _T("Right tool clamp button click") );
		//////////////////////////////////////////////////////////////////////////
		// Clamp
		//PPNC_IPC_CLIENT->ToolClamp(1, FALSE );		// IO ������
		PPNC_IPC_CLIENT->SendMDACommand( "M921" );
	} else {
		//////////////////////////////////////////////////////////////////////////
		// log
		writeLog( _T("Right tool unclamp button click") );
		//////////////////////////////////////////////////////////////////////////
		// Unclamp
		//PPNC_IPC_CLIENT->ToolClamp(1, TRUE );
		PPNC_IPC_CLIENT->SendMDACommand( "M920" );
		//////////////////////////////////////////////////////////////////////////
		// ��-Ŭ������ ���, ����ȣ�� ���� �Ѵ� 
		// log
		writeLog( _T("reset right tool no.") );
		//////////////////////////////////////////////////////////////////////////
		PPNC_IPC_CLIENT->SendMDACommand( "M138" );
	}
}

void CSetupToolDlg::OnBnClickedCheckSpindleRun()
{
	int nBtnChk = chkBtnSpindleRun_.GetCheck();

	if( nBtnChk != 0 ) {
		//////////////////////////////////////////////////////////////////////////
		// log
		writeLog( _T("Left spindle run button click") );
		//////////////////////////////////////////////////////////////////////////
		// Spindle Run
		PPNC_IPC_CLIENT->SendMDACommand( "M103" );
	} else {
		//////////////////////////////////////////////////////////////////////////
		// log
		writeLog( _T("Left spindle stop button click") );
		//////////////////////////////////////////////////////////////////////////
		// Spindle Stop
		PPNC_IPC_CLIENT->SendMDACommand( "M105" );
	}
}

void CSetupToolDlg::OnBnClickedCheckSpindle2Run()
{
	int nBtnChk = chkBtnSpindle2Run_.GetCheck();

	if( nBtnChk != 0 ) {
		//////////////////////////////////////////////////////////////////////////
		// log
		writeLog( _T("Right spindle run button click") );
		//////////////////////////////////////////////////////////////////////////
		// Spindle Run
		PPNC_IPC_CLIENT->SendMDACommand( "M113" );
	} else {
		//////////////////////////////////////////////////////////////////////////
		// log
		writeLog( _T("Right spindle stop button click") );
		//////////////////////////////////////////////////////////////////////////
		// Spindle Stop
		PPNC_IPC_CLIENT->SendMDACommand( "M115" );
	}
}

//////////////////////////////////////////////////////////////////////////
#include "RegisterRelToolDlg.h"
void CSetupToolDlg::OnBnClickedButtonRegisterRelatedTool()
{
	CRegisterRelToolDlg dlg;

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("register related tool button click") );
	//////////////////////////////////////////////////////////////////////////

	if( dlg.DoModal() == IDOK ) 
	{
		CString strRelTool = dlg.GetRelatedToolData();
		char	szTemp[128];

		if( strRelTool.GetLength() > 0 ) 
		{
			memset( (void*)szTemp, 0, 128 );
			hcutil::UNICODE_TO_ASCII( (TCHAR*)(LPCTSTR)strRelTool, szTemp, 128 );
			pa::PTool->AddRelatedToolData( szTemp );

			//////////////////////////////////////////////////////////////////////////
			// log
			CString strLog;
			strLog.Format( _T("%s"), szTemp );
			WriteLog_EXT( strLog );
			//////////////////////////////////////////////////////////////////////////
		} 

		updateToolRelatedData();

	}
}

void CSetupToolDlg::OnBnClickedButtonRemoveRelatedTool()
{
	int nSel = lbRelTool_.GetCurSel();

	if( nSel != -1 ) 
	{
		//////////////////////////////////////////////////////////////////////////
		// log
		CString strLog;
		strLog.Format( _T("unregister related tool data no. %d"), nSel );
		writeLog( strLog );
		//////////////////////////////////////////////////////////////////////////

		pa::PTool->RemoveRelatedToolData( nSel );

		updateToolRelatedData();

	}
}

//////////////////////////////////////////////////////////////////////////

void CSetupToolDlg::OnBnClickedCheckAtcDoor()
{
#ifdef _PA_G2400_
	if( pa::PPAStatus->GetPAStatus()->bInput[pa::IN102_ATC_DOOR_CLOSE] != FALSE ) {
		//////////////////////////////////////////////////////////////////////////
		// log
		writeLog( _T("atc door open button click") );
		//////////////////////////////////////////////////////////////////////////
		// atc door�� ���� ����. Door Open  
		PPNC_IPC_CLIENT->ATCDoor( TRUE ); //FALSE ); //TRUE );
	}
	else {
		//////////////////////////////////////////////////////////////////////////
		// log
		writeLog( _T("atc door close button click") );
		//////////////////////////////////////////////////////////////////////////
		// atc door�� ���� ����. Door Close
		PPNC_IPC_CLIENT->ATCDoor( FALSE ); //TRUE ); //FALSE );
	}
#endif
#ifdef _PA_G1600_
	// DS200-5Z : ATC Door ���� 
	// DS200-4W : ATC Door ���� 
// 	switch( pa::PSWConfig->GetConfigData()->nModelID )
// 	{
// 	case 0: // DS200-5Z : ATC DOOR ���� 
// 		break;
// 	case 1:	// DS200-4W
// 	case 2:	// DS200-4WA
// 	case 3:	// DS200-4WAS
// 	case 4:	// DM200-5P
// 	case 5:	// DM200-5A
// 	case 6:	// DM200-5M
// 		if( pa::PPAStatus->GetPAStatus()->bInput[pa::IN20014_AtcDoorCloseCheck_] == FALSE ) {
// 			// open �Ǿ� �����Ƿ�, close �Ѵ� 
// 			PPNC_IPC_CLIENT->ATCDoor( FALSE );
// 		} 
// 		else {
// 			// close �Ǿ� �����Ƿ� open �Ѵ� 
// 			PPNC_IPC_CLIENT->ATCDoor( TRUE );
// 		}
// 		break;
// 	}
// 	if (pa::MODEL_INFO.IsUsingATCDoor())
// 	{
// 		if (pa::PPAStatus->GetPAStatus()->bInput[pa::IN20014_AtcDoorCloseCheck_] == FALSE)
// 		{
// 			// open �Ǿ� �����Ƿ�, close �Ѵ� 
// 			PPNC_IPC_CLIENT->ATCDoor( FALSE );
// 		}
// 		else
// 		{
// 			// close �Ǿ� �����Ƿ� open �Ѵ� 
// 			PPNC_IPC_CLIENT->ATCDoor( TRUE );
// 		}
// 	}
#endif
}

void CSetupToolDlg::OnBnClickedCheckToolMaxUsageTime()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	CString strLog;
	strLog.Format( _T("set enable tool usage time %d"), chkMaxToolUsageTime_.GetCheck() );
	writeLog( strLog );
	//////////////////////////////////////////////////////////////////////////
	pa::PTool->SetEnableToolUsageTime( chkMaxToolUsageTime_.GetCheck() );
}

void CSetupToolDlg::OnBnClickedCheckToolRelated()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	CString strLog;
	strLog.Format( _T("set enable related tool %d"), chkUsingRelatedTool_.GetCheck() );
	writeLog( strLog );
	//////////////////////////////////////////////////////////////////////////
	pa::PTool->SetEnableRelatedTool( chkUsingRelatedTool_.GetCheck() );
}

void CSetupToolDlg::writeLog( LPCTSTR log_msg )
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	WriteLog( CLog::TYPE_OPER, 4, log_msg );
	//////////////////////////////////////////////////////////////////////////
}

void CSetupToolDlg::OnBnClickedButtonIncSpindleOvr()
{
//	setSpindleRPMOverride( pa::PPAStatus->GetPAStatus()->nSpindleOverride + 5 );
	setSpindleRPMOverride( nSpindleOverride_ + 5 );
}

void CSetupToolDlg::OnBnClickedButtonDecSpindleOvr()
{
//	setSpindleRPMOverride( pa::PPAStatus->GetPAStatus()->nSpindleOverride - 5 );
	setSpindleRPMOverride( nSpindleOverride_ - 5 );
}

void CSetupToolDlg::setSpindleRPMOverride( int new_ovr )
{
	if( new_ovr < 0 ) {
		new_ovr = 1;
	}
	if( new_ovr > 200 ) {
		new_ovr = 200;
	}

	if( new_ovr != 1 && new_ovr % 5 != 0 ) {
		new_ovr = new_ovr - ( new_ovr % 5 );
	}

	// WCSO ���� ���
	char sztemp[64];
	sprintf_s( sztemp, 64, "WCSO %d", new_ovr );
	PPNC_IPC_CLIENT->SendCommand( sztemp, 5000 );
	nSpindleOverride_ = new_ovr;
}

void CSetupToolDlg::PreInitDialog()
{
	CString strImageFilePath;
	CDC*	pDC = GetDC();
	CRect	rcWnd;

	GetClientRect( &CUIrectSetT );
	MoveWindow(0,0,1025,621);
	GetClientRect( &rcWnd );

	//////////////////////////////////////////////////////////////////////////
	strImageFilePath.Format( _T("%s\\Background_setup.bmp"), pResourcePath_ );

	GetClientRect( &rcWnd );

	pCanvasCE_ = new hcutil::CCanvasCE();
	ASSERT(pCanvasCE_ );
	pCanvasCE_->Create( this, pDC->GetSafeHdc(), rcWnd.Width(), rcWnd.Height(), RGB(1, 1, 0) );
	pCanvasCE_->GetCanvasCELayerMgr()->Add( FALSE, RGB(0, 0, 0) );
	pCanvasCE_->GetCanvasCELayerMgr()->Add( TRUE, RGB(255, 0, 255) );

	pCanvasCE_->GetCanvasCELayerMgr()->Get( 0 )->FillSolidRect( rcWnd, pa::CLR_SETUP_TOOL );
	pCanvasCE_->GetCanvasCELayerMgr()->Get( 1 )->LoadImageFormFile( strImageFilePath, CPoint(0, 0), CPoint(rcWnd.Width(), rcWnd.Height()) );
	//////////////////////////////////////////////////////////////////////////

	ReleaseDC( pDC );
	pDC = NULL;

	CDialogListPage::PreInitDialog();
}

void CSetupToolDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting


	if( pCanvasCE_ ) {
		pCanvasCE_->Draw( dc.m_hDC, dc.m_ps.rcPaint );
	}
}