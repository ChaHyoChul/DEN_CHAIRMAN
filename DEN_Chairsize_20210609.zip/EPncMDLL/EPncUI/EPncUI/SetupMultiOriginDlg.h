#pragma once

#include "TitleBarWnd.h"
#include "OptionDataListBox.h"

// CSetupMultiOriginDlg ��ȭ �����Դϴ�.

class CSetupMultiOriginDlg : public CDialogListPage
{
public:
	enum EN_SUB_PAGE
	{
		SUB_PAGE_MULTI_ORG = 0,
		SUB_PAGE_MULTI_ORG_TEACH
	};

private:
	DECLARE_DYNCREATE(CSetupMultiOriginDlg)

	CWnd*	pParentWnd_;
	TCHAR*	pResourcePath_;

	hcutil::CCanvasCE*	pCanvasCE_;

	CDialogMap			*pDlgMap_;			// 
	EN_SUB_PAGE			hCurrSubPage_;		// 

	BOOL	bIsModify_;
	BOOL	bIsModifyAutoTeach_;

	CTitleBarWnd*		pTitleBarWnd_;
	CFont				fntButton_;
	CBrush				brhBackground_;
	CBrush				brhBackButton_;

	COptionDataListBox*	pDataListBox_;

	CRect CUIrectSMO;

	// ����� ������ 
	pa::SMultiOriginData	hTempMultiOriginData_;

	//
	void update_button_state();

	// multi origin �����͸� ����⿡�� pc�� �о� ���δ� 
	void upload_to_pc();

	// ����⿡ "sav" ���� ���� 
	void save_control();	

	// listbox 
	void reflash_listbox();

	// 
	void reflash_max_min_data();

	//
	void writeLog( LPCTSTR log_msg );

	void initialize_DlgMap();
	void destroy_DlgMap();

public:
	CSetupMultiOriginDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupMultiOriginDlg();

	void SetParentWnd( CWnd* pParent ) { pParentWnd_ = pParent; }
	virtual void StartPageWork();
	virtual void StopPageWork();
	virtual void UpdatePage();

	void SetModifyAutoTeach( BOOL b ) { bIsModifyAutoTeach_ = b; }

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_MULTIORG };


protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
protected:
	virtual void PreInitDialog();
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedButtonClose();
	LRESULT OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedButtonDownloadToCtrl();
//	afx_msg void OnBnClickedButtonUploadToPc();
	afx_msg void OnBnClickedButtonSav();
	afx_msg void OnBnClickedButtonAutoTeach();
	afx_msg void OnBnClickedButtonLoad();
	afx_msg LRESULT OnWindowMove(WPARAM wparam, LPARAM lparam);
};
