#pragma once


// CSetupSystemFilterManagementDlg ��ȭ �����Դϴ�.

class CSetupSystemFilterManagementDlg : public CDialog
{
	DECLARE_DYNAMIC(CSetupSystemFilterManagementDlg)
	
	CFont fntEdit_;
	CFont fntButton_;

	void displayFilterInfo();
	BOOL save_to_file_sw_config(CString& strErrMsg);

public:
	CSetupSystemFilterManagementDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSetupSystemFilterManagementDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_SETUP_SYSTEM_FILTER_MANAGEMENT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedButtonClose();

	CButton btnHour_;
	CButton btnMin_;
	CButton btnSec_;
	afx_msg void OnBnClickedButtonHour();
	afx_msg void OnBnClickedButtonMin();
	afx_msg void OnBnClickedButtonSec();
	afx_msg void OnBnClickedButtonReset();
	afx_msg void OnBnClickedButtonSet();
};
