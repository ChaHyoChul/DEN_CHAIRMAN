#include "StdAfx.h"
#include "PAStatus.h"

pa::CPAStatus::CPAStatus(void)
{
	pShMem_		= NULL;
	pPAStatus_	= NULL;
	bUpdateFlag_= FALSE;
}

pa::CPAStatus::~CPAStatus(void)
{
	Destroy();
}

BOOL pa::CPAStatus::Initialize( CString& strErrMsg )
{
	//////////////////////////////////////////////////////////////////////////
	pShMem_ = new hcipc::CSharedMem();
	if( pShMem_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pa::CPState::pShMem_ object") );
		return FALSE;
	}

	pPAStatus_ = (SPAStatus *)pShMem_->Create( NULL, PMAC_STATE_OBJECT_NAME, sizeof(SPAStatus), FALSE, 0 );
	if( pPAStatus_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pa::CPState::pState_ object") );
		return FALSE;
	}

	pShMem_->MemSet( 0 );

	//////////////////////////////////////////////////////////////////////////
	pShMemForThreadState_ = new hcipc::CSharedMem();
	if( pShMemForThreadState_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::CPThreadStateImpl::pShMemForThreadState_ object") );
		return FALSE;
	}
	pThreadState_ = (SThreadState *)pShMemForThreadState_->Create( NULL, PTHREADSTATE_OBJECT_NAME, sizeof(SThreadState), FALSE, 0 );
	if( pThreadState_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pa::CPThreadStateImpl::pShMemForThreadState_ object") );
		return FALSE;
	}

	//////////////////////////////////////////////////////////////////////////
	// 1. Multi Origin Data
	CString strMultiOriginFilePath = CONFIG_FILEPATH + CString(_T("\\MultiOriginData.ini"));
	pShMemForMultiOrigin_ = new hcipc::CSharedMem();
	if( pShMemForMultiOrigin_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pa::SMultiOriginData object") );
		return FALSE;
	}
	pMultiOriginData_ = (SMultiOriginData *)pShMemForMultiOrigin_->Create( NULL, MULTIORIGIN_OBJECT_NAME, sizeof(SMultiOriginData), FALSE, 0 );
	if( pMultiOriginData_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pa::SMultiOriginData object") );
		return FALSE;
	}
	pMultiOriginData_->Load(INI_MULTI_ORIGIN_CONFIG_PATH, strErrMsg, FALSE);

	//////////////////////////////////////////////////////////////////////////
	// 2. Auto Cal. CoordinateOffsetParam
	pShMemForAutoCalCoordinateOffsetParam_ = new hcipc::CSharedMem();
	if( pShMemForAutoCalCoordinateOffsetParam_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pa::SAutoCalParamForCoordOffset") );
		return FALSE;
	}
	pAutoCalCoordinateOffsetParam_ = (SAutoCalCoordinateOffsetParam *)pShMemForAutoCalCoordinateOffsetParam_->Create( NULL, AUTOCAL_PARAM_OBEJCT_NAME, sizeof(SAutoCalCoordinateOffsetParam), FALSE, 0 );
	if( pAutoCalCoordinateOffsetParam_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pa::SAutoCalParamForCoordOffset") );
		return FALSE;
	}

	//////////////////////////////////////////////////////////////////////////
	// 3. Auto Teaching Multi Origin
	pShMemForAutoTeachMultiOrgParam_ = new hcipc::CSharedMem();
	if( pShMemForAutoTeachMultiOrgParam_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pa::SAutoTeachMultiOrgParam") );
		return FALSE;
	}
	pAutoTeachMultiOrgParam_ = (SAutoTeachMultiOrgParam *)pShMemForAutoTeachMultiOrgParam_->Create( NULL,  AUTOTEACH_MULTIORG_PARAM_OBJECT_NAME, sizeof(SAutoTeachMultiOrgParam), FALSE, 0 );
	if( pAutoTeachMultiOrgParam_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pmac::SAutoTeachMultiOrgParam") );
		return FALSE;
	}

	//////////////////////////////////////////////////////////////////////////
	// 4. Auto Teaching Tool Pocket
	pShMemForAutoTeachToolPocketParam_ = new hcipc::CSharedMem();
	if( pShMemForAutoTeachToolPocketParam_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::SAutoTeachToolPocketParam") );
		return FALSE;
	}
	pAutoTeachToolPocketParam_ = (SAutoTeachToolPocketParam *)pShMemForAutoTeachToolPocketParam_->Create( NULL, AUTOTEACH_TOOLPOCKET_PARAM_OBJECT_NAME, sizeof(SAutoTeachToolPocketParam), FALSE, 0 );
	if( pAutoTeachToolPocketParam_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pmac::SAutoTeachToolPocketParam") );
		return FALSE;
	}

	//////////////////////////////////////////////////////////////////////////
	// 5. AutoCal. SingleAbutment CoordinateOffset Param 
	pShMemForAutoCalSingleAbutmentCoordinateOffsetParam_ = new hcipc::CSharedMem();
	if( pShMemForAutoCalSingleAbutmentCoordinateOffsetParam_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pa::SAutoCalSingleAbutmentCoordinateOffsetParam") );
		return FALSE;
	}
	pAutoCalSingleAbutmentCoordinateOffsetParam_ = 
		(SAutoCalSingleAbutmentCoordinateOffsetParam *)pShMemForAutoCalSingleAbutmentCoordinateOffsetParam_->
		Create( NULL, AUTOCAL_SINGLE_ABUTMENT_NAME, sizeof(SAutoCalSingleAbutmentCoordinateOffsetParam), FALSE, 0 );
	if( pAutoCalSingleAbutmentCoordinateOffsetParam_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pa::SAutoCalSingleAbutmentCoordinateOffsetParam") );
		return FALSE;
	}
	pAutoCalSingleAbutmentCoordinateOffsetParam_->Load( INI_SINGLE_ABUTMENT_AT_COORD_OFFSET_PARAM_PATH, strErrMsg );

	//////////////////////////////////////////////////////////////////////////
	// 6. Coordinate Offset Data Range 
	pShMemForCoordinateOffsetDataRange_ = new hcipc::CSharedMem();
	if( pShMemForCoordinateOffsetDataRange_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pa::SCoordinateOffsetDataRange") );
		return FALSE;
	}
	pCoordinateOffsetDataRange_ = 
		(SCoordinateOffsetDataRange*)pShMemForCoordinateOffsetDataRange_->
		Create( NULL, COORDINATE_OFFSET_DATA_RANGE, sizeof(SCoordinateOffsetDataRange), FALSE, 0 );
	if( pCoordinateOffsetDataRange_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pa::SCoordinateOffsetDataRange") );
		return FALSE;
	}
	pCoordinateOffsetDataRange_->Load( INI_COORDINATE_OFFSET_DATA_RANGE_PATH, strErrMsg );

	//////////////////////////////////////////////////////////////////////////
	// 7. Measure Param ETC.
	pShMemForMeasureParamEtc_ = new hcipc::CSharedMem();
	if( pShMemForMeasureParamEtc_ == NULL ) {
		strErrMsg.Format( _T("memory alloc error for pa::SMeasureParamEtc") );
		return FALSE;
	}
	pMeasureParamEtc_ = (SMeasureParamEtc *)pShMemForMeasureParamEtc_->
		Create( NULL, MEASRE_PARAM_ETC, sizeof(SMeasureParamEtc), FALSE, 0 );
	if( pMeasureParamEtc_ == NULL ) {
		strErrMsg.Format( _T("create shared memory error for pa::SMeasureParamEtc") );
		return FALSE;
	}
	pMeasureParamEtc_->Load( INI_MEASURE_PARAM_ETC_PATH, strErrMsg );

	//////////////////////////////////////////////////////////////////////////
	pThreadState_->bIpcCmdComplete_		= TRUE;
	pThreadState_->bIsDemoMode_			= FALSE;
	pThreadState_->bIsClientConnected_	= FALSE;
	pThreadState_->bRemoteLock_			= FALSE;
	pThreadState_->bRemoteReset_		= FALSE;

	pThreadState_->bRemoteAutoUpdate_	= TRUE; //FALSE;
	pThreadState_->bSendRegistered_NCFileList_	= FALSE;
	pThreadState_->bSendSDMemory_NCFileList_	= FALSE;
	
	memset((void*)(pThreadState_->szUIProgVersion), 0, sizeof(TCHAR)*128);
	
	return TRUE;
}

void pa::CPAStatus::Destroy()
{
	if( pShMem_ ) {
		pShMem_->Destroy();
		delete pShMem_;
		pShMem_ = NULL;
		pPAStatus_ = NULL;
	}

	if( pShMemForThreadState_ ) {
		pShMemForThreadState_->Destroy();
		delete pShMemForThreadState_;
		pShMemForThreadState_ = NULL;
		pThreadState_ = NULL;
	}

	if( pShMemForMultiOrigin_ ) {
		pShMemForMultiOrigin_->Destroy();
		delete pShMemForMultiOrigin_;
		pShMemForMultiOrigin_ = NULL;
		pMultiOriginData_ = NULL;
	}

	if( pShMemForAutoCalCoordinateOffsetParam_ ) {
		pShMemForAutoCalCoordinateOffsetParam_->Destroy();
		delete pShMemForAutoCalCoordinateOffsetParam_;
		pShMemForAutoCalCoordinateOffsetParam_ = NULL;
		pAutoCalCoordinateOffsetParam_ = NULL;
	}

	if( pShMemForAutoTeachMultiOrgParam_ ) {
		pShMemForAutoTeachMultiOrgParam_->Destroy();
		delete pShMemForAutoTeachMultiOrgParam_;
		pShMemForAutoTeachMultiOrgParam_ = NULL;
		pAutoTeachMultiOrgParam_ = NULL;
	}

	if( pShMemForAutoTeachToolPocketParam_ ) {
		pShMemForAutoTeachToolPocketParam_->Destroy();
		delete pShMemForAutoTeachToolPocketParam_;
		pShMemForAutoTeachToolPocketParam_ = NULL;
		pAutoTeachToolPocketParam_ = NULL;
	}

	if( pShMemForAutoTeachMultiOrgParam_ ) {
		pShMemForAutoTeachMultiOrgParam_->Destroy();
		delete pShMemForAutoTeachMultiOrgParam_;
		pShMemForAutoTeachMultiOrgParam_ = NULL;
		pAutoTeachMultiOrgParam_ = NULL;
	}

	if( pShMemForAutoCalSingleAbutmentCoordinateOffsetParam_ ) {
		pShMemForAutoCalSingleAbutmentCoordinateOffsetParam_->Destroy();
		delete pShMemForAutoCalSingleAbutmentCoordinateOffsetParam_;
		pShMemForAutoCalSingleAbutmentCoordinateOffsetParam_ = NULL;
		pAutoCalSingleAbutmentCoordinateOffsetParam_ = NULL;
	}

	if( pShMemForCoordinateOffsetDataRange_ ) {
		pShMemForCoordinateOffsetDataRange_->Destroy();
		delete pShMemForCoordinateOffsetDataRange_;
		pShMemForCoordinateOffsetDataRange_ = NULL;
		pCoordinateOffsetDataRange_ = NULL;
	}

	if( pShMemForMeasureParamEtc_ ) {
		pShMemForMeasureParamEtc_->Destroy();
		delete pShMemForMeasureParamEtc_;
		pShMemForMeasureParamEtc_ = NULL;
		pMeasureParamEtc_ = NULL;
	}
}

pa::EN_NC_FILESTATE pa::CPAStatus::GetNCFileState()
{
	if( pThreadState_->bIsOpenNCFile == FALSE ) {
		return pa::NCFILE_STATE_NUM;
 	}

 	return (pa::EN_NC_FILESTATE)(pThreadState_->hNCFileInfo.state);
}

// ����⿡�� ���¸� �о�, Update �Ѵ� 
/*
void pa::CPAState::UploadPmacState()
{
#ifdef _USE_PMAC_
	static char sztemp[2048];
	int		offset = 4420;
	int		length = sizeof(SPmacState);
	length = 600;

	memset((void*)sztemp, 0, sizeof(char)*2048);

	PComm->GetMem( offset, length, (char*)sztemp, 2048 );
	
	memcpy((void*)pPmacState_, (const char*)sztemp, sizeof(char)*length);

	bUploadFlag_ = TRUE;

	//////////////////////////////////////////////////////////////////////////
	// Origin Complete ���� ���� 
	BOOL bOriginComplete = TRUE;
	for( int i = 0; i<pmac::PConfig->pConfig_->nNumAxis; i++ ) {
		if( pPmacState_->nOriginComplete[i] == 0 ) {
			bOriginComplete = FALSE; 
			break;
		} 
	}
	if( bOriginComplete && pmac::PAutoLoader->IsUsingAutoLoader() == TRUE ) {
		if( pPmacState_->nOriginComplete_BlockLoader == 0 ) {
			bOriginComplete = FALSE;
		}
	}
	pmac::PState->GetThreadState()->bIsOriginComplete_ = bOriginComplete;
// 	pmac::PState->GetThreadState()->bIsOriginComplete_ = TRUE;
	//////////////////////////////////////////////////////////////////////////
#endif
}
*/

// ����⿡�� ���� �����͸� ����ؼ�. pPAState_�� �ʱ�ȭ �Ѵ� 
// void pa::CPAStatus::UpdatePAState( char* pPAState )
// {
// 	
// }


// ThreadState�� NCFileInfo�� index ��° NCFile�� ������ �����Ѵ�. File Open ���·� �����  
// void pa::CPAStatus::SetNCFileInfo( int nNCFileIndex )
// {
// 	SNCFileInfo* pNCFileInfo = PNCFileMgr->GetNCFileInfo( nNCFileIndex );
// 
// 	ASSERT( pNCFileInfo );
// 
// 	memcpy( (void*)&(pThreadState_->hNCFileInfo), (const void*)pNCFileInfo, sizeof(SNCFileInfo) );
// 	
// 	pThreadState_->bIsOpenNCFile = TRUE;
// }

// ThreadState�� NCFileInfo�� ������ �����, File Close ���·� ����� 
// void pa::CPAStatus::ResetNCFileInfo()
// {
// 	pThreadState_->bIsOpenNCFile = FALSE;
// 
// 	memset( (void*)&(pThreadState_->hNCFileInfo), 0, sizeof(SNCFileInfo) );
// }

// void pa::CPAStatus::SetNCFileState( pa::EN_NC_FILESTATE state, BOOL bSaveMem )
// {
// 	if( pThreadState_->bIsOpenNCFile == FALSE ) {
// 		return ;
// 	}
// 
// 	pThreadState_->hNCFileInfo.state = (TCHAR)state;
// 
// 	if( bSaveMem ) 
// 	{
// 		// PNCFileMgr�� �����ϰ�, SD �޸𸮿��� �����Ѵ� 
// 		PNCFileMgr->UpdateNCFileInfo( PNCFileMgr->GetCurrentWorkNCFileIndex(), &(pThreadState_->hNCFileInfo) );
// 	}
// 
// 	// PThread ��ü�� ����� NC ���� ���°� ����� 
// 	if( PPAStatus->GetThreadState()->bSendRegistered_NCFileList_ == FALSE ) {
// 		PPAStatus->GetThreadState()->bSendRegistered_NCFileList_ = TRUE;
// 	}
// }

/*
enum EN_NC_FILESTATE 
{
NCFILE_STATE_BEFORE = 0,	// �۾� �� 
NCFILE_STATE_RUNNING,		// �۾� �� 
NCFILE_STATE_COMPLETE,		// �۾� �Ϸ� 
NCFILE_STATE_STOP,			// �۾� ����
NCFILE_STATE_ERROR,			// �۾� ���� ���� 
NCFILE_STATE_NUM
};
*/
// pa::EN_NC_FILESTATE pa::CPAStatus::GetNCFileState()
// {
// 	if( pThreadState_->bIsOpenNCFile == FALSE ) {
// 		return pa::NCFILE_STATE_NUM;
// 	}
// 
// 	return (pa::EN_NC_FILESTATE)(pThreadState_->hNCFileInfo.state);
// }

// void pa::CPAStatus::SetNCFileFinish( TCHAR finish, BOOL bSaveMem )
// {
// 	if( pThreadState_->bIsOpenNCFile == FALSE ) {
// 		return ;
// 	}
// 
// 	pThreadState_->hNCFileInfo.finish = finish;
// 
// 	if( bSaveMem )
// 	{
// 		// PNCFileMgr�� �����ϰ�, SD �޸𸮿��� �����Ѵ� 
// 		PNCFileMgr->UpdateNCFileInfo( PNCFileMgr->GetCurrentWorkNCFileIndex(), &(pThreadState_->hNCFileInfo) );
// 	}
// }

// void pa::CPAStatus::SetNCFileTotalLine( int nTotalLine, BOOL bSaveMem )
// {
// 	if( pThreadState_->bIsOpenNCFile == FALSE ) {
// 		return ;
// 	}
// 
// 	pThreadState_->hNCFileInfo.total_lines = nTotalLine;
// 
// 	if( bSaveMem ) 
// 	{
// 		// PNCFileMgr�� �����ϰ�, SD �޸𸮿��� �����Ѵ� 
// 		PNCFileMgr->UpdateNCFileInfo( PNCFileMgr->GetCurrentWorkNCFileIndex(), &(pThreadState_->hNCFileInfo) );
// 	}
// }

// void pa::CPAStatus::SetNCFileMachiningLine( int nMachiningLine, BOOL bSaveMem )
// {
// 	if( pThreadState_->bIsOpenNCFile == FALSE ) {
// 		return ;
// 	}
// 
// 	pThreadState_->hNCFileInfo.machining_lines = nMachiningLine;
// 
// 	if( bSaveMem ) 
// 	{
// 		// PNCFileMgr�� �����ϰ�, SD �޸𸮿��� �����Ѵ� 
// 		PNCFileMgr->UpdateNCFileInfo( PNCFileMgr->GetCurrentWorkNCFileIndex(), &(pThreadState_->hNCFileInfo) );
// 	}
// }

// void pa::CPAStatus::SetNCFileStartTime( BOOL bSaveMem )
// {
// 	if( pThreadState_->bIsOpenNCFile == FALSE ) {
// 		return ;
// 	}
// 	
// 	CTime tm = CTime::GetCurrentTime();
//  	CString strTm = tm.Format( _T("%H:%M:%S") );
// 
// 	memset( (void*)(pThreadState_->hNCFileInfo.start_time), 0, sizeof(char)*16 );
// 	_stprintf_s( pThreadState_->hNCFileInfo.start_time, 15, _T("%s"), (LPCTSTR)strTm );
// 
// 	if( bSaveMem ) 
// 	{
// 		// PNCFileMgr�� �����ϰ�, SD �޸𸮿��� �����Ѵ� 
// 		PNCFileMgr->UpdateNCFileInfo( PNCFileMgr->GetCurrentWorkNCFileIndex(), &(pThreadState_->hNCFileInfo) );
// 	}
// }

// void pa::CPAStatus::SetNCFileWorkTime( DWORD sec, BOOL bSaveMem )
// {
// 	if( pThreadState_->bIsOpenNCFile == FALSE ) {
// 		return ;
// 	}
// 
// 	CTimeSpan tms(sec);
// 	memset( (void*)(pThreadState_->hNCFileInfo.work_time), 0, sizeof(char)*16 );
// 	_stprintf_s( pThreadState_->hNCFileInfo.work_time, 15, _T("%s"), tms.Format( _T("%H:%M:%S") ) );
// 
// 	if( bSaveMem ) 
// 	{
// 		// PNCFileMgr�� �����ϰ�, SD �޸𸮿��� �����Ѵ� 
// 		PNCFileMgr->UpdateNCFileInfo( PNCFileMgr->GetCurrentWorkNCFileIndex(), &(pThreadState_->hNCFileInfo) );
// 	}
// }

//////////////////////////////////////////////////////////////////////////

