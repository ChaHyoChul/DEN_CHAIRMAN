#pragma once
#include "afxwin.h"


// CConnectErrorDlg ��ȭ �����Դϴ�.

class CConnectErrorDlg : public CDialog
{
	DECLARE_DYNAMIC(CConnectErrorDlg)

	CFont	fntTitle_;
	CFont	fntMsg_;
	CFont	fntButton_;

	CString strTitle_;
	CString strMseeage_;

	BOOL	bButtonStatus_;

public:
	CConnectErrorDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CConnectErrorDlg();

	void SetTitle(CString& strTitle)
	{
		strTitle_= strTitle;
	}
	void SetMessage(CString& strMsg)
	{
		strMseeage_ = strMsg;
	}
	void SetButtonStatus( BOOL b ) 
	{
		bButtonStatus_ = b;
	}

// ��ȭ ���� �������Դϴ�.
	enum { IDD = 183 }; //IDD_DIALOG_CONNECT_ERROR };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedButtonRun();
	afx_msg void OnBnClickedButtonStop();
	afx_msg void OnBnClickedButtonClose();
	CStatic stcTitle_;
	CStatic stcMessage_;
	CButton btnRun_;
	CButton btnStop_;
	CButton btnClose_;
};
