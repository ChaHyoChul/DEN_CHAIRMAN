// SetupSystemMultiOriginDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "SetupSystemMultiOriginDlg.h"
#include "NumericInputDlg.h"
#include "MsgDlg.h"
#include "MsgDlgThread.h"

// CSetupSystemMultiOriginDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CSetupSystemMultiOriginDlg, CDialog)

CSetupSystemMultiOriginDlg::CSetupSystemMultiOriginDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetupSystemMultiOriginDlg::IDD, pParent)
{

}

CSetupSystemMultiOriginDlg::~CSetupSystemMultiOriginDlg()
{
}

void CSetupSystemMultiOriginDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CSetupSystemMultiOriginDlg, CDialog)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, &CSetupSystemMultiOriginDlg::OnBnClickedButtonClose)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, &CSetupSystemMultiOriginDlg::OnBnClickedButtonSave)
	ON_MESSAGE(WM_NOTIFY_OPTIONDATA_LISTBOX, &CSetupSystemMultiOriginDlg::OnNotifyPointDataListBox)
	ON_WM_CTLCOLOR()
	ON_WM_TIMER()
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CSetupSystemMultiOriginDlg �޽��� ó�����Դϴ�.
//////////////////////////////////////////////////////////////////////////

BOOL CSetupSystemMultiOriginDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CSetupSystemMultiOriginDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	bIsModify_ = FALSE;

	//////////////////////////////////////////////////////////////////////////

	brhBackground_.CreateSolidBrush( RGB(128, 196, 128) );

	//////////////////////////////////////////////////////////////////////////

	fntButton_.CreateFont( 
		18, 0,
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Courier New") ); //_T("MS Sans Serif") );

	((CButton*)GetDlgItem(IDC_BUTTON_SAVE))->SetFont( &fntButton_, FALSE );
	((CButton*)GetDlgItem(IDC_BUTTON_CLOSE))->SetFont( &fntButton_, FALSE );

	//////////////////////////////////////////////////////////////////////////

	memcpy((void*)&hTempMultiOriginData_, (void*)(pa::PPAStatus->GetMultiOriginData()), sizeof(pa::SMultiOriginData) );

	//////////////////////////////////////////////////////////////////////////

	CRect	rcTemp;
	int		nNumRow = 7;
	CString strRowName[] = { _T("NAME"), _T("X_DIST."), _T("Y_DIST."), _T("Z_DIST."), _T("X_OFFSET"), _T("Y_OFFSET"), _T("Z_OFFSET") };
	int		nRowWidth[] = {190, 90, 90, 90, 90, 90, 90, 90, 90 };

	hcutil::GetControlPos( IDC_STATIC_TITLE, this, &rcTemp, TRUE );

	pTitleBarWnd_ = new CTitleBarWnd();
	ASSERT( pTitleBarWnd_ );
	pTitleBarWnd_->InitResource( CString(_T("Multi origin offset")), pa::CLR_SETUP_TEACHING, RGB(32, 32, 32), RGB(32, 32, 32), CSize(8, 16) );
	pTitleBarWnd_->InitResourceEx( nNumRow, strRowName, nRowWidth, 24 );
	pTitleBarWnd_->Create( this, rcTemp, IDC_STATIC_TITLE );
	pTitleBarWnd_->SetWindowPos( &wndTop, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE );

	//////////////////////////////////////////////////////////////////////////

	hcutil::GetControlPos( IDC_STATIC_TABLE, this, &rcTemp, TRUE );

	pDataListBox_ = new COptionDataListBox();
	ASSERT( pDataListBox_ );
	pDataListBox_->SetBackgroundColor( RGB(180, 180, 180) );
	pDataListBox_->SetFontSize( 8, 16 );
	pDataListBox_->SetItemHeight( 30 );
	pDataListBox_->SetItemWidth( nNumRow, nRowWidth );
	pDataListBox_->SetID( IDC_STATIC_TABLE );
	pDataListBox_->Create( WS_CHILD|WS_VISIBLE, rcTemp, this, IDC_STATIC_TABLE );

	int nNumGCode = pa::PPAStatus->GetMultiOriginData()->nNumGCode;

	for( int i = 0; i<nNumGCode; i++ )
	{
		int gcode_no = pa::PPAStatus->GetMultiOriginData()->hMultiOrigin[i].nGcode;
		int num_sub_coord = pa::PPAStatus->GetMultiOriginData()->hMultiOrigin[i].nNumSubCoord;

		CString strItem;
		for( int j = 0; j<num_sub_coord; j++ )
		{
//			TCHAR *pReverseXY = pmac::PState->GetMultiOriginData()->hMultiOrigin[i].bReverseXY[j] == TRUE ? _T("-") : _T("");
			TCHAR *pReverseXY = pa::PPAStatus->GetMultiOriginData()->hMultiOrigin[i].bReverseXY[j] == TRUE ? _T("-") : _T("");

			strItem.Format( _T("G%d.%d %s"), gcode_no, j+1, pReverseXY );
			int nIndex = pDataListBox_->AddString( strItem );
			void *p = (void*)(hTempMultiOriginData_.hMultiOrigin[i].fOffset[j]);
			pDataListBox_->SetItemDataPtr( nIndex, p );
		}
	}

	//////////////////////////////////////////////////////////////////////////

	CString strTemp;
	strTemp.Format( _T("[%.3f ~ %.3f]"), pa::PPAStatus->GetMultiOriginData()->fOffset_Min_,  pa::PPAStatus->GetMultiOriginData()->fOffset_Max_ );
	((CStatic *)GetDlgItem(IDC_STATIC_MSG2))->SetWindowText( strTemp );

	SetTimer( 1, 500, NULL );

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CSetupSystemMultiOriginDlg::OnDestroy()
{

	KillTimer( 1 );

	fntButton_.DeleteObject();
	brhBackground_.DeleteObject();

	if( pTitleBarWnd_ )
	{
		pTitleBarWnd_->DestroyWindow();
		delete pTitleBarWnd_;
		pTitleBarWnd_ = NULL;
	}
	if( pDataListBox_ ) 
	{
		pDataListBox_->DestroyWindow();
		delete pDataListBox_;
		pDataListBox_ = NULL;
	}

	CDialog::OnDestroy();
}

void CSetupSystemMultiOriginDlg::OnBnClickedButtonClose()
{
	CString strMsg;

	if( bIsModify_ == TRUE ) {
		// ������ ���� Ȯ�� 
		strMsg.Format( _T("Data is modified. Do you want to save ?") );
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
		CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();

		if( hRet == TRUE ) {
			strMsg.Format( _T("Wait for save data...") );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

			// ������ ���� 
			pa::SMultiOriginData *p = pa::PPAStatus->GetMultiOriginData();
			memcpy((void*)(p), (void*)&(hTempMultiOriginData_), sizeof(pa::SMultiOriginData) );
			pa::PPAStatus->GetMultiOriginData()->Save( INI_MULTI_ORIGIN_CONFIG_PATH );

			CMsgDlgThread::GetInstance()->Hide();
		} 
	}

	CDialog::OnOK();
}

void CSetupSystemMultiOriginDlg::OnBnClickedButtonSave()
{
	CString strMsg;

	strMsg.Format( _T("Do you want to save changed data ?") );
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, strMsg );
	CMsgDlg::EN_RET hRet = CMsgDlgThread::GetInstance()->Wait();

	if( hRet == CMsgDlg::RET_CANCEL ) 
	{
		pa::SMultiOriginData *p = pa::PPAStatus->GetMultiOriginData();
		memcpy((void*)&hTempMultiOriginData_, (void*)p, sizeof(pa::SMultiOriginData) );
	}
	else 
	{
		strMsg.Format( _T("Wait for save data...") );
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, strMsg );

		pa::SMultiOriginData *p = pa::PPAStatus->GetMultiOriginData();
		memcpy((void*)(p), (void*)&(hTempMultiOriginData_), sizeof(pa::SMultiOriginData) );
		pa::PPAStatus->GetMultiOriginData()->Save( INI_MULTI_ORIGIN_CONFIG_PATH );

		CMsgDlgThread::GetInstance()->Hide();

		strMsg.Format( _T("Save complete !") );
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_INFO, strMsg );
		CMsgDlgThread::GetInstance()->Wait();
	}

	pDataListBox_->Invalidate( FALSE );

	bIsModify_ = FALSE;
}

LRESULT CSetupSystemMultiOriginDlg::OnNotifyPointDataListBox(WPARAM wparam, LPARAM lparam)
{
	CNumericInputDlg dlg;
	int		nCurSel = LOWORD( lparam );			// low word
	int		nCurSelItem = HIWORD( lparam );		// high word

//	if( pa::USER_MODE < pa::USER_MODE_RND )
	if( pa::GET_CURRENT_USERMODE() < pa::USER_MODE_RND )
	{
		return 0;
	}

	//////////////////////////////////////////////////////////////////////////
	// X,Y,Z Dist. ���� ������ �� ������ ����. 2015.09.01
	if( nCurSelItem < 3 ) {
		return 0;
	}
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	// nCurSel�� ����ؼ� �ε����� ����Ѵ� 
	int nGCodeIndex = 0;
	int nGCodeSel = 0;
	int nGCodeSubitem = nCurSelItem;

	int nTemp = 0;
	for( int i = 0; i<hTempMultiOriginData_.nNumGCode; i++ )
	{
		int nStop = hTempMultiOriginData_.hMultiOrigin[i].nNumSubCoord;
		
		if( nCurSel < (nTemp + nStop) ) 
		{
			nGCodeIndex = i;
			nGCodeSel	= nCurSel - nTemp;
			break;
		}

		nTemp += nStop;
	}

	//////////////////////////////////////////////////////////////////////////

	dlg.SetIsFloatType( TRUE );
	dlg.SetPrevNumber( hTempMultiOriginData_.hMultiOrigin[nGCodeIndex].fOffset[nGCodeSel][nGCodeSubitem] );
	dlg.SetProperty( 0 );

	if( dlg.DoModal() == IDOK ) {
		double fVal = hcutil::ToDouble( (wchar_t*)(LPCTSTR)dlg.GetNumber(), FALSE );
		double fMin = pa::PPAStatus->GetMultiOriginData()->fOffset_Min_;
		double fMax = pa::PPAStatus->GetMultiOriginData()->fOffset_Max_;
		if( fVal >= fMin && fVal <= fMax ) {
			hTempMultiOriginData_.hMultiOrigin[nGCodeIndex].fOffset[nGCodeSel][nGCodeSubitem] = fVal;		
			bIsModify_ = TRUE;
		} else {
			CString strMsg;
			strMsg.Format( _T("Offset data is available [%.3f ~ %.3f]"), fMin, fMax );
			CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_INFO, strMsg );
			CMsgDlgThread::GetInstance()->Wait();
		}
	}
	if( pDataListBox_ ) {
		pDataListBox_->Invalidate( FALSE );
	}

	return 0;
}

//////////////////////////////////////////////////////////////////////////

HBRUSH CSetupSystemMultiOriginDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	if( nCtlColor == 4 ) {
		hbr = (HBRUSH)brhBackground_;
	}
	else {
		UINT nCtrlID = pWnd->GetDlgCtrlID();
		switch( nCtrlID )
		{
		case IDC_STATIC_MSG1:
		case IDC_STATIC_MSG2:
			pDC->SetBkMode( TRANSPARENT );
			hbr = (HBRUSH)brhBackground_;
			break;
		}
	}

	return hbr;
}

//////////////////////////////////////////////////////////////////////////

void CSetupSystemMultiOriginDlg::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 1 )
	{
		update_button_state();
	}

	CDialog::OnTimer(nIDEvent);
}

void CSetupSystemMultiOriginDlg::update_button_state()
{
	static int PREV_SAVE_BTN_STATE = -1;
	int curr_save_btn_state = ( bIsModify_ == TRUE ) ? 1 : 0;

	if( PREV_SAVE_BTN_STATE != curr_save_btn_state )
	{
		PREV_SAVE_BTN_STATE = curr_save_btn_state;

		((CButton*)GetDlgItem(IDC_BUTTON_SAVE))->EnableWindow( curr_save_btn_state );
	}
}

