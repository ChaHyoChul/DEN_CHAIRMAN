// SetupAutoLoaderManualOperDlg.cpp : 구현 파일입니다.
//

#include "stdafx.h"
#include "EPncUI.h"
#include "SetupAutoLoaderManualOperDlg.h"
#include "MsgDlgThread.h"

// CSetupAutoLoaderManualOperDlg 대화 상자입니다.

IMPLEMENT_DYNCREATE(CSetupAutoLoaderManualOperDlg, CDialogListPage)

CSetupAutoLoaderManualOperDlg::CSetupAutoLoaderManualOperDlg(CWnd* pParent /*=NULL*/)
	: CDialogListPage(CSetupAutoLoaderManualOperDlg::IDD, pParent)
{
	nPREV_BARCODE_ = -1;
}

CSetupAutoLoaderManualOperDlg::~CSetupAutoLoaderManualOperDlg()
{
}

void CSetupAutoLoaderManualOperDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogListPage::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_SEL_BLOCK_NO, cboSelBlockNo_);
	DDX_Control(pDX, IDC_BUTTON_ALR_DOOR_OPEN, btnALR_DoorOpen_);
	DDX_Control(pDX, IDC_BUTTON_ALR_DOOR_CLOSE, btnALR_DoorClose_);
	DDX_Control(pDX, IDC_BUTTON_ALR_GRIPPER_GRIP, btnALR_GripperGrip_);
	DDX_Control(pDX, IDC_BUTTON_ALR_GRIPPER_UNGRIP, btnALR_Gripper_Ungrip_);
	DDX_Control(pDX, IDC_BUTTON_ALR_HAND_FORWARD, btnALR_HandForward_);
	DDX_Control(pDX, IDC_BUTTON_ALR_HAND_BACKWARD, btnALR_HandBackward_);
	DDX_Control(pDX, IDC_BUTTON_ALR_ROTATE_CASSETTE, btnALR_RotateCassette_);
	DDX_Control(pDX, IDC_BUTTON_ALR_ROTATE_XYSTATE, btnALR_RotateXYStage_);
	DDX_Control(pDX, IDC_BUTTON_ALR_GET_BLOCK_FROM_CASSETTE, btnALR_GetBlockFromCassette_);
	DDX_Control(pDX, IDC_BUTTON_ALR_LOADING_BLOCK_XYTAGE, btnALR_LoadingBlockToXYStage_);
	DDX_Control(pDX, IDC_BUTTON_ALR_PUT_BLOCK_TO_CASSETTE, btnALR_PutBlockToCassette_);
	DDX_Control(pDX, IDC_BUTTON_ALR_UNLOADING_BLOCK_TO_CASSETTE, btnALR_UnloadingBlockToCassette_);
	DDX_Control(pDX, IDC_BUTTON_XYS_GRIPPER_GRIP, btnXYS_GripperGrip_);
	DDX_Control(pDX, IDC_BUTTON_XYS_GRIPPER_UNGRIP_, btnXYS_GripperUngrip_);
	DDX_Control(pDX, IDC_BUTTON_XYS_GRIPPER_UP, btnXYS_GripperUp_);
	DDX_Control(pDX, IDC_BUTTON_XYS_GRIPPER_DOWN, btnXYS_GripperDown_);
	DDX_Control(pDX, IDC_BUTTON_XYS_AUTOLOADER_POS, btnXYS_AutoLoaderPos_);
	DDX_Control(pDX, IDC_BUTTON_XYS_MACHINING_POS, btnXYS_MachiningPos_);
	DDX_Control(pDX, IDC_BUTTON_ALR_RETURN_ARM_TO_CASSETTE, btnALR_ReturnArmToCassette_);
	DDX_Control(pDX, IDC_BUTTON_ALR_EXTEND_ARM_TO_STAGE, btnALR_ExtendArmToXYStage_);
	DDX_Control(pDX, IDC_BUTTON_WORK_SPACE_BLOCK_CLAMP, btnWS_BlockCamp_);
	DDX_Control(pDX, IDC_BUTTON_WORK_SPACE_BLOCK_UNCLAMP, btnWS_BlockUnclamp_);
	DDX_Control(pDX, IDC_EDIT_AL_BARCODE, editBarcode_);
}

void CSetupAutoLoaderManualOperDlg::StartPageWork()
{
	SetTimer( 1, 100, NULL );
	SetTimer( 2, 100, NULL );

	// 초기화 
	nPREV_BARCODE_ = -1;
	editBarcode_.SetWindowText( _T("") );
}

void CSetupAutoLoaderManualOperDlg::StopPageWork()
{
	KillTimer( 1 );
	KillTimer( 2 );
}

void CSetupAutoLoaderManualOperDlg::UpdatePage()
{

}

//////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CSetupAutoLoaderManualOperDlg, CDialogListPage)
	ON_WM_DESTROY()
	ON_WM_CTLCOLOR()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_ALR_DOOR_OPEN, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrDoorOpen)
	ON_BN_CLICKED(IDC_BUTTON_ALR_DOOR_CLOSE, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrDoorClose)
	ON_BN_CLICKED(IDC_BUTTON_ALR_HAND_FORWARD, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrHandForward)
	ON_BN_CLICKED(IDC_BUTTON_ALR_GRIPPER_GRIP, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrGripperGrip)
	ON_BN_CLICKED(IDC_BUTTON_ALR_GRIPPER_UNGRIP, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrGripperUngrip)
	ON_BN_CLICKED(IDC_BUTTON_ALR_HAND_BACKWARD, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrHandBackward)
	ON_BN_CLICKED(IDC_BUTTON_ALR_ROTATE_CASSETTE, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrRotateCassette)
	ON_BN_CLICKED(IDC_BUTTON_ALR_ROTATE_XYSTATE, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrRotateXystate)
	ON_BN_CLICKED(IDC_BUTTON_ALR_GET_BLOCK_FROM_CASSETTE, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrGetBlockFromCassette)
	ON_BN_CLICKED(IDC_BUTTON_ALR_PUT_BLOCK_TO_CASSETTE, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrPutBlockToCassette)
	ON_BN_CLICKED(IDC_BUTTON_ALR_LOADING_BLOCK_XYTAGE, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrLoadingBlockXytage)
	ON_BN_CLICKED(IDC_BUTTON_ALR_UNLOADING_BLOCK_TO_CASSETTE, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrUnloadingBlockToCassette)
	ON_BN_CLICKED(IDC_BUTTON_XYS_GRIPPER_GRIP, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysGripperGrip)
	ON_BN_CLICKED(IDC_BUTTON_XYS_GRIPPER_UNGRIP_, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysGripperUngrip)
	ON_BN_CLICKED(IDC_BUTTON_XYS_GRIPPER_UP, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysGripperUp)
	ON_BN_CLICKED(IDC_BUTTON_XYS_GRIPPER_DOWN, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysGripperDown)
	ON_BN_CLICKED(IDC_BUTTON_XYS_AUTOLOADER_POS, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysAutoloaderPos)
	ON_BN_CLICKED(IDC_BUTTON_XYS_MACHINING_POS, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysMachiningPos)
	ON_BN_CLICKED(IDC_BUTTON_ALR_RETURN_ARM_TO_CASSETTE, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrReturnArmToCassette)
	ON_BN_CLICKED(IDC_BUTTON_ALR_EXTEND_ARM_TO_STAGE, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrExtendArmToStage)
	ON_BN_CLICKED(IDC_BUTTON_WORK_SPACE_BLOCK_CLAMP, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonBlockClamp)
	ON_BN_CLICKED(IDC_BUTTON_WORK_SPACE_BLOCK_UNCLAMP, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonBlockUnclamp)
//	ON_BN_CLICKED(IDC_BUTTON1, &CSetupAutoLoaderManualOperDlg::OnBnClickedButton1)
//	ON_BN_CLICKED(IDC_BUTTON5, &CSetupAutoLoaderManualOperDlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON_STEP_01, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep01)
	ON_BN_CLICKED(IDC_BUTTON_STEP_02, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep02)
	ON_BN_CLICKED(IDC_BUTTON_STEP_03, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep03)
	ON_BN_CLICKED(IDC_BUTTON_STEP_04, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep04)
	ON_BN_CLICKED(IDC_BUTTON_STEP_05, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep05)
	ON_BN_CLICKED(IDC_BUTTON_STEP_06, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep06)
	ON_BN_CLICKED(IDC_BUTTON_STEP_07, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep07)
	ON_BN_CLICKED(IDC_BUTTON_STEP_08, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep08)
	ON_BN_CLICKED(IDC_BUTTON_STEP_09, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep09)
	ON_BN_CLICKED(IDC_BUTTON_STEP_10, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep10)
	ON_BN_CLICKED(IDC_BUTTON_XYS_MOVE_EXCHANGING_POS, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysMoveExchangingPos)
	ON_BN_CLICKED(IDC_BUTTON_XYS_MOVE_MACHINING_POS, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysMoveMachiningPos)
	ON_BN_CLICKED(IDC_BUTTON_MOVE_BLOCK_SENSING_POS, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonMoveBlockSensingPos)
	ON_BN_CLICKED(IDC_BUTTON_MOVE_BARCODE_READ_POS, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonMoveBarcodeReadPos)
	ON_BN_CLICKED(IDC_BUTTON_AL_BARCODE, &CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlBarcode)
END_MESSAGE_MAP()

//////////////////////////////////////////////////////////////////////////
// CSetupAutoLoaderManualOperDlg 메시지 처리기입니다.
//////////////////////////////////////////////////////////////////////////

BOOL CSetupAutoLoaderManualOperDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE))
		return TRUE;

	return CDialogListPage::PreTranslateMessage(pMsg);
}

BOOL CSetupAutoLoaderManualOperDlg::OnInitDialog()
{
	CDialogListPage::OnInitDialog();

	nRecentRun_ManualButton_ = -1;

	//////////////////////////////////////////////////////////////////////////
	//
	CRect	rcTemp;
	GetClientRect( &CUIrectSALM );
	MoveWindow(0,0,717,437);
	GetClientRect( &rcTemp );

	hcutil::GetControlPos2( IDC_STATIC_TITLE_AL_ROBOT, this, &rcTemp, &CUIrectSALM, TRUE );
	pTitleBar_ALRManual_ = new CTitleBarWnd();
	ASSERT( pTitleBar_ALRManual_ );
	pTitleBar_ALRManual_->InitResource( CString( _T("AutoLoader Manual Operation")), pa::CLR_SETUP_AUTOLOADER, RGB(32, 32, 32), RGB(32, 32, 32), CSize(8, 16) );
	pTitleBar_ALRManual_->Create( this, rcTemp, IDC_STATIC_TITLE_AL_ROBOT );

	hcutil::GetControlPos2( IDC_STATIC_TITLE_XY_ROBOT, this, &rcTemp, &CUIrectSALM, TRUE );
	pTitleBar_XYRManual_ = new CTitleBarWnd();
	ASSERT( pTitleBar_XYRManual_ );
	pTitleBar_XYRManual_->InitResource( CString( _T("X-Y Stage Manual Operation")), pa::CLR_SETUP_AUTOLOADER, RGB(32, 32, 32), RGB(32, 32, 32), CSize(8, 16) );
	pTitleBar_XYRManual_->Create( this, rcTemp, IDC_STATIC_TITLE_XY_ROBOT );

	hcutil::GetControlPos2( IDC_STATIC_TITLE_WORK_SPACE, this, &rcTemp, &CUIrectSALM, TRUE );
	pTitleBar_WSManual_ = new CTitleBarWnd();
	ASSERT( pTitleBar_WSManual_ );
	pTitleBar_WSManual_->InitResource( CString( _T("Work Space Manual Operation")), pa::CLR_SETUP_AUTOLOADER, RGB(32, 32, 32), RGB(32, 32, 32), CSize(8, 16) );
	pTitleBar_WSManual_->Create( this, rcTemp, IDC_STATIC_TITLE_WORK_SPACE );

	//////////////////////////////////////////////////////////////////////////
	//
	fntOperButton_.CreateFont(
		14, 0, 
		0, 0, FW_BOLD,
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	btnALR_DoorOpen_.SetFont( &fntOperButton_, TRUE );
	btnALR_DoorClose_.SetFont( &fntOperButton_, TRUE );
	btnALR_GripperGrip_.SetFont( &fntOperButton_, TRUE );
	btnALR_Gripper_Ungrip_.SetFont( &fntOperButton_, TRUE );

	btnALR_HandForward_.SetFont( &fntOperButton_, TRUE );
	btnALR_HandBackward_.SetFont( &fntOperButton_, TRUE );
	btnALR_RotateCassette_.SetFont( &fntOperButton_, TRUE );
	btnALR_RotateXYStage_.SetFont( &fntOperButton_, TRUE );

	btnALR_GetBlockFromCassette_.SetFont( &fntOperButton_, TRUE );
	btnALR_LoadingBlockToXYStage_.SetFont( &fntOperButton_, TRUE );
	btnALR_PutBlockToCassette_.SetFont( &fntOperButton_, TRUE );
	btnALR_UnloadingBlockToCassette_.SetFont( &fntOperButton_, TRUE );
	btnALR_ReturnArmToCassette_.SetFont( &fntOperButton_, TRUE );
	btnALR_ExtendArmToXYStage_.SetFont( &fntOperButton_, TRUE );

	btnXYS_GripperGrip_.SetFont( &fntOperButton_, TRUE );
	btnXYS_GripperUngrip_.SetFont( &fntOperButton_, TRUE );
	btnXYS_GripperUp_.SetFont( &fntOperButton_, TRUE );
	btnXYS_GripperDown_.SetFont( &fntOperButton_, TRUE );

	btnXYS_AutoLoaderPos_.SetFont( &fntOperButton_, TRUE );
	btnXYS_MachiningPos_.SetFont( &fntOperButton_, TRUE );

	//////////////////////////////////////////////////////////////////////////
	//
	fntCombo_.CreateFont(
		22, 0,
		0, 0, FW_BOLD, //FW_NORMAL, 
		FALSE, FALSE, FALSE, 
		ANSI_CHARSET, 
		OUT_DEFAULT_PRECIS, 
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, 
		DEFAULT_PITCH, _T("Arial") ); //_T("Courier New") ); //_T("MS Sans Serif") );

	cboSelBlockNo_.SetFont( &fntCombo_, TRUE );
	cboSelBlockNo_.SetCurSel( 0 );

	//////////////////////////////////////////////////////////////////////////
	// 
	editBarcode_.SetFont( &fntCombo_, TRUE );

	//////////////////////////////////////////////////////////////////////////
	//
	brhBkgnd_.CreateSolidBrush( pa::CLR_SETUP_AUTOLOADER );

	brhRecentRun_.CreateSolidBrush( RGB(0, 128, 0) );

	//////////////////////////////////////////////////////////////////////////
	//
	nSS_ID[SS_ALR_DOOR_OPEN]		= IDC_STATIC_ALR_DOOR_OPEN;
	nSS_ID[SS_ALR_DOOR_CLOSE]		= IDC_STATIC_ALR_DOOR_CLOSE;
	nSS_ID[SS_ALR_GRIPPER_GRIP]		= IDC_STATIC_ALR_GRIPPER_GRIP;
	nSS_ID[SS_ALR_GRIPPER_UNGRIP]	= IDC_STATIC_ALR_GRIPPER_UNGRIP;
	nSS_ID[SS_ALR_HAND_FORWARD]		= IDC_STATIC_ALR_HAND_FORWARD;
	nSS_ID[SS_ALR_HAND_BACKWARD]	= IDC_STATIC_ALR_HAND_BACKWARD;
	nSS_ID[SS_ALR_ROTATE_CASSETTE]	= IDC_STATIC_ALR_ROTATE_CASSETTE;
	nSS_ID[SS_ALR_ROTATE_XYSTAGE]	= IDC_STATIC_ALR_ROTATE_XYSTAGE;
	nSS_ID[SS_XYS_GRIPPER_GRIP]		= IDC_STATIC_XYS_GRIPPER_GRIP;
	nSS_ID[SS_XYS_GRIPPER_UNGRIP]	= IDC_STATIC_XYS_GRIPPER_UNGRIP;
	nSS_ID[SS_XYS_GRIPPER_UP]		= IDC_STATIC_XYS_GRIPPER_UP;
	nSS_ID[SS_XYS_GRIPPER_DOWN]		= IDC_STATIC_XYS_GRIPPER_DOWN;
	nSS_ID[SS_ALR_GRIP_EXIST_BLOCK]	= IDC_STATIC_ALR_EXIST_BLOCK; //IDC_STATIC_ALR_GRIP_BLOCK;

	BOOL bReverseSignal[] = {
		FALSE, FALSE, TRUE, FALSE, FALSE, 
		FALSE, FALSE, FALSE, FALSE, FALSE,
		FALSE, FALSE, FALSE };
	//////////////////////////////////////////////////////////////////////////

	for( int i = 0; i<SS_NUM; i++ ) {
		hcutil::GetControlPos2(  nSS_ID[i], this, &rcTemp, &CUIrectSALM, TRUE );
		pSensorStateWnd_[i] = new CSensorStateWnd();
		ASSERT( pSensorStateWnd_[i] );
		pSensorStateWnd_[i]->Create( this, rcTemp, bReverseSignal[i] );
		pSensorStateWnd_[i]->SetWindowPos( &wndTop, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// 예외: OCX 속성 페이지는 FALSE를 반환해야 합니다.
}

void CSetupAutoLoaderManualOperDlg::OnDestroy()
{
	if( pTitleBar_ALRManual_ ) {
		pTitleBar_ALRManual_->DestroyWindow();
		delete pTitleBar_ALRManual_;
		pTitleBar_ALRManual_ = NULL;
	}

	if( pTitleBar_XYRManual_ ) {
		pTitleBar_XYRManual_->DestroyWindow();
		delete pTitleBar_XYRManual_;
		pTitleBar_XYRManual_ = NULL;
	}

	if( pTitleBar_WSManual_ ) {
		pTitleBar_WSManual_->DestroyWindow();
		delete pTitleBar_WSManual_;
		pTitleBar_WSManual_ = NULL;
	}

	for( int i = 0; i<SS_NUM; i++ ) {
		if( pSensorStateWnd_[i] ) {
			pSensorStateWnd_[i]->DestroyWindow();
			delete pSensorStateWnd_[i];
			pSensorStateWnd_[i] = NULL;
		}
	}

	fntOperButton_.DeleteObject();

	fntCombo_.DeleteObject();

	brhBkgnd_.DeleteObject();

	brhRecentRun_.DeleteObject();

	CDialogListPage::OnDestroy();
}

HBRUSH CSetupAutoLoaderManualOperDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogListPage::OnCtlColor(pDC, pWnd, nCtlColor);

	if( nCtlColor == 4 ) {
		hbr = (HBRUSH)brhBkgnd_;
	}
	else {
		if( pWnd->GetDlgCtrlID() == IDC_STATIC_SLOT_INDEX  ) {
			pDC->SetBkMode( TRANSPARENT );
			return (HBRUSH)brhBkgnd_;
		}
		int nID = pWnd->GetDlgCtrlID();
		int nTemp = -1;
		switch( nID ) 
		{
		case IDC_BUTTON_STEP_01: nTemp = 0; break; 
		case IDC_BUTTON_STEP_02: nTemp = 1; break; 
		case IDC_BUTTON_STEP_03: nTemp = 2; break; 
		case IDC_BUTTON_STEP_04: nTemp = 3; break; 
		case IDC_BUTTON_STEP_05: nTemp = 4; break; 
		case IDC_BUTTON_STEP_06: nTemp = 5; break; 
		case IDC_BUTTON_STEP_07: nTemp = 6; break; 
		case IDC_BUTTON_STEP_08: nTemp = 7; break; 
		case IDC_BUTTON_STEP_09: nTemp = 8; break; 
		case IDC_BUTTON_STEP_10: nTemp = 9; break; 
		}
		if( nRecentRun_ManualButton_ == nTemp ) {
			hbr = (HBRUSH)brhRecentRun_;
		}
	}

	return hbr;
}

//////////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////////

void CSetupAutoLoaderManualOperDlg::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 1 )
	{
		KillTimer( 1 );

		update_SensorState();

		update_ButtonState();

		update_BarcodeState();

		if( IsWindowVisible() ) 
		{
			SetTimer( 1, 200, NULL );
		}
	}
	else if( nIDEvent == 2 )
	{
		KillTimer( 2 );

		if( IsWindowVisible() )
		{
			SetTimer( 2, 1000, NULL );
		}
	}

	CDialogListPage::OnTimer(nIDEvent);
}

void CSetupAutoLoaderManualOperDlg::update_ButtonState()
{
	static int PREV_BTN_STATE = -1;
	int		curr_btn_state = 1;
	BOOL	bEnable = FALSE;

	BOOL c1 = pa::PPAStatus->GetRunMode() != pa::RUNMODE_STOP;
	BOOL c2 = pa::PPAStatus->GetPAStatus()->nRunStatus != pa::PA_RUN_STATUS_IDLE;
	BOOL c3 = pa::PPAStatus->GetPAStatus()->nServoHomeState != 1;

	if( c1 || c2 || c3 ) 
	{
		curr_btn_state = 0;
	}

	if( PREV_BTN_STATE != curr_btn_state ) 
	{
		PREV_BTN_STATE = curr_btn_state;
		
		bEnable = ( curr_btn_state == 0 ) ? FALSE : TRUE;
		
		btnALR_DoorOpen_.EnableWindow( bEnable );
		btnALR_DoorClose_.EnableWindow( bEnable );
		btnALR_GripperGrip_.EnableWindow( bEnable );
		btnALR_Gripper_Ungrip_.EnableWindow( bEnable );

		btnALR_HandForward_.EnableWindow( bEnable );
		btnALR_HandBackward_.EnableWindow( bEnable );
		btnALR_RotateCassette_.EnableWindow( bEnable );
		btnALR_RotateXYStage_.EnableWindow( bEnable );

		btnALR_GetBlockFromCassette_.EnableWindow( bEnable );
		btnALR_LoadingBlockToXYStage_.EnableWindow( bEnable );
		btnALR_PutBlockToCassette_.EnableWindow( bEnable );
		btnALR_UnloadingBlockToCassette_.EnableWindow( bEnable );

		btnXYS_GripperGrip_.EnableWindow( bEnable );
		btnXYS_GripperUngrip_.EnableWindow( bEnable );
		btnXYS_GripperUp_.EnableWindow( bEnable );
		btnXYS_GripperDown_.EnableWindow( bEnable );

		btnXYS_AutoLoaderPos_.EnableWindow( bEnable );
		btnXYS_MachiningPos_.EnableWindow( bEnable );

		btnALR_ReturnArmToCassette_.EnableWindow( bEnable );
		btnALR_ExtendArmToXYStage_.EnableWindow( bEnable );

		((CButton *)GetDlgItem(IDC_BUTTON_STEP_01))->EnableWindow( bEnable );
		((CButton *)GetDlgItem(IDC_BUTTON_STEP_02))->EnableWindow( bEnable );
		((CButton *)GetDlgItem(IDC_BUTTON_STEP_03))->EnableWindow( bEnable );
		((CButton *)GetDlgItem(IDC_BUTTON_STEP_04))->EnableWindow( bEnable );
		((CButton *)GetDlgItem(IDC_BUTTON_STEP_05))->EnableWindow( bEnable );
		((CButton *)GetDlgItem(IDC_BUTTON_STEP_06))->EnableWindow( bEnable );
		((CButton *)GetDlgItem(IDC_BUTTON_STEP_07))->EnableWindow( bEnable );
		((CButton *)GetDlgItem(IDC_BUTTON_STEP_08))->EnableWindow( bEnable );
		((CButton *)GetDlgItem(IDC_BUTTON_STEP_09))->EnableWindow( bEnable );
		((CButton *)GetDlgItem(IDC_BUTTON_STEP_10))->EnableWindow( bEnable );

		((CButton *)GetDlgItem(IDC_BUTTON_XYS_MOVE_EXCHANGING_POS))->EnableWindow( bEnable );
		((CButton *)GetDlgItem(IDC_BUTTON_XYS_MOVE_MACHINING_POS))->EnableWindow( bEnable );

		static BOOL B_INIT = FALSE;
		if( B_INIT == FALSE ) 
		{
			B_INIT = TRUE;
			CRect recbutton;
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_STEP_01), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_STEP_02), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_STEP_03), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_STEP_04), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_STEP_05), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_STEP_06), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_STEP_07), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_STEP_08), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_STEP_09), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_STEP_10), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_MOVE_BLOCK_SENSING_POS), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_MOVE_BARCODE_READ_POS), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_AL_BARCODE), this, &recbutton, &CUIrectSALM);

			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_XYS_MOVE_EXCHANGING_POS), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_XYS_MOVE_MACHINING_POS), this, &recbutton, &CUIrectSALM);

			hcutil::reposcombo( (CComboBox*)GetDlgItem(IDC_COMBO_SEL_BLOCK_NO), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ALR_DOOR_OPEN), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ALR_DOOR_CLOSE), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ALR_GRIPPER_GRIP), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ALR_GRIPPER_UNGRIP), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ALR_HAND_FORWARD), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ALR_HAND_BACKWARD), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ALR_ROTATE_CASSETTE), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ALR_ROTATE_XYSTATE), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ALR_GET_BLOCK_FROM_CASSETTE), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ALR_LOADING_BLOCK_XYTAGE), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ALR_PUT_BLOCK_TO_CASSETTE), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ALR_UNLOADING_BLOCK_TO_CASSETTE), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_XYS_GRIPPER_GRIP), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_XYS_GRIPPER_UNGRIP_), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_XYS_GRIPPER_UP), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_XYS_GRIPPER_DOWN), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_XYS_AUTOLOADER_POS), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_XYS_MACHINING_POS), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ALR_RETURN_ARM_TO_CASSETTE), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_ALR_EXTEND_ARM_TO_STAGE), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_WORK_SPACE_BLOCK_CLAMP), this, &recbutton, &CUIrectSALM);
			hcutil::reposbutton( (CButton*)GetDlgItem(IDC_BUTTON_WORK_SPACE_BLOCK_UNCLAMP), this, &recbutton, &CUIrectSALM);


			CRect recedit;
			hcutil::reposedit( (CEdit*)GetDlgItem(IDC_EDIT_AL_BARCODE), this, &recedit, &CUIrectSALM);
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// 현재 위치에 따라 hand forward 버튼의상태를 변경한다 
//	if( bEnable ) {
	if( curr_btn_state == 1 ) {
		double	first_pos = pa::PAutoLoader->GetTeachingPoint( pa::AUTOLOADER_TP_FIRST_BLOCK_POS ) - pa::PAutoLoader->GetTeachingPoint( pa::AUTOLOADER_TP_GETPUT_DN_STROKE );
		double	block_pitch = pa::PAutoLoader->GetTeachingPoint( pa::AUTOLOADER_TP_BLOCK_PITCH );
		double	jump_pitch = pa::PAutoLoader->GetTeachingPoint( pa::AUTOLOADER_TP_SLOT_JUMP_DIST );
		int		jump_index = (int)(pa::PAutoLoader->GetTeachingPoint( pa::AUTOLOADER_TP_SLOT_JUMP_NUMBER ));
		double	z_pos = pa::PPAStatus->GetPAStatus()->fAutoLoaderPosition;

		bEnable = FALSE;

		for( int i = 0; i<pa::PAutoLoader->GetNumBlock(); i++ ) {
			double pos = first_pos + (block_pitch * i) + (( i >= jump_index ) ? jump_pitch : 0.0);
			if( z_pos > pos-2.5 && z_pos < pos+2.5 ) {
				bEnable = TRUE;
				break;
			}
		}

		btnALR_HandForward_.EnableWindow( bEnable );
	}
	//////////////////////////////////////////////////////////////////////////
}

void CSetupAutoLoaderManualOperDlg::update_SensorState()
{
	static int PREV_STATE[SS_NUM] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
	static int* REF_DATA[SS_NUM] = 
	{
		// 		&(pmac::PState->GetPmacState()->nIn22_BlockLoader_PNC_Door_Open),
		// 		&(pmac::PState->GetPmacState()->nIn23_BlockLoader_PNC_Door_Close),
		// 		&(pmac::PState->GetPmacState()->nIn28_BlockLoader_Sensing_Block),	//nIn26_BlockLoader_Gripper_Grip),		
		// 		&(pmac::PState->GetPmacState()->nIn27_BlockLoader_Gripper_Ungrip),	//nIn27_BlockLoader_Gripper_Ungrip),
		// 		&(pmac::PState->GetPmacState()->nIn24_BlockLoader_EXT_ARM),
		// 		&(pmac::PState->GetPmacState()->nIn25_BlockLoader_RET_ARM),
		// 		&(pmac::PState->GetPmacState()->nIn29_BlockLoader_ROT_ARM_ToCassette),
		// 		&(pmac::PState->GetPmacState()->nIn30_BlockLoader_ROT_ARM_ToPNC),
		// 		&(pmac::PState->GetPmacState()->nIn18_BlockLoader_PNC_Gripper_Grip),
		// 		&(pmac::PState->GetPmacState()->nIn19_BlockLoader_PNC_Gripper_Ungrip),
		// 		&(pmac::PState->GetPmacState()->nIn20_BlockLoader_PNC_Gripper_Up),
		// 		&(pmac::PState->GetPmacState()->nIn21_BlockLoader_PNC_Gripper_Down),
		// 		&(pmac::PState->GetPmacState()->nIn26_BlockLoader_Gripper_Grip),	//nIn28_BlockLoader_Sensing_Block)

// 		&(pa::PPAStatus->GetPAStatus()->bInput[pa::IN20022_AutoLoader_PNC_Door_Open]), 
// 		&(pa::PPAStatus->GetPAStatus()->bInput[pa::IN20023_AutoLoader_PNC_Door_Close]), 
// 		&(pa::PPAStatus->GetPAStatus()->bInput[pa::IN20028_AutoLoader_Sensing_Block]), 
// 		&(pa::PPAStatus->GetPAStatus()->bInput[pa::IN20027_AutoLoader_Gripper_Ungrip]), 
// 		&(pa::PPAStatus->GetPAStatus()->bInput[pa::IN20025_AutoLoader_EXT_ARM]),//	IN20024_AutoLoader_EXT_ARM]), 
// 		&(pa::PPAStatus->GetPAStatus()->bInput[pa::IN20024_AutoLoader_RET_ARM]),// 
// 		&(pa::PPAStatus->GetPAStatus()->bInput[pa::IN20029_AutoLoader_ROT_ARM_ToCassette]), 
// 		&(pa::PPAStatus->GetPAStatus()->bInput[pa::IN20030_AutoLoader_ROT_ARM_ToPNC]), 
// 		&(pa::PPAStatus->GetPAStatus()->bInput[pa::IN20018_AutoLoader_PNC_Gripper_Grip]), 
// 		&(pa::PPAStatus->GetPAStatus()->bInput[pa::IN20019_AutoLoader_PNC_Gripper_Ungrip]), 
// 		&(pa::PPAStatus->GetPAStatus()->bInput[pa::IN20020_AutoLoader_PNC_Gripper_Up]), 
// 		&(pa::PPAStatus->GetPAStatus()->bInput[pa::IN20021_AutoLoader_PNC_Gripper_Down]), 
// 		&(pa::PPAStatus->GetPAStatus()->bInput[pa::IN20026_]) 
	};
	int curr_state[SS_NUM];

	for( int i = 0; i<SS_NUM; i++ ) 
	{
		if( PREV_STATE[i] != *REF_DATA[i] ) 
		{
			PREV_STATE[i] = *REF_DATA[i];
			pSensorStateWnd_[i]->SetState( (CSensorStateWnd::EN_STATE)PREV_STATE[i] );
		}
	}
}

// 이전 바코드와 다르면 Edit 컨트롤 업데이트 
void CSetupAutoLoaderManualOperDlg::update_BarcodeState()
{
	int nCurrBarcode = pa::PPAStatus->GetThreadState()->nBarcode_Data;

	if( nPREV_BARCODE_ != nCurrBarcode )
	{
		nPREV_BARCODE_ = nCurrBarcode;

		CString strBarcode;
		strBarcode.Format( _T("%d"), nPREV_BARCODE_ );
		editBarcode_.SetWindowText( strBarcode );
	}
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrDoorOpen()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("door open button click") );

	PPNC_IPC_CLIENT->ALR_OpenDoor();
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrDoorClose()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("door close button click") );

	PPNC_IPC_CLIENT->ALR_CloseDoor();
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrGripperGrip()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("gripper grip button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->ALR_Gripper_Grip();
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrGripperUngrip()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("gripper ungrip button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->ALR_Gripper_Ungrip();
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrHandForward()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("hand forward button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->ALR_Hand_Forward();
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrHandBackward()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("hand backward button click") );
	//////////////////////////////////////////////////////////////////////////
	PPNC_IPC_CLIENT->ALR_Hand_Backward();
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrRotateCassette()
{
	CString strMsg;
	double	fTeachingPos = pa::PAutoLoader->GetTeachingPoint( pa::AUTOLOADER_TP_ROTATION_POS );
	double	fCurrentPos	 = pa::PPAStatus->GetPAStatus()->fAutoLoaderPosition;
	BOOL	bError = FALSE;

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("rotate to cassette button click") );
	//////////////////////////////////////////////////////////////////////////

	if( fabs( fTeachingPos - fCurrentPos ) > 2.0 ) 
	{
		// 		strMsg.Format( _T("Buffer 위치에서만 회전할 수 있습니다.") );
		strMsg.Format( _T("you can rotate only in the buffer location") );
		WriteLog_EXT( strMsg );
		bError = TRUE;
	}

	if( !bError ) 
	{
		PPNC_IPC_CLIENT->ALR_Rotate_Cassette();
	}
	else
	{
		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
		CMsgDlgThread::GetInstance()->Wait();
	}
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrRotateXystate()
{
	CString strMsg;
	double	xpos = pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X];
	double	ypos = pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y];
	double	fTeachingPos = pa::PAutoLoader->GetTeachingPoint( pa::AUTOLOADER_TP_ROTATION_POS );
	double	fCurrentPos  = pa::PPAStatus->GetPAStatus()->fAutoLoaderPosition;
	BOOL	bError = FALSE;

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("rotate to xy stage button click") );
	//////////////////////////////////////////////////////////////////////////
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrGetBlockFromCassette()
{

}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrPutBlockToCassette()
{

}

// AutoLoader 핸드를 XY Stage 방향으로 넣는다 
void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrLoadingBlockXytage()
{

}

// AutoLoader 핸드를 접고 Cassette 방향으로 뺀다 
void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrReturnArmToCassette()
{

}

// 블록을 회수하기 위해 AutoLoader의 핸드를 XY Stage로 넣는다 
void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrExtendArmToStage()
{

}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlrUnloadingBlockToCassette()
{

}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysGripperGrip()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("xy stage gripper grip button click") );
	//////////////////////////////////////////////////////////////////////////

	PPNC_IPC_CLIENT->XYS_Gripper_Grip();
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysGripperUngrip()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("xy stage gripper ungrip button click") );
	//////////////////////////////////////////////////////////////////////////

	PPNC_IPC_CLIENT->XYS_Geipper_Ungrip();
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysGripperUp()
{
	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("xy stage gripper up button click") );
	//////////////////////////////////////////////////////////////////////////

	PPNC_IPC_CLIENT->XYS_Gripper_Up();
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysGripperDown()
{
	double	fCPosX = pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X];
	double	fCPosY = pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y];
	CString strMsg;
	BOOL	bIsError = FALSE;

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("xy stage gripper down button click") );
	//////////////////////////////////////////////////////////////////////////
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysAutoloaderPos()
{

}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysMachiningPos()
{

}

void CSetupAutoLoaderManualOperDlg::writeLog( LPCTSTR log_msg )
{
	//////////////////////////////////////////////////////////////////////////
	// log 
	WriteLog( CLog::TYPE_OPER, 8, log_msg );
	//////////////////////////////////////////////////////////////////////////
}

//////////////////////////////////////////////////////////////////////////
// 
//////////////////////////////////////////////////////////////////////////

#define SHOW_CONFIRM_DIALOG( msg )															\
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_OKCANCEL, CMsgDlg::ICON_QUEST, msg );	\
	if( CMsgDlgThread::GetInstance()->Wait() == CMsgDlg::RET_CANCEL ) {						\
		return ;																			\
	}																						\
	msg.Format( _T("wait...") );															\
	CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_INFO, msg );		\

#define HIDE_CONFIRM_DIALOG()				\
	CMsgDlgThread::GetInstance()->Hide();	\

#define MOTION_DONE_OR_ERR_CHECK()			\
	while( TRUE ) {							\
		if( theApp.MotionDone(TRUE) ) {		\
			break;							\
		}									\
		if( pa::PPAStatus->GetRunMode() == pa::RUNMODE_ERROR ) {	\
			HIDE_CONFIRM_DIALOG()	\
			return;	\
		}	\
		Sleep(100);	\
	}	\

void CSetupAutoLoaderManualOperDlg::updateManualButton()
{
	((CButton*)GetDlgItem(IDC_BUTTON_STEP_01))->Invalidate(FALSE);	
	((CButton*)GetDlgItem(IDC_BUTTON_STEP_02))->Invalidate(FALSE);	
	((CButton*)GetDlgItem(IDC_BUTTON_STEP_03))->Invalidate(FALSE);	
	((CButton*)GetDlgItem(IDC_BUTTON_STEP_04))->Invalidate(FALSE);	
	((CButton*)GetDlgItem(IDC_BUTTON_STEP_05))->Invalidate(FALSE);	
	((CButton*)GetDlgItem(IDC_BUTTON_STEP_06))->Invalidate(FALSE);	
	((CButton*)GetDlgItem(IDC_BUTTON_STEP_07))->Invalidate(FALSE);	
	((CButton*)GetDlgItem(IDC_BUTTON_STEP_08))->Invalidate(FALSE);	
	((CButton*)GetDlgItem(IDC_BUTTON_STEP_09))->Invalidate(FALSE);	
	((CButton*)GetDlgItem(IDC_BUTTON_STEP_10))->Invalidate(FALSE);	
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep01()
{
	int nBlockNo = cboSelBlockNo_.GetCurSel();
	CString strMsg;

	if( nBlockNo < 0 ) 
	{
		return ;
	}

	strMsg.Format( _T("do you want to moving STEP #01 ?\nget block from cassette (%d)"), nBlockNo+1 );
	SHOW_CONFIRM_DIALOG( strMsg )

	nRecentRun_ManualButton_ = 0;
	updateManualButton();

	//////////////////////////////////////////////////////////////////////////
	// log
	CString strLog;
	strLog.Format( _T("step #01 : get block from cassette (%d)"), nBlockNo+1 );
	writeLog( strLog );
	//////////////////////////////////////////////////////////////////////////

	if (!checkIfValidState(MANUAL_STEP_01)) {
		return;
	}

	PPNC_IPC_CLIENT->ALR_GetBlockFromCassette( nBlockNo+1 );	// M751
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	HIDE_CONFIRM_DIALOG()
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep02()
{
	CString strMsg;

	strMsg.Format( _T("do you want to moving to STEP #02 ?\nmove xy-stage to block load position" ) );
	SHOW_CONFIRM_DIALOG( strMsg )

	nRecentRun_ManualButton_ = 1;
	updateManualButton();

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("step #02 : move xy-stage to block load position") );
	//////////////////////////////////////////////////////////////////////////

	if (!checkIfValidState(MANUAL_STEP_02)) {
		return;
	}

	PPNC_IPC_CLIENT->XYS_MoveBlockLoadPos( 0 );		// Load 위치
	Sleep( 500 );
	MOTION_DONE_OR_ERR_CHECK()

	PPNC_IPC_CLIENT->XYS_Geipper_Ungrip();
	Sleep( 500 );
	MOTION_DONE_OR_ERR_CHECK()

	HIDE_CONFIRM_DIALOG()
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep03()
{
	CString strMsg;
	BOOL	bError = FALSE;

	strMsg.Format( _T("do you want to moving to STEP #03 ?\nextend arm to xy-stage") );
	SHOW_CONFIRM_DIALOG( strMsg )

	nRecentRun_ManualButton_ = 2;
	updateManualButton();

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("step #03 : extend arm to xy-stage") );
	//////////////////////////////////////////////////////////////////////////

	if (!checkIfValidState(MANUAL_STEP_03)) {
		return;
	}

	double	xpos = pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X];
	double	ypos = pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y];
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep04()
{
	CString strMsg;
// 	BOOL	bError = FALSE;

	strMsg.Format( _T("do you want to moving to STEP #04 ?\nreturn arm to cassette") );
	SHOW_CONFIRM_DIALOG( strMsg );

	nRecentRun_ManualButton_ = 3;
	updateManualButton();

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("step #04: return arm to cassette") );
	//////////////////////////////////////////////////////////////////////////

	if (!checkIfValidState(MANUAL_STEP_04)) {
		return;
	}

	//////////////////////////////////////////////////////////////////////////
	// xy-stage hand로 블록을 잡고
	PPNC_IPC_CLIENT->XYS_Gripper_Grip();
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	// autoloader hand를 풀어준다
	PPNC_IPC_CLIENT->ALR_Gripper_Ungrip();
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	//////////////////////////////////////////////////////////////////////////
	// autoloader hand를 cassette 방향으로 돌린다 
	PPNC_IPC_CLIENT->ALR_ReturnArmToAcssette( 0 );	// Load 위치 
	Sleep(500);
	MOTION_DONE_OR_ERR_CHECK()

	HIDE_CONFIRM_DIALOG()
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep05()
{
	CString strMsg;

	strMsg.Format( _T("do you want to moving to STEP #05 ?\nput block to machining position") );
	SHOW_CONFIRM_DIALOG( strMsg );

	nRecentRun_ManualButton_ = 4;
	updateManualButton();

	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("step #05 : put block to machining position") );
	//////////////////////////////////////////////////////////////////////////

	if (!checkIfValidState(MANUAL_STEP_05)) {
		return;
	}

	//////////////////////////////////////////////////////////////////////////
	// xy-stage의 hand가 down 되어 있는지 확인 
// 	if( pa::PPAStatus->GetPAStatus()->bInput[pa::IN20020_AutoLoader_PNC_Gripper_Up] == 0 ) {
// 		strMsg.Format( _T("xy-stage's hand is down ! retry after hand up.") );
// 		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
// 		CMsgDlgThread::GetInstance()->Wait();
// 		return ;
// 	}

	//////////////////////////////////////////////////////////////////////////
	// 가공 룸 ungrip
	PPNC_IPC_CLIENT->BlockClamp( FALSE );
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	//////////////////////////////////////////////////////////////////////////
	// 가공 스테이지에 블록이 있는지 확인 
	//	if( pmac::PState->GetPmacState()->nIn16_DetectedBlock != 0 ) {
// 	if( pa::PPAStatus->GetPAStatus()->bInput[pa::IN20017_DetectedBlock] != 0 ) {
// 		// 블록이 있음 
// 		strMsg.Format( _T("xy-stage have block ! retry after remove block.") );
// 		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
// 		CMsgDlgThread::GetInstance()->Wait();
// 		return ;
// 	}

	//////////////////////////////////////////////////////////////////////////
	// 블록 이송 
	PPNC_IPC_CLIENT->XYS_MoveBlockWorkPos();
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	PPNC_IPC_CLIENT->XYS_Gripper_Donw();
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	PPNC_IPC_CLIENT->XYS_Geipper_Ungrip();
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	PPNC_IPC_CLIENT->XYS_Gripper_Up();
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	//////////////////////////////////////////////////////////////////////////
	// 가공 룸 grip
	PPNC_IPC_CLIENT->BlockClamp( TRUE );
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	HIDE_CONFIRM_DIALOG()
}

// xy-stage의 작업 위치에서 블록을 꺼낸다 
void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep06()
{
	CString strMsg;

	strMsg.Format( _T("do you want to moving to STEP #06 ?\nget block from machining position") );
	SHOW_CONFIRM_DIALOG( strMsg )

	nRecentRun_ManualButton_ = 5;
	updateManualButton();

	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("step #06 : get block from machining position") );
	//////////////////////////////////////////////////////////////////////////

	if (!checkIfValidState(MANUAL_STEP_06)) {
		return;
	}

	//////////////////////////////////////////////////////////////////////////
	// xy-stage의 hand가 down 되어 있는지 확인 
// 	if( pa::PPAStatus->GetPAStatus()->bInput[pa::IN20020_AutoLoader_PNC_Gripper_Up] == 0 ) {
// 		strMsg.Format( _T("xy-stage's hand is down ! retry after hand up.") );
// 		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
// 		CMsgDlgThread::GetInstance()->Wait();
// 		return ;
// 	}

	//////////////////////////////////////////////////////////////////////////
	// 가공 룸 ungrip
	PPNC_IPC_CLIENT->BlockClamp( FALSE );
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	//////////////////////////////////////////////////////////////////////////
	// 가공 스테이지에 블록이 있는지 확인 
	//	if( pmac::PState->GetPmacState()->nIn16_DetectedBlock == 0 ) {
// 	if( pa::PPAStatus->GetPAStatus()->bInput[pa::IN20017_DetectedBlock] == 0 ) {
// 		// 블록이 없음 
// 		strMsg.Format( _T("xy-stage's have not block !") );
// 		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
// 		CMsgDlgThread::GetInstance()->Wait();
// 		return ;
// 	}

	//////////////////////////////////////////////////////////////////////////
	// 블록 이송 
	PPNC_IPC_CLIENT->XYS_Geipper_Ungrip();
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	PPNC_IPC_CLIENT->XYS_MoveBlockWorkPos();
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	PPNC_IPC_CLIENT->XYS_Gripper_Donw();
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	PPNC_IPC_CLIENT->XYS_Gripper_Grip();
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	PPNC_IPC_CLIENT->XYS_Gripper_Up();
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	HIDE_CONFIRM_DIALOG()
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep07()
{
	CString strMsg;

	strMsg.Format( _T("do you want to moving to STEP #07 ?\nmove block to unload position") );
// 	SHOW_CONFIRM_DIALOG( strMsg )
// 
// 	nRecentRun_ManualButton_ = 6;
// 	updateManualButton();
// 
// 	//////////////////////////////////////////////////////////////////////////
// 	// log 
// 	writeLog( _T("step #07 : move block to unload position") );
// 	//////////////////////////////////////////////////////////////////////////
// 
// 	if (!checkIfValidState(MANUAL_STEP_07)) {
// 		return;
// 	}
// 
// 	if( pa::PPAStatus->GetPAStatus()->bInput[pa::IN20020_AutoLoader_PNC_Gripper_Up] == 0 ) {
// 		strMsg.Format( _T("XY-Stage's hand is down") );
// 		writeLog( strMsg );
// 		CMsgDlgThread::GetInstance()->Show( CMsgDlg::TYPE_WAIT, CMsgDlg::ICON_ERROR, strMsg );
// 		CMsgDlgThread::GetInstance()->Wait();
// 		return ;
// 	}
// 
// 	PPNC_IPC_CLIENT->XYS_MoveBlockLoadPos( 1 );		// Unload 위치 
// 	Sleep( 500 );
// 
// 	MOTION_DONE_OR_ERR_CHECK()

//	HIDE_CONFIRM_DIALOG();
}


void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep08()
{
	CString strMsg;
	BOOL	bError = FALSE;

	strMsg.Format( _T("do you want to moving to STEP #08 ?\nextend arm to xy-stage") );
	SHOW_CONFIRM_DIALOG( strMsg )

	nRecentRun_ManualButton_ = 7;
	updateManualButton();

	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("step #08 : extend arm to xy-stage") );
	//////////////////////////////////////////////////////////////////////////

	if (!checkIfValidState(MANUAL_STEP_08)) {
		return;
	}

	double	xpos = pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X];
	double	ypos = pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y];
}


void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep09()
{
	CString strMsg;

	strMsg.Format( _T("do you want to moving to STEP #09 ?\nrotate arm to cassette") );
	SHOW_CONFIRM_DIALOG( strMsg )

	nRecentRun_ManualButton_ = 8;
	updateManualButton();

	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("step #09 : rotate arm to cassette") );
	//////////////////////////////////////////////////////////////////////////

	if (!checkIfValidState(MANUAL_STEP_09)) {
		return;
	}

	//////////////////////////////////////////////////////////////////////////
	// xy-stage hand로 블록을 놓고
	PPNC_IPC_CLIENT->XYS_Geipper_Ungrip();
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()
	
	//////////////////////////////////////////////////////////////////////////
	// autoloader gripper... grip
	PPNC_IPC_CLIENT->ALR_Gripper_Grip();
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	//////////////////////////////////////////////////////////////////////////
	// autoloader hand를 cassette 방향으로 돌린다 

	PPNC_IPC_CLIENT->ALR_ReturnArmToAcssette( 1 );		// Unload 위치 
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	HIDE_CONFIRM_DIALOG()
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonStep10()
{
	int nBlockNo = cboSelBlockNo_.GetCurSel();
	CString strMsg;

	if( nBlockNo < 0 ) {
		return ;
	}

	strMsg.Format( _T("do you want to moving to STEP #10 ?\nput block from cassette (%d)"), nBlockNo+1 );
	SHOW_CONFIRM_DIALOG( strMsg )

	nRecentRun_ManualButton_ = 9;
	updateManualButton();

	//////////////////////////////////////////////////////////////////////////
	// log
	CString strLog;
	strLog.Format( _T("step #10 : put block from cassette (%d)"), nBlockNo+1 );
	writeLog( strLog );
	//////////////////////////////////////////////////////////////////////////

	if (!checkIfValidState(MANUAL_STEP_10)) {
		return;
	}

	PPNC_IPC_CLIENT->ALR_PutBlockToCassette( nBlockNo+1 );
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	HIDE_CONFIRM_DIALOG()
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysMoveExchangingPos()
{
	CString strMsg;

	//////////////////////////////////////////////////////////////////////////
	// log 
	writeLog( _T("exchanging position button click") );
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonXysMoveMachiningPos()
{
	CString strMsg;

	//////////////////////////////////////////////////////////////////////////
	// log
	writeLog( _T("machining position button click") );
	//////////////////////////////////////////////////////////////////////////

}

// 현재 선택된 블럭 번호의 Sensing 위치로 이동 
// M753 
void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonMoveBlockSensingPos()
{
	int nBlockNo = cboSelBlockNo_.GetCurSel();
	CString strMsg;

	if( nBlockNo < 0 ) {
		return ;
	}

	strMsg.Format( _T("do you want to move to block(%d) sensing position ?"), nBlockNo+1 );
	SHOW_CONFIRM_DIALOG( strMsg )

	//////////////////////////////////////////////////////////////////////////
	// log
	CString strLog;
	strLog.Format( _T("move to block(%d) sensing position"), nBlockNo+1 );
	writeLog( strLog );
	//////////////////////////////////////////////////////////////////////////

	PPNC_IPC_CLIENT->ALR_BlockSensingPosition( nBlockNo+1 );
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	HIDE_CONFIRM_DIALOG()
}

// 현재 선택된 블럭 번호의 Barcode 위치로 이동 
// M754 
void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonMoveBarcodeReadPos()
{
	int nBlockNo = cboSelBlockNo_.GetCurSel();
	CString strMsg;

	if( nBlockNo < 0 ) {
		return ;
	}

	strMsg.Format( _T("do you want to move to block(%d) barcode reading position ?"), nBlockNo+1 );
	SHOW_CONFIRM_DIALOG( strMsg )

	//////////////////////////////////////////////////////////////////////////
	// log
	CString strLog;
	strLog.Format( _T("move to block(%d) barcode reading position"), nBlockNo+1 );
	writeLog( strLog );
	//////////////////////////////////////////////////////////////////////////

	PPNC_IPC_CLIENT->ALR_BlockBarcodeReadPosition( nBlockNo+1 );
	Sleep( 500 );

	MOTION_DONE_OR_ERR_CHECK()

	HIDE_CONFIRM_DIALOG()
}

// 현재 위치에서 버코드를 읽어서 Edit에 출력 한다 
void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonAlBarcode()
{
	CString strMsg;

	strMsg.Format( _T("do you want to read barcode data ?") );
	SHOW_CONFIRM_DIALOG( strMsg )

	//////////////////////////////////////////////////////////////////////////
	// 
	PPNC_IPC_CLIENT->ALR_ReadBarcode();

	HIDE_CONFIRM_DIALOG()
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonBlockClamp()
{
	PPNC_IPC_CLIENT->BlockClamp( TRUE );
}

void CSetupAutoLoaderManualOperDlg::OnBnClickedButtonBlockUnclamp()
{
	PPNC_IPC_CLIENT->BlockClamp( FALSE );
}

BOOL CSetupAutoLoaderManualOperDlg::checkIfValidState(MANUAL_STEP manualStep)
{
// 	BOOL AutoLoader_ROT_ARM_ToCassette = pa::PPAStatus->GetPAStatus()->bInput[pa::IN20029_AutoLoader_ROT_ARM_ToCassette];
// 	BOOL AutoLoader_RET_ARM = pa::PPAStatus->GetPAStatus()->bInput[pa::IN20024_AutoLoader_RET_ARM];
// 	BOOL AutoLoader_Sensing_Block = pa::PPAStatus->GetPAStatus()->bInput[pa::IN20028_AutoLoader_Sensing_Block];
// 	BOOL AutoLoader_PNC_Sensing_Item = pa::PPAStatus->GetPAStatus()->bInput[pa::IN20016_AutoLoader_PNC_Sensing_Item];
// 	BOOL AutoLoader_PNC_Gripper_Up = pa::PPAStatus->GetPAStatus()->bInput[pa::IN20020_AutoLoader_PNC_Gripper_Up];
// 	BOOL AutoLoader_PNC_Gripper_Ungrip = pa::PPAStatus->GetPAStatus()->bInput[pa::IN20019_AutoLoader_PNC_Gripper_Ungrip];
// 	BOOL DetectedBlock = pa::PPAStatus->GetPAStatus()->bInput[pa::IN20017_DetectedBlock];
// 
// 	CString strMsg;
// 
// 	switch (manualStep) {
// 		case MANUAL_STEP_01:
// 			// TODO: refactor this
// 			if (!AutoLoader_ROT_ARM_ToCassette) {
// 				strMsg = getManualErrorMessage(AL_HAND_FACE_WORKSPACE);
// 			} else if (!AutoLoader_RET_ARM) {
// 				strMsg = getManualErrorMessage(AL_HAND_FORWARD);
// 			} else if (AutoLoader_Sensing_Block) {
// 				strMsg = getManualErrorMessage(AL_HAND_SENSING_ITEM);
// 			} else {
// 				return TRUE;
// 			}
// 			break;
// 		case MANUAL_STEP_02:
// 			if (AutoLoader_PNC_Sensing_Item) {
// 				strMsg = getManualErrorMessage(XY_GRIPPER_SENSING_ITEM);
// 			} else if (!AutoLoader_PNC_Gripper_Up) {
// 				strMsg = getManualErrorMessage(XY_GRIPPER_DOWN);
// 			} else {
// 				return TRUE;
// 			}
// 			break;
// 		case MANUAL_STEP_03: {
// 			double	xpos = pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X];
// 			double	ypos = pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y];
// // 			double	fx = fabs( xpos - pa::PSWConfig->GetConfigData()->fTeachingPoint[pa::TEACHING_POINT_BLOCK_LOADER][pa::AXIS_X] );
// // 			double	fy = fabs( ypos - pa::PSWConfig->GetConfigData()->fTeachingPoint[pa::TEACHING_POINT_BLOCK_LOADER][pa::AXIS_Y] );
// // 
// // 			BOOL XYGripperReady = fx < 1.0 && fy < 1.0;
// // 
// // 			if (!XYGripperReady) {
// // 				strMsg = getManualErrorMessage(XY_GRIPPER_NOT_IN_EXCHANGE_POSITION);
// // 			} else if (!AutoLoader_ROT_ARM_ToCassette) {
// // 				strMsg = getManualErrorMessage(AL_HAND_FACE_WORKSPACE);
// // 			} else if (!AutoLoader_RET_ARM) {
// // 				strMsg = getManualErrorMessage(AL_HAND_FORWARD);
// // 			} else if (!AutoLoader_Sensing_Block) {
// // 				strMsg = getManualErrorMessage(AL_HAND_NOT_SENSING_ITEM);
// // 			} else if (!AutoLoader_PNC_Gripper_Ungrip) {
// // 				strMsg = getManualErrorMessage(XY_GRIPPER_GRIP);
// // 			} else if (AutoLoader_PNC_Sensing_Item) {
// // 				strMsg = getManualErrorMessage(XY_GRIPPER_SENSING_ITEM);
// // 			} else {
// // 				return TRUE;
// // 			}
// // 			break;
// 		}
// 		case MANUAL_STEP_04:
// 			if ( AutoLoader_RET_ARM) {
// 				strMsg = getManualErrorMessage(AL_HAND_BACKWARD);
// 			} else if (!AutoLoader_PNC_Gripper_Up) {
// 				strMsg = getManualErrorMessage(XY_GRIPPER_DOWN);
// 			} else if (!AutoLoader_Sensing_Block) {
// 				strMsg = getManualErrorMessage(AL_HAND_NOT_SENSING_ITEM);
// 			} else if (!AutoLoader_PNC_Sensing_Item) {
// 				strMsg = getManualErrorMessage(XY_GRIPPER_NOT_SENSING_ITEM);
// 			} else {
// 				return TRUE;
// 			}
// 			break;
// 		case MANUAL_STEP_05:
// 			if (!AutoLoader_PNC_Sensing_Item) {
// 				strMsg = getManualErrorMessage(XY_GRIPPER_NOT_SENSING_ITEM);
// 			} else if (!AutoLoader_PNC_Gripper_Up) {
// 				strMsg = getManualErrorMessage(XY_GRIPPER_DOWN);
// 			} else if (DetectedBlock) {
// 				strMsg = getManualErrorMessage(WS_SENSING_ITEM);
// 			} else {
// 				return TRUE;
// 			}
// 			break;
// 		case MANUAL_STEP_06:
// 			if (!DetectedBlock) {
// 				strMsg = getManualErrorMessage(WS_NOT_SENSING_ITEM);
// 			} else if (AutoLoader_PNC_Sensing_Item) {
// 				strMsg = getManualErrorMessage(XY_GRIPPER_SENSING_ITEM);
// 			} else if (!AutoLoader_PNC_Gripper_Up) {
// 				strMsg = getManualErrorMessage(XY_GRIPPER_DOWN);
// 			} else {
// 				return TRUE;
// 			}
// 			break;
// 		case MANUAL_STEP_07:
// 			if (!AutoLoader_PNC_Sensing_Item) {
// 				strMsg = getManualErrorMessage(XY_GRIPPER_NOT_SENSING_ITEM);
// 			} else if (!AutoLoader_PNC_Gripper_Up) {
// 				strMsg = getManualErrorMessage(XY_GRIPPER_DOWN);
// 			} else {
// 				return TRUE;
// 			}
// 			break;
// 		case MANUAL_STEP_08: {
// 			double	xpos = pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_X];
// 			double	ypos = pa::PPAStatus->GetPAStatus()->fPosition[pa::AXIS_Y];
// // 			double	fx = fabs( xpos - pa::PSWConfig->GetConfigData()->fTeachingPoint[pa::TEACHING_POINT_BLOCK_UNLOADER][pa::AXIS_X] );
// // 			double	fy = fabs( ypos - pa::PSWConfig->GetConfigData()->fTeachingPoint[pa::TEACHING_POINT_BLOCK_UNLOADER][pa::AXIS_Y] );
// 
// // 			BOOL XYGripperReady = fx < 1.0 && fy < 1.0;
// // 
// // 			if (!XYGripperReady) {
// // 				strMsg = getManualErrorMessage(XY_GRIPPER_NOT_IN_EXCHANGE_POSITION);
// // 			} else if (!AutoLoader_ROT_ARM_ToCassette) {
// // 				strMsg = getManualErrorMessage(AL_HAND_FACE_WORKSPACE);
// // 			} else if (!AutoLoader_RET_ARM) {
// // 				strMsg = getManualErrorMessage(AL_HAND_FORWARD);
// // 			} else if (AutoLoader_Sensing_Block) {
// // 				strMsg = getManualErrorMessage(AL_HAND_SENSING_ITEM);
// // 			} else {
// // 				return TRUE;
// // 			}
// // 			break;
// 		}
// 		case MANUAL_STEP_09:
// 			if ( AutoLoader_RET_ARM) {
// 				strMsg = getManualErrorMessage(AL_HAND_BACKWARD);
// 			} else if (!AutoLoader_PNC_Sensing_Item) {
// 				strMsg = getManualErrorMessage(XY_GRIPPER_NOT_SENSING_ITEM);
// 			} else if (!AutoLoader_PNC_Gripper_Up) {
// 				strMsg = getManualErrorMessage(XY_GRIPPER_DOWN);
// 			} else if (AutoLoader_Sensing_Block) {
// 				strMsg = getManualErrorMessage(AL_HAND_SENSING_ITEM);
// 			} else {
// 				return TRUE;
// 			}
// 			break;
// 		case MANUAL_STEP_10:
// 			if (!AutoLoader_ROT_ARM_ToCassette) {
// 				strMsg = getManualErrorMessage(AL_HAND_FACE_WORKSPACE);
// 			} else if (!AutoLoader_RET_ARM) {
// 				strMsg = getManualErrorMessage(AL_HAND_FORWARD);
// 			} else if (!AutoLoader_Sensing_Block) {
// 				strMsg = getManualErrorMessage(AL_HAND_NOT_SENSING_ITEM);
// 			} else {
// 				return TRUE;
// 			}
// 			break;
// 	}
// 
// 	P_LOG->WriteLog_EXT( strMsg );
// 	CMsgDlgThread::GetInstance()->Show(CMsgDlg::TYPE_CLOSE, CMsgDlg::ICON_ERROR, strMsg );
// 	CMsgDlgThread::GetInstance()->Wait();
// 
 	return FALSE;
}

CString CSetupAutoLoaderManualOperDlg::getManualErrorMessage(MANUAL_STEP_ERR manualStepErr)
{
	CString errMsg;
	switch (manualStepErr) {
		case AL_HAND_FACE_CASSETTE:
			return CString(_T("AutoLoader hand is facing the cassette. Please check orientation of the hand."));
		case AL_HAND_FACE_WORKSPACE:
			return CString(_T("AutoLoader hand is facing the workspace. Please check orientation of the hand."));
		case AL_HAND_FORWARD:
			return CString(_T("AutoLoader hand is at the forward position. Please pull in the hand before proceeding."));
		case AL_HAND_BACKWARD:
			return CString(_T("AutoLoader hand is at the backward position. Please pull out the hand before proceeding."));
		case AL_HAND_SENSING_ITEM:
			return CString(_T("There is an item inside the AutoLoader hand. Please clear the item before proceeding."));
		case AL_HAND_NOT_SENSING_ITEM:
			return CString(_T("There is no item inside the AutoLoader hand. Please get the item before proceeding."));

		case XY_GRIPPER_SENSING_ITEM:
			return CString(_T("There is an item inside the XY Gripper. Please clear the item before proceeding."));
		case XY_GRIPPER_NOT_SENSING_ITEM:
			return CString(_T("There is no item inside the XY Gripper. Please get the item before proceeding."));
		case XY_GRIPPER_UP:
			return CString(_T("XY gripper is in its UP position. Please check the state of the grippper before proceeding."));
		case XY_GRIPPER_DOWN:
			return CString(_T("XY gripper is in its DOWN position. Please check the state of the grippper before proceeding."));
		case XY_GRIPPER_GRIP:
			return CString(_T("XY gripper is in its GRIP position. Please UNGRIP the grippper before proceeding."));
		case XY_GRIPPER_UNGRIP:
			return CString(_T("XY gripper is in its UNGRIP position. Please GRIP the grippper before proceeding."));
		case XY_GRIPPER_NOT_IN_EXCHANGE_POSITION:
			return CString(_T("XY gripper is not at the exchange position. Please check the position of the grippper before proceeding."));

		case WS_SENSING_ITEM:
			return CString(_T("There is an item inside the Work Space. Please clear the item before proceeding."));
		case WS_NOT_SENSING_ITEM:
			return CString(_T("There is no item inside the Work Space. Please get the item before proceeding."));
	}

	return CString(_T("Unknown Error"));
}
